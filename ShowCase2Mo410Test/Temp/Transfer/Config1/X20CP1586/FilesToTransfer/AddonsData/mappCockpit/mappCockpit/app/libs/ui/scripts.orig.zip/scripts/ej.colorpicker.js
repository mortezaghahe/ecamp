﻿/*!
*  filename: ej.colorpicker.js
*  version : 16.4.0.52
*  Copyright Syncfusion Inc. 2001 - 2019. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
*/


window.ej = window.Syncfusion = window.Syncfusion || {};


(function ($, ej, undefined) {
    'use strict';

    ej.version = "16.4.0.52";

    ej.consts = {
        NamespaceJoin: '-'
    };
    ej.TextAlign = {
        Center: 'center',
        Justify: 'justify',
        Left: 'left',
        Right: 'right'
    };
    ej.Orientation = { Horizontal: "horizontal", Vertical: "vertical" };

    ej.serverTimezoneOffset = 0;

    ej.parseDateInUTC = false;

    ej.persistStateVersion = null;

    ej.locales = ej.locales || [];

    if (!Object.prototype.hasOwnProperty) {
        Object.prototype.hasOwnProperty = function (obj, prop) {
            return obj[prop] !== undefined;
        };
    }

    //to support toISOString() in IE8
    if (!Date.prototype.toISOString) {
        (function () {
            function pad(number) {
                var r = String(number);
                if (r.length === 1) {
                    r = '0' + r;
                }
                return r;
            }
            Date.prototype.toISOString = function () {
                return this.getUTCFullYear()
                    + '-' + pad(this.getUTCMonth() + 1)
                    + '-' + pad(this.getUTCDate())
                    + 'T' + pad(this.getUTCHours())
                    + ':' + pad(this.getUTCMinutes())
                    + ':' + pad(this.getUTCSeconds())
                    + '.' + String((this.getUTCMilliseconds() / 1000).toFixed(3)).slice(2, 5)
                    + 'Z';
            };
        }());
    }

    String.format = function () {
        var source = arguments[0];
        for (var i = 0; i < arguments.length - 1; i++)
            source = source.replace(new RegExp("\\{" + i + "\\}", "gm"), arguments[i + 1]);

        source = source.replace(/\{[0-9]\}/g, "");
        return source;
    };

    jQuery.uaMatch = function (ua) {
        ua = ua.toLowerCase();

        var match = /(chrome)[ \/]([\w.]+)/.exec(ua) ||
            /(webkit)[ \/]([\w.]+)/.exec(ua) ||
            /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua) ||
            /(msie) ([\w.]+)/.exec(ua) ||
            ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua) ||
            [];

        return {
            browser: match[1] || "",
            version: match[2] || "0"
        };
    };
    // Function to create new class
    ej.defineClass = function (className, constructor, proto, replace) {
        /// <summary>Creates the javascript class with given namespace & class name & constructor etc</summary>
        /// <param name="className" type="String">class name prefixed with namespace</param>
        /// <param name="constructor" type="Function">constructor function</param>
        /// <param name="proto" type="Object">prototype for the class</param>
        /// <param name="replace" type="Boolean">[Optional]Replace existing class if exists</param>
        /// <returns type="Function">returns the class function</returns>
        if (!className || !proto) return undefined;

        var parts = className.split(".");

        // Object creation
        var obj = window, i = 0;
        for (; i < parts.length - 1; i++) {

            if (ej.isNullOrUndefined(obj[parts[i]]))
                obj[parts[i]] = {};

            obj = obj[parts[i]];
        }

        if (replace || ej.isNullOrUndefined(obj[parts[i]])) {

            //constructor
            constructor = typeof constructor === "function" ? constructor : function () {
            };

            obj[parts[i]] = constructor;

            // prototype
            obj[parts[i]].prototype = proto;
        }

        return obj[parts[i]];
    };

    ej.util = {
        getNameSpace: function (className) {
            /// <summary>Internal function, this will create namespace for plugins using class name</summary>
            /// <param name="className" type="String"></param>
            /// <returns type="String"></returns>
            var splits = className.toLowerCase().split(".");
            splits[0] === "ej" && (splits[0] = "e");

            return splits.join(ej.consts.NamespaceJoin);
        },

        getObject: function (nameSpace, from) {
            if (!from || !nameSpace) return undefined;
			(typeof(nameSpace) != "string") && (nameSpace = JSON.stringify(nameSpace));
            var value = from, splits = nameSpace.split('.');

            for (var i = 0; i < splits.length; i++) {

                if (ej.util.isNullOrUndefined(value)) break;

                value = value[splits[i]];
            }

            return value;
        },

        createObject: function (nameSpace, value, initIn) {
            var splits = nameSpace.split('.'), start = initIn || window, from = start, i, t, length = splits.length;

            for (i = 0; i < length; i++) {
                t = splits[i];
                if (i + 1 == length)
                    from[t] = value;
                else if (ej.isNullOrUndefined(from[t]))
                    from[t] = {};

                from = from[t];
            }

            return start;
        },

        isNullOrUndefined: function (value) {
            /// <summary>Util to check null or undefined</summary>
            /// <param name="value" type="Object"></param>
            /// <returns type="Boolean"></returns>
            return value === undefined || value === null;
        },
        exportAll: function (action, controlIds) {
            var inputAttr = [], widget, locale = [], index, controlEle, controlInstance, controlObject, modelClone;
            var attr = { action: action, method: 'post', "data-ajax": "false" };
            var form = ej.buildTag('form', "", null, attr);
            if (controlIds.length != 0) {
                for (var i = 0; i < controlIds.length; i++) {
                    index = i;
                    controlEle = $("#" + controlIds[i]);
                    controlInstance = $("#" + controlIds[i]).data();
                    widget = controlInstance["ejWidgets"];
                    controlObject = $(controlEle).data(widget[0]);
                    locale.push({ id: controlObject._id, locale: controlObject.model.locale });
                    if (!ej.isNullOrUndefined(controlObject)) {
                        modelClone = controlObject._getExportModel(controlObject.model);
                        inputAttr.push({ name: widget[0], type: 'hidden', value: controlObject.stringify(modelClone) });
                        var input = ej.buildTag('input', "", null, inputAttr[index]);
                        form.append(input);
                    }
                }
                $('body').append(form);
                form.submit();
                setTimeout(function () {
                    var ctrlInstance, ctrlObject;
                    if (locale.length) {
                        for (var j = 0; j < locale.length; j++) {
                            if (!ej.isNullOrUndefined(locale[j].locale)) {
                                ctrlInstance = $("#" + locale[j].id).data();
                                widget = ctrlInstance["ejWidgets"];
                                ctrlObject = $("#" + locale[j].id).data(widget[0]);
                                ctrlObject.model.locale = locale[j].locale;
                            }
                        }
                    }
                }, 0);
                form.remove();
            }
            return true;
        },
        print: function (element, printWin) {
            var $div = ej.buildTag('div')
            var elementClone = element.clone();
            $div.append(elementClone);
            if (!printWin)
                var printWin = window.open('', 'print', "height=452,width=1024,tabbar=no");
            printWin.document.write('<!DOCTYPE html>');
            var links = $('head').find('link').add("style");
            if (ej.browserInfo().name === "msie") {
                var a = ""
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.write('<html><head></head><body>' + a + $div[0].innerHTML + '</body></html>');
            }
            else {
                var a = ""
                printWin.document.write('<html><head>')
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.writeln(a + '</head><body>')
                printWin.document.writeln($div[0].innerHTML + '</body></html>')
            }
            printWin.document.close();
            printWin.focus();
            setTimeout(function () {
                if (!ej.isNullOrUndefined(printWin.window)) {
                    printWin.print();
                    setTimeout(function () { printWin.close() }, 1000);
                }
            }, 1000);
        },
        ieClearRemover: function (element) {
            var searchBoxHeight = $(element).height();
            element.style.paddingTop = parseFloat(searchBoxHeight / 2) + "px";
            element.style.paddingBottom = parseFloat(searchBoxHeight / 2) + "px";
            element.style.height = "1px";
            element.style.lineHeight = "1px";
        },
        //To send ajax request
        sendAjaxRequest: function (ajaxOptions) {
            $.ajax({
                type: ajaxOptions.type,
                cache: ajaxOptions.cache,
                url: ajaxOptions.url,
                dataType: ajaxOptions.dataType,
                data: ajaxOptions.data,
                contentType: ajaxOptions.contentType,
                async: ajaxOptions.async,
                success: ajaxOptions.successHandler,
                error: ajaxOptions.errorHandler,
                beforeSend: ajaxOptions.beforeSendHandler,
                complete: ajaxOptions.completeHandler
            });
        },

        buildTag: function (tag, innerHtml, styles, attrs) {
            /// <summary>Helper to build jQuery element</summary>
            /// <param name="tag" type="String">tagName#id.cssClass</param>
            /// <param name="innerHtml" type="String"></param>
            /// <param name="styles" type="Object">A set of key/value pairs that configure styles</param>
            /// <param name="attrs" type="Object">A set of key/value pairs that configure attributes</param>
            /// <returns type="jQuery"></returns>
            var tagName = /^[a-z]*[0-9a-z]+/ig.exec(tag)[0];

           var id = /#([_a-z0-9-&@\/\\,+()$~%:*?<>{}\[\]]+\S)/ig.exec(tag);
            id = id ? id[id.length - 1].replace(/[&@\/\\,+()$~%.:*?<>{}\[\]]/g, ''): undefined;

            var className = /\.([a-z]+[-_0-9a-z ]+)/ig.exec(tag);
            className = className ? className[className.length - 1] : undefined;

            return $(document.createElement(tagName))
                .attr(id ? { "id": id } : {})
                .addClass(className || "")
                .css(styles || {})
                .attr(attrs || {})
                .html(innerHtml || "");
        },
        _preventDefaultException: function (el, exceptions) {
            if (el) {
                for (var i in exceptions) {
                    if (exceptions[i].test(el[i])) {
                        return true;
                    }
                }
            }

            return false;
        },

        //Gets the maximum z-index in the document
        getMaxZindex: function () {
            var maxZ = 1;
            maxZ = Math.max.apply(null, $.map($('body *'), function (e, n) {
                if ($(e).css('position') == 'absolute' || $(e).css('position') == 'fixed')
                    return parseInt($(e).css('z-index')) || 1;
            })
            );
            if (maxZ == undefined || maxZ == null)
                maxZ = 1;
            return maxZ;
        },

        //To prevent default actions for the element
        blockDefaultActions: function (e) {
            e.cancelBubble = true;
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
            if (e.stopPropagation) e.stopPropagation();
        },

        //To get dimensions of the element when its hidden
        getDimension: function (element, method) {
            var value;
            var $hidden = $(element).parents().andSelf().filter(':hidden');
            if ($hidden) {
                var prop = { visibility: 'hidden', display: 'block' };
                var tmp = [];
                $hidden.each(function () {
                    var temp = {}, name;
                    for (name in prop) {
                        temp[name] = this.style[name];
                        this.style[name] = prop[name];
                    }
                    tmp.push(temp);
                });
                value = /(outer)/g.test(method) ?
                $(element)[method](true) :
               $(element)[method]();

                $hidden.each(function (i) {
                    var temp = tmp[i], name;
                    for (name in prop) {
                        this.style[name] = temp[name];
                    }
                });
            }
            return value;
        },
        //Get triggers when transition End
        transitionEndEvent: function () {
            var transitionEnd = {
                '': 'transitionend',
                'webkit': 'webkitTransitionEnd',
                'Moz': 'transitionend',
                'O': 'otransitionend',
                'ms': 'MSTransitionEnd'
            };

            return transitionEnd[ej.userAgent()];
        },
        //Get triggers when transition End
        animationEndEvent: function () {
            var animationEnd = {
                '': 'animationend',
                'webkit': 'webkitAnimationEnd',
                'Moz': 'animationend',
                'O': 'webkitAnimationEnd',
                'ms': 'animationend'
            };

            return animationEnd[ej.userAgent()];
        },
        //To return the start event to bind for element
        startEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchstart" : "mousedown";
        },
        //To return end event to bind for element
        endEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchend" : "mouseup"
        },
        //To return move event to bind for element
        moveEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? ($.support.hasPointer && !ej.isMobile()) ? "ejtouchmove" : "touchmove" : "mousemove";
        },
        //To return cancel event to bind for element
        cancelEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchcancel" : "mousecancel";
        },
        //To return tap event to bind for element
        tapEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "tap" : "click";
        },
        //To return tap hold event to bind for element
        tapHoldEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "taphold" : "click";
        },
        //To check whether its Device
        isDevice: function () {
            if (ej.getBooleanVal($('head'), 'data-ej-forceset', false))
                return ej.getBooleanVal($('head'), 'data-ej-device', this._device());
            else
                return this._device();
        },
        //To check whether its portrait or landscape mode
        isPortrait: function () {
            var elem = document.documentElement;
            return (elem) && ((elem.clientWidth / elem.clientHeight) < 1.1);
        },
        //To check whether its in lower resolution
        isLowerResolution: function () {
            return ((window.innerWidth <= 640 && ej.isPortrait() && ej.isDevice()) || (window.innerWidth <= 800 && !ej.isDevice()) || (window.innerWidth <= 800 && !ej.isPortrait() && ej.isWindows() && ej.isDevice()) || ej.isMobile());
        },
        //To check whether its iOS web view
        isIOSWebView: function () {
            return (/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(navigator.userAgent));
        },
        //To check whether its Android web view
        isAndroidWebView: function () {
            return (!(typeof (Android) === "undefined"));
        },
        //To check whether its windows web view
        isWindowsWebView: function () {
            return location.href.indexOf("x-wmapp") != -1;
        },
        _device: function () {
            return (/Android|BlackBerry|iPhone|iPad|iPod|IEMobile|kindle|windows\sce|palm|smartphone|iemobile|mobile|pad|xoom|sch-i800|playbook/i.test(navigator.userAgent.toLowerCase()));
        },
        //To check whether its Mobile
        isMobile: function () {
            return ((/iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/i.test(navigator.userAgent.toLowerCase()) && /mobile/i.test(navigator.userAgent.toLowerCase()))) || (ej.getBooleanVal($('head'), 'data-ej-mobile', false) === true);
        },
        //To check whether its Tablet
        isTablet: function () {
            return (/ipad|xoom|sch-i800|playbook|tablet|kindle/i.test(navigator.userAgent.toLowerCase())) || (ej.getBooleanVal($('head'), 'data-ej-tablet', false) === true) || (!ej.isMobile() && ej.isDevice());
        },
        //To check whether its Touch Device
        isTouchDevice: function () {
            return (('ontouchstart' in window || (window.navigator.msPointerEnabled && ej.isMobile())) && this.isDevice());
        },
        //To get the outerHTML string for object
        getClearString: function (string) {
            return $.trim(string.replace(/\s+/g, " ").replace(/(\r\n|\n|\r)/gm, "").replace(new RegExp("\>[\n\t ]+\<", "g"), "><"));
        },
        //Get the attribute value with boolean type of element
        getBooleanVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value.toLowerCase() == "true";
            else
                return option;
        },
        //Gets the Skew class based on the element current position
        _getSkewClass: function (item, pageX, pageY) {
            var itemwidth = item.width();
            var itemheight = item.height();
            var leftOffset = item.offset().left;
            var rightOffset = item.offset().left + itemwidth;
            var topOffset = item.offset().top;
            var bottomOffset = item.offset().top + itemheight;
            var widthoffset = itemwidth * 0.3;
            var heightoffset = itemheight * 0.3;
            if (pageX < leftOffset + widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topleft";
            if (pageX > rightOffset - widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topright";
            if (pageX > rightOffset - widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomright";
            if (pageX < leftOffset + widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomleft";
            if (pageX > leftOffset + widthoffset && pageY < topOffset + heightoffset && pageX < rightOffset - widthoffset)
                return "e-m-skew-top";
            if (pageX < leftOffset + widthoffset)
                return "e-m-skew-left";
            if (pageX > rightOffset - widthoffset)
                return "e-m-skew-right";
            if (pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottom";
            return "e-m-skew-center";
        },
        //Removes the added Skew class on the element
        _removeSkewClass: function (element) {
            $(element).removeClass("e-m-skew-top e-m-skew-bottom e-m-skew-left e-m-skew-right e-m-skew-topleft e-m-skew-topright e-m-skew-bottomleft e-m-skew-bottomright e-m-skew-center e-skew-top e-skew-bottom e-skew-left e-skew-right e-skew-topleft e-skew-topright e-skew-bottomleft e-skew-bottomright e-skew-center");
        },
        //Object.keys  method to support all the browser including IE8.
        _getObjectKeys: function (obj) {
            var i, keys = [];
            obj = Object.prototype.toString.call(obj) === Object.prototype.toString() ? obj : {};
            if (!Object.keys) {
                for (i in obj) {
                    if (obj.hasOwnProperty(i))
                        keys.push(i);
                }
                return keys;
            }
            if (Object.keys)
                return Object.keys(obj);
        },
        _touchStartPoints: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt;
                object._distX = 0;
                object._distY = 0;
                object._moved = false;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
            }
        },
        _isTouchMoved: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt,
                deltaX = point.pageX - object._pointX,
                deltaY = point.pageY - object._pointY,
                timestamp = Date.now(),
                newX, newY,
                absDistX, absDistY;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
                object._distX += deltaX;
                object._distY += deltaY;
                absDistX = Math.abs(object._distX);
                absDistY = Math.abs(object._distY);
                return !(absDistX < 5 && absDistY < 5);
            }
        },
        //To bind events for element
        listenEvents: function (selectors, eventTypes, handlers, remove, pluginObj, disableMouse) {
            for (var i = 0; i < selectors.length; i++) {
                ej.listenTouchEvent(selectors[i], eventTypes[i], handlers[i], remove, pluginObj, disableMouse);
            }
        },
        //To bind touch events for element
        listenTouchEvent: function (selector, eventType, handler, remove, pluginObj, disableMouse) {
            var event = remove ? "removeEventListener" : "addEventListener";
            var jqueryEvent = remove ? "off" : "on";
            var elements = $(selector);
            for (var i = 0; i < elements.length; i++) {
                var element = elements[i];
                switch (eventType) {
                    case "touchstart":
                        ej._bindEvent(element, event, eventType, handler, "mousedown", "MSPointerDown", "pointerdown", disableMouse);
                        break;
                    case "touchmove":
                        ej._bindEvent(element, event, eventType, handler, "mousemove", "MSPointerMove", "pointermove", disableMouse);
                        break;
                    case "touchend":
                        ej._bindEvent(element, event, eventType, handler, "mouseup", "MSPointerUp", "pointerup", disableMouse);
                        break;
                    case "touchcancel":
                        ej._bindEvent(element, event, eventType, handler, "mousecancel", "MSPointerCancel", "pointercancel", disableMouse);
                        break;
                    case "tap": case "taphold": case "ejtouchmove": case "click":
                        $(element)[jqueryEvent](eventType, handler);
                        break;
                    default:
                        if (ej.browserInfo().name == "msie" && ej.browserInfo().version < 9)
                            pluginObj["_on"]($(element), eventType, handler);
                        else
                            element[event](eventType, handler, true);
                        break;
                }
            }
        },
        //To bind events for element
        _bindEvent: function (element, event, eventType, handler, mouseEvent, pointerEvent, ie11pointerEvent, disableMouse) {
            if ($.support.hasPointer)
                element[event](window.navigator.pointerEnabled ? ie11pointerEvent : pointerEvent, handler, true);
            else
                element[event](eventType, handler, true);
        },
        _browser: function () {
            return (/webkit/i).test(navigator.appVersion) ? 'webkit' : (/firefox/i).test(navigator.userAgent) ? 'Moz' : (/trident/i).test(navigator.userAgent) ? 'ms' : 'opera' in window ? 'O' : '';
        },
        styles: document.createElement('div').style,
        /**
       * To get the userAgent Name     
       * @example             
       * &lt;script&gt;
       *       ej.userAgent();//return user agent name
       * &lt;/script&gt         
       * @memberof AppView
       * @instance
       */
        userAgent: function () {
            var agents = 'webkitT,t,MozT,msT,OT'.split(','),
            t,
            i = 0,
            l = agents.length;

            for (; i < l; i++) {
                t = agents[i] + 'ransform';
                if (t in ej.styles) {
                    return agents[i].substr(0, agents[i].length - 1);
                }
            }

            return false;
        },
        addPrefix: function (style) {
            if (ej.userAgent() === '') return style;

            style = style.charAt(0).toUpperCase() + style.substr(1);
            return ej.userAgent() + style;
        },
        //To Prevent Default Exception

        //To destroy the mobile widgets
        destroyWidgets: function (element) {
            var dataEl = $(element).find("[data-role *= ejm]");
            dataEl.each(function (index, element) {
                var $element = $(element);
                var plugin = $element.data("ejWidgets");
                if (plugin)
                    $element[plugin]("destroy");
            });
        },
        //Get the attribute value of element
        getAttrVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value;
            else
                return option;
        },

        // Get the offset value of element
        getOffset: function (ele) {
            var pos = {};
            var offsetObj = ele.offset() || { left: 0, top: 0 };
            $.extend(true, pos, offsetObj);
            if ($("body").css("position") != "static") {
                var bodyPos = $("body").offset();
                pos.left -= bodyPos.left;
                pos.top -= bodyPos.top;
            }
            return pos;
        },

        // Z-index calculation for the element
        getZindexPartial: function (element, popupEle) {
            if (!ej.isNullOrUndefined(element) && element.length > 0) {
                var parents = element.parents(), bodyEle;
                bodyEle = $('body').children();
                if (!ej.isNullOrUndefined(element) && element.length > 0)
                    bodyEle.splice(bodyEle.index(popupEle), 1);
                $(bodyEle).each(function (i, ele) { parents.push(ele); });

                var maxZ = Math.max.apply(maxZ, $.map(parents, function (e, n) {
                    if ($(e).css('position') != 'static') return parseInt($(e).css('z-index')) || 1;
                }));
                if (!maxZ || maxZ < 10000) maxZ = 10000;
                else maxZ += 1;
                return maxZ;
            }
        },

        isValidAttr: function (element, attribute) {
            var element = $(element)[0];
            if (typeof element[attribute] != "undefined")
                return true;
            else {
                var _isValid = false;
                $.each(element, function (key) {
                    if (key.toLowerCase() == attribute.toLowerCase()) {
                        _isValid = true;
                        return false;
                    }
                });
            }
            return _isValid;
        }

    };

    $.extend(ej, ej.util);

    // base class for all ej widgets. It will automatically inhertied
    ej.widgetBase = {
        droppables: { 'default': [] },
        resizables: { 'default': [] },

        _renderEjTemplate: function (selector, data, index, prop, ngTemplateType) {
            var type = null;
            if (typeof selector === "object" || selector.startsWith("#") || selector.startsWith("."))
                type = $(selector).attr("type");
            if (type) {
                type = type.toLowerCase();
                if (ej.template[type])
                    return ej.template[type](this, selector, data, index, prop);
            }
            // For ejGrid Angular2 Template Support
            else if (!ej.isNullOrUndefined(ngTemplateType))
                 return ej.template['text/x-'+ ngTemplateType](this, selector, data, index, prop);
            return ej.template.render(this, selector, data, index, prop);
        },

        destroy: function () {

            if (this._trigger("destroy"))
                return;

            if (this.model.enablePersistence) {
                this.persistState();
                $(window).off("unload", this._persistHandler);
            }

            try {
                this._destroy();
            } catch (e) { }

            var arr = this.element.data("ejWidgets") || [];
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] == this.pluginName) {
                    arr.splice(i, 1);
                }
            }
            if (!arr.length)
                this.element.removeData("ejWidgets");

            while (this._events) {
                var item = this._events.pop(), args = [];

                if (!item)
                    break;

                for (var i = 0; i < item[1].length; i++)
                    if (!$.isPlainObject(item[1][i]))
                        args.push(item[1][i]);

                $.fn.off.apply(item[0], args);
            }

            this._events = null;

            this.element
                .removeClass(ej.util.getNameSpace(this.sfType))
                .removeClass("e-js")
                .removeData(this.pluginName);

            this.element = null;
            this.model = null;
        },

        _on: function (element) {
            if (!this._events)
                this._events = [];
            var args = [].splice.call(arguments, 1, arguments.length - 1);

            var handler = {}, i = args.length;
            while (handler && typeof handler !== "function") {
                handler = args[--i];
            }

            args[i] = ej.proxy(args[i], this);

            this._events.push([element, args, handler, args[i]]);

            $.fn.on.apply(element, args);

            return this;
        },

        _off: function (element, eventName, selector, handlerObject) {
            var e = this._events, temp;
            if (!e || !e.length)
                return this;
            if (typeof selector == "function") {
                temp = handlerObject;
                handlerObject = selector;
                selector = temp;
            }
            var t = (eventName.match(/\S+/g) || [""]);
            for (var i = 0; i < e.length; i++) {
                var arg = e[i],
                r = arg[0].length && (!handlerObject || arg[2] === handlerObject) && (arg[1][0] === eventName || t[0]) && (!selector || arg[1][1] === selector) && $.inArray(element[0], arg[0]) > -1;
                if (r) {
                    $.fn.off.apply(element, handlerObject ? [eventName, selector, arg[3]] : [eventName, selector]);
                    e.splice(i, 1);
                    break;
                }
            }

            return this;
        },

        // Client side events wire-up / trigger helper.
        _trigger: function (eventName, eventProp) {
            var fn = null, returnValue, args, clientProp = {};
            $.extend(clientProp, eventProp)

            if (eventName in this.model)
                fn = this.model[eventName];

            if (fn) {
                if (typeof fn === "string") {
                    fn = ej.util.getObject(fn, window);
                }

                if ($.isFunction(fn)) {

                    args = ej.event(eventName, this.model, eventProp);

                    
                    returnValue = fn.call(this, args);

                    // sending changes back - deep copy option should not be enabled for this $.extend 
                    if (eventProp) $.extend(eventProp, args);

                    if (args.cancel || !ej.isNullOrUndefined(returnValue))
                        return returnValue === false || args.cancel;
                }
            }

            var isPropDefined = Boolean(eventProp);
            eventProp = eventProp || {};
            eventProp.originalEventType = eventName;
            eventProp.type = this.pluginName + eventName;

            args = $.Event(eventProp.type, ej.event(eventProp.type, this.model, eventProp));

            this.element && this.element.trigger(args);

            // sending changes back - deep copy option should not be enabled for this $.extend 
            if (isPropDefined) $.extend(eventProp, args);

            if (ej.isOnWebForms && args.cancel == false && this.model.serverEvents && this.model.serverEvents.length)
                ej.raiseWebFormsServerEvents(eventName, eventProp, clientProp);

            return args.cancel;
        },

        setModel: function (options, forceSet) {
            // check for whether to apply values are not. if _setModel function is defined in child,
            //  this will call that function and validate it using return value

            if (this._trigger("modelChange", { "changes": options }))
                return;

            for (var prop in options) {
                if (!forceSet) {
                    if (this.model[prop] === options[prop]) {
                        delete options[prop];
                        continue;
                    }
                    if ($.isPlainObject(options[prop])) {
                        iterateAndRemoveProps(this.model[prop], options[prop]);
                        if ($.isEmptyObject(options[prop])) {
                            delete options[prop];
                            continue;
                        }
                    }
                }

                if (this.dataTypes) {
                    var returnValue = this._isValidModelValue(prop, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + prop + " - " + returnValue;
                }
                if (this.model.notifyOnEachPropertyChanges && this.model[prop] !== options[prop]) {
                    var arg = {
                        oldValue: this.model[prop],
                        newValue: options[prop]
                    };

                    options[prop] = this._trigger(prop + "Change", arg) ? this.model[prop] : arg.newValue;
                }
            }
            if ($.isEmptyObject(options))
                return;

            if (this._setFirst) {
                var ds = options.dataSource;
                if (ds) delete options.dataSource;

                $.extend(true, this.model, options);
                if (ds) {
                    this.model.dataSource = (ds instanceof Array) ? ds.slice() : ds;
                    options["dataSource"] = this.model.dataSource;
                }
                !this._setModel || this._setModel(options);

            } else if (!this._setModel || this._setModel(options) !== false) {
                $.extend(true, this.model, options);
            }
            if ("enablePersistence" in options) {
                this._setState(options.enablePersistence);
            }
        },
        option: function (prop, value, forceSet) {
            if (!prop)
                return this.model;

            if ($.isPlainObject(prop))
                return this.setModel(prop, forceSet);

            if (typeof prop === "string") {
                prop = prop.replace(/^model\./, "");
                var oldValue = ej.getObject(prop, this.model);

                if (value === undefined && !forceSet)
                    return oldValue;

                if (prop === "enablePersistence")
                    return this._setState(value);

                if (forceSet && value === ej.extensions.modelGUID) {
                    return this._setModel(ej.createObject(prop, ej.getObject(prop, this.model), {}));
                }

                if (forceSet || ej.getObject(prop, this.model) !== value)
                    return this.setModel(ej.createObject(prop, value, {}), forceSet);
            }
            return undefined;
        },

        _isValidModelValue: function (prop, types, options) {
            var value = types[prop], option = options[prop], returnValue;

            if (!value)
                return true;

            if (typeof value === "string") {
                if (value == "enum") {
                    options[prop] = option ? option.toString().toLowerCase() : option;
                    value = "string";
                }

                if (value === "array") {
                    if (Object.prototype.toString.call(option) === '[object Array]')
                        return true;
                }
                else if (value === "data") {
                    return true;
                }
                else if (value === "parent") {
                    return true;
                }
                else if (typeof option === value)
                    return true;

                return "Expected type - " + value;
            }

            if (option instanceof Array) {
                for (var i = 0; i < option.length; i++) {
                    returnValue = this._isValidModelValue(prop, types, option[i]);
                    if (returnValue !== true) {
                        return " [" + i + "] - " + returnValue;
                    }
                }
                return true;
            }

            for (var innerProp in option) {
                returnValue = this._isValidModelValue(innerProp, value, option);
                if (returnValue !== true)
                    return innerProp + " : " + returnValue;
            }

            return true;
        },

        _returnFn: function (obj, propName) {
            if (propName.indexOf('.') != -1) {
                this._returnFn(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
            }
            else
                obj[propName] = obj[propName].call(obj.propName);
        },

        _removeCircularRef: function (obj) {
            var seen = [];
            function detect(obj, key, parent) {
                if (typeof obj != 'object') { return; }
                if (!Array.prototype.indexOf) {
                    Array.prototype.indexOf = function (val) {
                        return jQuery.inArray(val, this);
                    };
                }
                if (seen.indexOf(obj) >= 0) {
                    delete parent[key];
                    return;
                }
                seen.push(obj);
                for (var k in obj) { //dive on the object's children
                    if (obj.hasOwnProperty(k)) { detect(obj[k], k, obj); }
                }
                seen.pop();
                return;
            }
            detect(obj, 'obj', null);
            return obj;
        },

        stringify: function (model, removeCircular) {
            var observables = this.observables;
            for (var k = 0; k < observables.length; k++) {
                var val = ej.getObject(observables[k], model);
                if (!ej.isNullOrUndefined(val) && typeof (val) === "function")
                    this._returnFn(model, observables[k]);
            }
            if (removeCircular) model = this._removeCircularRef(model);
            return JSON.stringify(model);
        },

        _setState: function (val) {
            if (val === true) {
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
            } else {
                this.deleteState();
                $(window).off("unload", this._persistHandler);
            }
        },

        _removeProp: function (obj, propName) {
            if (!ej.isNullOrUndefined(obj)) {
                if (propName.indexOf('.') != -1) {
                    this._removeProp(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
                }
                else
                    delete obj[propName];
            }
        },

        persistState: function () {
            var model;

            if (this._ignoreOnPersist) {
                model = copyObject({}, this.model);
                for (var i = 0; i < this._ignoreOnPersist.length; i++) {
                    this._removeProp(model, this._ignoreOnPersist[i]);
                }
                model.ignoreOnPersist = this._ignoreOnPersist;
            } else if (this._addToPersist) {
                model = {};
                for (var i = 0; i < this._addToPersist.length; i++) {
                    ej.createObject(this._addToPersist[i], ej.getObject(this._addToPersist[i], this.model), model);
                }
                model.addToPersist = this._addToPersist;
            } else {
                model = copyObject({}, this.model);
            }

            if (this._persistState) {
                model.customPersists = {};
                this._persistState(model.customPersists);
            }

            if (window.localStorage) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") == null)
                    window.localStorage.setItem("persistKey", ej.persistStateVersion);
                window.localStorage.setItem("$ej$" + this.pluginName + this._id, JSON.stringify(model));
            }
            else if (document.cookie) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") == null)
                    ej.cookie.set("persistKey", ej.persistStateVersion);
                ej.cookie.set("$ej$" + this.pluginName + this._id, model);
            }
        },

        deleteState: function () {
            if (window.localStorage)
                window.localStorage.removeItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                ej.cookie.set("$ej$" + this.pluginName + this._id, model, new Date());
        },

        restoreState: function (silent) {
            var value = null;
            if (window.localStorage)
                value = window.localStorage.getItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                value = ej.cookie.get("$ej$" + this.pluginName + this._id);

            if (value) {
                var model = JSON.parse(value);

                if (this._restoreState) {
                    this._restoreState(model.customPersists);
                    delete model.customPersists;
                }

                if (ej.isNullOrUndefined(model) === false)
                    if (!ej.isNullOrUndefined(model.ignoreOnPersist)) {
                        this._ignoreOnPersist = model.ignoreOnPersist;
                        delete model.ignoreOnPersist;
                    } else if (!ej.isNullOrUndefined(model.addToPersist)) {
                        this._addToPersist = model.addToPersist;
                        delete model.addToPersist;
                    }
            }
            if (!ej.isNullOrUndefined(model) && !ej.isNullOrUndefined(this._ignoreOnPersist)) {
                for(var i = 0, len =  this._ignoreOnPersist.length; i < len; i++) {
					if (this._ignoreOnPersist[i].indexOf('.') !== -1)
                        ej.createObject(this._ignoreOnPersist[i], ej.getObject(this._ignoreOnPersist[i], this.model), model);
                    else
                        model[this._ignoreOnPersist[i]] = this.model[this._ignoreOnPersist[i]];
				}
                this.model = model;
            }
            else
                this.model = $.extend(true, this.model, model);

            if (!silent && value && this._setModel)
                this._setModel(this.model);
        },

        //to prevent persistence
        ignoreOnPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    this._ignoreOnPersist.push(collection[i]);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    var index = this._addToPersist.indexOf(collection[i]);
                    this._addToPersist.splice(index, 1);
                }
            }
        },

        //to maintain persistence
        addToPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    var index = this._ignoreOnPersist.indexOf(collection[i]);
                    this._ignoreOnPersist.splice(index, 1);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    if ($.inArray(collection[i], this._addToPersist) === -1)
                        this._addToPersist.push(collection[i]);
                }
            }
        },

        // Get formatted text 
        formatting: function (formatstring, str, locale) {
            formatstring = formatstring.replace(/%280/g, "\"").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
            locale = ej.preferredCulture(locale) ? locale : "en-US";
            var s = formatstring;
            var frontHtmlidx, FrontHtml, RearHtml, lastidxval;
            frontHtmlidx = formatstring.split("{0:");
            lastidxval = formatstring.split("}");
            FrontHtml = frontHtmlidx[0];
            RearHtml = lastidxval[1];
            if (typeof (str) == "string" && $.isNumeric(str))
                str = Number(str);
            if (formatstring.indexOf("{0:") != -1) {
                var toformat = new RegExp("\\{0(:([^\\}]+))?\\}", "gm");
                var formatVal = toformat.exec(formatstring);
                if (formatVal != null && str != null) {
                    if (FrontHtml != null && RearHtml != null)
                        str = FrontHtml + ej.format(str, formatVal[2], locale) + RearHtml;
                    else
                        str = ej.format(str, formatVal[2], locale);
                } else if (str != null)
                    str = str;
                else
                    str = "";
                return str;
            } else if (s.startsWith("{") && !s.startsWith("{0:")) {
                var fVal = s.split(""), str = (str || "") + "", strSplt = str.split(""), formats = /[0aA\*CN<>\?]/gm;
                for (var f = 0, f, val = 0; f < fVal.length; f++)
                    fVal[f] = formats.test(fVal[f]) ? "{" + val++ + "}" : fVal[f];
                return String.format.apply(String, [fVal.join("")].concat(strSplt)).replace('{', '').replace('}', '');
            } else if (this.data != null && this.data.Value == null) {
                $.each(this.data, function (dataIndex, dataValue) {
                    s = s.replace(new RegExp('\\{' + dataIndex + '\\}', 'gm'), dataValue);
                });
                return s;
            } else {
                return this.data.Value;
            }
        },
    };

    ej.WidgetBase = function () {
    }

    var iterateAndRemoveProps = function (source, target) {
		if(source instanceof Array) {
			for (var i = 0, len = source.length; i < len; i++) {
				prop = source[i];
				if(prop === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(prop))
					iterateAndRemoveProps(prop, target[prop]);
			}
		}
		else {
			for (var prop in source) {
				if (source[prop] === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(source[prop]))
					iterateAndRemoveProps(source[prop], target[prop]);
			}
		}
    }

    ej.widget = function (pluginName, className, proto) {
        /// <summary>Widget helper for developers, this set have predefined function to jQuery plug-ins</summary>
        /// <param name="pluginName" type="String">the plugin name that will be added in jquery.fn</param>
        /// <param name="className" type="String">the class name for your plugin, this will help create default cssClas</param>
        /// <param name="proto" type="Object">prototype for of the plug-in</param>

        if (typeof pluginName === "object") {
            proto = className;
            for (var prop in pluginName) {
                var name = pluginName[prop];

                if (name instanceof Array) {
                    proto._rootCSS = name[1];
                    name = name[0];
                }

                ej.widget(prop, name, proto);

                if (pluginName[prop] instanceof Array)
                    proto._rootCSS = "";
            }

            return;
        }

        var nameSpace = proto._rootCSS || ej.getNameSpace(className);

        proto = ej.defineClass(className, function (element, options) {

            this.sfType = className;
            this.pluginName = pluginName;
            this.instance = pInstance;

            if (ej.isNullOrUndefined(this._setFirst))
                this._setFirst = true;

            this["ob.values"] = {};

            $.extend(this, ej.widgetBase);

            if (this.dataTypes) {
                for (var property in options) {
                    var returnValue = this._isValidModelValue(property, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + property + " - " + returnValue;
                }
            }

            var arr = (element.data("ejWidgets") || []);
            arr.push(pluginName);
            element.data("ejWidgets", arr);

            for (var i = 0; ej.widget.observables && this.observables && i < this.observables.length; i++) {
                var t = ej.getObject(this.observables[i], options);
                if (t) ej.createObject(this.observables[i], ej.widget.observables.register(t, this.observables[i], this, element), options);
            }

            this.element = element.jquery ? element : $(element);
            this.model = copyObject(true, {}, proto.prototype.defaults, options);
            this.model.keyConfigs = copyObject(this.keyConfigs);

            this.element.addClass(nameSpace + " e-js").data(pluginName, this);

            this._id = element[0].id;

            if (this.model.enablePersistence) {
                if (window.localStorage && !ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") != ej.persistStateVersion) {
                    for (var i in window.localStorage) {
                        if (i.indexOf("$ej$") != -1) {
                            window.localStorage.removeItem(i); //removing the previously stored plugin item from local storage
							window.localStorage.setItem("persistKey", ej.persistStateVersion);
						}				
                    }
                }
                else if (document.cookie && !ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") != ej.persistStateVersion) {
                    var splits = document.cookie.split(/; */);
                    for (var k in splits) {
                        if (k.indexOf("$ej$") != -1) {
                            ej.cookie.set(k.split("=")[0], model, new Date()); //removing the previously stored plugin item from local storage
							ej.cookie.set("persistKey", ej.persistStateVersion);
						}		
                    }
                }
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
                this.restoreState(true);
            }

            this._init(options);

            if (typeof this.model.keyConfigs === "object" && !(this.model.keyConfigs instanceof Array)) {
                var requiresEvt = false;
                if (this.model.keyConfigs.focus)
                    this.element.attr("accesskey", this.model.keyConfigs.focus);

                for (var keyProps in this.model.keyConfigs) {
                    if (keyProps !== "focus") {
                        requiresEvt = true;
                        break;
                    }
                }

                if (requiresEvt && this._keyPressed) {
                    var el = element, evt = "keydown";

                    if (this.keySettings) {
                        el = this.keySettings.getElement ? this.keySettings.getElement() || el : el;
                        evt = this.keySettings.event || evt;
                    }

                    this._on(el, evt, function (e) {
                        if (!this.model.keyConfigs) return;

                        var action = keyFn.getActionFromCode(this.model.keyConfigs, e.which, e.ctrlKey, e.shiftKey, e.altKey);
                        var arg = {
                            code: e.which,
                            ctrl: e.ctrlKey,
                            alt: e.altKey,
                            shift: e.shiftKey
                        };
                        if (!action) return;

                        if (this._keyPressed(action, e.target, arg, e) === false)
                            e.preventDefault();
                    });
                }
            }
            this._trigger("create");
        }, proto);

        $.fn[pluginName] = function (options) {
            var opt = options, args;
            for (var i = 0; i < this.length; i++) {

                var $this = $(this[i]),
                    pluginObj = $this.data(pluginName),
                    isAlreadyExists = pluginObj && $this.hasClass(nameSpace),
                    obj = null;

                if (this.length > 0 && $.isPlainObject(opt))
                    options = ej.copyObject({}, opt);

                // ----- plug-in creation/init
                if (!isAlreadyExists) {
                    if (proto.prototype._requiresID === true && !$(this[i]).attr("id")) {
                        $this.attr("id", getUid("ejControl_"));
                    }
                    if (!options || typeof options === "object") {
                        if (proto.prototype.defaults && !ej.isNullOrUndefined(ej.setCulture) && "locale" in proto.prototype.defaults && pluginName != "ejChart") {
                            if (options && !("locale" in options)) options.locale = ej.setCulture().name;
                            else if (ej.isNullOrUndefined(options)) {
                                options = {}; options.locale = ej.setCulture().name;
                            }
                        }
                        new proto($this, options);
                    }
                    else {
                        throwError(pluginName + ": methods/properties can be accessed only after plugin creation");
                    }
                    continue;
                }

                if (!options) continue;

                args = [].slice.call(arguments, 1);

                if (this.length > 0 && args[0] && opt === "option" && $.isPlainObject(args[0])) {
                    args[0] = ej.copyObject({}, args[0]);
                }

                // --- Function/property set/access
                if ($.isPlainObject(options)) {
                    // setModel using JSON object
                    pluginObj.setModel(options);
                }

                    // function/property name starts with "_" is private so ignore it.
                else if (options.indexOf('_') !== 0
                    && !ej.isNullOrUndefined(obj = ej.getObject(options, pluginObj))
                    || options.indexOf("model.") === 0) {

                    if (!obj || !$.isFunction(obj)) {

                        // if property is accessed, then break the jquery chain
                        if (arguments.length == 1)
                            return obj;

                        //setModel using string input
                        pluginObj.option(options, arguments[1]);

                        continue;
                    }

                    var value = obj.apply(pluginObj, args);

                    // If function call returns any value, then break the jquery chain
                    if (value !== undefined)
                        return value;

                } else {
                    throwError(className + ": function/property - " + options + " does not exist");
                }
            }
            if (pluginName.indexOf("ejm") != -1)
                ej.widget.registerInstance($this, pluginName, className, proto.prototype);
            // maintaining jquery chain
            return this;
        };

        ej.widget.register(pluginName, className, proto.prototype);
        ej.loadLocale(pluginName);
    };

    ej.loadLocale = function (pluginName) {
        var i, len, locales = ej.locales;
        for (i = 0, len = locales.length; i < len; i++)
            $.fn["Locale_" + locales[i]](pluginName);
    };


    $.extend(ej.widget, (function () {
        var _widgets = {}, _registeredInstances = [],

        register = function (pluginName, className, prototype) {
            if (!ej.isNullOrUndefined(_widgets[pluginName]))
                throwError("ej.widget : The widget named " + pluginName + " is trying to register twice.");

            _widgets[pluginName] = { name: pluginName, className: className, proto: prototype };

            ej.widget.extensions && ej.widget.extensions.registerWidget(pluginName);
        },
        registerInstance = function (element, pluginName, className, prototype) {
            _registeredInstances.push({ element: element, pluginName: pluginName, className: className, proto: prototype });
        }

        return {
            register: register,
            registerInstance: registerInstance,
            registeredWidgets: _widgets,
            registeredInstances: _registeredInstances
        };

    })());

    ej.widget.destroyAll = function (elements) {
        if (!elements || !elements.length) return;

        for (var i = 0; i < elements.length; i++) {
            var data = elements.eq(i).data(), wds = data["ejWidgets"];
            if (wds && wds.length) {
                for (var j = 0; j < wds.length; j++) {
                    if (data[wds[j]] && data[wds[j]].destroy)
                        data[wds[j]].destroy();
                }
            }
        }
    };

    ej.cookie = {
        get: function (name) {
            var value = RegExp(name + "=([^;]+)").exec(document.cookie);

            if (value && value.length > 1)
                return value[1];

            return undefined;
        },
        set: function (name, value, expiryDate) {
            if (typeof value === "object")
                value = JSON.stringify(value);

            value = escape(value) + ((expiryDate == null) ? "" : "; expires=" + expiryDate.toUTCString());
            document.cookie = name + "=" + value;
        }
    };

    var keyFn = {
        getActionFromCode: function (keyConfigs, keyCode, isCtrl, isShift, isAlt) {
            isCtrl = isCtrl || false;
            isShift = isShift || false;
            isAlt = isAlt || false;

            for (var keys in keyConfigs) {
                if (keys === "focus") continue;

                var key = keyFn.getKeyObject(keyConfigs[keys]);
                for (var i = 0; i < key.length; i++) {
                    if (keyCode === key[i].code && isCtrl == key[i].isCtrl && isShift == key[i].isShift && isAlt == key[i].isAlt)
                        return keys;
                }
            }
            return null;
        },
        getKeyObject: function (key) {
            var res = {
                isCtrl: false,
                isShift: false,
                isAlt: false
            };
            var tempRes = $.extend(true, {}, res);
            var $key = key.split(","), $res = [];
            for (var i = 0; i < $key.length; i++) {
                var rslt = null;
                if ($key[i].indexOf("+") != -1) {
                    var k = $key[i].split("+");
                    for (var j = 0; j < k.length; j++) {
                        rslt = keyFn.getResult($.trim(k[j]), res);
                    }
                }
                else {
                    rslt = keyFn.getResult($.trim($key[i]), $.extend(true, {}, tempRes));
                }
                $res.push(rslt);
            }
            return $res;
        },
        getResult: function (key, res) {
            if (key === "ctrl")
                res.isCtrl = true;
            else if (key === "shift")
                res.isShift = true;
            else if (key === "alt")
                res.isAlt = true;
            else res.code = parseInt(key, 10);
            return res;
        }
    };

    ej.getScrollableParents = function (element) {
        return $(element).parentsUntil("html").filter(function () {
            return $(this).css("overflow") != "visible";
        }).add($(window));
    }
    ej.browserInfo = function () {
        var browser = {}, clientInfo = [],
        browserClients = {
            opera: /(opera|opr)(?:.*version|)[ \/]([\w.]+)/i, edge: /(edge)(?:.*version|)[ \/]([\w.]+)/i, webkit: /(chrome)[ \/]([\w.]+)/i, safari: /(webkit)[ \/]([\w.]+)/i, msie: /(msie|trident) ([\w.]+)/i, mozilla: /(mozilla)(?:.*? rv:([\w.]+)|)/i
        };
        for (var client in browserClients) {
            if (browserClients.hasOwnProperty(client)) {
                clientInfo = navigator.userAgent.match(browserClients[client]);
                if (clientInfo) {
                    browser.name = clientInfo[1].toLowerCase() == "opr" ? "opera" : clientInfo[1].toLowerCase();
                    browser.version = clientInfo[2];
                    browser.culture = {};
                    browser.culture.name = browser.culture.language = navigator.language || navigator.userLanguage;
                    if (typeof (ej.globalize) != 'undefined') {
                        var oldCulture = ej.preferredCulture().name;
                        var culture = (navigator.language || navigator.userLanguage) ? ej.preferredCulture(navigator.language || navigator.userLanguage) : ej.preferredCulture("en-US");
                        for (var i = 0; (navigator.languages) && i < navigator.languages.length; i++) {
                            culture = ej.preferredCulture(navigator.languages[i]);
                            if (culture.language == navigator.languages[i])
                                break;
                        }
                        ej.preferredCulture(oldCulture);
                        $.extend(true, browser.culture, culture);
                    }
                    if (!!navigator.userAgent.match(/Trident\/7\./)) {
                        browser.name = "msie";
                    }
                    break;
                }
            }
        }
        browser.isMSPointerEnabled = (browser.name == 'msie') && browser.version > 9 && window.navigator.msPointerEnabled;
        browser.pointerEnabled = window.navigator.pointerEnabled;
        return browser;
    };
    ej.eventType = {
        mouseDown: "mousedown touchstart",
        mouseMove: "mousemove touchmove",
        mouseUp: "mouseup touchend",
        mouseLeave: "mouseleave touchcancel",
        click: "click touchend"
    };

    ej.event = function (type, data, eventProp) {

        var e = $.extend(eventProp || {},
            {
                "type": type,
                "model": data,
                "cancel": false
            });

        return e;
    };

    ej.proxy = function (fn, context, arg) {
        if (!fn || typeof fn !== "function")
            return null;

        if ('on' in fn && context)
            return arg ? fn.on(context, arg) : fn.on(context);

        return function () {
            var args = arg ? [arg] : []; args.push.apply(args, arguments);
            return fn.apply(context || this, args);
        };
    };

    ej.hasStyle = function (prop) {
        var style = document.documentElement.style;

        if (prop in style) return true;

        var prefixs = ['ms', 'Moz', 'Webkit', 'O', 'Khtml'];

        prop = prop[0].toUpperCase() + prop.slice(1);

        for (var i = 0; i < prefixs.length; i++) {
            if (prefixs[i] + prop in style)
                return true;
        }

        return false;
    };

    Array.prototype.indexOf = Array.prototype.indexOf || function (searchElement) {
        var len = this.length;

        if (len === 0) return -1;

        for (var i = 0; i < len; i++) {
            if (i in this && this[i] === searchElement)
                return i;
        }
        return -1;
    };

    String.prototype.startsWith = String.prototype.startsWith || function (key) {
        return this.slice(0, key.length) === key;
    };
    var copyObject = ej.copyObject = function (isDeepCopy, target) {
        var start = 2, current, source;
        if (typeof isDeepCopy !== "boolean") {
            start = 1;
        }
        var objects = [].slice.call(arguments, start);
        if (start === 1) {
            target = isDeepCopy;
            isDeepCopy = undefined;
        }

        for (var i = 0; i < objects.length; i++) {
            for (var prop in objects[i]) {
                current = target[prop], source = objects[i][prop];

                if (source === undefined || current === source || objects[i] === source || target === source)
                    continue;
                if (source instanceof Array) {
                    if (i === 0 && isDeepCopy) {
                        if (prop === "dataSource" || prop === "data" || prop === "predicates")
                            target[prop] = source.slice();
					  else  {
                        target[prop] = new Array();
                        for (var j = 0; j < source.length; j++) {
                            copyObject(true, target[prop], source);
                        }
					  }
                    }
                    else
                        target[prop] = source.slice();
                }
                else if (ej.isPlainObject(source)) {
                    target[prop] = current || {};
                    if (isDeepCopy)
                        copyObject(isDeepCopy, target[prop], source);
                    else
                        copyObject(target[prop], source);
                } else
                    target[prop] = source;
            }
        }
        return target;
    };
    var pInstance = function () {
        return this;
    }

    var _uid = 0;
    var getUid = function (prefix) {
        return prefix + _uid++;
    }

    ej.template = {};

    ej.template.render = ej.template["text/x-jsrender"] = function (self, selector, data, index, prop) {
        if (selector.slice(0, 1) !== "#")
            selector = ["<div>", selector, "</div>"].join("");
        var property = { prop: prop, index: index };
        return $(selector).render(data, property);
    }

    ej.isPlainObject = function (obj) {
        if (!obj) return false;
        if (ej.DataManager !== undefined && obj instanceof ej.DataManager) return false;
        if (typeof obj !== "object" || obj.nodeType || jQuery.isWindow(obj)) return false;
        try {
            if (obj.constructor &&
                !obj.constructor.prototype.hasOwnProperty("isPrototypeOf")) {
                return false;
            }
        } catch (e) {
            return false;
        }

        var key, ownLast = ej.support.isOwnLast;
        for (key in obj) {
            if (ownLast) break;
        }

        return key === undefined || obj.hasOwnProperty(key);
    };
    var getValueFn = false;
    ej.util.valueFunction = function (prop) {
        return function (value, getObservable) {
            var val = ej.getObject(prop, this.model);

            if (getValueFn === false)
                getValueFn = ej.getObject("observables.getValue", ej.widget);

            if (value === undefined) {
                if (!ej.isNullOrUndefined(getValueFn)) {
                    return getValueFn(val, getObservable);
                }
                return typeof val === "function" ? val.call(this) : val;
            }

            if (typeof val === "function") {
                this["ob.values"][prop] = value;
                val.call(this, value);
            }
            else
                ej.createObject(prop, value, this.model);
        }
    };
    ej.util.getVal = function (val) {
        if (typeof val === "function")
            return val();
        return val;
    };
    ej.support = {
        isOwnLast: function () {
            var fn = function () { this.a = 1; };
            fn.prototype.b = 1;

            for (var p in new fn()) {
                return p === "b";
            }
        }(),
        outerHTML: function () {
            return document.createElement("div").outerHTML !== undefined;
        }()
    };

    var throwError = ej.throwError = function (er) {
        try {
            throw new Error(er);
        } catch (e) {
            throw e.message + "\n" + e.stack;
        }
    };

    ej.getRandomValue = function (min, max) {
        if (min === undefined || max === undefined)
            return ej.throwError("Min and Max values are required for generating a random number");

        var rand;
        if ("crypto" in window && "getRandomValues" in crypto) {
            var arr = new Uint16Array(1);
            window.crypto.getRandomValues(arr);
            rand = arr[0] % (max - min) + min;
        }
        else rand = Math.random() * (max - min) + min;
        return rand | 0;
    }

    ej.extensions = {};
    ej.extensions.modelGUID = "{0B1051BA-1CCB-42C2-A3B5-635389B92A50}";
})(window.jQuery, window.Syncfusion);
(function () {
    $.fn.addEleAttrs = function (json) {
        var $this = $(this);
        $.each(json, function (i, attr) {
            if (attr && attr.specified) {
                $this.attr(attr.name, attr.value);
            }
        });

    };
    $.fn.removeEleAttrs = function (regex) {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && regex.test(attr.name)) {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.fn.attrNotStartsWith = function (regex) {
        var proxy = this;
        var attributes = [], attrs;
        this.each(function () {
            attrs = $(this.attributes).clone();
        });
        for (i = 0; i < attrs.length; i++) {
            if (attrs[i] && attrs[i].specified && regex.test(attrs[i].name)) {
                continue
            }
            else
                attributes.push(attrs[i])
        }
        return attributes;

    }
    $.fn.removeEleEmptyAttrs = function () {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && attr.value === "") {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.extend($.support, {
        has3d: ej.addPrefix('perspective') in ej.styles,
        hasTouch: 'ontouchstart' in window,
        hasPointer: navigator.msPointerEnabled,
        hasTransform: ej.userAgent() !== false,
        pushstate: "pushState" in history &&
        "replaceState" in history,
        hasTransition: ej.addPrefix('transition') in ej.styles
    });
    //Ensuring elements having attribute starts with 'ejm-' 
    $.extend($.expr[':'], {
        attrNotStartsWith: function (element, index, match) {
            var i, attrs = element.attributes;
            for (i = 0; i < attrs.length; i++) {
                if (attrs[i].nodeName.indexOf(match[3]) === 0) {
                    return false;
                }
            }
            return true;
        }
    });
    //addBack() is supported from Jquery >1.8 and andSelf() supports later version< 1.8. support for both the method is provided by extending the JQuery function.
    var oldSelf = $.fn.andSelf || $.fn.addBack;
    $.fn.andSelf = $.fn.addBack = function () {
        return oldSelf.apply(this, arguments);
    };
})();;
;
(function($, undefined){
    
ej.globalize = {};
ej.cultures = {};

ej.cultures['default'] = ej.cultures['en-US'] = $.extend(true, {
    name: 'en-US',
    englishName: "English",
    nativeName: "English",
    language: 'en',
    isRTL: false,
    numberFormat: {
        pattern: ["-n"],
        decimals: 2,
        ',': ",",
        '.': ".",
        groupSizes: [3],
        '+': "+",
        '-': "-",
        percent: {
            pattern: ["-n %", "n %"],
            decimals: 2,
            groupSizes: [3],
            ',': ",",
            '.': ".",
            symbol: '%'
        },
        currency: {
            pattern: ["($n)", "$n"],
            decimals: 2,
            groupSizes: [3],
            ',': ",",
            '.': ".",
            symbol: '$'
        }
    },
    calendars: {
    	standard: {
	        '/': '/',
	        ':': ':',
	        firstDay: 0,
			week:{
			name:"Week",
			nameAbbr:"Wek",
			nameShort:"Wk"
			},
	        days: {
	            names: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
	            namesAbbr: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
	            namesShort: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]
	        },
	        months: {
	            names: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ""],
	            namesAbbr: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", ""]
	        },
	        AM: ['AM', 'am', 'AM'],
	        PM: ['PM', 'pm', 'PM'],
            twoDigitYearMax: 2029,
	        patterns: {
                d: "M/d/yyyy",
                D: "dddd, MMMM dd, yyyy",
                t: "h:mm tt",
                T: "h:mm:ss tt",
                f: "dddd, MMMM dd, yyyy h:mm tt",
                F: "dddd, MMMM dd, yyyy h:mm:ss tt",
                M: "MMMM dd",
                Y: "yyyy MMMM",
                S: "yyyy\u0027-\u0027MM\u0027-\u0027dd\u0027T\u0027HH\u0027:\u0027mm\u0027:\u0027ss"

	        }
    	}
    }
}, ej.cultures['en-US']);

ej.cultures['en-US'].calendar = ej.cultures['en-US'].calendar || ej.cultures['en-US'].calendars.standard; 



// *************************************** Numbers ***************************************
var regexTrim = /^\s+|\s+$/g,
    regexInfinity = /^[+-]?infinity$/i,
    regexHex = /^0x[a-f0-9]+$/i,
    regexParseFloat = /^[+-]?\d*\.?\d*(e[+-]?\d+)?$/;
var charMap =  {
                '9': "[0-9 ]",
				'0': "[0-9 ]",
                'a': "[A-Za-z0-9 ]",
                'A': "[A-Za-z0-9]",
                'N': "[0-9]",
                '#': "[0-9]",
                '&': '[^\x7f]+',
                '<': "",
                '>': "",
                'C': "[A-Za-z ]",
                '?': "[A-Za-z]",
            };

function  formatMapper (format, value) {
    var mask = format || "", rules = charMap, value = value.toString(), isDecimal = value.indexOf(".") > -1 || format.indexOf(".") > -1, diff = 0, stIdx = 0, preFormat = "", escFormat = "",
		separator = format.split(","), newChar = "0", expValue, exponentIdx = format.toLowerCase().indexOf("e"), valueColl, formatColl, hashIdx = mask.indexOf("#");
	if(format.indexOf("\\") > -1) {
		escFormat = format.substr(0, format.lastIndexOf("\\") + 1);
		format = format.substr(format.lastIndexOf("\\") + 1, format.length);
		hashIdx = format.indexOf("#");
	}
	if(exponentIdx > -1) {
		var maskFirst = "", mask = "";
		formatColl = format.toLowerCase().split("e");
		expValue = format.indexOf("+") > -1 ? format.split("+")[1] : format.split("-")[1];
		value = parseInt(value).toExponential();
		valueColl = value.split("e");
		diff = formatColl[1].length - valueColl[1].length;
		for(var k = formatColl[1].length - 1; k > 0; k--) {
			if(formatColl[1][k] != "0")
				mask += formatColl[1][k];
			else if(diff > 1) {
				mask += "#";
				diff--;
			}
			else
				mask += "0";
		}
		oprMask = (format.indexOf("+") > -1) ? "+" : "";
		mask = oprMask + mask.split("").reverse().join("");
		for(var k = 0; k < valueColl[0].length; k++)
			maskFirst = (valueColl[0][k] != ".") ? maskFirst.concat("#") : maskFirst.concat(".");
		if(maskFirst.length > formatColl[0].length)
			maskFirst = formatColl[0];
		mask = escFormat + maskFirst + "e" + mask;
	}
	else if(isDecimal) {
		formatColl = format.split(".");
		valueColl = value.split(".");
		formatColl[1] = formatColl[1].replace(/[,.]/g, "");
		diff = formatColl[0].replace(/[,.]/g, "").length - valueColl[0].replace(/[,.]/g, "").length;
		if(diff < 0 && ej.isNullOrUndefined(format.match(/[\[\(\)\]]/g))) {
			separator = formatColl[0].split(",");
			preFormat = formatColl[0].split(",")
			for(var j = separator.length - 1;j >= 0; j--) {
				if(separator[j]) {
					var cnt = separator[j].length;
					for(var k = 0, len = Math.abs(diff); k < len; k++) {
						if(cnt === 3) {
							break;
							cnt = 0;
						}
						preFormat[j] = "0" + preFormat[j];
						cnt++;
						diff++;
					}
				}
			}
			preFormat = preFormat.join();
			if(diff < 0) {
				(!ej.isNullOrUndefined(cnt) && cnt != 3) && (preFormat = "," + preFormat);
				for(var k = 0, len = Math.abs(diff); k < len; k++) {
					if(cnt === 3) {
						preFormat = "," + preFormat;
						cnt = 0;
					}
					preFormat = "0" + preFormat;
					cnt++;
				}
			}
			diff = 0;
			mask = escFormat + preFormat + "." + formatColl[1];
		}
		else if(ej.isNullOrUndefined(format.match(/[\[\(\)\]]/g))){
			preFormat = formatColl[0].replace(/[,.]/g, "");
			postFormat = "";
			var cnt = 0;
			for(var i = preFormat.length - 1; i >= 0; i--) {
				if(cnt === 3) {
					postFormat = "," + postFormat;
					cnt = 0;
				}
				else
					cnt++;
				postFormat = preFormat[i] + postFormat;
			}
			mask = escFormat + postFormat + "." + formatColl[1];
		}
	}
	else {
		var hashCount = 0, separatorColl = separator.splice(1, separator.length);
		diff = format.replace(/[,.\[\(\]\)]/g, "").length - value.replace(/[,.]/g, "").length;
		if(hashIdx > -1) {
			for(var f = 0, len = format.length; f < len; f++)
				(format[f] === "#") && hashCount++;
			if(hashCount === 1 || (separator[1] && hashCount === 2))
				newChar = "#";
			(hashCount === 1) && (separatorColl = separator[0]);
		}
		if(diff < 0) {
			formatColl = mask.split(",");
			preFormat = formatColl.splice(1, formatColl.length);	
			for(var j = separator.length - 1;j >= 0; j--) {
				if(separatorColl[j]) {
					var cnt = separatorColl[j].length;
					!preFormat[j] && (preFormat[j] = "");
					for(var k = 0, len = Math.abs(diff) + 1; k < len; k++) {
						if(hashCount != 1 && cnt === 3) {
							cnt = 0;
							break;
						}
						preFormat[j] = preFormat[j].concat(newChar);
						cnt++;
						diff++;
					}
				}
			}
			preFormat = preFormat.join();
			if(diff < 0) {
				(!ej.isNullOrUndefined(cnt) && cnt != 3) && (preFormat = "," + preFormat);
				for(var k = 0, len = Math.abs(diff) + 1; k < len; k++) {
					if(hashCount != 1 && cnt === 3) {
						preFormat = "," + preFormat;
						cnt = 0;
					}
					preFormat = newChar + preFormat;
					cnt++;
				}
			}
			diff = 0;
			mask = escFormat + preFormat;
		}
		stIdx = 0;
	}
	var mapper = [], maskChars = mask.split(""), mapperIdx = 0, i = 0, idx = 0, chr, rule, isEscChar = false, isExp = false, escIdx = format.indexOf("\\");
    for (; i < mask.length; i++) {
        chr = maskChars[i];
		if(chr === "e")
			isExp = true;
        if((chr === "0" && hashIdx < 0)) {
			if((diff > 0 && stIdx <= i)) {
				diff--;
				stIdx++;
			}
			else if(diff > 0)
				diff--;
			else
				rule = rules[chr];
		}
		else if(chr != "0" || (!isExp && chr == "0")) 
			rule = rules[chr];
		if(chr === "0" && escIdx > -1) 
			rule = rules[chr];
		if(i === mask.lastIndexOf("\\"))
			isEscChar = false;
        if (rule && !isEscChar) {
            mapper[mapperIdx] = { rule: rule };
            mapperIdx += 1;
        } else {
            if (chr === "\\") {
                chr = "";
				!(i === mask.lastIndexOf("\\")) && (isEscChar = true);
            }
            chr = chr.split("");
            for (var j = 0; j < chr.length; j++) {
                mapper[mapperIdx] = chr[j];
                mapperIdx += 1;
            }
        }
    }
    rules = mapper;
	return {"rules": rules, "format": mask};
}

function customFormat(value, format, locale) {
	if(ej.isNullOrUndefined(value) || typeof value === "string" || !format)
		throw "Bad Number Format Exception";
	var formatLength, formatObj, rules, orgFormat = format;
	formatObj = formatMapper(format, value);
	rules = formatObj.rules;
	format = formatObj.format;
    if (!(format.indexOf("\\") >= 0))
        formatModel = format.replace(/[9?CANa#&]/g, '_');
    else {
		var escIdx = format.lastIndexOf("\\"), first = format.slice(0, escIdx), second = format.slice(escIdx + 1, format.length), altFormat;
		second = second.replace(/[9?CANa#&]/g, '_');
		altFormat = first + second;
        formatModel = altFormat.replace(/[\\]/g, "");
		format = format.replace(/[\\]/g, "");
	}
    formatModel = changeCulture(formatModel, locale);
    return validateValue(value, format, formatModel, rules, locale, orgFormat);
}

function changeCulture(formatModel, locale) {
	if (formatModel.length != 0) {
        var preferredlocale = ej.preferredCulture(locale), groupSep, currecySymbol, decimalSep,unmask = "";
        groupSep = preferredlocale.numberFormat[','];
        currecySymbol = preferredlocale.numberFormat.currency.symbol;
        decimalSep = preferredlocale.numberFormat['.'];
        for (var i = 0; i < formatModel.length; i++) {
            if (formatModel[i] == ",")
                unmask += groupSep;
            else if (formatModel[i] == ".")
                unmask += decimalSep;
            else if (formatModel[i] == "$")
                unmask += currecySymbol;
            else
                unmask += formatModel[i];
        }
        formatModel = unmask;
    }
	return formatModel;
}

function validateValue(value, format, formatModel, rules, locale, orgFormat) {
	if(ej.isNullOrUndefined(value))
		return;
	if(format.toLowerCase().indexOf("e") > -1) {
		var expValue = orgFormat.indexOf("+") > -1 ? orgFormat.split("+")[1] : orgFormat.split("-")[1];
		value = value.toExponential();
		(orgFormat.indexOf("-") > -1) && (value = value.replace("+", "")); 
	}
	var tempValue = oldvalue = replacestring = value.toString(), tempModel = formatModel, maskIndex = i = 0, chr, prompt = "_", rule,
		strBefore, strAfter, charValue, isBracket = format.match(/[\(\[\]\)]/g);
    if (!format.indexOf("\\") >= 0)
        tempValue = value = replacestring.replace(/[\(\)-]/g, "");
    else
        tempValue = tvalue;
	j = rules.length - 1;
	v = oldvalue.length - 1;
	if(!ej.isNullOrUndefined(isBracket)) {
		while (j >= 0) {
			chr = oldvalue[v];
			rule = rules[j];
			if (chr == undefined) break;
			if (chr === rule || chr === prompt || (chr === "e" && (chr === rule.toLowerCase()))) {
				chr === prompt ? prompt : "";
				strBefore = tempModel.substring(0, j+1);
				strAfter = tempModel.substring(j+1);
				chr = changeCulture(chr, locale);
				tempModel = strBefore.substr(0, strBefore.length - 1)  + chr + strAfter;
				j--;
				v--;
			}
			else if (rules[j].rule != undefined ) {
				var charCode = oldvalue.charCodeAt(v);
				if (validateChars(format, charCode, j)) {
					strBefore = tempModel.substring(0, j +1);
					strAfter = tempModel.substring(j+1);
					charValue = getRoundValue(oldvalue, v, j, format, formatModel);
					tempModel = strBefore.substr(0, strBefore.length - 1) + charValue + strAfter;
					j--;
					v--;
				} else 
					j--;
			} 
			else
				j--;
			if (i > tempValue.length || j<0) break;
		}
	}
	else {
		while (maskIndex < rules.length) {
			chr = oldvalue[i];
			rule = rules[maskIndex];
			if (chr == undefined) break;
			if (chr === rule || chr === prompt || (chr === "e" && (chr === rule.toLowerCase()))) {
				chr === prompt ? prompt : "";
				strBefore = tempModel.substring(0, maskIndex);
				strAfter = tempModel.substring(maskIndex);
				chr = changeCulture(chr, locale);
				tempModel = strBefore + chr + strAfter.substr(1, strAfter.length);
				i += 1;
				maskIndex += 1;
			}
			else if (rules[maskIndex].rule != undefined ) {
				var charCode = oldvalue.charCodeAt(i);
				if (validateChars(format, charCode, maskIndex)) {
					strBefore = tempModel.substring(0, maskIndex);
					strAfter = tempModel.substring(maskIndex);
					charValue = getRoundValue(oldvalue, i, maskIndex, format, formatModel);
					tempModel = strBefore + charValue + strAfter.substr(1, strAfter.length);
					maskIndex++;
					i++;
				} else
					maskIndex++;
			} 
			else {
				if(rule === "e")
					i = oldvalue.indexOf("e") + 1;
				maskIndex++;
			}
			if (i > tempValue.length || j<0) break;
		}
	}
    if (value) {
		if((tempModel.indexOf("_") - tempModel.indexOf(",") === 1) || (tempModel.indexOf("_") - tempModel.indexOf(".") === 1))
			tempModel = tempModel.slice(0, tempModel.indexOf("_")-1);
        strippedValue = $.trim(tempModel.replace(/[_]/g, "")) == "" ? null : tempModel.replace(/[_]/g, "");
		return strippedValue;
	}
}

function validateChars (format, keyChar, caretPos){
	var charmap = charMap, match = false, maskChar = format.substr(caretPos, 1), actualkey = String.fromCharCode(keyChar);
    $.each(charmap, function (key, value) {
        if (maskChar == key) {
            if (actualkey.match(new RegExp(value))) match = true;
                else match = false;
        }
    });
    return match;
}

function getRoundValue(value, valIdx, maskIndex, format, formatModel) {
	var isCeil = false;
	if(format.indexOf(".") > -1 && (maskIndex === formatModel.length - 1))
		(value[valIdx + 1] > 5) && (isCeil = true);
	return (isCeil ? (parseInt(value[valIdx]) + 1).toString() : value[valIdx]);
}

function patternStartsWith(value, pattern) {
    return value.indexOf( pattern ) === 0;
}

function patternEndsWith(value, pattern) {
    return value.substr( value.length - pattern.length ) === pattern;
}

function trim(value) {
    return (value+"").replace( regexTrim, "" );
}

function truncate(value){
    if(isNaN(value))
        return NaN;
    
    return Math[value < 0 ? "ceil" : "floor"](value);
}

function padWithZero(str, count, left) {
    for (var l = str.length; l < count; l++) {
        str = (left ? ('0' + str) : (str + '0'));
    }
    return str;
}

function parseNumberWithNegativePattern(value, nf, negativePattern) {
    var neg = nf["-"],
        pos = nf["+"],
        ret;
    switch (negativePattern) {
        case "n -":
            neg = ' ' + neg;
            pos = ' ' + pos;
            // fall through
        case "n-":
            if ( patternEndsWith( value, neg ) ) {
                ret = [ '-', value.substr( 0, value.length - neg.length ) ];
            }
            else if ( patternEndsWith( value, pos ) ) {
                ret = [ '+', value.substr( 0, value.length - pos.length ) ];
            }
            break;
        case "- n":
            neg += ' ';
            pos += ' ';
            // fall through
        case "-n":
            if ( patternStartsWith( value, neg ) ) {
                ret = [ '-', value.substr( neg.length ) ];
            }
            else if ( patternStartsWith(value, pos) ) {
                ret = [ '+', value.substr( pos.length ) ];
            }
            break;
        case "(n)":
            if ( patternStartsWith( value, '(' ) && patternEndsWith( value, ')' ) ) {
                ret = [ '-', value.substr( 1, value.length - 2 ) ];
            }
            break;
    }
    return ret || [ '', value ];
}

function getFullNumber(number, precision, formatInfo) {
    var groupSizes = formatInfo.groupSizes || [3],
        curSize = groupSizes[0],
        curGroupIndex = 1,
        factor = Math.pow(10, precision),
        rounded = Math.round(number * factor) / factor;
    if (!isFinite(rounded)) {
        rounded = number;
    }
    number = rounded;

    var numberString = number + "",
        right = "",
        split = numberString.split(/e/i),
        exponent = split.length > 1 ? parseInt(split[1], 10) : 0;
    numberString = split[0];
    split = numberString.split(".");
    numberString = split[0];
    right = split.length > 1 ? split[1] : "";

    var l;
    if (exponent > 0) {
        right = padWithZero(right, exponent, false);
        numberString += right.slice(0, exponent);
        right = right.substr(exponent);
    } else if (exponent < 0) {
        exponent = -exponent;
        numberString = padWithZero(numberString, exponent + 1, true);
        right = numberString.slice(-exponent, numberString.length) + right;
        numberString = numberString.slice(0, -exponent);
    }

    var dot = formatInfo['.'] || '.';
    if (precision > 0) {
        right = dot +
            ((right.length > precision) ? right.slice(0, precision) : padWithZero(right, precision));
    } else {
        right = "";
    }

    var stringIndex = numberString.length - 1,
        sep = formatInfo[","] || ',',
        ret = "";

    while (stringIndex >= 0) {
        if (curSize === 0 || curSize > stringIndex) {
            return numberString.slice(0, stringIndex + 1) + (ret.length ? (sep + ret + right) : right);
        }
        ret = numberString.slice(stringIndex - curSize + 1, stringIndex + 1) + (ret.length ? (sep + ret) : "");

        stringIndex -= curSize;

        if (curGroupIndex < groupSizes.length) {
            curSize = groupSizes[curGroupIndex];
            curGroupIndex++;
        }
    }
    return numberString.slice(0, stringIndex + 1) + sep + ret + right;
}

function formatNumberToCulture(value, format, culture) {
    if (!format || format === 'i') {
        return culture.name.length ? value.toLocaleString() : value.toString();
    }
    format = format || "D";

    var nf = culture.numberFormat,
        number = Math.abs(value),
        precision = -1,
        pattern;

    if (format.length > 1) precision = parseInt(format.slice(1), 10);

    var current = format.charAt(0).toUpperCase(),
        formatInfo;

    switch (current) {
        case 'D':
            pattern = 'n';
            number = truncate(number);
            if (precision !== -1) {
                number = padWithZero("" + number, precision, true);
            }
            if (value < 0) number = -number;
            break;
        case 'N':
            formatInfo = nf;
            formatInfo.pattern = formatInfo.pattern || ['-n'];
            // fall through
        case 'C':
            formatInfo = formatInfo || nf.currency;
            formatInfo.pattern = formatInfo.pattern || ['-$n', '$n'];
            // fall through
        case 'P':
            formatInfo = formatInfo || nf.percent;
            formatInfo.pattern = formatInfo.pattern || ['-n %', 'n %'];
            pattern = value < 0 ? (formatInfo.pattern[0] || "-n") : (formatInfo.pattern[1] || "n");
            if (precision === -1) precision = formatInfo.decimals;
            number = getFullNumber(number * (current === "P" ? 100 : 1), precision, formatInfo);
            break;
        default:
			return customFormat(value, format, culture);
    }

    return matchNumberToPattern(number, pattern, nf);
}



function matchNumberToPattern(number, pattern, nf){
    var patternParts = /n|\$|-|%/g,
        ret = "";
    for (;;) {
        var index = patternParts.lastIndex,
            ar = patternParts.exec(pattern);

        ret += pattern.slice(index, ar ? ar.index : pattern.length);

        if (!ar) {
            break;
        }

        switch (ar[0]) {
            case "n":
                ret += number;
                break;
            case "$":
                ret += nf.currency.symbol || "$";
                break;
            case "-":
                // don't make 0 negative
                if (/[1-9]/.test(number)) {
                    ret += nf["-"] || "-";
                }
                break;
            case "%":
                ret += nf.percent.symbol || "%";
                break;
        }
    }

    return ret;
}

function parseValue(value, culture, radix ) {
		// make radix optional
    if (typeof radix === "string") {
        culture = radix;
        radix = 10;
    }
    culture = ej.globalize.findCulture(culture);
    var ret = NaN, nf = culture.numberFormat, npattern = culture.numberFormat.pattern[0];
    value = value.replace(/ /g, '');
    if (value.indexOf(culture.numberFormat.currency.symbol) > -1) {
        // remove currency symbol
        value = value.replace(culture.numberFormat.currency.symbol || "$", "");
        // replace decimal seperator
        value = value.replace(culture.numberFormat.currency["."] || ".", culture.numberFormat["."] || ".");
        // pattern of the currency
        npattern = trim(culture.numberFormat.currency.pattern[0].replace("$", ""));
    } else if (value.indexOf(culture.numberFormat.percent.symbol) > -1) {
        // remove percentage symbol
        value = value.replace(culture.numberFormat.percent.symbol || "%", "");
        // replace decimal seperator
        value = value.replace(culture.numberFormat.percent["."] || ".", culture.numberFormat["."] || ".");
        // pattern of the percent
        npattern = trim(culture.numberFormat.percent.pattern[0].replace("%", ""));
    }

    // trim leading and trailing whitespace
    value = trim( value );

    // allow infinity or hexidecimal
    if (regexInfinity.test(value)) {
        ret = parseFloat(value, "" ,radix);
    }
    else if (regexHex.test(value)) {
        ret = parseInt(value, 16);
    }
    else {
        var signInfo = parseNumberWithNegativePattern( value, nf, npattern ),
            sign = signInfo[0],
            num = signInfo[1];
        // determine sign and number
        if ( sign === "" && nf.pattern[0] !== "-n" ) {
            signInfo = parseNumberWithNegativePattern( value, nf, "-n" );
            sign = signInfo[0];
            num = signInfo[1];
        }
        sign = sign || "+";
        // determine exponent and number
        var exponent,
            intAndFraction,
            exponentPos = num.indexOf( 'e' );
        if ( exponentPos < 0 ) exponentPos = num.indexOf( 'E' );
        if ( exponentPos < 0 ) {
            intAndFraction = num;
            exponent = null;
        }
        else {
            intAndFraction = num.substr( 0, exponentPos );
            exponent = num.substr( exponentPos + 1 );
        }
        // determine decimal position
        var integer,
            fraction,
            decSep = nf['.'] || '.',
            decimalPos = intAndFraction.indexOf( decSep );
        if ( decimalPos < 0 ) {
            integer = intAndFraction;
            fraction = null;
        }
        else {
            integer = intAndFraction.substr( 0, decimalPos );
            fraction = intAndFraction.substr( decimalPos + decSep.length );
        }
        // handle groups (e.g. 1,000,000)
        var groupSep = nf[","] || ",";
        integer = integer.split(groupSep).join('');
        var altGroupSep = groupSep.replace(/\u00A0/g, " ");
        if ( groupSep !== altGroupSep ) {
            integer = integer.split(altGroupSep).join('');
        }
        // build a natively parsable number string
        var p = sign + integer;
        if ( fraction !== null ) {
            p += '.' + fraction;
        }
        if ( exponent !== null ) {
            // exponent itself may have a number patternd
            var expSignInfo = parseNumberWithNegativePattern( exponent, nf, npattern );
            p += 'e' + (expSignInfo[0] || "+") + expSignInfo[1];
        }
        if ( !radix && regexParseFloat.test( p ) ) {
            ret = parseFloat( p );
        }
		else if(radix)
			ret = parseInt(p, radix);
    }
    return ret;
}

// *************************************** Dates ***************************************

var dateFormat = {
    DAY_OF_WEEK_THREE_LETTER : "ddd",
    DAY_OF_WEEK_FULL_NAME : "dddd",
    DAY_OF_MONTH_SINGLE_DIGIT : "d",
    DAY_OF_MONTH_DOUBLE_DIGIT : "dd",
    MONTH_THREE_LETTER : "MMM",
    MONTH_FULL_NAME : "MMMM",
    MONTH_SINGLE_DIGIT : "M",
    MONTH_DOUBLE_DIGIT : "MM",
    YEAR_SINGLE_DIGIT : "y",
    YEAR_DOUBLE_DIGIT : "yy",
    YEAR_FULL : "yyyy",
    HOURS_SINGLE_DIGIT_12_HOUR_CLOCK : "h",
    HOURS_DOUBLE_DIGIT_12_HOUR_CLOCK : "hh",
    HOURS_SINGLE_DIGIT_24_HOUR_CLOCK : "H",
    HOURS_DOUBLE_DIGIT_24_HOUR_CLOCK : "HH",
    MINUTES_SINGLE_DIGIT : "m",
    MINUTES_DOUBLE_DIGIT : "mm",
    SECONDS_SINGLE_DIGIT : "s",
    SECONDS_DOUBLE_DIGIT : "ss",
    MERIDIAN_INDICATOR_SINGLE : "t",
    MERIDIAN_INDICATOR_FULL : "tt",
    DECISECONDS : "f",
    CENTISECONDS: "ff",
    MILLISECONDS : "fff",
    TIME_ZONE_OFFSET_SINGLE_DIGIT : "z",
    TIME_ZONE_OFFSET_DOUBLE_DIGIT : "zz",
    TIME_ZONE_OFFSET_FULL : "zzz",
    DATE_SEPARATOR : "/"
};

function valueOutOfRange(value, low, high) {
    return value < low || value > high;
}

function expandYear(cal, year) {
    // expands 2-digit year into 4 digits.
    var now = new Date();
    if ( year < 100 ) {
        var twoDigitYearMax = cal.twoDigitYearMax;
        twoDigitYearMax = typeof twoDigitYearMax === 'string' ? new Date().getFullYear() % 100 + parseInt( twoDigitYearMax, 10 ) : twoDigitYearMax;
        var curr = now.getFullYear();
        year += curr - ( curr % 100 );
        if ( year > twoDigitYearMax ) {
            year -= 100;
        }
    }
    return year;
}

function arrayIndexOf( array, item ) {
    if ( array.indexOf ) {
        return array.indexOf( item );
    }
    for ( var i = 0, length = array.length; i < length; i++ ) {
        if ( array[ i ] === item ) return i;
    }
    return -1;
}

function toUpper(value) {
    // 'he-IL' has non-breaking space in weekday names.
    return value.split( "\u00A0" ).join(' ').toUpperCase();
}

function toUpperArray(arr) {
    var results = [];
    for ( var i = 0, l = arr.length; i < l; i++ ) {
        results[i] = toUpper(arr[i]);
    }
    return results;
}

function getIndexOfDay(cal, value, abbr) {
    var ret,
        days = cal.days,
        upperDays = cal._upperDays;
    if ( !upperDays ) {
        cal._upperDays = upperDays = [
            toUpperArray( days.names ),
            toUpperArray( days.namesAbbr ),
            toUpperArray( days.namesShort )
        ];
    }
    value = toUpper( value );
    if ( abbr ) {
        ret = arrayIndexOf( upperDays[ 1 ], value );
        if ( ret === -1 ) {
            ret = arrayIndexOf( upperDays[ 2 ], value );
        }
    }
    else {
        ret = arrayIndexOf( upperDays[ 0 ], value );
    }
    return ret;
}

function getIndexOfMonth(cal, value, abbr) {
    var months = cal.months,
        monthsGen = cal.monthsGenitive || cal.months,
        upperMonths = cal._upperMonths,
        upperMonthsGen = cal._upperMonthsGen;
    if ( !upperMonths ) {
        cal._upperMonths = upperMonths = [
            toUpperArray( months.names ),
            toUpperArray( months.namesAbbr )
        ];
        cal._upperMonthsGen = upperMonthsGen = [
            toUpperArray( monthsGen.names ),
            toUpperArray( monthsGen.namesAbbr )
        ];
    }
    value = toUpper( value );
    var i = arrayIndexOf( abbr ? upperMonths[ 1 ] : upperMonths[ 0 ], value );
    if ( i < 0 ) {
        i = arrayIndexOf( abbr ? upperMonthsGen[ 1 ] : upperMonthsGen[ 0 ], value );
    }
    return i;
}

function appendMatchStringCount(preMatch, strings) {
    var quoteCount = 0,
        escaped = false;
    for ( var i = 0, il = preMatch.length; i < il; i++ ) {
        var c = preMatch.charAt( i );
        if(c == '\''){
            escaped ? strings.push( "'" ) : quoteCount++;
            escaped = false;
        } else if( c == '\\'){
            if (escaped) strings.push( "\\" );
            escaped = !escaped;
        } else {
            strings.push( c );
            escaped = false;
        }
    }
    return quoteCount;
}


function parseDayByInt(value, format, culture, cal) {
    if (!value) {
        return null;
    }
    var index = 0, valueX = 0, day = null;
    format = format.split("");
    length = format.length;
    var countDays = function (match) {
        var i = 0;
        while (format[index] === match) {
            i++;
            index++;
        }
        if (i > 0) {
            index -= 1;
        }
        return i;
    },
    getNumber = function (size) {
        var rg = new RegExp('^\\d{1,' + size + '}'),
            match = value.substr(valueX, size).match(rg);

        if (match) {
            match = match[0];
            valueX += match.length;
            return parseInt(match, 10);
        }
        return null;
    },
    getName = function (names, lower) {
        var i = 0,
            length = names.length,
            name, nameLength,
            subValue;

        for (; i < length; i++) {
            name = names[i];
            nameLength = name.length;
            subValue = value.substr(valueX, nameLength);

            if (lower) {
                subValue = subValue.toLowerCase();
            }

            if (subValue == name) {
                valueX += nameLength;
                return i + 1;
            }
        }
        return null;
    },
     lowerArray = function (data) {
         var index = 0,
             length = data.length,
             array = [];

         for (; index < length; index++) {
             array[index] = (data[index] + "").toLowerCase();
         }

         return array;
     },
     lowerInfo = function (localInfo) {
         var newLocalInfo = {}, property;

         for (property in localInfo) {
             newLocalInfo[property] = lowerArray(localInfo[property]);
         }

         return newLocalInfo;
     };
    for (; index < length; index++) {
        ch = format[index];
        if (ch === "d") {
            count = countDays("d");
            if (!cal._lowerDays) {
                cal._lowerDays = lowerInfo(cal.days);
            }
            day = count < 3 ? getNumber(2) : getName(cal._lowerDays[count == 3 ? "namesAbbr" : "names"], true)
        }
    }
    return day;
}


function getFullDateFormat(cal, format) {
    // expands unspecified or single character date formats into the full pattern.
    format = format || "F";
    var pattern,
        patterns = cal.patterns,
        len = format.length;
    if ( len === 1 ) {
        pattern = patterns[ format ];
        if ( !pattern ) {
            throw "Invalid date format string '" + format + "'.";
        }
        format = pattern;
    }
    else if ( len === 2  && format.charAt(0) === "%" ) {
        // %X escape format -- intended as a custom format string that is only one character, not a built-in format.
        format = format.charAt( 1 );
    }
    return format;
}

ej.globalize._getDateParseRegExp = function (cal, format) {
    // converts a format string into a regular expression with groups that
    // can be used to extract date fields from a date string.
    // check for a cached parse regex.
    var re = cal._parseRegExp;
    if ( !re ) {
        cal._parseRegExp = re = {};
    }
    else {
        var reFormat = re[ format ];
        if ( reFormat ) {
            return reFormat;
        }
    }

    // expand single digit formats, then escape regular expression characters.
    var expFormat = getFullDateFormat( cal, format ).replace( /([\^\$\.\*\+\?\|\[\]\(\)\{\}])/g, "\\\\$1" ),
        regexp = ["^"],
        groups = [],
        index = 0,
        quoteCount = 0,
        tokenRegExp = /\/|dddd|ddd|dd|d|MMMM|MMM|MM|M|yyyy|yy|y|hh|h|HH|H|mm|m|ss|s|tt|t|fff|ff|f|zzz|zz|z|gg|g/g,
        match;

    // iterate through each date token found.
    while ( (match = tokenRegExp.exec( expFormat )) !== null ) {
        var preMatch = expFormat.slice( index, match.index );
        index = tokenRegExp.lastIndex;

        // don't replace any matches that occur inside a string literal.
        quoteCount += appendMatchStringCount( preMatch, regexp );
        if ( quoteCount % 2 ) {
            regexp.push( match[ 0 ] );
            continue;
        }

        // add a regex group for the token.
        var m = match[ 0 ],
            len = m.length,
            add;
            
        switch ( m ) {
            case dateFormat.DAY_OF_WEEK_THREE_LETTER: case dateFormat.DAY_OF_WEEK_FULL_NAME:
            case dateFormat.MONTH_FULL_NAME: case dateFormat.MONTH_THREE_LETTER:
                add = "(\\D+)";
                break;
            case dateFormat.MERIDIAN_INDICATOR_FULL: case dateFormat.MERIDIAN_INDICATOR_SINGLE:
                add = "(\\D*)";
                break;
            case dateFormat.YEAR_FULL:
            case dateFormat.MILLISECONDS:
            case dateFormat.CENTISECONDS:
            case dateFormat.DECISECONDS:
                add = "(\\d{" + len + "})";
                break;
            case dateFormat.DAY_OF_MONTH_DOUBLE_DIGIT: case dateFormat.DAY_OF_MONTH_SINGLE_DIGIT:
            case dateFormat.MONTH_DOUBLE_DIGIT: case dateFormat.MONTH_SINGLE_DIGIT:
            case dateFormat.YEAR_DOUBLE_DIGIT: case dateFormat.YEAR_SINGLE_DIGIT:
            case dateFormat.HOURS_DOUBLE_DIGIT_24_HOUR_CLOCK: case dateFormat.HOURS_SINGLE_DIGIT_24_HOUR_CLOCK:
            case dateFormat.HOURS_DOUBLE_DIGIT_12_HOUR_CLOCK: case dateFormat.HOURS_SINGLE_DIGIT_12_HOUR_CLOCK:
            case dateFormat.MINUTES_DOUBLE_DIGIT: case dateFormat.MINUTES_SINGLE_DIGIT:
            case dateFormat.SECONDS_DOUBLE_DIGIT: case dateFormat.SECONDS_SINGLE_DIGIT:
                add = "(\\d\\d?)";
                break;
            case dateFormat.TIME_ZONE_OFFSET_FULL:
                add = "([+-]?\\d\\d?:\\d{2})";
                break;
            case dateFormat.TIME_ZONE_OFFSET_DOUBLE_DIGIT: case dateFormat.TIME_ZONE_OFFSET_SINGLE_DIGIT:
                add = "([+-]?\\d\\d?)";
                break;
            case dateFormat.DATE_SEPARATOR:
                add = "(\\" + cal["/"] + ")";
                break;
            default:
                throw "Invalid date format pattern '" + m + "'.";
                break;
        }
        if ( add ) {
            regexp.push( add );
        }
        groups.push( match[ 0 ] );
    }
    appendMatchStringCount( expFormat.slice( index ), regexp );
    regexp.push( "$" );

    // allow whitespace to differ when matching formats.
    var regexpStr = regexp.join( '' ).replace( /\s+/g, "\\s+" ),
        parseRegExp = {'regExp': regexpStr, 'groups': groups};

    // cache the regex for this format.
    return re[ format ] = parseRegExp;
}

function getParsedDate(value, format, culture) {
    // try to parse the date string by matching against the format string
    // while using the specified culture for date field names.
    value = trim( value );
    format = trim(format);
    var cal = culture.calendar,
        // convert date formats into regular expressions with groupings.
        parseInfo = ej.globalize._getDateParseRegExp(cal, format),
        match = new RegExp(parseInfo.regExp).exec(value);
    if (match === null) {
        return null;
    }
    // found a date format that matches the input.
    var groups = parseInfo.groups,
        year = null, month = null, date = null, weekDay = null,
        hour = 0, hourOffset, min = 0, sec = 0, msec = 0, tzMinOffset = null,
        pmHour = false;
    // iterate the format groups to extract and set the date fields.
    for ( var j = 0, jl = groups.length; j < jl; j++ ) {
        var matchGroup = match[ j + 1 ];
        if ( matchGroup ) {
            var current = groups[ j ],
                clength = current.length,
                matchInt = parseInt( matchGroup, 10 );
            
            switch ( current ) {
                case dateFormat.DAY_OF_MONTH_DOUBLE_DIGIT: case dateFormat.DAY_OF_MONTH_SINGLE_DIGIT:
                    date = matchInt;
                    if ( valueOutOfRange( date, 1, 31 ) ) return null;
                    break;
                case dateFormat.MONTH_THREE_LETTER:
                case dateFormat.MONTH_FULL_NAME:
                    month = getIndexOfMonth( cal, matchGroup, clength === 3 );
                    if ( valueOutOfRange( month, 0, 11 ) ) return null;
                    break;
                case dateFormat.MONTH_SINGLE_DIGIT: case dateFormat.MONTH_DOUBLE_DIGIT:
                    month = matchInt - 1;
                    if ( valueOutOfRange( month, 0, 11 ) ) return null;
                    break;
                case dateFormat.YEAR_SINGLE_DIGIT: case dateFormat.YEAR_DOUBLE_DIGIT:
                case dateFormat.YEAR_FULL:
                    year = clength < 4 ? expandYear( cal, matchInt ) : matchInt;
                    if ( valueOutOfRange( year, 0, 9999 ) ) return null;
                    break;
                case dateFormat.HOURS_SINGLE_DIGIT_12_HOUR_CLOCK: case dateFormat.HOURS_DOUBLE_DIGIT_12_HOUR_CLOCK:
                    hour = matchInt;
                    if ( hour === 12 ) hour = 0;
                    if ( valueOutOfRange( hour, 0, 11 ) ) return null;
                    break;
                case dateFormat.HOURS_SINGLE_DIGIT_24_HOUR_CLOCK: case dateFormat.HOURS_DOUBLE_DIGIT_24_HOUR_CLOCK:
                    hour = matchInt;
                    if ( valueOutOfRange( hour, 0, 23 ) ) return null;
                    break;
                case dateFormat.MINUTES_SINGLE_DIGIT: case dateFormat.MINUTES_DOUBLE_DIGIT:
                    min = matchInt;
                    if ( valueOutOfRange( min, 0, 59 ) ) return null;
                    break;
                case dateFormat.SECONDS_SINGLE_DIGIT: case dateFormat.SECONDS_DOUBLE_DIGIT:
                    sec = matchInt;
                    if ( valueOutOfRange( sec, 0, 59 ) ) return null;
                    break;
                case dateFormat.MERIDIAN_INDICATOR_FULL: case dateFormat.MERIDIAN_INDICATOR_SINGLE:
                    pmHour = cal.PM && ( matchGroup === cal.PM[0] || matchGroup === cal.PM[1] || matchGroup === cal.PM[2] );
                    if ( !pmHour && ( !cal.AM || (matchGroup !== cal.AM[0] && matchGroup !== cal.AM[1] && matchGroup !== cal.AM[2]) ) ) return null;
                    break;
                case dateFormat.DECISECONDS:
                case dateFormat.CENTISECONDS:
                case dateFormat.MILLISECONDS:
                    msec = matchInt * Math.pow( 10, 3-clength );
                    if ( valueOutOfRange( msec, 0, 999 ) ) return null;
                    break;
                case dateFormat.DAY_OF_WEEK_THREE_LETTER:
                    date = parseDayByInt(value, format, culture, cal);
                    break;
                case dateFormat.DAY_OF_WEEK_FULL_NAME:
                     getIndexOfDay( cal, matchGroup, clength === 3 );
                    if ( valueOutOfRange( weekDay, 0, 6 ) ) return null;
                    break;
                case dateFormat.TIME_ZONE_OFFSET_FULL:
                    var offsets = matchGroup.split( /:/ );
                    if ( offsets.length !== 2 ) return null;

                    hourOffset = parseInt( offsets[ 0 ], 10 );
                    if ( valueOutOfRange( hourOffset, -12, 13 ) ) return null;
                    
                    var minOffset = parseInt( offsets[ 1 ], 10 );
                    if ( valueOutOfRange( minOffset, 0, 59 ) ) return null;
                    
                    tzMinOffset = (hourOffset * 60) + (patternStartsWith( matchGroup, '-' ) ? -minOffset : minOffset);
                    break;
                case dateFormat.TIME_ZONE_OFFSET_SINGLE_DIGIT: case dateFormat.TIME_ZONE_OFFSET_DOUBLE_DIGIT:
                    // Time zone offset in +/- hours.
                    hourOffset = matchInt;
                    if ( valueOutOfRange( hourOffset, -12, 13 ) ) return null;
                    tzMinOffset = hourOffset * 60;
                    break;
            }
        }
    }
    var result = new Date(), defaultYear, convert = cal.convert;
    defaultYear = convert ? convert.fromGregorian( result )[ 0 ] : result.getFullYear();
    if ( year === null ) {
        year = defaultYear;
    }
    
    // set default day and month to 1 and January, so if unspecified, these are the defaults
    // instead of the current day/month.
    if ( month === null ) {
        month = 0;
    }
    if ( date === null ) {
        date = 1;
    }
    // now have year, month, and date, but in the culture's calendar.
    if ( convert ) {
        result = convert.toGregorian( year, month, date );
        if ( result === null ) return null;
    }
    else {
        // have to set year, month and date together to avoid overflow based on current date.
        result.setFullYear( year, month, date );
        // check to see if date overflowed for specified month (only checked 1-31 above).
        if ( result.getDate() !== date ) return null;
        // invalid day of week.
        if ( weekDay !== null && result.getDay() !== weekDay ) {
            return null;
        }
    }
    // if pm designator token was found make sure the hours fit the 24-hour clock.
    if ( pmHour && hour < 12 ) {
        hour += 12;
    }
    result.setHours( hour, min, sec, msec );
    if ( tzMinOffset !== null ) {
        var adjustedMin = result.getMinutes() - ( tzMinOffset + result.getTimezoneOffset() );
        result.setHours( result.getHours() + parseInt( adjustedMin / 60, 10 ), adjustedMin % 60 );
    }
    return result;
}


function formatDateToCulture(value, format, culture) {
    var cal = culture.calendar,
        convert = cal.convert;
    if ( !format || !format.length || format === 'i' ) {
        var ret;
        if ( culture && culture.name.length ) {
            if ( convert ) {
                // non-gregorian calendar, so we cannot use built-in toLocaleString()
                ret = formatDateToCulture( value, cal.patterns.F, culture );
            }
            else {
                ret = value.toLocaleString();
            }
        }
        else {
            ret = value.toString();
        }
        return ret;
    }

    var sortable = format === "s";
        format = getFullDateFormat(cal, format);


    // Start with an empty string
    ret = [];
    var hour,
        zeros = ['0','00','000'],
        foundDay,
        checkedDay,
        dayPartRegExp = /([^d]|^)(d|dd)([^d]|$)/g,
        quoteCount = 0,
        tokenRegExp = /\/|dddd|ddd|dd|d|MMMM|MMM|MM|M|yyyy|yy|y|hh|h|HH|H|mm|m|ss|s|tt|t|fff|ff|f|zzz|zz|z|gg|g/g,
        converted;

    function padWithZeros(num, c) {
        var r, s = num+'';
        if ( c > 1 && s.length < c ) {
            r = ( zeros[ c - 2 ] + s);
            return r.substr( r.length - c, c );
        }
        else {
            r = s;
        }
        return r;
    }

    function hasDay() {
        if ( foundDay || checkedDay ) {
            return foundDay;
        }
        foundDay = dayPartRegExp.test( format );
        checkedDay = true;
        return foundDay;
    }

    if ( !sortable && convert ) {
        converted = convert.fromGregorian( value );
    }

    for (;;) {
        // Save the current index
        var index = tokenRegExp.lastIndex,
            // Look for the next pattern
            ar = tokenRegExp.exec( format );

        // Append the text before the pattern (or the end of the string if not found)
        var preMatch = format.slice( index, ar ? ar.index : format.length );
        quoteCount += appendMatchStringCount( preMatch, ret );

        if ( !ar ) {
            break;
        }

        // do not replace any matches that occur inside a string literal.
        if ( quoteCount % 2 ) {
            ret.push( ar[ 0 ] );
            continue;
        }

        var current = ar[ 0 ],
            clength = current.length;


        switch ( current ) {
            case dateFormat.DAY_OF_WEEK_THREE_LETTER:
            case dateFormat.DAY_OF_WEEK_FULL_NAME:
                var names = (clength === 3) ? cal.days.namesAbbr : cal.days.names;
                ret.push( names[ value.getDay() ] );
                break;
            case dateFormat.DAY_OF_MONTH_SINGLE_DIGIT:
            case dateFormat.DAY_OF_MONTH_DOUBLE_DIGIT:
                foundDay = true;
                ret.push( padWithZeros( (converted ? converted[2] : value.getDate()), clength ) );
                break;
            case dateFormat.MONTH_THREE_LETTER:
            case dateFormat.MONTH_FULL_NAME:
                var part = converted ? converted[1] : value.getMonth();
                ret.push( (cal.monthsGenitive && hasDay())
                    ? cal.monthsGenitive[ clength === 3 ? "namesAbbr" : "names" ][ part ]
                    : cal.months[ clength === 3 ? "namesAbbr" : "names" ][ part ] );
                break;
            case dateFormat.MONTH_SINGLE_DIGIT:
            case dateFormat.MONTH_DOUBLE_DIGIT:
                ret.push( padWithZeros((converted ? converted[1] : value.getMonth()) + 1, clength ) );
                break;
            case dateFormat.YEAR_SINGLE_DIGIT:
            case dateFormat.YEAR_DOUBLE_DIGIT:
            case dateFormat.YEAR_FULL:
                part = converted ? converted[ 0 ] : value.getFullYear();
                if ( clength < 4 ) {
                    part = part % 100;
                }
                ret.push( padWithZeros( part, clength ) );
                break;
            case dateFormat.HOURS_SINGLE_DIGIT_12_HOUR_CLOCK:
            case dateFormat.HOURS_DOUBLE_DIGIT_12_HOUR_CLOCK:
                hour = value.getHours() % 12;
                if ( hour === 0 ) hour = 12;
                ret.push( padWithZeros( hour, clength ) );
                break;
            case dateFormat.HOURS_SINGLE_DIGIT_24_HOUR_CLOCK:
            case dateFormat.HOURS_DOUBLE_DIGIT_24_HOUR_CLOCK:
                ret.push( padWithZeros( value.getHours(), clength ) );
                break;
            case dateFormat.MINUTES_SINGLE_DIGIT:
            case dateFormat.MINUTES_DOUBLE_DIGIT:
                ret.push( padWithZeros( value.getMinutes(), clength ) );
                break;
            case dateFormat.SECONDS_SINGLE_DIGIT:
            case dateFormat.SECONDS_DOUBLE_DIGIT:
                ret.push( padWithZeros(value .getSeconds(), clength ) );
                break;
            case dateFormat.MERIDIAN_INDICATOR_SINGLE:
            case dateFormat.MERIDIAN_INDICATOR_FULL:
                part = value.getHours() < 12 ? (cal.AM ? cal.AM[0] : " ") : (cal.PM ? cal.PM[0] : " ");
                ret.push( clength === 1 ? part.charAt( 0 ) : part );
                break;
            case dateFormat.DECISECONDS:
            case dateFormat.CENTISECONDS:
            case dateFormat.MILLISECONDS:
                ret.push( padWithZeros( value.getMilliseconds(), 3 ).substr( 0, clength ) );
                break;
            case dateFormat.TIME_ZONE_OFFSET_SINGLE_DIGIT:
            case dateFormat.TIME_ZONE_OFFSET_DOUBLE_DIGIT:
                hour = value.getTimezoneOffset() / 60;
                ret.push( (hour <= 0 ? '+' : '-') + padWithZeros( Math.floor( Math.abs( hour ) ), clength ) );
                break;
            case dateFormat.TIME_ZONE_OFFSET_FULL:
                hour = value.getTimezoneOffset() / 60;
                ret.push( (hour <= 0 ? '+' : '-') + padWithZeros( Math.floor( Math.abs( hour ) ), 2 ) +
                    ":" + padWithZeros( Math.abs( value.getTimezoneOffset() % 60 ), 2 ) );
                break;
            case dateFormat.DATE_SEPARATOR:
                ret.push( cal["/"] || "/" );
                break;
            default:
                throw "Invalid date format pattern '" + current + "'.";
                break;
        }
    }
    return ret.join( '' );
}

//add new culture into ej 
ej.globalize.addCulture = function (name, culture) {
    ej.cultures[name] = $.extend(true, $.extend(true, {}, ej.cultures['default'], culture), ej.cultures[name]);
	ej.cultures[name].calendar = ej.cultures[name].calendars.standard;
}

//return the specified culture or default if not found
ej.globalize.preferredCulture = function (culture) {
    culture = (typeof culture != "undefined" && typeof culture === typeof this.cultureObject) ? culture.name : culture;
    this.cultureObject = ej.globalize.findCulture(culture);
    return this.cultureObject;
}
ej.globalize.setCulture = function (culture) {
	if (ej.isNullOrUndefined(this.globalCultureObject)) this.globalCultureObject = ej.globalize.findCulture(culture);
	culture = (typeof culture != "undefined" && typeof culture === typeof this.globalCultureObject) ? culture.name : culture;
    if (culture) this.globalCultureObject = ej.globalize.findCulture(culture);
    ej.cultures.current = this.globalCultureObject;
    return this.globalCultureObject;
}
ej.globalize.culture=function(name){
    ej.cultures.current = ej.globalize.findCulture(name);
}

//return the specified culture or current else default if not found
ej.globalize.findCulture = function (culture) {
    var cultureObject;
    if (culture) {

        if ($.isPlainObject(culture) && culture.numberFormat) {
            cultureObject = culture;
        }
        if (typeof culture === "string") {
            var cultures = ej.cultures;
            if (cultures[culture]) {
                return cultures[culture];
            }
            else {
                if (culture.indexOf("-") > -1) {
                    var cultureShortName = culture.split("-")[0];
                    if (cultures[cultureShortName]) {
                        return cultures[cultureShortName];
                    }
                }
                else {
                    var cultureArray = $.map(cultures, function (el) { return el });
                    for (var i = 0; i < cultureArray.length; i++) {
                        var shortName = cultureArray[i].name.split("-")[0];
                        if (shortName === culture) {
                            return cultureArray[i];
                        }
                    };
                }
            }
            return ej.cultures["default"];
        }
    }
    else {
        cultureObject = ej.cultures.current || ej.cultures["default"];
    }

    return cultureObject;
}
//formatting date and number based on given format
ej.globalize.format = function (value, format, culture) {
    var cultureObject =  ej.globalize.findCulture(culture);
    if (typeof(value) === 'number') {
        value = formatNumberToCulture(value, format, cultureObject);
    } else if(value instanceof Date){
    	value = formatDateToCulture(value, format, cultureObject);
    }

    return value;
}

//parsing integer takes string as input and return as number
ej.globalize.parseInt = function(value, radix, culture) {
	if(!radix)
		radix = 10;
    return Math.floor( parseValue( value, culture, radix ) );
}

//returns the ISO date string from date object
ej.globalize.getISODate = function(value) {
    if(value instanceof Date) return value.toISOString();
}

//parsing floationg poing number takes string as input and return as number
ej.globalize.parseFloat = function(value, radix, culture) {
	if (typeof radix === "string") {
        culture = radix;
        radix = 10;
    }
    return parseValue( value, culture);
}

//parsing date takes string as input and return as date object
ej.globalize.parseDate = function(value, formats, culture) {
    culture = ej.globalize.findCulture(culture);

    var date, prop, patterns;
    if ( formats ) {
        if ( typeof formats === "string" ) {
            formats = [ formats ];
        }
        if ( formats.length ) {
            for ( var i = 0, l = formats.length; i < l; i++ ) {
                var format = formats[ i ];
                if ( format ) {
                    date = getParsedDate( value, format, culture );
                    if ( date ) break;
                }
            }
        }
    }
    else {
        patterns = culture.calendar.patterns;
        for ( prop in patterns ) {
            date = getParsedDate( value, patterns[prop], culture );
            if ( date ) break;
        }
    }
    return date || null;
}

function getControlObject(obj, stringArray){
    return stringArray.length ? getControlObject(obj[stringArray[0]], stringArray.slice(1)) : obj;
}

//return localized constants as object for the given widget control and culture
ej.globalize.getLocalizedConstants = function(controlName, culture){
    var returnObject,
        controlNameArray = controlName.replace("ej.", "").split(".");
    
    returnObject = getControlObject(ej, controlNameArray);

    return ( $.extend(true, {}, returnObject.Locale['default'], returnObject.Locale[culture ? culture : this.cultureObject.name]) ) ;
}

$.extend(ej, ej.globalize);

}(jQuery));;
/**
* @fileOverview Plugin to style the Html Button elements
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, undefined) {

    ej.widget("ejButton", "ej.Button", {

        element: null,

        model: null,
        validTags: ["button", "input"],
        _setFirst: false,

        _rootCSS: "e-button",
        _requiresID: true,

        defaults: {

            size: "normal",

            type: "submit",

            height: "",

            width: "",

            enabled: true,

            htmlAttributes: {},

            text: null,

            contentType: "textonly",

            imagePosition: "imageleft",

            showRoundedCorner: false,

            cssClass: "",

            prefixIcon: null,

            suffixIcon: null,

            enableRTL: false,

            repeatButton: false,

            timeInterval: "150",

            create: null,

            click: null,

            destroy: null
        },


        dataTypes: {
            size: "enum",
            enabled: "boolean",
            type: "enum",
            showRoundedCorner: "boolean",
            text: "string",
            contentType: "enum",
            imagePosition: "enum",
            prefixIcon: "string",
            suffixIcon: "string",
            cssClass: "string",
            repeatButton: "boolean",
            enableRTL: "boolean",
            timeInterval: "string",
            htmlAttributes: "data"
        },

        disable: function () {
            this.element.addClass("e-disable").attr("aria-disabled", true);
            this.model.enabled = false;
        },

        enable: function () {
            this.element.removeClass("e-disable").attr("aria-disabled", false);
            this.model.enabled = true;
        },

        _init: function () {
            this._cloneElement = this.element.clone();
            this._initialize();
            this._render();
            this._controlStatus(this.model.enabled);
            this._wireEvents(this.model.repeatButton);
            this._addAttr(this.model.htmlAttributes);
        },
        _addAttr: function (htmlAttr) {
            var proxy = this;
            $.map(htmlAttr, function (value, key) {
                if (key == "class") proxy.element.addClass(value);
                else proxy.element.attr(key, value);
                if (key == "disabled" && value == "disabled") proxy.disable();
            });
        },

        _destroy: function () {
            this._off(this.element, "blur", this._btnBlur);
            this.element.removeClass(this.model.cssClass + "e-ntouch e-btn e-txt e-select e-disable e-corner e-widget").removeAttr("role aria-describedby aria-disabled");
            !this._cloneElement.attr("type") && this.element.attr("type") && this.element.removeAttr("type");			
            this.element.removeClass("e-btn-" + this.model.size);
            this.model.contentType && this.model.contentType != "textonly" ? this.element.append(this._cloneElement.text()) && this.imgtxtwrap[0].remove() : "";
            
        },


        _setModel: function (options) {
            var option;
            for (option in options) {
                switch (option) {
                    case "size":
                        this._setSize(options[option]);
                        break;
                    case "height":
                        this._setHeight(options[option]);
                        break;
                    case "width":
                        this._setWidth(options[option]);
                        break;
                    case "contentType":
                        this._setContentType(options[option]);
                        break;
                    case "imagePosition":
                        this._setImagePosition(options[option]);
                        break;
                    case "text":
                        this._setText(options[option]);
                        break;
                    case "prefixIcon":
                        if (!this.element.is("input"))
                        this._setMajorIcon(options[option]);
                        break;
                    case "suffixIcon":
                        if (!this.element.is("input"))
                        this._setMinorIcon(options[option]);
                        break;
                    case "enabled":
                        this._controlStatus(options[option]);
                        break;
                    case "showRoundedCorner":
                        this._roundedCorner(options[option]);
                        break;
                    case "cssClass":
                        this._setSkin(options[option]);
                        break;
                    case "enableRTL":
                        this._setRTL(options[option]);
                        break;
                    case "timeInterval":
                        this.model.timeInterval = options[option];
                        break;
                    case "htmlAttributes": this._addAttr(options[option]); break;
                }
            }
        },


        _setSize: function (val) {
            this.element.removeClass('e-btn-mini e-btn-medium e-btn-small e-btn-large e-btn-normal');
            this.element.addClass("e-btn-" + val);
        },
        _setType: function (val) {
            this.element.prop({ "type": val });
        },

        _setHeight: function (val) {
            this.element.css('height', val);
        },

        _setWidth: function (val) {
            this.element.css('width', val);
        },

        _setText: function (val) {
            if (this.buttonType == "inputButton") {
                this.element.val(val);
            } else {
                if (this.model.contentType == ej.ContentType.TextOnly) {
                    this.element.html(val);
                } else {
                    this.textspan.html(val);
                }
            }
            this.model.text = val;
        },

        _setMajorIcon: function (val) {
            this.majorimgtag.removeClass(this.model.prefixIcon);
            this.majorimgtag.addClass(val);
            this.model.prefixIcon = val;
        },

        _setMinorIcon: function (val) {
            this.minorimgtag.removeClass(this.model.suffixIcon);
            this.minorimgtag.addClass(val);
            this.model.suffixIcon = val;
        },

        _setContentType: function (val) {
            if (val != this.model.contentType) {
                this.element.empty();
                this.model.contentType = val;
                if (!this.element.is("input"))
                this._renderButtonNormal();
            }
        },

        _setImagePosition: function (val) {
            if ((this.model.contentType == ej.ContentType.TextAndImage) && (val != this.model.imagePosition)) {
                this.element.empty();
                this.model.imagePosition = val;
                if (!this.element.is("input"))
                this._renderButtonNormal();
            }
        },

        _setRTL: function (val) {
            if (val) {
                this.element.addClass("e-rtl");
            } else {
                this.element.removeClass("e-rtl");
            }
        },

        _controlStatus: function (value) {
            if (!value) {
                this.disable();
            } else {
                this.enable();
            }
        },

        _setSkin: function (skin) {
            if (this.model.cssClass != skin) {
                this.element.removeClass(this.model.cssClass);
                this.element.addClass(skin);
            }
        },

        _initialize: function () {
            if(!ej.isTouchDevice()) this.element.addClass("e-ntouch");
            if (this.element.is("input")) {
                this.buttonType = "inputButton";
            }
            else if ((this.element.is("a")) || (this.element.is("button"))) {
                this.buttonType = "tagButton";
            }
            else {
                this.element.removeClass("e-button");
            }
            if (this.element.attr("type")) {
                this.model.type = this.element.attr("type");
            }
            else
                this._setType(this.model.type);
            this._timeout = null;
        },


        _render: function () {
            this._setSize(this.model.size);
            this._setHeight(this.model.height);
            this._setWidth(this.model.width);
            this._setRTL(this.model.enableRTL);
            this.element.addClass(this.model.cssClass + " e-btn e-select e-widget").attr("role", "button");
            if (this.buttonType == "inputButton") {
                this.element.addClass("e-txt");
                if ((this.model.text != null) && (this.model.text != "")) {
                    this.element.val(this.model.text);
                } else {
                    this.model.text = this.element.val();
                }
            } else { this._renderButtonNormal(); }
            this._roundedCorner(this.model.showRoundedCorner);
            if (this.element[0].id)
                this.element.attr("aria-describedby", this.element[0].id);
        },

        _renderButtonNormal: function () {
            if ((this.model.text == null) || (this.model.text == "")) {
                this.model.text = this.element.html();
            }
            this.element.empty();
            /*Image and Text*/
            this.textspan = ej.buildTag('span.e-btntxt', this.model.text);
            if (this.model.contentType.indexOf("image") > -1) {
                this.majorimgtag = ej.buildTag('span').addClass(this.model.prefixIcon);
                this.minorimgtag = ej.buildTag('span').addClass(this.model.suffixIcon);
                this.imgtxtwrap = ej.buildTag('span').addClass('e-btn-span');
            }

            if (this.model.contentType == ej.ContentType.TextAndImage) {
                switch (this.model.imagePosition) {
                    case ej.ImagePosition.ImageRight:
                        this.imgtxtwrap.append(this.textspan, this.majorimgtag);
                        break;
                    case ej.ImagePosition.ImageLeft:
                        this.imgtxtwrap.append(this.majorimgtag, this.textspan);
                        break;
                    case ej.ImagePosition.ImageBottom:
                        this.majorimgtag.attr("style", "display:inherit");
                        this.imgtxtwrap.append(this.textspan, this.majorimgtag);
                        break;
                    case ej.ImagePosition.ImageTop:
                        this.majorimgtag.attr("style", "display:inherit");
                        this.imgtxtwrap.append(this.majorimgtag, this.textspan);
                        break;
                }
                this.element.append(this.imgtxtwrap);
            } else if (this.model.contentType == ej.ContentType.ImageTextImage) {
                this.imgtxtwrap.append(this.majorimgtag, this.textspan, this.minorimgtag);
                this.element.append(this.imgtxtwrap);
            } else if (this.model.contentType == ej.ContentType.ImageBoth) {
                this.imgtxtwrap.append(this.majorimgtag, this.minorimgtag);
                this.element.append(this.imgtxtwrap);
            } else if (this.model.contentType == ej.ContentType.ImageOnly) {
                this.imgtxtwrap.append(this.majorimgtag);
                this.element.append(this.imgtxtwrap);
            } else {
                this.element.addClass("e-txt");
                this.element.html(this.model.text);
            }
        },

        _roundedCorner: function (value) {
            value == true ? this.element.addClass('e-corner') : this.element.removeClass('e-corner');
        },

        _wireEvents: function (val) {
            if (val) {
                this._on(this.element, "mousedown", this._btnRepatMouseClickEvent);
                this._on($(document), 'mouseup', this._mouseUpClick);
                this._on(this.element, "keyup", this._btnRepatKeyUpEvent);
                this._on($(document), "keypress", this._btnRepatKeyDownEvent);

            }
            this._on(this.element, "click", this._btnMouseClickEvent);
            this._on(this.element, "blur", this._btnBlur);
        },

        _btnBlur:function(e){
            this.element.removeClass("e-animate");
        },

        _btnMouseClickEvent: function (e) {
            var self = this;
            this.element.addClass("e-animate");
            if(!self.model.enabled) return false;
            if (!self.element.hasClass("e-disable")) {
                // here aregument 'e' used in serverside events 
                var args = { target: e.currentTarget, e : e , status:self.model.enabled};
				//Trigger _click function to apply scope changes
                self._trigger("_click", args);
                self._trigger("click", args);
            } 
        },

        _btnRepatMouseClickEvent: function (e) {
            var self = this;
            if(!self.model.enabled) return false;
            if (!self.element.hasClass("e-disable")) {
                var args = { status: self.model.enabled };
                if ((e.button == 0) || (e.which == 1)) {

                    self._timeout = setInterval(function () { self._trigger("click", { target: e.currentTarget, status: self.model.enabled }); }, this.model.timeInterval);
                }
            }
        },

        _mouseUpClick: function (event) {
            clearTimeout(this._timeout);
        },

        _btnRepatKeyDownEvent: function (e) {
            var self = this;
            if (!self.element.hasClass("e-disable")) {
                var args = { status: self.model.enabled };
                if ((e.keyCode == 32) || (e.keyCode == 13)) {
                    self._trigger("click", args);
                }
            }
        },

        _btnRepatKeyUpEvent: function (e) {
            if ((e.keyCode == 32) || (e.keyCode == 13)) {
                clearTimeout(this._timeout);
            }
        },
    });


    ej.ContentType = {
		/**  Supports only for text content only */
		TextOnly: "textonly", 
		/** Supports only for image content only */
		ImageOnly: "imageonly", 
		/** Supports image for both ends of the button */
		ImageBoth: "imageboth", 
		/** Supports image with the text content */
		TextAndImage: "textandimage", 
		/** Supports image with both ends of the text */
        ImageTextImage: "imagetextimage"
    };


    ej.ImagePosition = {
		/**  support for aligning text in left and image in right. */
		ImageRight: "imageright", 
		/**  support for aligning text in right and image in left. */
		ImageLeft: "imageleft",
		/**  support for aligning text in bottom and image in top. */
		ImageTop: "imagetop", 
		/**  support for aligning text in top and image in bottom. */
		ImageBottom: "imagebottom"
    };

    ej.ButtonSize = {
		/**  Creates button with inbuilt default size height, width specified */
		Normal : "normal",
		/**  Creates button with inbuilt mini size height, width specified */
		Mini: "mini", 
		/**  Creates button with inbuilt small size height, width specified */
		Small: "small",
		/**  Creates button with inbuilt medium size height, width specified */
		Medium:"medium", 
		/**  Creates button with inbuilt large size height, width specified */
        Large: "large"
    };

    ej.ButtonType = {
		/**  Creates button with inbuilt button type specified */
		Button : "button",
		/**  Creates button with inbuilt reset type specified */
		Reset: "reset", 
		/**  Creates button with inbuilt submit type specified */
		Submit: "submit"
    };
})(jQuery, Syncfusion);
;
/**
* @fileOverview Plugin to style the Html div elements
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, undefined) {

    ej.widget("ejSlider", "ej.Slider", {

        element: null,

        model: null,
        validTags: ["div", "span"],
        _addToPersist: ["value", "values"],
        _rootCSS: "e-slider",
        _setFirst: false,
        _requiresID: true,

        defaults: {

            orientation: "horizontal",

            enableAnimation: true,

            animationSpeed: 500,

            showTooltip: true,

            cssClass: "",

            showRoundedCorner: false,

            readOnly: false,

            enableRTL: false,

            htmlAttributes: {},

            minValue: 0,

            maxValue: 100,

            sliderType: "default",

            value: null,

            values: null,

            incrementStep: 1,

            height: null,

            width: null,

            enabled: true,

            showScale: false,

            largeStep: 10,

            smallStep: 1,

            showSmallTicks: true,

            showButtons: false,

            enablePersistence: false,
            
            allowMouseWheel:false,

            start: null,

            stop: null,

            slide: null,

            change: null,

            create: null,

            destroy: null,

            tooltipChange: null,

            renderingTicks: null
        },

        dataTypes: {
            orientation: "enum",
            enableAnimation: "boolean",
            animationSpeed: "number",
            cssClass: "string",
            showRoundedCorner: "boolean",
            readOnly: "boolean",
            enableRTL: "boolean",
            minValue: "number",
            maxValue: "number",
            sliderType: "enum",
            incrementStep: "number",
            enabled: "boolean",
            showButtons: "boolean",
            showScale: "boolean",
            largeStep: "number",
            smallStep: "number",
            showSmallTicks: "boolean",
            enablePersistence: "boolean",
            htmlAttributes: "data",
            allowMouseWheel:"boolean"
        },

        observables: ["value", "values"],
        value: ej.util.valueFunction("value"),
        values: ej.util.valueFunction("values"),

        enable: function () {
            if (!this.model.enabled) {
                this.model.enabled = true;
                if (this.wrapper) this.wrapper.removeClass("e-disable");
                this.element.removeClass("e-disable");
                if (this.model.showButtons) this.element.siblings('.e-sliderbtn').ejButton("model.enabled", this.model.enabled);
                this._wireEvents();
            }
        },

        disable: function () {
            if (this.model.enabled) {
                this.model.enabled = false;
                if (this.wrapper) this.wrapper.addClass("e-disable");
                this.element.addClass("e-disable");
                if (this.model.showButtons) this.element.siblings('.e-sliderbtn').ejButton("model.enabled", this.model.enabled);
                this._unWireEvents();
            }
        },

        _validateValue: function (value, animation) {
            animation = (typeof animation === 'undefined') ? false : animation;
            if (value == null || value === "") value = this.model.minValue;
            else if (typeof value === "string") value = parseFloat(value);

            if (this._isNumber(value)) {
                this._hidden.val(value);
                this.value(value);
            }
            else if (!this._isNumber(this.value())) {
                this._hidden.val(this.model.minValue);
                this.value(this.model.minValue);
            }
            if (this.model.sliderType != "range") this._setValue(animation);
        },

        _validateRangeValue: function (value, animation) {
            animation = (typeof animation === 'undefined') ? false : animation;
            if (value == null) value = new Array(this.model.minValue, this.model.maxValue);
            else if (typeof value === "string") {
                var vals = value.split(",");
                if (vals.length > 1) value = new Array(parseFloat(vals[0]), parseFloat(vals[1]));
            }

            if (typeof value === "object" && this._isNumber(value[0]) && this._isNumber(value[1])) {
                this._hidden.val(new Array(value[0], value[1]));
                this.values(new Array(value[0], value[1]));
            }
            else if (!(typeof this.values() === "object" && this._isNumber(this.values()[0]) && this._isNumber(this.values()[1]))) {
                this._hidden.val(new Array(this.model.minValue, this.model.maxValue));
                this.values(new Array(this.model.minValue, this.model.maxValue));
            }
            if (this.model.sliderType == "range") this._setRangeValue(animation);
        },

        _validateStartEnd: function () {
            if (isNaN(this.model.minValue)) this.model.minValue = 0;
            if (isNaN(this.model.maxValue)) this.model.maxValue = 100;
        },

        _isNumber: function (number) {
            return typeof number === "number" && !isNaN(number);
        },

        _outerCorner: function (boolean) {
            if (boolean) this._roundedCorner();
            else this._sharpedCorner();
        },

        _changeSkin: function (skin) {
            this.element.removeClass(this.model.cssClass).addClass(skin);
            if (this.model.showScale)
                this.ul.removeClass(this.model.cssClass).addClass(skin);
        },

        getValue: function () {

            return this._getHandleValue();
        },

        setValue: function (value, animation) {
            this._isInteraction = false;
            if (this.model.sliderType == "range")
                this._validateRangeValue(value, animation);
            else
                this._validateValue(value, animation);
            this._isInteraction = true;
        },

        _getTransition: function () {
            var body = document.body || document.documentElement, bodyStyle = body.style,
                support = bodyStyle.transition !== undefined || bodyStyle.WebkitTransition !== undefined || bodyStyle.MozTransition !== undefined || bodyStyle.MsTransition !== undefined || bodyStyle.OTransition !== undefined;
            return support;
        },

        _init: function () {
            this._isInteraction = true;
            this._isTransition = this._getTransition();
            this._initialize();
            this._render();
        },

        _setModel: function (options) {
            this._isInteraction = false;
            if (!ej.isNullOrUndefined(options["minValue"]) || !ej.isNullOrUndefined(options["maxValue"])) {
                if (this._isNumber(options["minValue"])) this.model.minValue = options["minValue"];
                else options["minValue"] = this.model.minValue;

                if (this._isNumber(options["maxValue"])) this.model.maxValue = options["maxValue"];
                else options["maxValue"] = this.model.maxValue;

                if (this.model.sliderType == "range" && options["values"] == undefined) this._setRangeValue();
                else if (this.model.sliderType != "range" && options["value"] == undefined) this._setValue();
            }

            var option;
            for (option in options) {
                switch (option) {
                    case "value":
                        this._validateValue(ej.util.getVal(options[option]));
                        options[option] = this.model.value;
                        break;
                    case "values":
                        var val= typeof options.values == "function" ? options.values() : options.values;
                        if (!ej.isNullOrUndefined(val) && !ej.isNullOrUndefined(val.length) && typeof val != "string")
                        {
                            if (!isNaN(val[0]) && !isNaN(val[1])) {
                                var actualValue = typeof this.values().join == "function" ? val.join() : val;
                                if (actualValue == this._hidden.val()) break;
                            }
                        }
                        this._validateRangeValue(ej.util.getVal(options[option]));
                        options[option] = this.model.values;
                        break;
                    case "height": this.model.height = options[option]; this._setDimension();
                        if (this.model.showScale) this._scaleAlignment();
                        break;
                    case "width": this.model.width = options[option]; this._setDimension();
                        if (this.model.showScale) this._scaleAlignment();
                        break;
                    case "enabled": this._disabled(!options[option]); break;
                    case "showRoundedCorner": this._outerCorner(options[option]); break;
                    case "enableRTL": this.model.enableRTL = options[option];
                        if (this.model.showButtons) this._valueChanged = true;
                        this._checkRTL();
                        options[option] = this.model.enableRTL;
                        break;
                    case "cssClass": this._changeSkin(options[option]);
                        if (this.model.showButtons) this.element.siblings('.e-sliderbtn').ejButton("model.cssClass", options[option]);
                        break;
                    case "showScale": this._renderScale(options[option]);
                        if (this.model.enableRTL) this._changeVerticalScaleDir(options[option]); break;
                    case "orientation":
                        var t = this.model.height;
                        this.model.height = this.model.width;
                        this.model.width = t;
                    case "sliderType":
                        this._sliderOptions(option, options[option]); break;
                    case "smallStep":
                    case "largeStep":
                    case "showSmallTicks":
                    case "minValue":
                    case "maxValue":
                        this._scaleOptions(option, options[option]); break;
                    case "htmlAttributes": this._addAttr(options[option]); break;
                    case "tooltipChange":
                        this.model.tooltipChange = options[option]; break;
                    case "allowMouseWheel": this.model.allowMouseWheel = options[option]; break;
                    case "renderingTicks": this.model.renderingTicks = options[option]; break;
                    case "showButtons": this.model.showButtons = options[option]; this._renderButtons(); break;
                }
            }
            this._isInteraction = true;
        },

        _destroy: function () {
            if (this.model.showScale) this._destroyScale();
            this.element.insertAfter(this.wrapper);
            this.wrapper.remove();
            this.element.removeClass("e-widget e-box e-corner " + this.model.cssClass).empty();
            if (this.model.showButtons) this.element.removeAttr("style");
        },

        _initialize: function () {
            this.target = this.element[0];
            this.horDir = "left";
            this.verDir = "bottom";
            this._isFocused = false;
        },

        _render: function () {
            this.initialRender = true;
            this._isIE8 = (ej.browserInfo().name == 'msie' && ej.browserInfo().version == '8.0') ? true : false
            this.wrapper = ej.buildTag("div.e-slider-wrap e-widget" + this.model.cssClass + "#" + this.target.id + "_wrapper", { tabindex: "0", role: "slider" })
                .insertAfter(this.element);
            (this.model.showButtons) ? this._showButtons() : this.wrapper.append(this.element);

            this.element.addClass("e-widget e-box " + this.model.cssClass);
            if (this.model.sliderType != "default") {
                this.header = ej.buildTag("div.e-range");
                this.element.append(this.header);
                if (this.model.sliderType == "range") {
                    this.secondHandle = this._createHandle();
                }
            }
            this.firstHandle = this._createHandle();
            this._setOrientation();
            this._setDimension();
            this._insertHiddenField();
            this._checkProperties();
            if(!this.model.showScale) this._alignButtons();
            this._addAttr(this.model.htmlAttributes);
            this._setSliderValue();
        },

        _showButtons: function () {
            var proxy = this;
            var decreaseButton = ej.buildTag('button.e-decreasebtn e-sliderbtn e-animate');
            var increaseButton = ej.buildTag('button.e-increasebtn e-sliderbtn e-animate');
            decreaseButton.ejButton({
                contentType: "imageonly",
                prefixIcon: "e-icon e-minus",
                type: "button",
                repeatButton: true,
                enabled: proxy.model.enabled,
                cssClass: proxy.model.cssClass,
                click: function (e) { proxy._clickButtons(e) }
            });
            increaseButton.ejButton({
                contentType: "imageonly",
                prefixIcon: "e-icon e-plus",
                type: "button",
                repeatButton: true,
                enabled: proxy.model.enabled,
                cssClass: proxy.model.cssClass,
                click: function (e) { proxy._clickButtons(e) }
            });
            if ((this.model.enableRTL && this.model.orientation == "horizontal") || (this.model.orientation == "vertical" && !this.model.enableRTL))
                this.wrapper.append($(increaseButton)).append(this.element).append($(decreaseButton)).addClass("e-slider-buttons");
            else this.wrapper.append($(decreaseButton)).append(this.element).append($(increaseButton)).addClass("e-slider-buttons");
            this.wrapper.find('.e-sliderbtn').attr("tabindex", -1);
        },

        _renderButtons: function () {
            if (this.model.showButtons) {
                this._showButtons();
                if(!this.model.showScale) this._alignButtons();
            }
            else {
                this.element.siblings('.e-sliderbtn').remove();
                this.element.removeAttr('style');
                this.wrapper.removeClass("e-slider-buttons");
            }
            if (this.wrapper.find('ul').hasClass('e-scale')) {
                this._destroyScale();
                this._renderScale(true);
            }
        },

        _alignButtons: function () {
            if (this.model.showButtons) {
                var sliderButtons = this.wrapper.find('.e-sliderbtn');
                if (this.model.orientation == "horizontal") 
                    sliderButtons.css("top", ((this.element.outerHeight() / 2) - parseFloat(sliderButtons.outerHeight() / 2) + parseFloat(this.wrapper.css("padding-top"))) + "px");
                else 
                    sliderButtons.css("left", ((this.element.outerWidth() / 2) - parseFloat(sliderButtons.outerWidth() / 2) + parseFloat(this.wrapper.css("padding-left"))) + "px");
            }
        },

        _clickButtons: function (evt) {
            if ($(evt.target).hasClass("e-animate"))
                $(evt.target).removeClass('e-animate');
            if (this.model.readOnly || ej.isNullOrUndefined(evt.target)) return;
            var value, hVal;
            if (this.model.sliderType == "range") {
                if ($(this.element).find('.e-handle.e-focus').is(this.firstHandle) && !this.model.enableRTL) { this.firstHandle.focus().addClass("e-no-tab"); hVal = this.handleVal; }
                else if (!this.model.enableRTL) { this.secondHandle.focus().addClass("e-no-tab"); hVal = this.handleVal2; }
                if ($(this.element).find('.e-handle.e-focus').is(this.secondHandle) && this.model.enableRTL) { this.secondHandle.focus().addClass("e-no-tab"); hVal = this.handleVal2; }
                else if (this.model.enableRTL) { this.firstHandle.focus().addClass("e-no-tab"); hVal = this.handleVal; }
            }
            else { this.firstHandle.focus().addClass("e-no-tab"); hVal = this.handleVal; }
            if ($(evt.target).hasClass("e-decreasebtn")) value = this._add(hVal, this.model.incrementStep, false);
            else value = this._add(hVal, this.model.incrementStep, true);
            this._changeHandleValue(value, false);
        },

        _addAttr: function (htmlAttr) {
            var proxy = this;
            $.map(htmlAttr, function (value, key) {
                if (key == "class") proxy.wrapper.addClass(value);
                else if (key == "disabled" && value == "disabled") proxy._disabled(true);
                else proxy.element.attr(key, value)
            });
        },

        _renderScale: function (showScale) {
            if (showScale) {
                this.wrapper.addClass("e-scale-wrap");
                var width = "width", orien = "h", spanText;
                if (this.model.orientation == "vertical") {
                    width = "height";
                    orien = "v";
                }

                var _smallStep = this.model.smallStep;
                if (!this.model.showSmallTicks) {
                    if (this.model.largeStep > 0)
                        _smallStep = this.model.largeStep;
                    else
                        _smallStep = this.model.maxValue - this.model.minValue;
                }
                else if (_smallStep <= 0)
                    _smallStep = this.model.incrementStep;
                var count = Math.abs(this.model.maxValue - this.model.minValue) / _smallStep;

                this.ul = ej.buildTag("ul.e-scale e-" + orien + "-scale " + this.model.cssClass);
                if (this._isIE8) this.ul.addClass('e-ie8')
                this.wrapper.append(this.ul);

                var li, args, start = this.model.minValue, left = 0, tickWidth = 100 / count;
                if (orien == "v") start = this.model.maxValue;
                for (var i = 0; i <= count; i++) {
                    li = ej.buildTag("li.e-tick", "", {}, { "title": start });
                    var islargeTick = (start % this.model.largeStep == 0) ? true : false;
                    if (islargeTick) li.addClass("e-large");
                    li.css(width, tickWidth + "%");
                    if (this.model.renderingTicks) {
                        args = { value: start, valueType: "tooltip", tick: li[0]};
                        this._trigger("renderingTicks", args);
                        li.attr("title", args.value);
                    }
                    if (islargeTick) {
                        if (this.model.renderingTicks) {
                            args.valueType = "label";
                            args.value = start;
                            this._trigger("renderingTicks", args);
                            spanText = args.value;
                        }
                        else spanText = start;
                        var span = ej.buildTag("span.e-tick-value", "" + spanText);
                        li.append(span);
                    }
                    this.ul.append(li);

                    if (orien == "h") start += _smallStep;
                    else start -= _smallStep;
                    left += _smallStep;
                }

                this.ul.children().first().addClass("e-first-tick").css(width, (tickWidth / 2) + "%");
                this.ul.children().last().addClass("e-last-tick").css(width, (tickWidth / 2) + "%");

                this._scaleAlignment();
            }
            else this._destroyScale();
            this._setWrapperHeight();
            this._alignButtons();
        },
        _destroyScale: function () {
            this.wrapper.removeClass("e-scale-wrap");
            this.ul.remove();
            this.ul = null;
        },

        _tickValuePosition: function () {
            var width = (this.model.orientation == "vertical") ? "height" : "width";
            var left = (this.model.orientation == "vertical") ? "top" : "left";
            var firstTick = this.ul.find(".e-tick.e-first-tick");
            var first = firstTick.find(".e-tick-value");
            var other = this.ul.find(".e-tick.e-large:not(.e-first-tick)").find(".e-tick-value");
            var tickWidth = firstTick[width]() * 2;
            first.css(left, -first[width]() / 2);
            other.css(left, (tickWidth - other[width]()) / 2);
        },

        _scaleAlignment: function () {
            this._tickValuePosition();
            var smallTick = 12, largeTick = 20, half = largeTick / 2;
            var height = "height", top = "top", orien = "h";
            if (this.model.orientation == "vertical") {
                height = "width";
                top = "right";
                orien = "v";
                (this.element.width() <= 15) ? this.wrapper.addClass("e-small-size") : this.wrapper.removeClass("e-small-size");
            }
            else
                (this.element.height() <= 15) ? this.wrapper.addClass("e-small-size") : this.wrapper.removeClass("e-small-size");
            // scale
             this.ul.css(top, -(this.wrapper[height]() + half));
            if(orien == "v") this.ul.css("top", -this.wrapper.height()).css(top, half);
            this.ul[height](this.wrapper[height]() + largeTick);
            // small-ticks
            var topSize = -(largeTick - smallTick) / 2;
            if (this.model.largeStep == null && orien != "v") topSize = -topSize;
            this.ul.find(".e-tick:not(.e-large)").css(height, this.wrapper[height]() + smallTick).css(top, topSize);
            // tick-values   // 4 - distance between tick value and tick
            if (orien == "v") this.ul.children(".e-large").find(".e-tick-value").css("right", this.wrapper.width() + largeTick + 4);
        },

        _setWrapperHeight : function(){
            var wrapHeight, wrapWidth;
            if (this.model.orientation == "horizontal") {
                if (this.ul)
                    wrapHeight = (this.firstHandle.outerHeight() > this.ul.height()) ? this.firstHandle.outerHeight() : this.ul.height();
                else wrapHeight = this.firstHandle.outerHeight();
                var top = (wrapHeight - this.element.outerHeight()) / 2;
                if (top < 0) top = 0;
                this.wrapper.css({ "padding": top + "px 0px" });
            }
            else {
                if (this.ul)
                    wrapWidth = (this.firstHandle.outerWidth() > this.ul.width()) ? this.firstHandle.outerWidth() : this.ul.width();
                else wrapWidth = this.firstHandle.outerWidth();
                var right = ( wrapWidth - this.element.outerWidth()) / 2;
                if (right < 0) right = 0;
                this.wrapper.css({ "padding": "0px " + right + "px" });
            }
        },


        _createHandle: function () {
			var handle = ej.buildTag("a.e-handle e-select", "", {}, { "aria-label": "drag", "tabindex": 0});
            this.element.attr({ role: "slider", "aria-valuemin": this.model.minValue, "aria-valuemax": this.model.maxValue });
            ej.browserInfo().name == "msie" && handle.addClass("e-pinch");
            this.element.append(handle);
            return handle;
        },

        _setDimension: function () {
            if (this.model.height) this.wrapper.height(this.model.height);
            if (this.model.width) this.wrapper.width(this.model.width);
            this._setHandleSize();
            this._handleAlignment(this.model.enableRTL);
            this._alignButtons();
        },

        _insertHiddenField: function () {
            this._hidden = ej.buildTag("input", "", {},
                { "type": "hidden", "name": this.element[0].id });
            this._hidden.val(this._getHandleValue());
            this.element.append(this._hidden);
        },

        _checkProperties: function () {
            if (!this.model.enabled) {
                if (this.wrapper) this.wrapper.addClass("e-disable");
                else this.element.addClass("e-disable");
            }
            else this._wireEvents();
			
            if (this.model.showScale) this._renderScale(true);
            else this._setWrapperHeight();
            if (this.model.enableRTL) this._checkRTL();
            if (this.model.showRoundedCorner) this._roundedCorner();
        },

        _roundedCorner: function () {
            this.element.addClass("e-corner");
        },

        _sharpedCorner: function () {
            this.element.removeClass("e-corner");
        },

        _handleAlignment: function (rtl) {
            var mar = -(this.firstHandle.outerWidth() / 2) + "px", margin;
            if (this.model.orientation != "vertical") {
                if (!rtl) margin = "0 0 0 " + mar;
                else margin = "0 " + mar + " 0 0";
            }
            else {
                if (!rtl) margin = "0 0 " + mar + " 0";
                else margin = mar + " 0 0 0";
            }
            this.element.children('.e-handle').css("margin", margin);
        },

        _checkRTL: function () {
            if (this.model.showButtons && this._valueChanged) {
                this.element.siblings('.e-sliderbtn').remove();
                this._renderButtons();
            }
            var rtl = this.model.enableRTL, preDir = (this.model.orientation != "vertical") ? this.horDir : this.verDir;
            if (rtl) {
				this.wrapper.addClass("e-rtl");
				if (this.model.orientation == "vertical") {
					this.wrapper.addClass("e-top-to-bottom");
				}
				 
                this.horDir = "right";
                this.verDir = "top";
            }
            else {
                this.wrapper.removeClass("e-rtl e-top-to-bottom");
                this.horDir = "left";
                this.verDir = "bottom";
            }
            if (!this.model.showButtons || (this.model.showButtons && this.model.enableRTL)) this._changeVerticalScaleDir(this.model.showScale);
            var currDir = (this.model.orientation != "vertical") ? this.horDir : this.verDir;

            if (preDir != currDir) {
                this.firstHandle.css(currDir, this.firstHandle[0].style[preDir]).css(preDir, "auto");
                if (this.model.sliderType != "default") {
                    this.header.css(currDir, this.header[0].style[preDir]).css(preDir, "auto");
                    if (this.model.sliderType == "range")
                        this.secondHandle.css(currDir, this.secondHandle[0].style[preDir]).css(preDir, "auto");
                }
            }
            this._handleAlignment(rtl);
        },

        _setOrientation: function () {
            if (this.model.orientation != "vertical") {
                this.wrapper.addClass("e-horizontal");
            }
            else {
                this.wrapper.addClass("e-vertical");
                this.firstHandle.css(this.verDir, "0");
            }
        },

        _changeVerticalScaleDir: function (showScale) {
            if (showScale) {
                var verscaleli = this.wrapper.find('.e-v-scale li');
                if (verscaleli.length > 0)
                {
                    var revdir = verscaleli.toArray().reverse(); verscaleli.remove();
                    this.wrapper.find('.e-v-scale').append(revdir);
                }
            }
        },

        _setHandleSize: function () {
            if ((this.model.height != null && this.model.orientation == "horizontal") || (this.model.width != null && this.model.orientation == "vertical") ) {
                var size;
                if (this.model.orientation != "vertical")
                    size = this.wrapper.height() + 2;
                else
                    size = this.wrapper.width() + 2;
                this.element.find(".e-handle").height(size).width(size);
            }
            else{
                this.wrapper.addClass("e-default-wrap");
                this.element.find(".e-handle").addClass("e-default");
            }
        },

        _disabled: function (boolean) {
            if (boolean) this.disable();
            else this.enable();
        },

        _sliderOptions: function (prop, value) {
            this._unWireEvents();
            this._destroy();
            this.model[prop] = value;
            this._init();
        },

        _scaleOptions: function (prop, value) {
            if (this.model.showScale) {
                this._destroyScale();
                this.model[prop] = value;
                this._renderScale(true);
                if (this.model.enableRTL)
                    this._changeVerticalScaleDir(true);
            }
        },

        _showTooltip: function () {
            if (this.model.showTooltip) {
                this._timeOut && clearTimeout(this._timeOut);
                var _tooltip = this.tooltip ? $('body .e-tooltipbox').text().replace(/\s+/g, '').replace("-", ",") : "";
                if (this.tooltip && this.tooltip.length && this.tooltip.css("display") != "none" && this._getHandle()[0] == this._oldHandle && _tooltip == this.preValue) {
                    if (this._getHandleValue().toString() != this.preValue)
                        this._setTooltipPosition();
                    return;
                }
                this._oldHandle = this._getHandle()[0];
                $('body .e-tooltipbox').remove();
                this.tooltip = ej.buildTag("div.e-tooltipbox " + this.model.cssClass + " e-corner", { role: "tooltip" }).css(this._getOffset(this._getHandle()));
                $("body").append(this.tooltip);
                if (this.model.orientation == "vertical") {
                    this.tooltip.addClass("e-vertical");
                }
                this._setTooltipPosition();
            }
        },

        _hideTooltip: function () {
            if (this.model.showTooltip) {
                var proxy = this;
                this._timeOut = setTimeout(function () {
                    proxy.tooltip.fadeOut(800);
                }, 1500);
            }
                
        },

        _showhideTooltip: function (showTooltip) {
            if (this.model.showTooltip && showTooltip) {
                this._showTooltip();
                this._timeOut && clearTimeout(this._timeOut);
                this._hideTooltip();
            }
        },

        _setTooltipPosition: function () {
            if (this.model.showTooltip) {
                this._updateTooltipValue();
                var top, left, remainLeft, remainTop, handle, pos, gap = 5, broder, tooltipPos, border; // gap -> distance between tooltip and slider
                handle = this._getHandle(), pos = this._getOffset(handle), tooltipPos = this._getOffset(this.tooltip);
                border = $(handle).outerHeight() - $(handle).height();
                if (this.model.orientation == "vertical") {
                    remainTop = (this.tooltip.outerHeight() - handle.outerHeight()) / 2;
                    remainLeft = handle.outerWidth() + gap;
                    top = pos.top - remainTop;
                    left = pos.left + remainLeft;
					var height=$(window).height();
                    if (window.pageYOffset > 0) height+=window.pageYOffset; 
                    if (top < 0) top = 0;
                    else if (height < top + this.tooltip.outerHeight()) top = height - this.tooltip.outerHeight() - border;
                    if ($(window).width() < left + this.tooltip.outerWidth()) left = pos.left - this.tooltip.outerWidth() - border;
                }
                else {
                    if (tooltipPos.left + this.tooltip.outerWidth() > $(window).width()) this.tooltip.css({ "left": '0px' });
                    remainLeft = (this.tooltip.outerWidth() - handle.outerWidth()) / 2;
                    remainTop = this.tooltip.outerHeight() + gap;
                    top = pos.top - remainTop;
                    left = pos.left - remainLeft;
					var width=$(window).width();
                    if (window.pageXOffset > 0) width+=window.pageXOffset;    
                    if (left < 0) left = 0;
                    else if (width < left + this.tooltip.outerWidth()) left = width - this.tooltip.outerWidth() - border;
                    if (top < 0 || pos.top < remainTop) {
                        if (pos.top + handle.outerHeight() + border + this.tooltip.outerHeight() > $(window).height()) {
                            top = pos.top;
                            if (pos.left > this.tooltip.outerWidth() + gap + border) left = pos.left - (this.tooltip.outerWidth() + border);
                            else left = pos.left + (handle.outerWidth() + gap + border);
                        } else top = pos.top + handle.outerHeight() + border;
                    }
                }
                var zindex = this._maxZindex();
                this.tooltip.css({ "top": top, "left": left, "zIndex": zindex + 1 });
            }
        },
        _getOffset: function (ele) {
            return ej.util.getOffset(ele);
        },


        _maxZindex: function () {
            return ej.util.getZindexPartial(this.element, this.popup);
        },

        _updateTooltipValue: function () {
            var one = 0, two = 1, val;
            if (this.model.enableRTL) { one = 1, two = 0; }
            if (this.model.tooltipChange)
                val = this._raiseEvent("tooltipChange");
            else
                val = this._getHandleValue();
            if (this.model.sliderType != "range")
                this.tooltip[0].innerHTML = val;
            else
                this.tooltip[0].innerHTML = val[one] + " - " + val[two];
        },

        _increaseHeaderWidth: function (animation) {
            if (this.model.sliderType != "default") {
                var size = "width", direction = this.horDir, properties = {};
                if (this.model.orientation == "vertical") { size = "height", direction = this.verDir; }

                if (this.model.sliderType == "range") {
                    properties[size] = this.handlePos - this.handlePos2 + "%";
                    properties[direction] = this.handlePos2 + "%";
                }
                else {
                    properties[size] = this.handlePos + "%";
                    properties[direction] = 0;
                }
                var proxy = this;
                if (!animation) this.header.css(properties);
                else {
                    if (this._isTransition) {
                        this.header[0].style.transition = 'all ' + this.model.animationSpeed + 'ms';
                        this.header[0].style['-webkit-transition'] = 'all ' + this.model.animationSpeed + 'ms';
                        this.header.css(direction, properties[direction]);
                        this.header.css(size, properties[size]);
                        setTimeout(function () {
                            proxy.header[0].style.transition = 'none';
                            proxy.header[0].style['-webkit-transition'] = 'none';
                        }, this.model.animationSpeed);
                    } else {
                        this.header.animate(properties, this.model.animationSpeed);
                    }
                }
            }
        },

        _setSliderValue: function () {
            this._validateStartEnd();

            if (this.model.sliderType == "range")
                this._validateRangeValue(this.values());
            else
                this._validateValue(this.value());
            this.preValue = this.getValue().toString();
        },


        _hoverOnHandle: function (evt) {
            $(evt.currentTarget).addClass("e-hover");
        },

        _leaveFromHandle: function (evt) {
            $(evt.currentTarget).removeClass("e-hover");
        },

        _firstHandleClick: function (evt) {
            evt.preventDefault();
            this.firstHandle.focus().addClass("e-no-tab");
            if (this._raiseEvent("start")) return false;

            this.mouseDownPos = this.handlePos;
            if (!this.model.readOnly)
            this._on($(document),ej.eventType.mouseMove, this._firstHandleMove);
            this._on($(document),ej.eventType.mouseUp,this._firstHandleUp);
            this._on($(document),"mouseleave",this._firstHandleUp);
            this._showTooltip();
        },

        _firstHandleMove: function (evt) {
            evt.preventDefault();
            evt = evt.type == "touchmove" ? evt.originalEvent.changedTouches[0] : evt;
            var position = { x: evt.pageX, y: evt.pageY };
            this.handlePos = this._xyToPosition(position);

            if (this.model.sliderType == "range" && this.handlePos < this.handlePos2) {
                this.handlePos = this.handlePos2;
            }
            if (this.handlePos != this.preHandlePos) {
                this.preHandlePos = this.handlePos;
                this.handleVal = this._positionToValue(this.handlePos);
                this._increaseHeaderWidth(false);
                this._setHandlePosition(false, false, false);
                this._setTooltipPosition();

                this._updateModelValue();
                this._raiseEvent("slide");
            }
        },

        _firstHandleUp: function (evt) {
            evt.preventDefault();
            this._off($(document),ej.eventType.mouseMove, this._firstHandleMove);
            this._off($(document),ej.eventType.mouseUp,this._firstHandleUp);
            this._off($(document), "mouseleave", this._firstHandleUp);
            this._timeOut && clearTimeout(this._timeOut);
            this._hideTooltip();

            if (this.mouseDownPos != this.handlePos) this._raiseChangeEvent();
        },

        _secondHandleClick: function (evt) {
            evt.preventDefault();
            this.secondHandle.focus().addClass("e-no-tab");
            if (this._raiseEvent("start")) return false;

            this.mouseDownPos2 = this.handlePos2;
            if (!this.model.readOnly)
            this._on($(document),ej.eventType.mouseMove, this._secondHandleMove);
            this._on($(document),ej.eventType.mouseUp,this._secondHandleUp);
            this._on($(document),"mouseleave",this._secondHandleUp);
            this._showTooltip();
        },

        _secondHandleMove: function (evt) {
            evt.preventDefault();
            evt = evt.type == "touchmove" ? evt.originalEvent.changedTouches[0] : evt;
            var position2 = { x: evt.pageX, y: evt.pageY };
            this.handlePos2 = this._xyToPosition(position2);

            if (this.handlePos2 > this.handlePos) {
                this.handlePos2 = this.handlePos;
            }
            if (this.handlePos2 != this.preHandlePos2) {
                this.preHandlePos2 = this.handlePos2;
                this.handleVal2 = this._positionToValue(this.handlePos2);
                this._increaseHeaderWidth(false);
                this._setHandlePosition(false, false, false);
                this._setTooltipPosition();

                this._updateModelValue();
                this._raiseEvent("slide");
            }
        },

        _secondHandleUp: function (evt) {
            evt.preventDefault();
            this._off($(document),ej.eventType.mouseMove,this._secondHandleMove);
            this._off($(document),ej.eventType.mouseUp,this._secondHandleUp);
            this._off($(document), "mouseleave", this._secondHandleUp);
            this._timeOut && clearTimeout(this._timeOut);
            this._hideTooltip();

            if (this.mouseDownPos2 != this.handlePos2) this._raiseChangeEvent();
        },

        _focusInHandle: function (evt) {
            if (!this._isFocused) {
                this._isFocused = true;
                $(evt.currentTarget).addClass("e-focus");
                if (!this.model.readOnly)
                   this._on($(document),"keydown",this._moveHandle);
                if (this.model.allowMouseWheel && !this.model.readOnly) {
                    this._on(this.element,"mousewheel DOMMouseScroll", this._moveHandle);
                }
                this.activeHandle = $(evt.currentTarget).is(this.firstHandle) ? 1 : 2;
                this._setZindex();
            }
        },

        _focusOutHandle: function (evt) {
            if ($(evt.relatedTarget).is('button') && $(evt.target).parent().siblings().is(evt.relatedTarget)) return;
            if (ej.isNullOrUndefined(evt.relatedTarget) && !ej.isNullOrUndefined(evt.originalEvent) && !ej.isNullOrUndefined(evt.originalEvent.toElement)) {
                if ($(evt.originalEvent.toElement).is('button') && $(evt.target).parent().siblings().is(evt.originalEvent.toElement)) return;
            }
            this._isFocused = false;
            if (this.model.showTooltip && this.tooltip)
                this.tooltip.fadeOut(800);
            this.element.find(".e-no-tab").removeClass("e-no-tab");
            $(evt.currentTarget).removeClass("e-focus");
         this._off($(document),"keydown",this._moveHandle);
            this._off(this.element,"mousewheel DOMMouseScroll", this._moveHandle);
        },

        _moveHandle: function (e) {
            if ((e.type == 'mousewheel') || (e.type=='DOMMouseScroll')) e.preventDefault()
            var oper, val, handleNo;
            handleNo = this._getHandleIndex(this.activeHandle) - 1;
            if ((e.type == 'mousewheel') || (e.type == 'DOMMouseScroll')) {
                var rawEvent = e.originalEvent;
                if (rawEvent.wheelDelta) {
                    delta = rawEvent.wheelDelta / 120;
                }
                else if (rawEvent.detail) {
                    // Firefox uses detail property, which is a multiple of 3.
                    delta = -rawEvent.detail / 3;
                }
                oper = delta > 0 ? 'add' : 'sub';
            }

            switch (e.keyCode || e.originalEvent.wheelDelta) {
                case -120:
                case 37:
                case 40:
                    this._getHandle().addClass("e-no-tab");
                    e.preventDefault();
                    oper = "sub";
                    break;
                case 120:
                case 38:
                case 39:
                    this._getHandle().addClass("e-no-tab");
                    e.preventDefault();
                    oper = "add";
                    break;
                case 36:
                    this._getHandle().addClass("e-no-tab");
                    e.preventDefault();
                    if (this._raiseEvent("start")) return false;
                    if (this.model.sliderType != "range" && this.value() != this.model.minValue) {
                        this._changeHandleValue(this.model.minValue, this.model.enableAnimation);
                    }
                    else if (this.model.sliderType == "range") {
                        val = (this.activeHandle == 2) ? this.model.minValue : this.handleVal2;
                        if (this.values()[handleNo] != val)
                            this._changeHandleValue(val, this.model.enableAnimation);
                    }
                    break;
                case 35:
                    this._getHandle().addClass("e-no-tab");
                    e.preventDefault();
                    if (this._raiseEvent("start")) return false;
                    if (this.model.sliderType != "range" && this.value() != this.model.maxValue) {
                        this._changeHandleValue(this.model.maxValue, this.model.enableAnimation);
                    }
                    else if (this.model.sliderType == "range") {
                        val = (this.activeHandle == 1) ? this.model.maxValue : this.handleVal;
                        if (this.values()[handleNo] != val)
                            this._changeHandleValue(val, this.model.enableAnimation);
                    }
                    break;
                case 27:
                    this._getHandle().addClass("e-no-tab");
                    e.preventDefault();
                    this._getHandle().focusout();
                    break;
            }

            if (oper == "add" || oper == "sub") {
                if (this._raiseEvent("start")) return false;
                var hVal = (this.activeHandle == 1) ? this.handleVal : this.handleVal2;
                var value = (oper == "add") ? this._add(hVal, this.model.incrementStep, true) : this._add(hVal, this.model.incrementStep, false);
                this._changeHandleValue(value, false);
            }
        },

        _changeHandleValue: function (value, animate) {
            var position = null;
            if (this.activeHandle == 1) {
                this.handleVal = this._checkHandleValue(value);
                this.handlePos = this._checkHandlePosition(this.handleVal);

                if (this.model.sliderType == "range" && this.handlePos < this.handlePos2) {
                    this.handlePos = this.handlePos2;
                    this.handleVal = this.handleVal2;
                }
                if (this.handlePos != this.preHandlePos)
                    position = this.preHandlePos = this.handlePos;
            }
            else {
                this.handleVal2 = this._checkHandleValue(value);
                this.handlePos2 = this._checkHandlePosition(this.handleVal2);

                if (this.model.sliderType == "range" && this.handlePos < this.handlePos2) {
                    this.handlePos2 = this.handlePos;
                    this.handleVal2 = this.handleVal;
                }
                if (this.handlePos2 != this.preHandlePos2)
                    position = this.preHandlePos2 = this.handlePos2;
            }

            if (position != null) {
                this._increaseHeaderWidth(animate);
                this._setHandlePosition(animate, true, true);
            }
        },

        _sliderBarClick: function (evt) {
            if (this.model.readOnly) return false;
            if (evt.target == this.target || (this.model.sliderType != "default" && evt.target == this.header[0]) || $(evt.target).hasClass('e-tick') || $(evt.target).hasClass('e-scale') || evt.target == this.wrapper[0]) {
                evt.preventDefault();
                if (this._raiseEvent("start")) return false;
                var pos = { x: evt.pageX, y: evt.pageY },
                handlepos = this._xyToPosition(pos),
                handleVal = this._positionToValue(handlepos);

                if (this.model.sliderType == "range" && (this.handlePos - handlepos) > (handlepos - this.handlePos2)) {
                    this.handlePos2 = this.preHandlePos2 = handlepos;
                    this.handleVal2 = handleVal;
                    this.activeHandle = 2;
                }
                else {
                    this.handlePos = this.preHandlePos = handlepos;
                    this.handleVal = handleVal;
                    this.activeHandle = 1;
                }

                this._getHandle().focus().addClass("e-no-tab");;
                if (this.model.sliderType != "default") this._increaseHeaderWidth(this.model.enableAnimation);
                this._setHandlePosition(this.model.enableAnimation, true, true);
            }
        },

        _setHandlePosition: function (animation, showTooltip, changeEvt) {
            var Handle = this._getHandle(), proxy = this, properties = {}, pos, val, direction;
            pos = (this.activeHandle == 1) ? this.handlePos : this.handlePos2;
            val = (this.activeHandle == 1) ? this.handleVal : this.handleVal2;
            Handle.attr("aria-label", val);
            direction = (this.model.orientation == "vertical") ? this.verDir : this.horDir;
            properties[direction] = pos + "%";
            if (pos == 0) {
                this.model.sliderType != "range" && this._getHandle().addClass("e-handle-start");
            }
            else {
                this._getHandle().removeClass("e-handle-start");
            }
            if (!animation) {
                Handle.css(properties);
                this._showhideTooltip(showTooltip);
                if (changeEvt) this._raiseChangeEvent();
            }
            else {
                if (this._isTransition) {
                    Handle[0].style.transition = 'all ' + this.model.animationSpeed + 'ms';
                    Handle[0].style['-webkit-transition'] = 'all ' + this.model.animationSpeed + 'ms';
                    Handle.css(direction, pos + '%');
                    setTimeout(function () {
                        Handle[0].style.transition = 'none';
                        Handle[0].style['-webkit-transition'] = 'none';
                        proxy._showhideTooltip(showTooltip);
                        if (changeEvt) proxy._raiseChangeEvent();
                    }, this.model.animationSpeed);
                } else {
                    Handle.animate(properties, this.model.animationSpeed, function () {
                        proxy._showhideTooltip(showTooltip);
                        if (changeEvt) proxy._raiseChangeEvent();
                    });
                }
            }
        },

        _xyToPosition: function (position) {
            if (this.model.minValue == this.model.maxValue)
                return 100;
            if (this.model.orientation != "vertical") {
                var left = position.x - this.element.offset().left,
                num = this.element.width() / 100,
                val = (left / num);
            }
            else {
                var top = position.y - this.element.offset().top,
                num = this.element.height() / 100,
                val = 100 - (top / num);
            }
            val = this._stepValueCalculation(val);
            if (val < 0) val = 0;
            else if (val > 100) val = 100;
            if (this.model.enableRTL) return 100 - val;
            return val;
        },

        _updateValue: function () {
            this.handleVal = this._checkHandleValue(this.value());
            this.handlePos = this._checkHandlePosition(this.handleVal);
            this.preHandlePos = this.handlePos;
            this.activeHandle = 1;
        },

        _setValue: function (animation) {
            this._updateValue();
            this._increaseHeaderWidth(animation);
            this._setHandlePosition(animation, false, true);
        },

        _updateRangeValue: function () {
            var values = this.values();
            this.handleVal = this._checkHandleValue(values[1]);
            this.handleVal2 = this._checkHandleValue(values[0]);
            this.handlePos = this._checkHandlePosition(this.handleVal);
            this.handlePos2 = this._checkHandlePosition(this.handleVal2);

            if (this.handlePos < this.handlePos2) {
                this.handlePos = this.handlePos2;
                this.handleVal = this.handleVal2;
            }
            this.preHandlePos = this.handlePos;
            this.preHandlePos2 = this.handlePos2;
        },

        _setRangeValue: function (animation) {
            this._updateRangeValue();
            this._increaseHeaderWidth(animation);
            this.activeHandle = 1;
            this._setHandlePosition(animation, false, false);
            this.activeHandle = 2;
            this._setHandlePosition(animation, false, true);
        },

        _checkHandlePosition: function (value) {
            if (this.model.minValue == this.model.maxValue)
                return 100;
            var handle = this._tempStartEnd();
            if (value >= handle.start && value <= handle.end)
                value = (100 * (value - this.model.minValue)) / (this.model.maxValue - this.model.minValue);
            else if (value < handle.start) value = 0;
            else value = 100;
            return value;
        },

        _checkHandleValue: function (value) {
            if (this.model.minValue == this.model.maxValue)
                return this.model.minValue;
            var handle = this._tempStartEnd();
            if (value < handle.start) value = handle.start;
            else if (value > handle.end) value = handle.end;
            return value;
        },

        _tempStartEnd: function () {
            if (this.model.minValue > this.model.maxValue)
                return {
                    start: this.model.maxValue,
                    end: this.model.minValue
                };
            else
                return {
                    start: this.model.minValue,
                    end: this.model.maxValue
                };
        },

        _positionToValue: function (pos) {
            var diff = this.model.maxValue - this.model.minValue,
            val = this._round(diff * pos / 100),
            total = this._add(val, this.model.minValue, true);
            return total;
        },

        _getHandle: function () {
            return (this.activeHandle == 1) ? this.firstHandle : this.secondHandle;
        },

        _getHandleIndex: function (no) {
            if (this.model.sliderType == "range" && no == 1)
                return 2;
            return 1;
        },

        _getHandleValue: function () {
            if (this.model.sliderType == "range") return [this.handleVal2, this.handleVal];
            else return this.handleVal;
        },

        _updateModelValue: function () {
            var value = this._getHandleValue();
            this._hidden.val(value);
            if (this.model.sliderType == "range") this.values(value);
            else this.value(value);
        },

        _add: function (a, b, addition, precision) {
            var x = Math.pow(10, precision || 3), val;
            if (addition) val = (Math.round(a * x) + Math.round(b * x)) / x;
            else val = (Math.round(a * x) - Math.round(b * x)) / x;
            return val;
        },

        _round: function (a) {
            var _f = this.model.incrementStep.toString().split(".");
            return _f[1] ? parseFloat(a.toFixed(_f[1].length)) : Math.round(a);
        },

        _raiseChangeEvent: function () {
            this._updateModelValue();
            if (this.initialRender)
                this.initialRender = false;
            else {
                if(this.getValue().toString() != this.preValue.toString()){
                        this._raiseEvent("change");
                        this._raiseEvent("stop");
                        this.preValue = this.getValue().toString();
                }
            }
        },

        _raiseEvent: function (name) {
            var data = { id: this.target.id, value: this._getHandleValue(), sliderIndex: this._getHandleIndex(this.activeHandle) };
            if (name == "change")
                data = { id: this.target.id, isInteraction: this._isInteraction, value: this._getHandleValue(), sliderIndex: this._getHandleIndex(this.activeHandle) };
            if (name == "tooltipChange")
                data = { id: this.target.id, isInteraction: this._isInteraction, value: this._getHandleValue(), sliderIndex: this._getHandleIndex(this.activeHandle) };
            var status = this._trigger(name, data);
            if (name == "tooltipChange")
                return data.value;
            return status;
        },

        _setZindex: function () {
            if (this.model.sliderType == "range") {
                if (this.activeHandle == 1) {
                    this.firstHandle.css("z-index", 2);
                    this.secondHandle.css("z-index", 1);
                }
                else {
                    this.firstHandle.css("z-index", 1);
                    this.secondHandle.css("z-index", 2);
                }
            }
        },

        _stepValueCalculation: function (value) {
            if (this.model.incrementStep == 0) this.model.incrementStep = 1;
            var percentStep = this.model.incrementStep / ((this.model.maxValue - this.model.minValue) / 100);
            var remain = value % Math.abs(percentStep);
            if (remain != 0) {
                if ((percentStep / 2) > remain) value -= remain;
                else value += Math.abs(percentStep) - remain;
            }
            return value;
        },

        _wireEvents: function () {
            this._on(this.wrapper, "mousedown", this._sliderBarClick);
            this._on(this.firstHandle, ej.eventType.mouseDown, this._firstHandleClick);
            this._on(this.firstHandle, "mouseenter", this._hoverOnHandle);
            this._on(this.firstHandle, "mouseleave", this._leaveFromHandle);
            this._on(this.firstHandle, "focusin", this._focusInHandle);
            this._on(this.firstHandle, "focusout", this._focusOutHandle);

            if (this.model.sliderType == "range") {
                this._on(this.secondHandle, ej.eventType.mouseDown, this._secondHandleClick);
                this._on(this.secondHandle, "mouseenter", this._hoverOnHandle);
                this._on(this.secondHandle, "mouseleave", this._leaveFromHandle);
                this._on(this.secondHandle, "focusin", this._focusInHandle);
                this._on(this.secondHandle, "focusout", this._focusOutHandle);
            }
        },


        _unWireEvents: function () {
            this._off(this.wrapper, "mousedown");
            this._off(this.firstHandle, ej.eventType.mouseDown);
            this._off(this.firstHandle, "mouseenter");
            this._off(this.firstHandle, "mouseleave");
            this._off(this.firstHandle, "focusin");
            this._off(this.firstHandle, "focusout");

            if (this.model.sliderType == "range") {
                this._off(this.secondHandle, ej.eventType.mouseDown);
                this._off(this.secondHandle, "mouseenter");
                this._off(this.secondHandle, "mouseleave");
                this._off(this.secondHandle, "focusin");
                this._off(this.secondHandle, "focusout");
            }
        }
    });

    ej.SliderType = {
        /**  support for slider control to select a single value. */
        Default: "default",
        /**  support for slider control to select a single value considered from start value to current handle. */
        MinRange: "minrange",
        /**  support for slider control to select a range of value between the two handles. */
        Range: "range"
    };
})(jQuery, Syncfusion);;
/**
* @fileOverview Plugin to style the Html Button elements
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, undefined) {

    ej.widget("ejSplitButton", "ej.SplitButton", {

        element: null,

        model: null,
        validTags: ["button"],
        _setFirst: false,

        _rootCSS: "e-splitbutton",

        defaults: {

            size: "normal",

            width: "",

            height: "",

            enabled: true,

            htmlAttributes: {},

            text: null,

            contentType: "textonly",

            imagePosition: "imageleft",

            buttonMode: "split",

            arrowPosition: "right",

            targetID: null,

            target: null, 

            showRoundedCorner: false,

            prefixIcon: null,

            suffixIcon: null,

            cssClass: "",

            enableRTL: false,

            create: null,

            beforeOpen: null,

            click: null,

            itemMouseOver: null,

            itemMouseOut: null,

            itemSelected: null,

            open: null,

            close: null,

            destroy: null,

            popupPosition: "down",
    
        },

        dataTypes: {
            size: "string",
            enabled: "boolean",
            showRoundedCorner: "boolean",
            text: "string",
            contentType: "enum",
            imagePosition: "enum",
            buttonMode: "enum",
            arrowPosition: "enum",
            target: "string",       
            targetID: "string",
            prefixIcon: "string",
            suffixIcon: "string",
            cssClass: "string",
            enableRTL: "boolean",
            htmlAttributes: "data"
        },


        disable: function () {
            this.element.addClass("e-disable");
            this.wrapper.addClass("e-disable");
            if (this.contstatus) {
                this._hidePopup();
            }
            if (this.model.buttonMode == ej.ButtonMode.Split)
                this.dropbutton.addClass("e-disable").attr("aria-disabled", true);
            if (this.model.buttonMode == ej.ButtonMode.Dropdown)
                this.btnimgwrap.addClass("e-disable").attr("aria-disabled", true);
            this.model.enabled = false;
        },

        visible: function (display) {
            if (!display) {
               this.wrapper.addClass("e-split-btn-hide");
               this.wrapper.find(".e-icon").css("visibility", "hidden");
            }
            else {
               this.wrapper.removeClass("e-split-btn-hide");
               this.wrapper.find(".e-icon").css("visibility", "");
            }
        },

        enable: function () {
            this.element.removeClass("e-disable");
            this.wrapper.removeClass("e-disable");
            if (this.model.buttonMode == ej.ButtonMode.Split)
                this.dropbutton.removeClass("e-disable").attr("aria-disabled", false);
            if (this.model.buttonMode == ej.ButtonMode.Dropdown)
                this.btnimgwrap.removeClass("e-disable").attr("aria-disabled", false);
            this.model.enabled = true;
        },

        hide: function () {
            if (this.contstatus) {
                this._hidePopup();
            }
        },

        show: function () {
            if (!this.contstatus) {
                if (this.model.buttonMode == ej.ButtonMode.Dropdown)
                    this.element.click();
                else if (this.model.buttonMode == ej.ButtonMode.Split)
                    this.dropbutton.click();
            }
        },

        setPopupPosition: function (val) {
            this._setPosition = true;
            this._val = val;
        },

        _init: function () {
            this._cloneElement = this.element.clone();
            this._setPosition = false;
            this._initialize();
            this._controlStatus(this.model.enabled);
            this._documentClickHandler = $.proxy(this._documentClick, this);
            this._wireEvents();
        },

        _createElement: function (tagName, attrs) {
            var ele = document.createElement(tagName);
            this._setAttributes(ele, attrs);
            return $(ele);
        },
        _setAttributes: function (ele, attrs) {
            for (var key in attrs) {
                ele.setAttribute(key, attrs[key]);
            }
        },

        _destroy: function () {
            if (this.contstatus) {
                this._hide();
            }
            this.splitwrap.removeClass("e-drop");
            this.splitwrap.removeClass("e-btn-" + this.model.size);
            this.innerWrap.removeClass("e-splitarrowright e-splitarrowleft e-splitarrowbottom e-splitarrowtop");
            this.element.removeClass(this.model.cssClass + "e-ntouch e-select e-corner e-btn e-disable e-split-btn e-droparrowright e-droparrowleft e-droparrowbottom e-droparrowtop e-left-btn e-txt").empty();
            this.element.append(this._cloneElement.text());
            this.element.insertAfter(this.wrapper);
            this.wrapper.remove();
            if(this._contextObj) this._contextObj.model && this._contextObj.destroy();            
			if(this._contextObj) this._contextObj = null;			
            //this has to be worked out in Menu
            $(this.model.target).show();
            $(this.model.target).insertAfter(this.element); 
            this._off(this.element, "click", this._btnMouseClick);
        },

        _setModel: function (options) {
            var option;
            for (option in options) {
                switch (option) {
                    case "size":
                        this._setSize(options[option]);
                        break;
                    case "width":
                        this._splitbtnWidth(options[option]);
                        break;
                    case "height":
                        this._splitbtnHeight(options[option]);
                        break;
                    case "contentType":
                        this._setContentType(options[option]);
                        break;
                    case "imagePosition":
                        this._setImagePosition(options[option]);
                        break;
                    case "buttonMode":
                        this._setButtonMode(options[option]);
                        break;
                    case "arrowPosition":
                        this._setArrowPosition(options[option]);
                        break;
                    case "text":
                        this._setText(options[option]);
                        break;
                    case "prefixIcon":
                        this._setMajorIcon(options[option]);
                        break;
                    case "suffixIcon":
                        this._setMinorIcon(options[option]);
                        break;
                    case "enabled":
                        this._controlStatus(options[option]);
                        break;
                    case "targetID":
                    case "target":
                        this._setTarget(options[option]);
                        break;
                    case "showRoundedCorner":
                        this._roundedCorner(options[option]);
                        break;
                    case "cssClass":
                        this._setSkin(options[option]);
                        break;
                    case "enableRTL":
                        this._setRTL(options[option]);
                        break;
                    case "htmlAttributes":
                        this._addAttr(options[option]);
                        break;
                    case "popupPosition":
                        this._setPopupPosition(options[option]);
                        break;
                }
            }
        },

        _setText: function (val) {
            if (this.model.contentType == ej.ContentType.TextOnly) {
                if (this.model.buttonMode == ej.ButtonMode.Split)
                    this.element.html(val);
                else {
                    this.element.empty();
                    this.imgtxtwrap = val;
                    if (this.model.arrowPosition == ej.ArrowPosition.Left || this.model.arrowPosition == ej.ArrowPosition.Top)
                        this.element.append(this.btnimgwrap, this.imgtxtwrap);
                    else
                        this.element.append(this.imgtxtwrap, this.btnimgwrap);
                }
            } else {
                this.textspan.html(val);
            }
        },

        _setMajorIcon: function (val) {
            this.majorimgtag.removeClass(this.model.prefixIcon);
            this.majorimgtag.addClass(val);
        },

        _setMinorIcon: function (val) {
            this.minorimgtag.removeClass(this.model.suffixIcon);
            this.minorimgtag.addClass(val);
        },
        _setTarget: function (val) {
            if ((val.substring(0, 1) == ".") || (val.substring(0, 1) == "#")) {
                this.model.target = val; 
            }
            else {
                this.model.targetID = val;
                this.model.target = "#" + val;
            }
            this._renderContxtMenu();
        },

        _setContentType: function (val) {
            if (val != this.model.contentType) {
                this.element.empty();
                this.model.contentType = val;
                this._renderButtonContent();
            }
        },

        _setImagePosition: function (val) {
            if (val == ej.ImagePosition.ImageRight || val == ej.ImagePosition.ImageLeft || val == ej.ImagePosition.ImageBottom || val == ej.ImagePosition.ImageTop) {
                if ((this.model.contentType == ej.ContentType.TextAndImage) && (val != this.model.imagePosition)) {
                    this.element.empty();
                    this.model.imagePosition = val;
                    this._renderButtonContent();
                }
            }
        },

        _setButtonMode: function (val) {
            if (val == ej.ButtonMode.Split || val == ej.ButtonMode.Dropdown) {
                if (val != this.model.buttonMode) {
                    this._destroy();
                    this.model.buttonMode = val;
                    this._init();
                }
            }
        },

        _setArrowPosition: function (val) {
            if (val == ej.ArrowPosition.Right || val == ej.ArrowPosition.Left || val == ej.ArrowPosition.Bottom || val == ej.ArrowPosition.Top) {
                if ((this.model.buttonMode == ej.ButtonMode.Dropdown) && (val != this.model.arrowPosition)) {
                    this.model.arrowPosition = val;
                    this.element.empty();
                    this._setSize(this.model.size);
                    this.element.removeClass("e-droparrowright e-droparrowleft e-droparrowbottom e-droparrowtop");
                    this._renderButtonContent();
                }
                else if ((this.model.buttonMode == ej.ButtonMode.Split) && (val != this.model.arrowPosition)) {
                    this.model.arrowPosition = val;
                    this._setSize(this.model.size);
                    this.innerWrap.removeClass("e-splitarrowright e-splitarrowleft e-splitarrowbottom e-splitarrowtop");
                    this._setRTL(this.model.enableRTL);
                }
            }
        },

        _setPopupPosition: function (val) {
            this.model.popupPosition = val;
            if (this.model.popupPosition == "down")
                this.dropdownimg.addClass("e-arrow-sans-down").removeClass("e-arrow-sans-up");
            if (this.model.popupPosition == "up")
                this.dropdownimg.addClass("e-arrow-sans-up").removeClass("e-arrow-sans-down");
        },

        _setRTL: function (val) {
            if (this.model.buttonMode == ej.ButtonMode.Split) {
                this.dropdownimg.removeClass("e-arrow-sans-up").addClass("e-arrow-sans-down");
                switch (this.model.arrowPosition) {
                    case ej.ArrowPosition.Right:
                        this.innerWrap.addClass("e-splitarrowright");
                        break;
                    case ej.ArrowPosition.Left:
                        this.innerWrap.addClass("e-splitarrowleft");
                        break;
                    case ej.ArrowPosition.Bottom:
                        this.innerWrap.addClass("e-splitarrowbottom");
                        break;
                    case ej.ArrowPosition.Top:
                        this.innerWrap.addClass("e-splitarrowtop");
                        this.dropdownimg.addClass("e-arrow-sans-up").removeClass("e-arrow-sans-down");
                        break;
                }
                val == true ? (this.innerWrap.hasClass("e-splitarrowleft") ? "" : this.splitwrap.addClass("e-rtl e-btnrtl")) && (this._contextObj && this._contextObj.model && this._contextObj.element.addClass('e-rtl')) : this.splitwrap.removeClass("e-rtl e-btnrtl") && (this._contextObj && this._contextObj.model && this._contextObj.element.removeClass('e-rtl'));
            }
            else
                val == true ? this.splitwrap.addClass('e-rtl') && (this._contextObj && this._contextObj.model && this._contextObj.element.addClass('e-rtl')) : this.splitwrap.removeClass('e-rtl') && (this._contextObj && this._contextObj.model && this._contextObj.element.removeClass('e-rtl'));
            this.model.enableRTL = val;
            this._roundedCorner(this.model.showRoundedCorner);
        },

        _roundedCorner: function (value) {
            if (value) {
                this.element.addClass('e-corner');
                if ($(this.model.target).length > 0) $(this.model.target).addClass('e-corner');  
            } else {
                this.element.removeClass('e-corner');
                if ($(this.model.target).length > 0) $(this.model.target).removeClass('e-corner');
            }
        },

        _controlStatus: function (value) {
            if (!value) {
                this.disable();
            } else {
                this.enable();
            }
        },

        _setSkin: function (skin) {
            this.element.removeClass(this.model.cssClass);
            if (this.model.buttonMode == ej.ButtonMode.Split) {
                this.dropbutton.removeClass(this.model.cssClass);
                this.dropbutton.addClass(skin);
            }
            this.element.addClass(skin);
            if(this._contextObj) this._contextObj.model && this._contextObj.option('cssClass', skin);  
        },

        _initialize: function () {
            if (this.element.is("button") || this.element.is("ej-splitbutton")) {
                this._render();
            } else {
                this.element.removeClass("e-splitbutton");//need to change in src level
            }
            this._timeout = null;
        },
        _addAttr: function (htmlAttr) {
            var proxy = this;
            $.map(htmlAttr, function (value, key) {
                if (key == "class") proxy.wrapper.addClass(value);
                else if (key == "disabled" && value == "disabled") proxy._controlStatus(false);
                else proxy.wrapper.attr(key, value)
            });
        },


        _render: function () {
            this.element.addClass(this.model.cssClass + " e-btn e-select e-split-btn " + (!ej.isTouchDevice() ? "e-ntouch" : ""));
            this._setAttributes(this.element[0]);
            if ((this.model.text == null) || (this.model.text == "")) {
                this.model.text = this.element.text();
            }
            else
                this._setAttributes(this.element[0],{"aria-describedby": this.model.text});
            if (this.model.buttonMode != ej.ButtonMode.Split && this.model.buttonMode != ej.ButtonMode.Dropdown)
                this.model.buttonMode = ej.ButtonMode.Split;
            if (this.model.arrowPosition != ej.ArrowPosition.Right && this.model.arrowPosition != ej.ArrowPosition.Left && this.model.arrowPosition != ej.ArrowPosition.Bottom && this.model.arrowPosition != ej.ArrowPosition.Top)
                this.model.arrowPosition = ej.ArrowPosition.Right;
            this.element.empty();
            this.splitwrap = (this.model.buttonMode == ej.ButtonMode.Split ? this._createElement('span', { 'class': 'e-split e-widget' }) : this._createElement('span', { 'class': 'e-split e-drop e-widget' }));
            this.splitwrap.insertBefore(this.element);
            this.innerWrap = this._createElement('span', { 'class': 'e-in-wrap e-box e-padding' });
            this.splitwrap[0].appendChild(this.innerWrap[0]);
            this.wrapper = this.splitwrap;
            /*DropDown Image*/
            this.dropdownimg = this._createElement('span', { "class": "e-icon e-arrow-sans-down" });
            this.dropdownimage = this._createElement('span', { "class": "e-icon e-arrow-sans-up" });
            this.btnimgwrap = this._createElement('span', { 'class': 'e-split-btn-div e-btn-span' });
            if (this.model.popupPosition == "up")
                this.btnimgwrap[0].appendChild(this.dropdownimage[0])
            else
            this.btnimgwrap[0].appendChild(this.dropdownimg[0]);
            /*Split Button*/
            if (this.model.buttonMode == ej.ButtonMode.Split) {
                this.dropbutton = ej.buildTag('button.e-split-btn e-btn e-select ' + this.model.cssClass + ' e-drp-btn' + (!ej.isTouchDevice() ? " e-ntouch" : ""), "", {}, { type: "button", "data-role": "none", "id": this.element[0].id + 'drpbtn' });
                this.dropbutton[0].appendChild(this.btnimgwrap[0]);
                this.dropbutton.insertAfter(this.element);
                if (this.model.contentType == ej.ContentType.TextOnly)
                    this.dropbutton.addClass("e-btn-txt");
                else
                    this.dropbutton.addClass("e-rht-btn");
            }
            this._setSize(this.model.size);
            this.element.addClass("e-left-btn");
            this._renderButtonContent();
            if (this.model.buttonMode == ej.ButtonMode.Dropdown)
                this.innerWrap[0].appendChild(this.element[0]);
            else {
                this.innerWrap[0].appendChild(this.element[0]);
                this.innerWrap[0].appendChild(this.dropbutton[0]);
            }
            /* If target ID is set, the value of target will be set to target prefixed with # tag */
            if ((this.model.target == null) && (this.model.targetID != null)) {
                this.model.target = "#"+this.model.targetID;
            }
            /*Rendering Context menu*/
            $(this.model.target).hide();
            this._roundedCorner(this.model.showRoundedCorner);
            this._setRTL(this.model.enableRTL);
            this._addAttr(this.model.htmlAttributes);
        },

        _renderButtonContent: function () {
            /*Image and Text*/
            this.textspan = ej.buildTag('span.e-btntxt', this.model.text);
            this.majorimgtag = ej.buildTag('span').addClass(this.model.prefixIcon);
            this.minorimgtag = ej.buildTag('span').addClass(this.model.suffixIcon);
            this.imgtxtwrap = ej.buildTag('span').addClass('e-btn-span');;
            /*Rendering Option*/
            if (this.model.contentType == ej.ContentType.TextAndImage) {
                switch (this.model.imagePosition) {
                    case ej.ImagePosition.ImageRight:
                        this.imgtxtwrap.append(this.textspan, this.majorimgtag);
                        break;
                    case ej.ImagePosition.ImageLeft:
                        this.imgtxtwrap.append(this.majorimgtag, this.textspan);
                        break;
                    case ej.ImagePosition.ImageBottom:
                        this.majorimgtag.css("display", "inline-table");
                        this.imgtxtwrap.append(this.textspan, this.majorimgtag);
                        break;
                    case ej.ImagePosition.ImageTop:
                        this.majorimgtag.css("display", "inline-table");
                        this.imgtxtwrap.append(this.majorimgtag, this.textspan);
                        break;
                }
            } else if (this.model.contentType == ej.ContentType.ImageTextImage) {
                this.imgtxtwrap.append(this.majorimgtag, this.textspan, this.minorimgtag);
            } else if (this.model.contentType == ej.ContentType.ImageBoth) {
                this.imgtxtwrap.append(this.majorimgtag, this.minorimgtag);
            } else if (this.model.contentType == ej.ContentType.ImageOnly) {
                this.imgtxtwrap.append(this.majorimgtag);
            } else {
                this.element.addClass("e-txt");
                this.imgtxtwrap = this.model.text;
            }
            if (this.model.buttonMode == ej.ButtonMode.Dropdown)
                this._renderDropdownArrow();
            else
                this.element.append(this.imgtxtwrap);
        },

        _renderDropdownArrow: function () {
            this.btnimgwrap.css("position", "absolute");
            this.dropdownimg.removeClass("e-arrow-sans-up").addClass("e-arrow-sans-down");
            switch (this.model.arrowPosition) {
                case ej.ArrowPosition.Right:
                    this.element.addClass("e-droparrowright");
                    this.element.append(this.imgtxtwrap, this.btnimgwrap);
                    break;
                case ej.ArrowPosition.Left:
                    this.element.addClass("e-droparrowleft");
                    this.element.append(this.btnimgwrap, this.imgtxtwrap);
                    break;
                case ej.ArrowPosition.Bottom:
                    this.element.addClass("e-droparrowbottom");
                    this.element.append(this.imgtxtwrap, this.btnimgwrap);
                    break;
                case ej.ArrowPosition.Top:
                    this.element.addClass("e-droparrowtop");
                    this.dropdownimg.addClass("e-arrow-sans-up").removeClass("e-arrow-sans-down");
                    this.element.append(this.btnimgwrap, this.imgtxtwrap);
                    break;
            }
        },


        _setSize: function (val) {
            this.wrapper.css({ "height": "", "width": "" });
            switch (val) {
                case "mini":
                    this._splitbtnSize(val);
                    break;
                case "small":
                    this._splitbtnSize(val);
                    break;
                case "medium":
                    this._splitbtnSize(val);
                    break;
                case "large":
                    this._splitbtnSize(val); 
                    break;
                default:
                    this._splitbtnSize(val);
                    break;
            }
            if ((this.model.arrowPosition == ej.ArrowPosition.Bottom || this.model.arrowPosition == ej.ArrowPosition.Top) && this.model.height == "")
                this.splitwrap.addClass("e-btn-arrowsplit-" + val);		   // 15px added the height of the wrapper due to Arrow positioned in bottom
            var wd, ht = this.model.height === "" ? this.wrapper.outerHeight() + "px" : this.model.height;
            this._splitbtnHeight(ht);
            if (this.model.size !== "normal") {
                wd = this.model.width === "" ? this.wrapper.outerWidth() + "px" : this.model.width;
                this._splitbtnWidth(wd);
            }
            else if (this.model.width !== "") {
                wd = this.model.width;
                this._splitbtnWidth(wd);
            }
        },

        _splitbtnSize: function (val) {
        
            this.splitwrap.removeClass('e-btn-mini e-btn-medium e-btn-small e-btn-large e-btn-normal e-btn-arrowsplit-large e-btn-arrowsplit-small e-btn-arrowsplit-mini e-btn-arrowsplit-medium e-btn-arrowsplit-normal');
            if (this.model.arrowPosition == ej.ArrowPosition.Left || this.model.arrowPosition == ej.ArrowPosition.Right)
            {
            this.splitwrap.addClass("e-btn-" + val);
            }
        },
        _splitbtnHeight: function (val) {
           if ((val == "") || (val == null)) val = '30px';
          this.splitwrap.css("height", val);
        },


        _splitbtnWidth: function (val) {
            this.splitwrap.css("width", val);
        },


        _renderContxtMenu: function () {
            /* Check whether target is a class and add a id to that target element if id of that element is not given */
            if ((this.model.target != null) && ($(this.model.target).attr("id") == null)) {
                if (this.model.target.substring(0, 1) == ".") {
                    $(this.model.target).attr("id", this.element.attr('id') + "_" + this.model.target.replace(".", ""));
                }
            }
            
            $(this.model.target).ejMenu({
                menuType: ej.MenuType.ContextMenu,
                openOnClick: false,
                contextMenuTarget: "",
                fields: this.model.fields,
                showArrow: true,
                cssClass: "e-split " + this.model.cssClass,
                enableRTL: this.model.enableRTL
            }).on("ejMenuclose", $.proxy(this._onKeyDown, this));
            this._contextObj = $(this.model.target).ejMenu("instance");
        },
        _onKeyDown: function (e) {
            e.keyCode == 27 && this._hide();
        },
        _itemClick: function (args) {
            args = { status: this.model.enabled, ID: args.ID, text: args.text };
            this._trigger("itemSelected", args);
            (!$(args.element).hasClass("e-haschild")) && this._hide();
        },

        _itemMouseOver: function (args) {
            this._trigger("itemMouseOver", args);
        },

        _itemMouseOut: function (args) {
            this._trigger("itemMouseOut", args);
        },


        _wireEvents: function () {
            this._on(this.element, "click", this._btnMouseClick);
            this._on(this.element, "mousedown", this._btnMouseDown);
            /*DrpBTN*/
            if (this.model.buttonMode == ej.ButtonMode.Split)
                this._on(this.dropbutton, "click", this._btnMouseClick);
            /*DocClk*/
            this._on($(document), "mousedown", this._docrhtclk);
        },


        _btnMouseClick: function (e) {
            !this._contextObj ? this._renderContxtMenu() : !this._contextObj.model && this._renderContxtMenu();
            var args;
            if(!this.model.enabled) return false;
            if (!$(e.currentTarget).hasClass("e-disable")) {
                if (e.currentTarget.id != this.element[0].id + "drpbtn" && this.model.buttonMode == ej.ButtonMode.Split) {
                    args = { status: this.model.enabled };
                    this._trigger("click", args);
                } else {
                    !this.contstatus && this._trigger("beforeOpen");
                    this.wrapper.addClass('e-active');
                    if (this.contstatus) {
                        this._hidecontext(e);
                    } else {
                        this._contextPosition(e);
                        this._trigger("open");
                        this._on($(window), "resize", this._OnWindowResize);
                        this.contstatus = true;
                        this.element.on("click", $.proxy(this._hidecontext, this));
                        ej.listenTouchEvent($(document), ej.startEvent(), this._documentClickHandler, false, this);
                        this._on(ej.getScrollableParents(this.wrapper), "scroll", this._hidePopup);
                    }
                }
            }
        },

        _OnWindowResize: function (e) {
            this._contextPosition(e);
        },

        _contextPosition: function (e,value,m,n) {
            if (this._contextObj.model) {
                if (this._setPosition) 
                    var position = this._val;
                else
                var position = this._getXYpos(e);
                var posleft, targetElement, posadjustleft;
                targetElement = (this.model.buttonMode == ej.ButtonMode.Split ? this.dropbutton : this.element);
                var contextObj = this._contextObj;
                posleft = position.x - ($(this.model.target).outerWidth() - (this.model.buttonMode == ej.ButtonMode.Split ? this.dropbutton.outerWidth() : this.element.outerWidth()));
                if (this.model.enableRTL)
                    position.x = (this.model.popupPosition=="left" || (posleft < $(this.model.target).outerWidth())) ? position.x : posleft;
                else
                    position.x = ((this.model.popupPosition == "left") || (position.x + $(this.model.target).outerWidth() < $(window).width())) ? position.x : posleft;
                if (this._posright < 0 && this.model.popupPosition == "left") position.x = $(window).outerWidth();
                 contextObj.option({
                    click: $.proxy(this._itemClick, this),
                    mouseover: $.proxy(this._itemMouseOver, this),
                    mouseout: $.proxy(this._itemMouseOut, this)
                 });
                 if (value)
                     contextObj.show(m, n, targetElement, e);
                else
                 contextObj.show(position.x, position.y, targetElement, e);
            }
        },

        _getXYpos: function (e) {
            var btnpos, btnposx, btnposy, posleft, posright, poscur = 1, postop;
            btnpos = this._getOffset(this.model.buttonMode == ej.ButtonMode.Split ? this.dropbutton : this.element);
            posleft = (this.model.popupPosition == "right" && ((!this.model.enableRTL) && (this.model.arrowPosition != ej.ArrowPosition.Left) && (this.model.arrowPosition != ej.ArrowPosition.Bottom) && (this.model.arrowPosition != ej.ArrowPosition.Top))) ? (this.model.buttonMode == ej.ButtonMode.Split?(btnpos.left + this.dropbutton.outerWidth()):(btnpos.left + this.element.outerWidth())) : ((this.model.popupPosition == "left" && (((this.model.enableRTL)||(this.model.arrowPosition != ej.ArrowPosition.Right)) && (this.model.arrowPosition != ej.ArrowPosition.Bottom) && (this.model.arrowPosition != ej.ArrowPosition.Top)))) ? (btnpos.left - ($(this.model.target).outerWidth())) : btnpos.left;
            this._posright = ($(window).width() - posleft) - ($(this.model.target).outerWidth());
            this._posleft = posleft - $(this.model.target).outerHeight();
            this._posrightht = ($(window).height() - btnpos.top - $(this.model.target).outerHeight());
            btnposx = ((this.model.popupPosition=="right" && (this._posright<0))||(posleft < 0))  ? (btnpos.left) : posleft;
            postop = ((this.model.arrowPosition == ej.ArrowPosition.Top) || (this.model.popupPosition == "up")) ? (btnpos.top - $(this.model.target).outerHeight() + 1) : (((this.model.arrowPosition != ej.ArrowPosition.Top) && (this.model.arrowPosition != ej.ArrowPosition.Bottom) && ((((this.model.arrowPosition == ej.ArrowPosition.Right) != (this.model.popupPosition == "left")) || ((this.model.arrowPosition == ej.ArrowPosition.Right) && this.model.enableRTL && (this.model.popupPosition == "left"))) && (((this.model.arrowPosition == ej.ArrowPosition.Left)) != (this.model.popupPosition == "right")) || ((this.model.arrowPosition == ej.ArrowPosition.Right) && this.model.enableRTL && (this.model.popupPosition == "left"))) && (((!this.model.enableRTL) && (this.model.popupPosition == "right")) || (this.model.popupPosition == "left")))  ? (btnpos.top) : ((this.model.buttonMode == ej.ButtonMode.Split ? (btnpos.top + this.dropbutton.outerHeight()) : (btnpos.top + this.element.outerHeight())) - poscur));//1px added to top due to element border-top as none
            btnposy =((this.model.popupPosition == "left") && this._posrightht < 0 && this._posright > 0 && this._posleft <0) ? (btnpos.top - ($(this.model.target).outerHeight())) : ((this.model.popupPosition == "left") && this._posrightht < 0 && this._posright > 0) ? (btnpos.top+this.element.outerHeight() - ($(this.model.target).outerHeight())) : ((this.model.popupPosition == "right"||this.model.popupPosition=="up"||this.model.popupPosition) && this._posrightht < 0 && this._posright < 0) ? (btnpos.top - ($(this.model.target).outerHeight())) : ((this.model.popupPosition == "right" || this.model.popupPosition == "left") && this._posrightht < 0) ? (btnpos.top + this.element.outerHeight() - ($(this.model.target).outerHeight())) : (this.model.popupPosition == "right" && this._posright < 0 && this._posrightht > 0) ? btnpos.top + this.element.outerHeight() :(this.model.popupPosition=="down"&&this._posrightht<0&&this._posright>0)?(btnpos.top-$(this.model.target).outerHeight()):((posleft < 0) || (this._posright < 0)) ? (btnpos.top + this.element.outerHeight()) : (postop < 0) ? (this.model.buttonMode == ej.ButtonMode.Split && this.model.popupPosition == "up" && this.model.arrowPosition != ej.ArrowPosition.Top) ? (btnpos.top + this.element.outerHeight() - poscur) : ((btnpos.top + (this.model.buttonMode == ej.ButtonMode.Split ? this.dropbutton.outerHeight() + this.element.outerHeight() : this.element.outerHeight()) - poscur)) : postop;
            return { x: btnposx, y: btnposy };
        },
        _getOffset: function (ele) {
            var pos = ele.offset();
            if ($("body").css("position") != "static") {
                var bodyPos = $("body").offset();
                pos.left -= bodyPos.left;
                pos.top -= bodyPos.top;
            }
            return pos;
        },


        _btnMouseDown: function (e) {
            if (!$(e.currentTarget).hasClass("e-disable")) {
                this._docrhtclk(e);
            }
        },
        _hidePopup: function (e) {
           this._contextObj && this._contextObj.hide(e);   
            this._hide();
            this._off(ej.getScrollableParents(this.wrapper), "scroll", this._hidePopup);
        },
        _hide: function () {
            this.contstatus = false;
            this.wrapper.removeClass('e-active');
            this.element.off("click", $.proxy(this._hidecontext, this));
            ej.listenTouchEvent($(document), ej.startEvent(), this._documentClickHandler, true, this);
            this._off($(window), "resize", this._OnWindowResize);
            this._off(ej.getScrollableParents(this.wrapper), "scroll", this._hide);
            this._closeEvent();
        },
        _closeEvent: function () {
            this._trigger("close");
        },

        _hidecontext: function (e) {
            if (($(e.target).is(this.element) || $(e.target).is(this.dropbutton) || $(e.target).is(this.textspan) || $(e.target).is(this.dropdownimg) || $(e.target).is(this.btnimgwrap) || !$(e.target).is(this.majorimgtag) || !$(e.target).is(this.minorimgtag)) && !$(e.target).is(this.splitwrap) && !$(e.target).parents().is($(this.model.target)) || (this.element.hasClass("e-txt") || $(e.target).is(this.imgtxtwrap))) {
                this._hidePopup(e);
            }
        },

        _documentClick: function (e) {
            if (!$(e.target).is(this.element) && !$(e.target).is(this.dropbutton) && !$(e.target).is(this.textspan) && !$(e.target).is(this.dropdownimg) && !$(e.target).is(this.btnimgwrap) && !$(e.target).is(this.majorimgtag) && !$(e.target).is(this.minorimgtag) && !$(e.target).is(this.splitwrap) && !$(e.target).parents().is($(this.model.target)) && (this.element.hasClass("e-txt") || !$(e.target).is(this.imgtxtwrap))) {
                this._hidePopup(e);
            }
        },

        _docrhtclk: function (e) {
            var isRightClick, targetElement;
            isRightClick = false;
            if (e.button) {
                isRightClick = (e.button == 2);
            } else if (e.which) {
                isRightClick = (e.which == 3); //for Opera
            }
            targetElement = e.target;
            if (isRightClick) {
                e.preventDefault();
            }
        },

    });

    ej.ContentType = { TextOnly: "textonly", ImageOnly: "imageonly", ImageBoth: "imageboth", TextAndImage: "textandimage", ImageTextImage: "imagetextimage" };

    ej.ImagePosition = { ImageRight: "imageright", ImageLeft: "imageleft", ImageTop: "imagetop", ImageBottom: "imagebottom" };

    ej.ButtonSize = { Mini: "mini", Small: "small", Medium: "medium", Large: "large" };

    ej.ButtonMode = { Split: "split", Dropdown: "dropdown" };

    ej.ArrowPosition = { Right: "right", Left: "left", Top: "top", Bottom: "bottom" };
})(jQuery, Syncfusion);;
/**
* @fileOverview Plugin to style the Menu control.
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, undefined) { 
    ej.widget("ejMenu", "ej.Menu", {

        element: null,

        model: null,
        validTags: ["ul"],
        _setFirst: false,
        _rootCss: "e-menu",
        angular: {
            terminal: false
        },


        defaults: {

            height: "",

            width: "",

            animationType: "default",

            orientation: ej.Orientation.Horizontal,

            menuType: "normalmenu",
			
			isResponsive: true,

            contextMenuTarget: null,

            htmlAttributes: {},

            cssClass: "",

            openOnClick: false,

            subMenuDirection: "none",

            enableCenterAlign: false,

            showRootLevelArrows: true,

            showSubLevelArrows: true,

            enableAnimation: true,
            
            container: null,

            enableSeparator: true,

            enabled: true,

            overflowHeight: "auto",

            overflowWidth: "auto",

            fields: {

                child: null,

                dataSource: null,

                query: null,

                tableName: null,

                id: "id",

                parentId: "parentId",

                text: "text",

                spriteCssClass: "spriteCssClass",

                url: "url",

                imageAttribute: "imageAttribute",

                htmlAttribute: "htmlAttribute",

                linkAttribute: "linkAttribute",

                imageUrl: "imageUrl",
            },

            enableRTL: false,

            titleText: "Menu",

            locale: "en-US",

            excludeTarget: null,

            beforeOpen: null,

            open: null,

            close: null,

            mouseover: null,

            mouseout: null,

            click: null,

            keydown: null,

            overflowOpen: null,

            overflowClose:null,

            create: null,

            destroy: null
        },

        dataTypes: {
            animationType: "enum",
            cssClass: "string",
            titleText: "string",
            locale: "string",
            openOnClick: "boolean",
            enabled: "boolean",
            enableCenterAlign: "boolean",
            showArrow: "boolean",
            showRootLevelArrows: "boolean",
            showSubLevelArrows: "boolean",
            enableSeparator: "boolean",
			isResponsive: "boolean",
            enableRTL: "boolean",
            enableAnimation: "boolean",
            fields: {
                dataSource: "data",
                query: "data",
                child: "data"
            },
            excludeTarget: "string",
            htmlAttributes: "data"
        },


        _setModel: function (jsondata) {
            for (var key in jsondata) {
                switch (key) {
                    case "menuType":
                        jsondata[key] = this.model.menuType;
                        break;
                    case "fields":
                        this._wireEvents("_off");
                        this.element.empty().insertBefore(this.wrapper);
                        this.wrapper.remove();
                        $.extend(this.model.fields, jsondata[key]);
                        this._intializeData();
                        if (!this.model.enabled)
                            this._wireEvents("_off");
                        break;
                    case "orientation": this._setOrientation(jsondata[key]); break;
                    case "showRootLevelArrows": this._addArrow(jsondata[key], this.model.showSubLevelArrows); break;
                    case "showSubLevelArrows": this._addArrow(this.model.showRootLevelArrows, jsondata[key]); break;
                    case "enableSeparator": this._setSeparator(jsondata[key]); break;
                    case "height": this._setHeight(jsondata[key]); break;
                    case "width": this._setWidth(jsondata[key]); break;
                    case "cssClass": this._setSkin(jsondata[key]); break;
                    case "isResponsive":
                        if (this.model.isResponsive)
                            this._responsiveLayout();
                        else {
                            $(this.resWrap).remove();
                            $(this.wrapper).removeClass("e-menu-responsive");
                            $(this.element).removeClass("e-menu-responsive");
                            this.resWrap = null;
                        }
                        break;
                    case "htmlAttributes": this._addAttr(jsondata[key]); break;
                    case "enableRTL": this._setRTL(jsondata[key]); break;
                    case "enableCenterAlign": this._centerAlign(jsondata[key]); break;
                    case "excludeTarget": this.model.excludeTarget = jsondata[key];
                        break;
                    case "enabled": this.model.enabled = jsondata[key]; this._controlStatus(jsondata[key]); break;
                    case "animationType":
                        this._setAnimation(jsondata[key]);
                        break;
                    case "enableAnimation": this.model.enableAnimation = jsondata[key]; break;
                    case "openOnClick":
                            this._hoverOpen = !jsondata[key];
                            this._hoverClose = !jsondata[key]; 
                        break;
                    case "subMenuDirection": this._setSubMenuDirection(this.model.subMenuDirection); break;
                    case "titleText":
						this._titleText(jsondata[key]);
                        break;
                    case "locale":
                        this.model.locale = jsondata[key];
                        this._updateLocalConstant();
                        this._setLocale();
                        break;
                    case "overflowHeight":                       
                            this._setOverflowDimensions("height",jsondata[key]); break;
                    case "overflowWidth":                      
                        this._setOverflowDimensions("width",jsondata[key]); break;

                }
            }
        },
        _updateLocalConstant: function () {
            this._localizedLabels = ej.getLocalizedConstants("ej.Menu", this.model.locale);
        },
        		
        _setLocale: function () {
            this._titleText(this._localizedLabels.titleText);
        },
        _titleText: function(val){
            if ((this.model.menuType != ej.MenuType.ContextMenu) && (this.model.orientation != "vertical"))
                $(this.label).text(val);
        },

        _destroy: function () {
            this.model.menuType == ej.MenuType.ContextMenu ? this._referenceElement.append(this._cloneElement) : this._cloneElement.insertBefore(this.wrapper);
            this._cloneElement.removeClass('e-menu e-js');
            this.wrapper.remove();
        },


        _init: function () {
            this._cloneElement = this.element.clone();
            this.element.css("visibility", "hidden");
            this._setValues();
            this._intializeData();
            this.element.css("visibility", "visible");
        },

        _setValues: function () {
            this._mouseOver = true;
            this._hoverOpen = true;
            this._hoverClose = true;
            this._isMenuOpen = false;
            this._hideSpeed = 100;
            this._showSpeed = 100;
            this._isSubMenuOpen = false;
            this._isContextMenuOpen = false;
            this._disabledMenuItems = new Array();
            this._hiddenMenuItems = new Array();
            this._delayMenuHover = 0;
            this._delaySubMenuHover = 0;
            this._delaySubMenuShow = 0;
            this._preventContextOpen = true;
            this._setAnimation(this.model.animationType);
            this._isFocused = true;
            this._menuOverflowItems = new Array();
            this._menuHeaderItems = new Array();
            this._menuCloneItems = new Array();
            this._itemWidth = 0; 
        },
        _intializeData: function () {
            if (!ej.isNullOrUndefined(this.model.fields) && this.model.fields["dataSource"] != null) {
                this._generateTemplate(this.model.fields["dataSource"]);
                this._renderMenu();
            }
            else {
                this._renderMenu();
                this._wireEvents("_on");
                this._calculateOverflowItems();
            }
        },
        _renderMenu: function () {
            this._renderControl();
            this._addArrow(this.model.showRootLevelArrows, this.model.showSubLevelArrows);
			this._renderArrow();
			this._intializeMenu();
            //item Width for width property		
			    this._itemWidth = this.element.width();
			    if (this.model.isResponsive) {
			        this._ensureResponsiveClasses($(window).width() < 767);
			    }
			    if (this.model.orientation == "horizontal") {
			        this._on(this.element.parent().find("span.e-check-wrap.e-icon"), "click", this._mobileResponsiveMenu);
			        if(this.model.fields["dataSource"] != null) this._calculateOverflowItems();
			    }
        },      

        _renderControl: function () {
            var label, checkBox, checkObj, list, spanlist, i;
            if (this.model.menuType == "normalmenu") {
                this.wrapper = ej.buildTag("div");
                this.wrapper.addClass(this.model.cssClass + " e-menu-wrap");
            } else
                this.wrapper = ej.buildTag("div.e-menu-wrap");
            if (this.model.isResponsive) this._responsiveLayout();
            if (this.model.menuType != ej.MenuType.ContextMenu) {
                this.wrapper.insertBefore(this.element);
                this.wrapper.append(this.element);
                }            
            this.element.addClass("e-menu e-widget e-box").attr({ "role": "menu", "tabindex": 0 });
            this._addAttr(this.model.htmlAttributes);
            if (this.model.enableRTL) this._setRTL(this.model.enableRTL);
            this._setSubMenuDirection(this.model.subMenuDirection);
            if (this.model.menuType == "normalmenu") {
                this.model.orientation == "horizontal" ? this.element.addClass("e-horizontal") : this.element.addClass("e-vertical");
            }
            //For ContextMenu Mode
            else this._contextMenu_Template();
            this._addClass();
            if (this.model.enableCenterAlign) this._centerAlign(this.model.enableCenterAlign);
            if (this.model.enableSeparator) this._setSeparator(true);
            (!this.model.enabled) && this.disable();
        },
        _renderPopupWrapper: function (e) {
            if(this._ensureOverflowPopup()){                          
                this.popupWrapper = ej.buildTag("div.e-menu-popwrap");                         
                this.popupWrapper.insertAfter(this.element);              
                var height = typeof value === "number" ? this.model.overflowHeight + "px" :this.model.overflowHeight;
                var width = typeof value === "number" ? this.model.overflowWidth + "px" : this.model.overflowWidth;
                this.popupWrapper.css({ "height": height,"width":width});
                this.popupWrapper.hide();
                this._addOverflowItems();                
            }
        
        },
        _calculateOverflowItems: function (e) {        
            if (this._ensureOverflowPopup()) {
                this.element.find("li.e-list").removeClass("e-menu-show");
                $(this.lastelement).removeClass("e-last");
                this._menuHeaderItems = [];  
                var menuHeaderWidth = this.element.outerWidth();               
                if (this.element.find("li.e-ham-wrap").length > 0) //for window resizing event neglect the hamburger icon list from the listCollection
                {                   
                    if ((this._itemWidth<=this.element.width())||(this._itemWidth>=this.element.width()) && (!(this._isOverflowPopupOpen()))) {
						if(!ej.isNullOrUndefined(this.popupWrapper))
							this.popupWrapper.hide();                        
                    }
                }
				this._renderHamburgerIcon();	
				this.element.find("li.e-ham-wrap").css({display: 'list-item'});
                var hamburgerWidth = this.element.find("li.e-ham-wrap").outerWidth(), itemsOuterWidth = 0, hideState=true;
				this.element.find("li.e-ham-wrap").hide();
                this._menuHeaderItems = this.element.find(">li.e-list");
                this._menuOverflowItems = [];
                for ( var i = 0; i < this._menuHeaderItems.length; i++) {
                   var menuItem = $(this._menuHeaderItems[i]);                                        
                        itemsOuterWidth = itemsOuterWidth + menuItem.outerWidth();
                        if (itemsOuterWidth < menuHeaderWidth) {                      
                            menuItem.removeClass('e-menu-hide');
							this.element.find(">li.e-list.e-haschild>ul").find("li.e-haschild").find("span.e-icon.e-arrowhead-down").removeClass("e-arrowhead-down").addClass("e-arrowhead-right");
                            if (this.model.enableSeparator) this._setSeparator(true);                  
                        }
                        else {
							if(hideState)
							{
								hideState=false;
								this.element.find("li.e-ham-wrap").css({display: 'list-item'}); 
								itemsOuterWidth = itemsOuterWidth - menuItem.outerWidth() + hamburgerWidth;
								if(i>1){
									(itemsOuterWidth = itemsOuterWidth - $(this._menuHeaderItems[i-1]).outerWidth());
									i=i-2;
								}								
								continue;
							}
                            this._menuOverflowItems.push($(menuItem).clone(true));                            
                            menuItem.addClass('e-menu-hide');                            
                        }
                }            
                if (this._menuOverflowItems.length>0) {
                    this._renderHamburgerIcon();
                    $('.e-menu-popwrap').length ?  this._addOverflowItems():  this._renderPopupWrapper();                     
                    this.lastelement = this.element.find('>li.e-list:visible').last().addClass('e-last');
                    this.element.find(">li.e-list.e-haschild>ul").find("li.e-haschild").find("span.e-icon.e-arrowhead-down").removeClass("e-arrowhead-down").addClass("e-arrowhead-right");            
                }
                else if (this._menuOverflowItems.length == 0 && $("li.e-ham-wrap").length > 0) {
                    this.element.find("li.e-ham-wrap").remove();
                }

            }           
            if (this.model.orientation == "vertical" || this.model.menuType == ej.MenuType.ContextMenu && ($(window).width() >= 768) && (this.model.isResponsive)) {
                this.element.find("span.e-icon.e-arrowhead-down").removeClass('e-arrowhead-down').addClass('e-arrowhead-right');
            }
            

        },
        _renderHamburgerIcon: function () {
            if((this._ensureOverflowPopup())&& (this.element.find("li.e-ham-wrap").length==0)){            
                var liTag = ej.buildTag("li.e-ham-wrap");
                var divTag = ej.buildTag("div");
                this.hamburgerspan = ej.buildTag('span.e-hamburger');                                                     
                divTag.append(this.hamburgerspan);
                liTag.append(divTag);    
                this.element.append(liTag);
                //to set border
                if (this.model.height != 0) this._setHeight(this.model.height);
                else {                       
                    $("li.e-ham-wrap").css({"height":this.element.find("li.e-list").first().height()});
                }
                //button click event
                this._on(this.element.find("li.e-ham-wrap"), "click", this._overflowOpen);                
            }
        },
        _addOverflowItems: function () {
            if ((this._ensureOverflowPopup()) && ($('.e-menu-popwrap').length>0)) {
				if(!ej.isNullOrUndefined(this.popupWrapper)){
					this.popupWrapper.empty();
					this._menuCloneItems.length = 0;                
					for (var i = 0; i < this._menuOverflowItems.length; i++) {
						this._menuCloneItems.push($(this._menuOverflowItems[i]).clone(true));                    
					}
					this.ulTag = ej.buildTag("ul");
					this.ulTag.addClass("e-menu e-js e-responsive e-widget e-box e-vertical");
					this.popupWrapper.append(this.ulTag);
					for (var i = 0; i < this._menuCloneItems.length; i++) {
						if ($(this._menuCloneItems[i]).hasClass('e-haschild')) {
							$(this._menuCloneItems[i]).find('span.e-icon').removeClass('e-arrowhead-down e-arrowhead-right').addClass('e-arrowhead-down');
							$(this._menuCloneItems[i]).children('span.e-menu-arrow.e-menu-left').remove();                       
						}
						this.ulTag.append(this._menuCloneItems[i]);
					}
					$(this.ulTag).children("li").removeClass("e-menu-hide");
					//to set width of ULTag          
					var popupWidth = Math.round(this.popupWrapper.width());
					if (popupWidth>0) {
						var popupWrapperWidth = this.popupWrapper.innerWidth();
						this.popupWrapper.find("ul.e-menu").css({ "width":popupWrapperWidth+ "px" });                
					}
					//to set the separator                  
					if (this.model.enableSeparator) this._setSeparator(true);                    
				}
            }         
        },
        _overflowOpen: function (e) {           
            if(this._isOverflowPopupOpen ()){   
                //set popup wrapper left position 
                 var location = ej.util.getOffset(this.element);
					var left = location.left + (this.model.enableRTL? 0 :(this.element.outerWidth() - this.popupWrapper.outerWidth()));
					var top = location.top + this.element.outerHeight();
					
					if(this.wrapper.parent().length && (this.wrapper.parent().css("position") == "absolute" || this.wrapper.parent().css("position") == "relative"))
					{
						location = ej.util.getOffset(this.wrapper.parent());
						left = left-location.left;
						top = top-location.top;
					}						
					this.popupWrapper.css({ "left": left,"top":top});                          
                this.popupWrapper.show();                                
                this._trigger("overflowOpen",  {e:e});
            }
            else {
                this._overflowClose(e);
            }
        },           
        _overflowClose: function (e) {
            if(this._ensureOverflowPopup() && !ej.isNullOrUndefined(this.popupWrapper)){            
                this.popupWrapper.find("li.e-list").removeClass(".e-mhover.e-active.e-mfocused");
                this._hideAnimation(this.popupWrapper.find('li.e-list:has("> ul")').find('> ul:visible'), this._hideAnim);
                this.popupWrapper.hide();                               
                this._trigger("overflowClose", { e: e });
            }
        },
        _isOverflowPopupOpen: function () {
		       if($(this.popupWrapper).length>0)
            return this.popupWrapper.css("display")=="none";           
        },
        _removePopup:function(e){
            if(($(window).width()<767)&& (this.model.isResponsive)){
			        this._ensureResponsiveClasses($(window).width());
                if ((this.element.find("li.e-ham-wrap").length > 0) && (this.popupWrapper.length>0)){
                    this.element.find("li.e-ham-wrap").remove();
                    $('.e-menu-popwrap').remove();                   
                    this.element.find("li.e-list").addClass("e-menu-show");             
                }
            }          
        },      
        _mobileResponsiveMenu:function(e){            
            if ((this.model.menuType != ej.MenuType.ContextMenu) && (this.model.orientation != "vertical") && ((this.element.css("display")=="none"))) {
                    this.element.removeClass("e-res-hide").addClass("e-res-show");                 
                }
            else if((this.model.menuType != ej.MenuType.ContextMenu) && (this.model.orientation != "vertical") && (!(this.element.css("display")=="none")))
                {
                    this.element.removeClass("e-res-show").addClass("e-res-hide");                    
                }          
        },
        _ensureOverflowPopup:function(e){
            return (this.model.menuType != ej.MenuType.ContextMenu) && (this.model.orientation != "vertical") && ($(window).width() >= 768) && (this.model.isResponsive);                
        },
        _onResize:function(e){
			this.element.find("li.e-ham-wrap").hide(); 
            $(window).width()>=768 ? this._calculateOverflowItems() : this._removePopup();
        },
        _ensureResponsiveClasses:function(viewport){
            if (viewport && this.element.find("span.e-icon").hasClass("e-arrowhead-right") ) this.element.find("span.e-icon.e-arrowhead-right").removeClass('e-arrowhead-right').addClass('e-arrowhead-down');            
        },

        _responsiveLayout: function () {
            if ((this.model.menuType != ej.MenuType.ContextMenu) && (this.model.orientation != "vertical")) {
                this.wrapper.addClass("e-menu-responsive");
                this.element.addClass("e-menu-responsive")
                this.resWrap = ej.buildTag('span.e-menu-res-wrap e-menu-responsive');
                this.inResWrap = ej.buildTag('span.e-in-wrap e-box e-menu-res-in-wrap');
                this.label = ej.buildTag('span.e-res-title').html(this.model.locale == "en-US" ? this.model.titleText : (ej.Menu.Locale[this.model.locale] && ej.Menu.Locale[this.model.locale].titleText)?ej.Menu.Locale[this.model.locale].titleText:this.model.titleText);
                this.check = ej.buildTag('span.e-check-wrap e-icon');
                this.wrapper.append(this.resWrap)
                this.resWrap.append(this.inResWrap);
                this.inResWrap.append(this.label).append(this.check);
            }
        },
        _addAttr: function (htmlAttr) {
            var proxy = this;
            $.map(htmlAttr, function (value, key) {
                if (key == "class") proxy.wrapper.addClass(value);
                else if (key == "disabled" && value == "disabled") proxy.disable();
                else proxy.element.attr(key, value)
            });
        },

        _oncheck: function (e) {
            var obj = this.element.parents('.e-menu-wrap').children('.e-menu');
            e.isChecked ? obj.removeClass('e-res-hide').addClass('e-res-show') : obj.removeClass('e-res-show').addClass('e-res-hide');
        },
        _addClass : function (){
            //Adding arrows to items with sub items
            this.element.find('li:has("> ul")').find('> a,> span').addClass('aschild');
            this.element.find('>li').addClass('e-list').attr({ "role": "menuitem" });
			this.element.find('li').find(">a, >span").addClass('e-menulink');
            var list = this.element.find('.e-list a.aschild');
            var spanlist = this.element.find('.e-list span.aschild');
            var listElement, spanElement;
            for ( var i = 0; i < list.length; i++) {
                listElement = $(list[i]);
                listElement.siblings().attr({ "aria-hidden": true });
                listElement.parent().attr({ "aria-haspopup": true, "role": "menuitem" }).addClass("e-haschild");
                listElement.siblings('ul').children('li').addClass('e-list').attr("role", "menuitem");
            }
            for ( var i = 0; i < spanlist.length; i++) {
                spanElement = $(spanlist[i]);
                spanElement.siblings().attr({ "aria-hidden": true });
                spanElement.parent().attr({ "aria-haspopup": true, "role": "menu" }).addClass("e-haschild");
                spanElement.siblings('ul').children('li').addClass('e-list').attr("role", "menuitem");
            }
        },
		_renderArrow : function(){
			 if ((this.model.menuType != ej.MenuType.ContextMenu) && (this.model.orientation != "vertical")) {
				if( $($(this.element).find("span.e-menu-arrow")).length == 0){
					var arrow = ej.buildTag("span.e-menu-arrow e-menu-left");
					$(arrow).append("<span class='e-arrowMenuOuter'></span>").append("<span class='e-arrowMenuInner'></span>");
					this.element.find('>li.e-list.e-haschild').append(arrow);
				}
			 }
		},
        _generateTemplate: function (data) {
            var proxy = this, queryPromise;
            if (data instanceof ej.DataManager) {
                queryPromise = data.executeQuery(this._columnToSelect(this.model.fields));
                queryPromise.done(function (e) {
                    proxy._odataFlag = true;
                    proxy._generateItemTemplate(e.result);
                    if (proxy.model.height != 0) proxy._setHeight(proxy.model.height);
                    proxy._wireEvents("_on");
                });
            } else {
                proxy._odataFlag = false;
                this._generateItemTemplate(proxy.model.fields['dataSource']);
                this._wireEvents("_on");
            }
        },

        _generateItemTemplate: function (items) {
            for (var i = 0; i < items.length; i++) {
                if ((items[i][this.model.fields.parentId] == null) || (items[i][this.model.fields.parentId] == 0)) {
                    var subItem = this._menuTemplate(items[i], items, this.model.fields);
                    this.element.append(subItem);
                }
            }
        },

        _menuTemplate: function (item, tableData, mapper) {
            var liTag, aTag, imgTag, spanTag;
            liTag = $(document.createElement('li'));
            liTag.attr("class", 'e-list');
            if (item[mapper.htmlAttribute]) this._setAttributes(item[mapper.htmlAttribute], liTag);
			aTag = $(document.createElement('a'));
			aTag.attr("class", 'e-menulink');
			if (item[mapper.imageUrl] && item[mapper.imageUrl] != "") {
				imgTag = $(document.createElement('img'));
				imgTag.attr('src', item[mapper.imageUrl]);
				if (item[mapper.imageAttribute]) this._setAttributes(item[mapper.imageAttribute], imgTag);
				aTag.append(imgTag);
			}
			else if (item[mapper.spriteCssClass] && item[mapper.spriteCssClass] != "") {
				spanTag = $(document.createElement('span'));
				spanTag.addClass(item[mapper.spriteCssClass]);
				aTag.append(spanTag);
			}
			aTag.append(item[mapper.text]);
			if (item[mapper.linkAttribute]) this._setAttributes(item[mapper.linkAttribute], aTag);
			if (item[mapper.url])
				aTag.attr('href', item[mapper.url]);
			liTag.append(aTag);
            if (item[mapper.id]) {
                liTag.prop("id", item[mapper.id]);
            }
            if (!ej.isNullOrUndefined(mapper["child"])) {
                this._odataFlag = true;
                if (mapper["child"]["dataSource"] instanceof ej.DataManager) {
                    var proxy = this, queryManager = ej.Query();
					$(liTag).attr({ "aria-haspopup": true, "role": "menu" }).addClass("e-haschild");
                    queryManager = this._columnToSelect(mapper["child"]);
                    queryManager.where(mapper["child"]["parentId"], ej.FilterOperators.equal, item[mapper.id]);
                    var queryPromise = mapper["child"]["dataSource"].executeQuery(queryManager);
                    queryPromise.done(function (e) {
                        var childItems = e.result;
                        if (childItems && childItems.length > 0) {
                            var ul = $(document.createElement('ul'));
                            for (var i = 0; i < childItems.length; i++) {
                                var liItem = proxy._menuTemplate(childItems[i], mapper["child"]["dataSource"], mapper["child"]);
                                ul.append(liItem);
                            }
                            liTag.append(ul);
                            $(liTag).children('a').addClass('aschild');
                            if ($(liTag).parent().hasClass('e-menu') && (proxy.model.showRootLevelArrows))
                                $(liTag).children('a.aschild').append($('<span>').addClass("e-icon e-arrowhead-down")).addClass("e-arrow-space");
                            else if (proxy.model.showSubLevelArrows)
                                $(liTag).children('a.aschild').append($('<span>').addClass("e-icon e-arrowhead-right")).addClass("e-arrow-space");
                            if (proxy.model.height != 0) proxy._setHeight(proxy.model.height);
                        }
                    });
                    queryPromise.then(function (e) {
                        proxy._renderArrow();
                    });
                }
                else {
					var childItems;
					if(!ej.isNullOrUndefined(item.child)){
						if(ej.isPlainObject(item.child))
							childItems = ej.DataManager(mapper["child"]["dataSource"]).executeLocal(ej.Query().where(mapper["child"]["parentId"], ej.FilterOperators.equal, item[mapper.id]));
						else if(item.child instanceof Array)
							childItems =  item.child;
					}	
                    if (childItems && childItems.length > 0) {
                        var ul = $(document.createElement('ul'));
                        for (var i = 0; i < childItems.length; i++) {
                            var liItem = this._menuTemplate(childItems[i], mapper["child"]["dataSource"], mapper["child"]);
                            ul.append(liItem);
                        }
                        liTag.append(ul);
                    }
                }
            }
            else if (!this._odataFlag) {
                var childItems = ej.DataManager(mapper["dataSource"]).executeLocal(ej.Query().where(mapper["parentId"], ej.FilterOperators.equal, item[mapper.id]));
                if (childItems && childItems.length > 0) {
                    var ul = ej.buildTag('ul');
                    for (var i = 0; i < childItems.length; i++) {
                        var liItem = this._menuTemplate(childItems[i], mapper["dataSource"], mapper);
                        ul.append(liItem);
                    }
                    liTag.append(ul);
                }
            }
            return liTag;
        },

        _setAttributes: function (data, element) {
            for (var key in data) {
                if (key == "class")
                    element.addClass(data[key]);
                else
                    element.attr(key, data[key]);
            }
        },

        _addArrow: function (topArrows, bottomArrows) {
            if (topArrows) {
				var arrowIcon = (this.model.orientation == "horizontal") ? "e-arrowhead-down" : "e-arrowhead-right";
				this.element.find('>li.e-list:has("> ul")').children('a').append($('<span>').addClass("e-icon "+arrowIcon)).addClass("e-arrow-space");
			}
            else {
                this.element.find('>li.e-list:has("> ul")').children('a').removeClass("e-arrow-space").children('span.e-icon').remove();
            }

            if (bottomArrows)
                this.element.find('>li.e-list > ul li.e-list:has(>ul)').children('a').append($('<span>').addClass("e-icon e-arrowhead-right")).addClass("e-arrow-space");
            else {
                this.element.find('>li.e-list > ul li.e-list:has(>ul)').children('a').removeClass("e-arrow-space").children('span.e-icon').remove();
            }

        },

        _intializeMenu: function () {
            if (this.model.height != 0) this._setHeight(this.model.height);
            if (this.model.width != 0) this._setWidth(this.model.width);
            if (this.model.menuType == "contextmenu")
                this.model.openOnClick = false;
            if (this.model.openOnClick) {
                this._hoverOpen = false;
                this._hoverClose = false;
            }
        },

        _setOrientation: function (val) {
            if (val == "horizontal") {
                this.element.removeClass("e-vertical e-horizontal").addClass("e-horizontal");
            } else {
                this.element.removeClass("e-horizontal e-vertical").addClass("e-vertical");
            }
            if (val == "vertical") {
                this._removePopup();
            }
        },

        _setHeight: function (value) {
            if (this.model.orientation == "horizontal" && value !=="auto") {
                value = typeof value === "number" ? value + "px" : value;
                this.element.find('> li').find('>a:first').css("line-height", value);
                if (this.model.showRootLevelArrows)
                    this.element.find('> li').find('>a:first').find('> span:first').css({ "line-height": value, "top": "0px" })
                if ((this.model.menuType != ej.MenuType.ContextMenu) && (this.model.orientation != "vertical")){
                    if ($("li.e-ham-wrap").length > 0) {                        
                        this.element.find("li.e-ham-wrap").children("div").css({ "line-height": value });
                        this.element.find("li.e-ham-wrap").css({ "height": value });
                        if($(".e-menu-popwrap").length>0)
                        this.popupWrapper.find("a.e-menulink").css({ "line-height":value });                        
                    }
                }
            }
            else
                this.element.height(value);
        },

        _setWidth: function (value) {
            this.element.css("width", value);
            if (this.model.orientation === "horizontal" && value !== "auto") {
                if (this.model.isResponsive)
                    this.resWrap.css("width", value);
            }
            if (this.model.orientation == "horizontal" &&  ((this.model.menuType != ej.MenuType.ContextMenu) && (this.model.orientation != "vertical")) ) {
                this._calculateOverflowItems();
            }
            
        },        
        _setOverflowDimensions:function(property,value){
            if ((this.model.menuType != ej.MenuType.ContextMenu) && (this.model.orientation != "vertical"))
                value = typeof value == "number" ? value + "px" : value;
                if (property == "height") this.popupWrapper.css({ height: value });
                else if (property == "width") this.popupWrapper.css({ width: value });                           
                this._addOverflowItems();
        },

        _setRTL: function (isRTL) {
            if (isRTL) {
                this.element.removeClass("e-rtl").addClass("e-rtl");
            } else {
                this.element.removeClass("e-rtl");
            }
            if (isRTL && this.model.orientation === "horizontal")
                this.wrapper.removeClass("e-menu-rtl").addClass("e-menu-rtl");
            else
                this.wrapper.removeClass("e-menu-rtl");
			this.model.subMenuDirection = isRTL ? "left" : "right";
        },

        _setSubMenuDirection: function (direction) {
            if (direction != "left" && direction != "right")
                this.model.subMenuDirection = this.model.enableRTL ? "left" : "right";
        },

        _setAnimation: function (value) {
            value === "none" ? (this._showAnim = "none", this._hideAnim = "none") : (this._showAnim = "slideDown", this._hideAnim = "slideUp");
        },

        _controlStatus: function (value) {
            value != true ? this.disable() : this.enable();
        },

        _centerAlign: function (enableCenterAlign) {
            if (this.model.orientation == "horizontal" && enableCenterAlign)
                this.element.css('text-align', 'center');
            else
                this.element.css('text-align', 'inherit');
        },
        _columnToSelect: function (mapper) {
            var column = [], queryManager = ej.Query();
            if (ej.isNullOrUndefined(mapper.query)) {
                for (var col in mapper) {
                    if (col !== "tableName" && col !== "child" && col !== "dataSource" && mapper[col])
                        column.push(mapper[col]);
                }
                if (column.length > 0)
                    queryManager.select(column);
                if (!this.model.fields["dataSource"].dataSource.url.match(mapper.tableName + "$"))
                    !ej.isNullOrUndefined(mapper.tableName) && queryManager.from(mapper.tableName);
            }
            else
                queryManager = mapper.query;
            return queryManager;
        },


        _max_zindex: function () {
            var parents, bodyEle, maxZ, index;
            if (this.model.menuType == "contextmenu") {
                parents = $(this._targetElement).parents();
                parents.push(this._targetElement);
            }
            else
                parents = $(this.element).parents();
            bodyEle = $('body').children(), index = bodyEle.index(this.popup);
            bodyEle.splice(index, 1);
            $(bodyEle).each(function (i, ele) { parents.push(ele); });
            maxZ = Math.max.apply(maxZ, $.map(parents, function (e, n) {
                if ($(e).css('position') != 'static') return parseInt($(e).css('z-index')) || 1;
            }));
            if (!maxZ || maxZ < 10000) maxZ = 10000;
            else maxZ += 1;
            return maxZ;

        },

        _recursiveFunction: function (items, menuText) {
            var context = this;
            var isFound = false;
            $.each(items, function (key, value) {
                if (value.Text == menuText) {
                    context.selectedItem = value;
                    isFound = true;
                    return false;
                }
                else if (value.ChildItems != null) {
                    context._recursiveFunction(value.ChildItems, menuText);
                }
                if (isFound)
                    return false;
            });
        },

        _contextMenu_Template: function () {
            if(this.element[0].id !="")
            var oldWrapper = $(".e-menu-wrap #" + this.element[0].id).get(0);
            if (oldWrapper)
                $(oldWrapper.parentElement).remove();
            this.model.orientation = "vertical";
            this.element.addClass(this.model.cssClass + " e-context");
			 this.element.css("display", "none");
            this._referenceElement = this.element.parent();
            $("body").append(this.element);
            this.wrapper.insertBefore(this.element);
            this.wrapper.append(this.element);
        },

        _closeMenu: function () {
            this._hideAnimation(this.element.find('li.e-list:has("> ul")').find('> ul:visible'), this._hideAnim);
        },

        _onMenuIntent: function (element, obj, canOpen) {
            obj._delayMenuHover = window.setTimeout(function () {
                if (obj._mouseOver == true && canOpen) {
                    var showanim = obj._showAnim;
                    var hideanim = obj._hideAnim;
                    var showSpeed = obj._showSpeed;
                    var hideSpeed = obj._hideSpeed;
                    obj._show(element, showanim, hideanim);
                }
            }, this._showSpeed);
        },

        _onHide: function (element, obj, canHide) {
            obj._delaySubMenuHover = window.setTimeout(function () {
                if (obj._mouseOver == false && canHide) {
                    var id = obj._id;
                    var hideanim = obj._hideAnim;
                    var hideSpeed = obj._hideSpeed;
                    obj._closeAll();
                }

            }, obj._hideSpeed);
        },

        _subMenuPos: function (element, direction) {
            var pos = $(element).offset();
            var subMenuLeft, subMenuRight ;
            var posLeft = pos.left;
            var subMenu = $('ul:first', element);
            var menuWidth = $(element).outerWidth();
            if (pos == null || pos == undefined)
                return false;
            var submenuWidth = subMenu.outerWidth() + 1; // +1 for the space between menu and submenu
            var left = this.model.container ? $(this.model.container).width() + $(document).scrollLeft() : document.documentElement.clientWidth + $(document).scrollLeft();
            if (this.model.menuType == "normalmenu") {
                if ($(element.parentNode).is(this.element)) {
                    if (this.model.orientation == "horizontal"){
                        subMenu.css("top", $(element).outerHeight() + "px");
                        if (!this.model.enableRTL) {
                            subMenuLeft = (left < (posLeft + submenuWidth)) ? ((posLeft + submenuWidth) - left) : 1;
                            subMenu.css("left", (subMenuLeft *(-1)) + "px");
                        }
                        else {
                            subMenuRight = (((posLeft + menuWidth) - submenuWidth) < 0) ? ((posLeft + menuWidth) - submenuWidth) : 1;
                            subMenu.css({ "left": "auto", "right": subMenuRight + "px" });
                        }
                    }
                    else if ((direction == "left" && posLeft > submenuWidth) || (direction == "right" && left <= pos.left + menuWidth + submenuWidth &&  posLeft > submenuWidth))
                        subMenu.css("left", -(submenuWidth + 4) + "px");
                    else {
                        subMenu.css("left", ($(element).outerWidth() + 4) + "px");
                    }
                } else if ((direction == "left" && posLeft > submenuWidth) || (direction == "right" && left <= pos.left + menuWidth + submenuWidth &&  posLeft > submenuWidth)) {
                    subMenu.css("left", -(submenuWidth + 4) + "px");
                }
                else {
                    subMenu.css("left", ($(element).outerWidth() + 4) + "px");
                    var submenuHeight = subMenu.outerHeight();
                    var winHeight = $(window).height();
                    var submenuTop = (winHeight - (pos.top - $(window).scrollTop()));
                    if (winHeight < submenuHeight) {
					     var menuPos = pos.top - $(window).scrollTop();
						subMenu.css("top", -(menuPos) + 4 + "px");
					}
                    else if (submenuTop < submenuHeight) {
                        var menuPos = submenuTop - submenuHeight;
						subMenu.css("top", menuPos - 2 + "px");
					}
					else subMenu.css("top", "");
				}
            }
            else {
                left -= (pos.left + (2 * submenuWidth) + 4);
                if (left < 0) {
                    var menuLeftPos = (submenuWidth == null) ? "-206.5px" : "-" + (submenuWidth + 5) + "px";
                    subMenu.css("left", menuLeftPos);
                }
                else {
                    if (subMenu.parent('li.e-list').parent('ul').width() && direction == "right") {
                        subMenu.css("left", (subMenu.parent('li.e-list').parent('ul').width() + 4) + "px");
                    }
                    else if (pos.left > submenuWidth)
                        subMenu.css("left", -(submenuWidth + 4) + "px");
                }
                var submenuHeight = subMenu.outerHeight();
                if ((pos.top + submenuHeight > $(window).height())) {
                    var top = -(submenuHeight) + $(element).outerHeight();
                    if (submenuHeight > (pos.top + ($(element).outerHeight() / 2))) {
                        subMenu.css("top", -(submenuHeight / 2) + "px");
                    }
                    else
                        subMenu.css("top", top + "px");
                }
                else
                    subMenu.css("top","0px");
            }
        },


        _setSkin: function (skin) {
            this.wrapper.removeClass(this.model.cssClass).addClass(skin + " e-menu-wrap");
        },

        _setSeparator: function (separator) {
            if (separator){
                this.element.addClass("e-separator");
                if ($('.e-menu-popwrap').length>0 && !ej.isNullOrUndefined(this.ulTag))
                    this.ulTag.addClass("e-separator");     
            }
            else this.element.removeClass("e-separator");
        },

        _contextMenuEvents: function (action) {
            this[action]($(this.model.contextMenuTarget), "mouseup taphold", this._ContextMenuHandler);
            this[action](this.element, "contextmenu", this._onDefaultPreventer);
            this[action]($(this.model.contextMenuTarget), "contextmenu", this._onDefaultPreventer);
            this[action]($(document), "mousedown", this._onContextClose);
        },

        _show: function (element, showanim, hideanim) {
            var siblingElement;
            var sibling = $('> ul', element);
			var zIndex = this._max_zindex();
            sibling.attr({ "aria-hidden": false });
            this._hideAnimation($(element).siblings().find(' > ul:visible'), hideanim);
            if (!($.inArray(this._disabledMenuItems, element) > -1)) {
                if (sibling.css('display') != "none") {
                    siblingElement = this.model.openOnClick ? $(sibling) : sibling.children().find('> ul');
                    this._hideAnimation(siblingElement, hideanim);
                }
                else $('> ul', element).children().find('> ul').hide();
                this._subMenuPos(element, this.model.subMenuDirection);
                sibling.css({ "z-index": zIndex + 1 });
				$(element).children('span.e-menu-arrow').css({"z-index": zIndex + 2 });
                if ($('> ul', element).css('display') != 'block' && !$(element).hasClass("e-disable-item")) {
                    this._showAnimation(sibling, showanim);
                    sibling.closest('li').addClass('e-active e-mfocused');
                }
                if ($(element).siblings("li.e-active").length > 0)
                    $(element).siblings("li.e-active").removeClass("e-active e-mfocused");
            }
        },

        _closeAll: function () {
            this._hideAnimation(this.element.find('li.e-list:has("> ul")').find('> ul:visible'), this._hideAnim);
            this._hideAnimation(this.element.find('> ul:visible'), this._hideAnim);
        },

        _showAnimation: function (element, anim) {
            switch (anim) {
                case "slideDown":
                    element.slideDown(this.model.enableAnimation ? 200 : 0); break;
                case "none":
                    element.css("display", "block"); break;
            }
        },

        _hideAnimation: function (element, anim) {
            switch (anim) {
                case "slideUp":
                    $(element).attr({ "aria-hidden": true });
                    element.slideUp(this.model.enableAnimation ? 100 : 0); break;
                case "none":
                    element.css("display", "none"); break;
            }
            element.closest('li').removeClass('e-active e-mfocused');
        },

        _removeValue: function (text, disableList) {
            var $browInfo = ej.browserInfo(), elementText;
            $browInfo.version === "8.0" && $browInfo.name === "msie" ? elementText = text[0].outerText : elementText = text[0].textContent;
            var count = $(disableList).length, i = 0;
            var childEle = $(disableList).children('a').length == 0 ? $(disableList).children('span') : $(disableList).children('a');
            while (i <= count) {
                if ($(childEle[i]).text() === elementText)
                    return i;
                i++;
            }
        },

        _createSubLevelItem: function (target, element) {
            var ulTag;
            ulTag = $(document.createElement('ul'));
            ulTag.append(element);
            target.append(ulTag);
            target.attr({ 'role': 'menu', 'aria-haspopup': 'true' });
            target.addClass("e-haschild");
            this.element.find('li:has("> ul")').find('> a,>span').addClass('aschild e-arrow-space');
            this._insertArrows(ulTag);
        },

        _insertArrows: function (ulTag) {
            if (this.model.showRootLevelArrows)
                ulTag.find('>a,>span').append($('<span>').addClass("e-icon e-arrowhead-down")).addClass("e-arrow-space");
            else
                ulTag.find('>a,>span').removeClass("e-arrow-space").find('>span.e-icon').remove();

            if (this.model.showSubLevelArrows)
                ulTag.parent('li.e-list:has(>ul)').children('a,span').append($('<span>').addClass("e-icon e-arrowhead-right")).addClass("e-arrow-space");
            else
                ulTag.parent('li.e-list:has(>ul)').children('a,span').removeClass("e-arrow-space").find('>span.e-icon').remove();
        },

        _createMenuItem: function (item) {
            var liTag, aTag, imgTag, spanTag;
            liTag = $(document.createElement('li'));
            liTag.attr({ "class": 'e-list', "role": "menuitem" });
            if (item["htmlAttribute"]) this._setAttributes(item["htmlAttribute"], liTag);
            if (item["text"] && item["text"] != "") {
                aTag = $(document.createElement('a'));
				aTag.attr({ "class": 'e-menulink'});
                if (item["imageUrl"] && item["imageUrl"] != "") {
                    imgTag = $(document.createElement('img'));
                    imgTag.attr('src', item["imageUrl"]);
                    if (item["imageAttribute"]) this._setAttributes(item["imageAttribute"], imgTag);
                    aTag.append(imgTag);
                }
                else if (item["spriteCssClass"] && item["spriteCssClass"] != "") {
                    spanTag = $(document.createElement('span'));
                    spanTag.addClass(item["spriteCssClass"]);
                    aTag.append(spanTag);
                }
                aTag.append(item["text"]);
                if (item["linkAttribute"]) this._setAttributes(item["linkAttribute"], aTag);
                if (item["url"])
                    aTag.attr('href', item["url"]);
                liTag.append(aTag);
            }
            if (item["id"]) {
                liTag.prop("id", item["id"]);
            }
            if (!this.model.enabled)
                liTag.addClass("e-disable-item");
            return liTag;
        },

        _insertNode: function (itemCollection, targetNode, operation) {
            var item = 0, targetList = 0, target = 0, targetCollection = [];
            if ($(targetNode).is(this.element))
                targetCollection.push(this.element);
            else
                typeof (targetNode) === "string" ? targetCollection.push(this.element.find(targetNode)) : typeof (targetNode) === "undefined" ? targetCollection.push(this.element) : targetCollection.push(targetNode);
            for (targetList = 0; targetList < targetCollection.length; targetList++) {
                for (target = 0; target < targetCollection[targetList].length; target++)
                    for (item = 0; item < itemCollection.length && !ej.isNullOrUndefined(itemCollection[item]) ; item++)
                        this._addItem(itemCollection[item], targetCollection[targetList][target], operation);
            }
        },

        _addItem: function (item, target, operation) {
            var element, targetElement;
            this._wireEvents("_off");
            element = this._createMenuItem(item);
            target = target === "default" ? $("#" + item["parentId"]) : $(target);
            switch (operation) {
                case "insert":
                    $(target).is(this.element) ? targetElement = target : targetElement = target.children('ul');
                    targetElement.length != 0 ? targetElement.append(element) : this._createSubLevelItem(target, element);
                    break;
                case "insertBefore":
                    if (!$(target).is(this.element))
                        element.insertBefore(target);
                    else
                        target.prepend(element);
                    break;
                case "insertAfter":
                    if (!$(target).is(this.element))
                        element.insertAfter(target);
                    else
                        target.append(element);
                    break;
            }
            this._wireEvents("_on");
        },

        _removeItem: function (item) {
            if (item.siblings('li').length == 0) {
                item.closest("ul").siblings('a.aschild').removeClass("aschild e-arrow-space").children('span.e-icon').remove();
                !item.closest("ul").hasClass("e-menu") ? item.closest("ul").remove() : item.remove();
            }
            else
                item.remove();
        },

        _hiddenElement: function (ele) {
            if (ele.length > 0 && ($.inArray(ele[0], this._hiddenMenuItems) == -1)) {
                ele.addClass("e-hidden-item");
                this._hiddenMenuItems.push(ele[0]);
            }
        },

        _showElement: function (ele) {
            if (ele.length > 0 && ($.inArray(ele[0], this._hiddenMenuItems) > -1)) {
                ele.removeClass("e-hidden-item");
                this._hiddenMenuItems.splice(this._hiddenMenuItems.indexOf(ele[0]), 1);
            }
        },

        _getNodeByID: function (node) {
            (typeof node != "object" && node != "") && (node = this.element.find(".e-list" + node));
            return $(node);
        },

        _processItems: function (node, bool) {
            var ele = this._getNodeByID(node);
            for (var i = 0; i < ele.length; i++) bool ? this._showElement($(ele[i])) : this._hiddenElement($(ele[i]));
        },

        insert: function (item, target) {
            this._insertNode(item, target, "insert");
        },

        insertBefore: function (item, target) {
            this._insertNode(item, target, "insertBefore");
        },

        insertAfter: function (item, target) {
            this._insertNode(item, target, "insertAfter");
        },

        remove: function (targetCollection) {
            var target = 0, innerTarget = 0;
            for (target = 0; target < targetCollection.length; target++) {
                targetCollection[target] = typeof (targetCollection[target]) === "string" ? (this.element.find(targetCollection[target])) : targetCollection[target];
                for (innerTarget = 0; innerTarget < targetCollection[target].length; innerTarget++)
                    (targetCollection[target][innerTarget].tagName === "LI" || targetCollection[target][innerTarget].tagName === "UL") ? this._removeItem($(targetCollection[target][innerTarget])) : targetCollection[target][innerTarget].remove();
            }
        },

        showContextMenu: function (locationX, locationY, targetElement, e, update) {
            this._closeMenu();
            this._eventArgs = e;
            if (!ej.isNullOrUndefined(e) && this._checkForExclusion(e.target)) return;
            if (this._trigger("beforeOpen", { target: targetElement, events: e })) return false;
            if (this._preventContextOpen) {
                if (!ej.isNullOrUndefined(targetElement))
                    this._targetElement = targetElement;
                else if (!ej.isNullOrUndefined(target))
                    this._targetElement = target;
                else
                    this._targetElement = this.element;
                if (update) {
                    var position = this._calculateContextMenuPosition(e);
                    locationX = position.X;
                    locationY = position.Y;
                }
                this.element.css({ "left": locationX, "top": locationY });
                this.element.css({ "z-index": this._max_zindex() + 1 });
                this._showAnimation(this.element, this._showAnim);
                this._isContextMenuOpen = true;
                this.element.focus();

                this._trigger("open", { target: targetElement });
                this._on(ej.getScrollableParents($(this.model.contextMenuTarget)), "scroll", this.hideContextMenu);
            }
            return false;
        },

        _checkForExclusion: function (e) {
            if (!ej.isNullOrUndefined(this.model.excludeTarget)) {
                var excludeTargets = this.model.excludeTarget.split(",");
                for (var target = 0; target < excludeTargets.length; target++) {
                    if ($(e).closest(this.model.excludeTarget).is($.trim(excludeTargets[target])))
                        return true;
                }
            }
        },


        hideContextMenu: function (e) {
            this._closeMenu();
            this.element.find(".e-mhover").removeClass("e-mhover");
            this.element.find(".e-mfocused").removeClass("e-mfocused");
            this._hideAnimation(this.element, this._hideAnim);
            this._isContextMenuOpen = false;

            this._trigger("close", $.extend({ events: e }, e));
            this._off(ej.getScrollableParents($(this.model.contextMenuTarget)), "scroll", this.hideContextMenu);
        },


        disableItem: function (itemToDisable) {
            var isMenuItem = $(this.element.find('li.e-list >a ,li.e-list >span')).filter(function () { return $.trim($(this).text()) === itemToDisable; });
            if (isMenuItem.length > 0 && !($.inArray(isMenuItem.parent()[0], this._disabledMenuItems) > -1)) {
                isMenuItem.parent().addClass("e-disable-item").attr({ "aria-disabled": true });
                isMenuItem.parent().find('>a.aschild span.e-icon').addClass("e-disable");
                this._disabledMenuItems.push(isMenuItem.parent()[0]);
            }
        },


        disableItemByID: function (itemId) {
            if (itemId && itemId != "") {
                var itemToDisable = this.element.find("#" + itemId) ? this.element.find("#" + itemId)[0] : undefined;
                if (itemToDisable && !($.inArray(itemToDisable, this._disabledMenuItems) > -1)) {
                    $(itemToDisable).addClass("e-disable-item").attr({ "aria-disabled": true });
                    $(itemToDisable).find('>a.aschild span.e-icon').addClass("e-disable");
                    this._disabledMenuItems.push(itemToDisable);
                }
            }
        },

        getHiddenItems:function(){
            return this._hiddenMenuItems;
        },

        hideItems: function (node) {
            if (typeof node == "object" && node.length !== undefined) {
                for (var i = 0; i < node.length; i++) this._processItems(node[i], false);                
            }
            else this._processItems(node, false);
        },

        showItems:function(node){
            if (typeof node == "object" && node.length !== undefined) {
                for (var i = 0; i < node.length; i++) this._processItems(node[i], true);
            }
            else this._processItems(node, true);
        },

        enableItem: function (itemToEnable) {
            var isMenuItem = $(this.element.find('li.e-list >a ,li.e-list >span')).filter(function () { return $.trim($(this).text()) === itemToEnable; });
            if (isMenuItem.length > 0 && ($.inArray(isMenuItem.parent()[0], this._disabledMenuItems) > -1)) {
                isMenuItem.parent().removeClass("e-disable-item").attr({ "aria-disabled": false });
                isMenuItem.parent().find('>a.aschild span.e-icon').removeClass("e-disable");
                var index = this._removeValue(isMenuItem, this._disabledMenuItems);
                this._disabledMenuItems.splice(index, 1);
            }
        },


        enableItemByID: function (itemId) {
            if (itemId && itemId != "") {
                var itemToEnable = this.element.find("#" + itemId)[0];
                if (itemToEnable && ($.inArray(itemToEnable, this._disabledMenuItems) > -1)) {
                    $(itemToEnable).removeClass("e-disable-item").attr({ "aria-disabled": false });
                    $(itemToEnable).find('>a.aschild span.e-icon').removeClass("e-disable");
                    for (var i = this._disabledMenuItems.length - 1; i >= 0; i--) {
                        if (this._disabledMenuItems[i].id == itemId) {
                            this._disabledMenuItems.splice(i, 1);
                        }
                    }
                }
            }
        },


        disable: function () {
            this.model.enabled = false;
            var menuItemCollection = this.element.find('>li[class~=e-list]');
            var proxy = this;
            $.each(menuItemCollection, function (key, value) {
                if (!($.inArray(value, proxy._disabledMenuItems) > -1))
                {
                    $(value).addClass("e-disable-item").attr({ "aria-disabled": true });
                    $(value).find('>a.aschild span.e-icon').addClass("e-disable");
                    proxy._disabledMenuItems.push(value);
                }
                
            });
        },


        enable: function () {
            var proxy = this;
            this.model.enabled = true;
            var menuItemCollection = this.element.find('li.e-disable-item');
            $.each(menuItemCollection, function (key, value) {
                $(value).removeClass("e-disable-item").attr({ "aria-disabled": false });
                $(value).find('>a.aschild span.e-icon').removeClass("e-disable");
                proxy._disabledMenuItems.pop(value);
            });
        },

        show: function (locationX, locationY, targetElement, e) {
            if (!this.model.enabled) return false;
            if (this.model.menuType == "contextmenu")
                this.showContextMenu(locationX, locationY, targetElement, e, false);
            else
                this.element.css("display", "block");
        },

        hide: function (e) {
            if (!this.model.enabled) return false;
            if (this.model.menuType == "contextmenu")
                this.hideContextMenu(e);
            else {
                this._closeMenu();
                this.element.css("display", "none");
            }
        },

        _wireEvents: function (action) {
            this[action](this.element.find("li.e-list"), "mouseout", this._mouseOutHandler);
            this[action](this.element.find("li.e-list"), "mouseover", this._mouseOverHandler);
            this[action](this.element.children(), "click", this._onClickHandler); 
            this[action](this.element, "keydown", this._onKeyDownHandler);
            this[action](this.element, "focus", this._OnFocusHandler);
            this[action](this.element, "blur", this._OnFocusOutHandler);
            if (this.model.menuType == "contextmenu" && $(this.model.contextMenuTarget)[0] != null) {
                this._contextMenuEvents(action);
            }
            if (this.model.menuType != "contextmenu") {
                this[action]($(document), "click", this._onDocumentClick);
                this[action](this.element, "mousedown", this._onMouseDownHandler);
            }
            this[action]($(window),"resize", $.proxy(this._onResize, this));            
        },

        _mouseOverHandler: function (event) {
            var element, itemId = "";
            this.element.find(".e-mhover").removeClass("e-mhover");
            event.currentTarget = $(event.target).closest("li")[0];
            if (!$(event.currentTarget).hasClass('e-disable-item'))
                $(event.currentTarget).addClass("e-mhover");
            else this._isFocused = false;
            if (event.stopPropagation)
                event.stopPropagation();
            if (typeof (this._delaySubMenuHover) !== 'undefined') {
                clearTimeout(this._delaySubMenuHover);
            }
            if (typeof (this._delaySubMenuHover) !== 'undefined') {
                clearTimeout(this._delayMenuHover);
            }
            this._mouseOver = true;
            this._isMenuOpen = true;
            if ($(event.currentTarget.parentNode.parentNode).is(this.element)) {
                this._isSubMenuOpen = false;
            }
            else {
                this._isSubMenuOpen = true;
            }
            if (event.currentTarget.nodeName == "LI")
                element = event.currentTarget;
            else if (event.currentTarget.parentNode) {
                if (event.currentTarget.parentNode.nodeName == "LI")
                    element = event.currentTarget.parentNode;
                else
                    return false;
            }
            else {
                event.preventDefault();
                return false;
            }
            if (!$(event.currentTarget).hasClass('e-disable-item'))
                this._onMenuIntent(element, this, this._hoverOpen);
            if (!($.inArray(element, this._disabledMenuItems) > -1)) {
                var menuText = $(element).children('a,span').text();
                itemId = !ej.isNullOrUndefined(element) ? $(element)[0].id : "";
                var eventArgs = { "text": menuText, "element": element, "event": event, "ID": itemId };

                this._trigger("mouseover", $.extend({ events: eventArgs }, eventArgs));
            }
        },

        _onMouseDownHandler: function (e) {
            if ($(e.target).hasClass('e-menu')) this._isFocused = false;
        },


        _mouseOutHandler: function (event) {
            var element, itemId = "";
            $(event.currentTarget).removeClass("e-mhover");
            if (event.stopPropagation)
                event.stopPropagation();
            if (typeof (this._delaySubMenuHover) !== 'undefined') {
                clearTimeout(this._delaySubMenuHover);
            }
            if (typeof (this._delaySubMenuHover) !== 'undefined') {
                clearTimeout(this._delayMenuHover);
            }
            this._mouseOver = false;
            this._isMenuOpen = false;

            if (event.currentTarget.nodeName == "LI")
                element = event.currentTarget;
            else if (event.currentTarget.parentNode) {
                if (event.currentTarget.parentNode.nodeName == "LI")
                    element = event.currentTarget.parentNode;
                else
                    return false;
            }
            else {
                event.preventDefault();
                return false;
            }
            this._onHide(element, this, this._hoverClose);
            if (!($.inArray(element, this._disabledMenuItems) > -1)) {
                var menuText = $(element).children('a,span').text();
                itemId = !ej.isNullOrUndefined(element) ? $(element)[0].id : "";
                var eventArgs = { "text": menuText, "element": element, "event": event, "ID": itemId };

                this._trigger("mouseout", $.extend({ events: eventArgs }, eventArgs));
            }
        },

        _onClickHandler: function (event) {
            var element, itemId = "" , parentId, parentText;
            this._isFocused = true;
            var openOnClickStart = false;
            if (!$(event.target).closest("li.e-list").hasClass('e-disable-item') && $(event.target).closest("li.e-list").length > 0) {
                element = $(event.target).closest("li.e-list")[0];
                if ($(element).is(this.element.find(">li.e-list")))
                    this._activeElement = element;
            }
            else {
                if ($(event.target).is(this.element))
                    this._activeElement = this.element.find(">li:first");
                return;
            }
            if ($(event.target).is("a") && $(element).find(">a,>span").hasClass('aschild') && this.model.openOnClick) {
                this._isFocused = false;
            }
            if (!this._hoverOpen && $(element).find(">a,>span").hasClass('aschild')) {
                this._show(element, this._showAnim, this._hideAnim);
                this._hoverOpen = false;
                openOnClickStart = true;
            }
            if (!($.inArray(element, this._disabledMenuItems) > -1)) {
                //Check if Context Menu, then hide the context menu firing the events
                if (this.model.menuType == "contextmenu") {
                    if (this._isContextMenuOpen && !$(element).hasClass("e-haschild")) {
                        this._hideAnimation(this.element, this._hideAnim);
                        this._isContextMenuOpen = false;

                        this._trigger("close", $.extend({ events: event }, event));
						this._off(ej.getScrollableParents($(this.model.contextMenuTarget)), "scroll", this.hideContextMenu);
                    }
                }
                if (!openOnClickStart) {



                    if (!$(element).find(">a,>span").hasClass("aschild")) {
                        this._closeMenu();
                        if (this.model.openOnClick)
                            this._hoverOpen = false;
                    }
                }
                var menuText = $(element).children('a,span').text();
                var parent = $(element).closest("ul").parent("li");
                if (parent.length != 0) {
                    parentId = ej.isNullOrUndefined(parent.attr("id")) ? null : parent.attr("id");
                    parentText = parent.children('a,span').text();
                }
                else {
                    parentId = null;
                    parentText = null;
                }
                itemId = !ej.isNullOrUndefined(element) ? $(element)[0].id : "";
                var eventArgs = { "text": menuText, "element": element, "event": event, "selectedItem": this.selectedItem, "ID": itemId, "parentId": parentId, "parentText": parentText };
                this._trigger("click", $.extend({ events: eventArgs }, eventArgs));
                this.selectedItem = null;
                if (this.model.openOnClick && this.model.menuType != "contextmenu")
                    this.element.focus();
            }
        },


        _onKeyDownHandler: function (e) {
            if( e.target && e.target.nodeName && $( e.target ).closest( "input, textarea" ).length > 0) return true;
            if (this.model.menuType == "contextmenu" && !this._isContextMenuOpen) return;
            var element, focusEle, itemId = "", hoverElement = this.element.find(".e-mhover"), focusedElement = this.element.find(".e-mfocused"), currentElement, liVisible;
            if (!$(hoverElement).length > 0 && $(this._activeElement).length > 0)
                hoverElement = focusedElement = $(this._activeElement);

            if (e.keyCode == 9) {
                this._isFocused = false;
                this._OnFocusOutHandler();
            }
            else if (e.keyCode == 37 || e.keyCode == 38 || e.keyCode == 39 || e.keyCode == 40)
                e.preventDefault();

            if (e.keyCode == 40) {
                if (this.model.orientation == "horizontal") {
                    if (this.element.find(">li.e-mhover").children("ul").length > 0 || $(this._activeElement).length > 0) {
                        if ($(hoverElement).children("ul").css('display') === "none")
                            this._show(hoverElement[hoverElement.length - 1], this._showAnim, this._hideAnim);
                        hoverElement.removeClass("e-mhover e-mfocused").children("ul:first").find("li:first").addClass("e-mhover");
                        this._activeElement == null ? hoverElement.addClass("e-mfocused") : $(this._activeElement).addClass("e-mfocused");
                    } else {
                        liVisible = hoverElement.parent().children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                        $(hoverElement[hoverElement.length-1]).removeClass("e-mfocused e-mhover");
                        focusEle = $(liVisible[liVisible.index(hoverElement) + 1]).length > 0 ? $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) + 1]) : liVisible.first();
                        focusEle.addClass("e-mhover");
                    }
                }
                else if (this.model.orientation != "horizontal") {
                    if (hoverElement.length == 0) liVisible = this.element.children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                    else liVisible = hoverElement.parent().children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                    hoverElement.removeClass("e-mfocused e-mfocused");
                    if (hoverElement.length > 0) {
                        hoverElement.removeClass("e-mhover");
                        focusEle = $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) + 1]).length > 0 ? $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) + 1]) : liVisible.first();
                    } else focusEle = liVisible.first();
                    focusEle.addClass("e-mhover");
                }
            }
            if (e.keyCode == 39) {
                if (this.model.orientation == "horizontal" && (this.element.find(">li.e-list").hasClass("e-mhover") || $(this._activeElement).length > 0)) {
                    hoverElement.removeClass("e-mfocused e-mhover");
                    liVisible = this.element.children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                    focusEle = $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) + 1]).length > 0 ? $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) + 1]) : liVisible.first();
                    focusEle.addClass("e-mhover");
                }
                else if ($(hoverElement).children("ul").length > 0) {
                    hoverElement.removeClass("e-mfocused e-mhover");
                    var firstChild = hoverElement.children("ul:first").find("li:first");
                    this._show(hoverElement[hoverElement.length - 1], this._showAnim, this._hideAnim);
                    liVisible = hoverElement.addClass('e-mfocused').children("ul:first").children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                    focusEle = $(liVisible[liVisible.index(firstChild)]).length > 0 ? $(liVisible[liVisible.index(firstChild)]) : liVisible.first();
                    focusEle.addClass("e-mhover");
                }
                else if (hoverElement.children("ul").length <= 0) {
                    if (this.model.orientation == "horizontal" && hoverElement.parent().closest('.e-list').parent().hasClass('e-menu')) {
                        this._hideAnimation(hoverElement.parent(), this._hideAnim);
                        hoverElement.removeClass("e-mfocused e-mhover");
                        $(focusedElement[focusedElement.length - 1]).removeClass("e-mfocused");
                        liVisible = hoverElement.parent().closest('.e-list').parent().children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                        focusEle = $(liVisible[liVisible.index(focusedElement[focusedElement.length - 1]) + 1]).length > 0 ? $(liVisible[liVisible.index(focusedElement[focusedElement.length - 1]) + 1]) : $(liVisible[liVisible.index(focusedElement.first())]);
                        focusEle.addClass("e-mhover");
                    }
                }
            }

            if (e.keyCode == 38) {
                if (this.model.orientation == "horizontal") {
                    liVisible = hoverElement.parent().children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                    hoverElement.removeClass("e-mfocused e-mhover");
                    focusEle = $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) - 1]).length > 0 ? $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) - 1]) : liVisible.last();
                }
                else if (this.model.orientation != "horizontal") {
                    if (hoverElement.length == 0) liVisible = this.element.children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                    else liVisible = hoverElement.parent().children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                    if (hoverElement.length > 0) {
                        hoverElement.removeClass("e-mfocused e-mhover");
                        focusEle = $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) - 1]).length > 0 ? $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) - 1]) : liVisible.last();
                    } else focusEle = liVisible.last();
                }
                focusEle.addClass("e-mhover");
            }

            if (e.keyCode == 37) {
                if (this.model.orientation == "horizontal") {
                    if (this.element.find(">li.e-list").hasClass("e-mhover") || $(this._activeElement).length > 0) {
                        hoverElement.removeClass("e-mfocused e-mhover");
                        liVisible = this.element.find('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                        focusEle = $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) - 1]).length > 0 ? $(liVisible[liVisible.index(hoverElement[hoverElement.length - 1]) - 1]) : liVisible.last();
                        focusEle.addClass("e-mhover");
                    }
                    else {
                        this._hideAnimation(hoverElement.parent(), this._hideAnim);
                        hoverElement.removeClass("e-mfocused e-mhover");
                        $(focusedElement[focusedElement.length - 1]).removeClass("e-mfocused e-active");
                        liVisible = hoverElement.parent().closest('.e-list').parent().children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                        if (hoverElement.parent().closest('.e-list').parent('.e-menu').length > 0)
                            focusEle = $(liVisible[liVisible.index(focusedElement[focusedElement.length - 1]) - 1]).length > 0 ? $(liVisible[liVisible.index(focusedElement[focusedElement.length - 1]) - 1]) : liVisible.last();
                        else
                            focusEle = $(liVisible[liVisible.index(focusedElement[focusedElement.length - 1])]).length > 0 ? $(liVisible[liVisible.index(focusedElement[focusedElement.length - 1])]) : liVisible.last();
                        focusEle.addClass("e-mhover");
                    }
                }
                else if (hoverElement.parent(".e-menu").length == 0 || (this.model.menuType == "contextmenu" && hoverElement.parent("ul.e-context").length == 0)) {
                        this._hideAnimation(hoverElement.parent(), this._hideAnim);
                        hoverElement.removeClass("e-mfocused e-mhover");
                        $(focusedElement[focusedElement.length - 1]).removeClass("e-mfocused");
                        liVisible = hoverElement.parent().closest('.e-list').parent().children('li.e-list:visible:not(.e-hidden-item, .e-disable-item)');
                        focusEle = $(liVisible[liVisible.index(focusedElement[focusedElement.length - 1])]).length > 0 ? $(liVisible[liVisible.index(focusedElement[focusedElement.length - 1])]) : $(liVisible[liVisible.index(focusedElement.last())]);
                        focusEle.addClass("e-mhover");
                }
            }
            if (e.keyCode == 13) {
                var menuText = $(hoverElement).children('a,span').text();
                itemId = !ej.isNullOrUndefined($(hoverElement)[0]) ? $(hoverElement)[0].id : "";
                var eventArgs = { "menuId": this.element[0].id, "text": menuText, "selectedItem": focusedElement, "ID": itemId };
                if (this.model.menuType == "contextmenu") {
                    if (this._isContextMenuOpen && hoverElement.length > 0 && !focusedElement.hasClass("e-disable-item")) {
                        if (this.model.click)
                            this._trigger("click", $.extend({ events: eventArgs }, eventArgs));
                        this.selectedItem = null;
                        this.hideContextMenu(e);
                    }
                } else {
                    if (hoverElement.length > 0 && !hoverElement.hasClass("e-disable-item")) {
                        if ($(hoverElement).find(">a,>span").hasClass('aschild') && $(hoverElement).children("ul").css('display') === "none") {
                            this._show(hoverElement[0], this._showAnim, this._hideAnim);
                            hoverElement.removeClass("e-mhover").children("ul:first").find("li:first").addClass("e-mhover");
                        }
                        else {
                            this.element.find(".e-mhover >a,.e-mhover >span ").focus();
                            this.element.find("li.e-list").removeClass("e-mhover e-mfocused");
                            this._closeAll();
                        }
                        if (ej.isNullOrUndefined($(hoverElement).find(">a").attr("href")))
                            this._trigger("click", $.extend({ events: eventArgs }, eventArgs));
                    }
                }
            }
            if (e.keyCode == 27) {
                if (this.model.menuType == "contextmenu")
                    this.hideContextMenu(e);
                else
					this.element.find("li.e-list").removeClass("e-mhover");
                    this.element.find('li.e-list:has("> ul")').find('> ul:visible').parents("li.e-list").addClass("e-mhover");
                    this._closeAll();
            }
            if ($(e.target).is(this.element) && e.target.parentNode) {
                if (hoverElement.length)
                    element = hoverElement;
            }
            else
                return false;
            if (!($.inArray(element, this._disabledMenuItems) > -1)) {
                var menuText = $(element).children('a,span').text();

                itemId = !ej.isNullOrUndefined(element) ? $(element)[0].id : "";
                if (this.element.find('li.e-mfocused.e-mhover').length || e.keyCode == 13)
                    currentElement = (e.keyCode == 13) ? hoverElement : this.element.find('li.e-mfocused.e-mhover');
                var eventArgs = { "text": menuText, "element": element, "targetElement": currentElement , "event": e, "ID": itemId };

                this._trigger("keydown", $.extend({ events: eventArgs }, eventArgs));
            }
            this._activeElement = null; focusedElement = this.element.find(".e-mfocused");
        },

        _OnFocusHandler: function (event) {
            if (this.model.menuType != "contextmenu" && !this.element.find(">li:first").hasClass("e-disable-item") && this._isFocused && this.element.find(".e-mhover").length == 0 && $('li.e-ham-wrap').length ==0) {
                this.element.find(">li:first").addClass("e-mhover");
            }
            else this._isFocused = true;
            if (this.model.menuType != "contextmenu")
                this._activeElement = this.element.find(">li:first");
        },

        _OnFocusOutHandler: function () {
            if (!this._isFocused) {
                this.element.find("li.e-list").removeClass("e-mhover e-mfocused");
                this._closeAll();
            }
            this._isFocused = false;
        },

        _onDocumentClick: function (event) {
            if (this.model.openOnClick)
                this._hoverOpen = false;
            if (!$(event.target).parents(".e-menu").is(this.element)) {
                this.element.find("li.e-list").removeClass("e-mhover e-mfocused");
                this._closeAll();
                this._isFocused = true;
            }
            if ((!$(event.target).parents("ul.e-menu").is(this.popupWrapper)) && (!$(event.target).hasClass('e-ham-wrap')) && (!($(event.target).parent().hasClass('e-ham-wrap'))) && (!$(event.target).hasClass('e-hamburger')) && (!$(event.target).parent("li").hasClass("e-haschild")) && (!$(event.target).is('span.e-icon.e-arrowhead-down')) && !(this._isOverflowPopupOpen()) && this.model.menuType != "contextmenu" && $("li.e-ham-wrap").length > 0) {
                this._overflowClose();
            }           
        },


        _ContextMenuHandler: function (e) {
            var isRightClick = false;
            if (e.type == "taphold" && e.button != 0)
                isRightClick = true;
            else if (e.button)
                isRightClick = (e.button == 2);
            else if (e.which)
                isRightClick = (e.which == 3); //for Opera
            var targetElement = e.target;
            if (isRightClick) {
                var evt = e;
                if (e.type == "taphold") {
                    if (e.options.type == "touchstart") evt = e.options.touches[0];
                    else evt = e.options;
                }
                var showSpeed = this._showSpeed;
                this.showContextMenu(null, null, targetElement, evt, true);
            }
            else {
                if (this._isContextMenuOpen) {
                    var hideanim = this._hideAnim;
                    var hideSpeed = this._hideSpeed;
                    this.hideContextMenu(e, hideanim, hideSpeed);
                }
            }
        },

        _calculateContextMenuPosition: function (e) {
            var locationX, locationY;
            this.element.css({"top": "", "left": ""}); 
            locationX = (e.clientX + this.element.width() < $(window).width()) ? e.pageX : e.pageX - this.element.width();
            locationY = (e.clientY + this.element.height() < $(window).height()) ? e.pageY : (e.clientY > this.element.height()) ? e.pageY - this.element.height() : $(window).height() - this.element.outerHeight();
            var bodyPos = $("body").css("position") != "static" ? $("body").offset() : { left: 0, top: 0 };
            locationX -= bodyPos.left, locationY -= bodyPos.top;
            return {
                X: locationX,
                Y: locationY
            };
        },


        _onDefaultPreventer: function (e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        },


        _onContextClose: function (e) {
            var proxy = this;
            if (this._isContextMenuOpen) {
                var isRightClick = false;
                if ($(e.target).is(this.element) || $(e.target).parents(".e-context").is(this.element))
                    isRightClick = true;
                if (!isRightClick) {
                    var hideanim = this._hideAnim;
                    var hideSpeed = this._hideSpeed;
                    this.hideContextMenu(e, hideanim, hideSpeed);
                    var parentElements = $(e.target).parents();
                    $.each(parentElements, function (index, value) {
                        if (value.id == proxy._ContextTargetId) {
                            return;
                        }
                    });

                }
            }
        }

    });

    ej.Menu.Locale = ej.Menu.Locale || {} ;
       
    ej.Menu.Locale['default'] = ej.Menu.Locale["en-US"] = {  	
        titleText: "Menu"
    };
    ej.MenuType = {
        /**  support for list of items appears as normal menu in horizontal or vertical direction. */
        NormalMenu: "normalmenu",
        /**  support for list of items appears as menu when right clicked on target area, thereby preventing browser’s default right click.. */
        ContextMenu: "contextmenu"
    };

    ej.Direction = {
        /**  support for Render sub menu popup in left direction. */
        Left: "left",
        /**  support for Render sub menu popup in Right direction. */
        Right: "right",
        /** Default opening direction of menu sub items */
        None: "none",
    };

    ej.AnimationType = {
        /**  support for disable the AnimationType while hover or click an menu items. */
        None: "none",
        /**  support for enable the AnimationType while hover or click an menu items. */
        Default: "default"
    };

})(jQuery, Syncfusion);;
/**
* @fileOverview Plugin provides support to display color picker within your web page and allows to pick the color.
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws.
* @version 12.1
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, undefined) {

    ej.widget("ejColorPicker", "ej.ColorPicker", {
        _rootCSS: "e-colorpicker",

        element: null,

        model: null,
        validTags: ["input", "div"],
        _addToPersist: ["value", "opacityValue"],
        _setFirst: false,
        angular: {
            require: ['?ngModel', '^?form', '^?ngModelOptions']
        },


        defaults: {

            enableOpacity: true,

            opacityValue: 100,

            columns: 10,

            palette: "basicpalette",

            htmlAttributes: {},

            buttonMode: "split",

            custom: [],

            presetType: "basic",

            modelType: "picker",

            locale: "en-US",

            showPreview: true,

            showTooltip: false,

            showClearButton: false,

            showSwitcher: true,

            value: null,

            displayInline: false,

            buttonText: {
                apply: "Apply",
                cancel: "Cancel",
                swatches: "Swatches"
            },

            tooltipText: {
                switcher: "Switcher",
                addButton: "Add Color",
                basic: "Basic",
                monoChrome: "Mono Chrome",
                flatColors: "Flat Colors",
                seaWolf: "Sea Wolf",
                webColors: "Web Colors",
                sandy: "Sandy",
                pinkShades: "Pink Shades",
                misty: "Misty",
                citrus: "Citrus",
                vintage: "Vintage",
                moonLight: "Moon Light",
                candyCrush: "Candy Crush",
                currentColor: "Current Color",
                selectedColor: "Selected Color",
            },

            showApplyCancel: true,

            showRecentColors: false,

            toolIcon: null,

            cssClass: "",

            enabled: true,

            change: null,

            select: null,

            open: null,

            close: null,

            create: null,

            destroy: null,
        },
        dataTypes: {
            modelType: "enum",
            palette: "enum",
            presetType: "enum",
            cssClass: "string",
            displayInline: "boolean",
            locale: "string",
            showSwitcher: "boolean",
            showRecentColors: "boolean",
            enabled: "boolean",
            showPreview: "boolean",
            enableOpacity: "boolean",
            buttonText: "data",
            custom: "array",
            htmlAttributs: "data"
        },

        observables: ["value", "opacityValue"],
        value: ej.util.valueFunction("value"),
        opacityValue: ej.util.valueFunction("opacityValue"),

        _setModel: function (jsondata) {
            for (var key in jsondata) {
                switch (key) {
                    case "enableOpacity":
                        this.model.enableOpacity = jsondata[key];
                        this._previewSlider(this.model.enableOpacity);
                        this._valueOperation();
                        break;
                    case "opacityValue":
                        if (this.model.enableOpacity) {
                            this._tempOpacity = parseFloat(ej.util.getVal(jsondata[key]));
                            this._opacity.option('value', this._tempOpacity);
                            !this._switch && this._changeOpacity();
                            this._updateValue();
                            this.opacityValue(this._tempOpacity);
                            typeof jsondata[key] == "function" ? jsondata[key](this.opacityValue()) : jsondata[key] = this.opacityValue();
                            break;
                        } else return false;
                    case "custom":
                        this.model.custom = jsondata[key];
                        this._reInitialize();
                        break;
                    case "palette":
                        this.model.palette = jsondata[key];
                        this._reInitialize();
                        break;
                    case "columns":
                        this.model.columns = parseFloat(jsondata[key]);
                        this._reInitialize();
                        jsondata[key] = this.model.columns;
                        break;
                    case "presetType":
                        this.model.presetType = jsondata[key];
                        if (ej.isNullOrUndefined(Colors[this.model.presetType])) return false;
                        else
                            this._reInitialize();
                        break;
                    case "buttonMode":
                        this._unBindIconClick();
                        this._buttonElement = ej.ColorPicker.ButtonMode.Split == jsondata[key] ? this.dropdownbutton : this.wrapper;
                        ej.ColorPicker.ButtonMode.Split == jsondata[key] ? this.wrapper.addClass("e-split") : this.wrapper.removeClass("e-split");
                        this._bindIconClick();
                        break;
                    case "showTooltip":
                        this._colorSlider.option('showTooltip', jsondata[key]);
                        this._opacity.option('showTooltip', jsondata[key]);
                        break;
                    case "value":
                        this._setValue(ej.util.getVal(jsondata[key]), true);
                        if (typeof jsondata[key] == "function")
                            jsondata[key](this.value());
                        else
                            jsondata[key] = this.value();
                        break;
                    case "modelType":
                        this.model.modelType = jsondata[key];
                        this._reInitialize();
                        break;
                    case "showSwitcher":
                        this.model.showSwitcher = jsondata[key];
                        this._showSwitcher();
                        break;
                    case "tooltipText":
                        this._toolTipText(jsondata[key]);
                        break;
                    case "locale": 
                        this.model.locale = jsondata[key];
                        this._localize(jsondata[key]);
                        break;
                    case "showPreview":
                        this.model.showPreview = jsondata[key];
                        this._previewPane(this.model.showPreview);
                        break;
                    case "buttonText":
                        this._buttonText(jsondata[key]);
                        break;
                    case "displayInline":
                        this._setDisplayInline(jsondata[key]);
                        break;
                    case "cssClass":
                        this._setSkin(jsondata[key]);
                        this.model.cssClass = jsondata[key];
                        break;
                    case "enabled":
                        this._enabled(jsondata[key]);
                        break;
                    case "showRecentColors":
                        this.model.showRecentColors = jsondata[key];
                        this._previewColor(this.model.showRecentColors);
                        break;
                    case "htmlAttributes": this._addAttr(jsondata[key]); break;
                    case "showClearButton": this._showClearIcon(jsondata[key]); break;
                    case "showApplyCancel": this.model.showApplyCancel = jsondata[key]; this._buttonContainer(); break;
                }
            }
        },


        _setSkin: function (className) {
            if (this.wrapper)
                this.wrapper.removeClass(this.model.cssClass).addClass(className);
            else
                this.element.removeClass(this.model.cssClass).addClass(className);
        },
        _showSwitcher: function () {
            if (this.model.showSwitcher) {
                this._changeTag.removeClass('e-hide');
                this.model.modelType == "picker" ? this._switcher.addClass('e-paletteModel').removeClass('e-pickerModel') : this._switcher.addClass('e-pickerModel').removeClass('e-paletteModel');
            }
            else
                this._changeTag.addClass('e-hide');
        },
        _pickerType: function () {
            this._modelType = "picker";
            this.PaletteWrapper.removeAttr('style');
            this.PaletteWrapper.addClass('e-hide');
            this._gradient.removeClass('e-hide');
            this._gradient.fadeIn(200);
            this._presetTag.parents('.e-split.e-widget').addClass('e-hide');
            this._switcher.removeAttr('class');
            this._switcher.addClass('e-color-image e-paletteModel');
            this._switch = true;
            this._rgbValue();
            this._hueGradient();
            this._updateUI();
            this._alphaGradient(this.RGBToHEX(this.rgb));
            this._hsva.ejButton("enable");
            this._switchEvents();
            this._unSwitchEvents();
            this._hideUnBindEvents();
            this.isPopupOpen && this._showBindEvents();
            this.model.modelType == "default" ? this._changeTag.removeClass('e-hide') : this._changeTag.addClass('e-hide');
            this.popupList.prepend(this._gradient);
            this._showSwitcher();
        },
        _paletteType: function () {
            this._gradient.removeAttr('style');
            this._presetTag.parents('.e-split.e-widget').removeClass('e-hide');
            this.PaletteWrapper.removeClass('e-hide');
            this.PaletteWrapper.fadeIn(200);
            this._switch = false;
            this._disableHSVButton();
            this._cellSelect();
            this._switchEvents();
            this._unSwitchEvents();
            this._splitObj.option('prefixIcon', 'e-icon e-color-image e-' + this.model.presetType);
            this.popupList.prepend(this.PaletteWrapper);
            this._showSwitcher();
        },
        _reInitialize: function () {
            this._destroyPalette(false);
        },
        _destroyPalette: function (presets) {
            this.PaletteWrapper.remove();
            if (presets || this._columns != this.model.columns && this.model.palette !== "custompalette") this.PaletteWrapper = this._presetType(this._presetsId);
            if (this._temp !== this.model.presetType) this.PaletteWrapper = this._layoutType(this.model.palette);
            if (this.model.modelType == "palette") {
                this._modelType = "palette";
                this.PaletteWrapper = this._layoutType(this.model.palette);
                this._hideUnBindEvents();
                this.isPopupOpen && this._showBindEvents();
                this._gradient.addClass('e-hide');
                this._paletteType();
                presets || this.model.palette == "custompalette" ? "" : this._splitObj.option('prefixIcon', 'e-icon e-color-image e-' + this.model.presetType);
            }
            if (this.model.modelType == "picker") {
                this._pickerType();
                if (this.model.displayInline && !this.element.is('input'))
                    this._footer.addClass('e-hide');
            }
            this._temp = this.model.presetType; this._columns = this.model.columns;
            if (this._modelType == "picker")
                this._presetTag.parents('.e-split.e-widget').addClass('e-hide');
            else
                this._presetTag.parents('.e-split.e-widget').removeClass('e-hide');
            this.refresh();
        },
        _previewColor: function (color) {
            if (color) {
                this._swatchesArea.fadeIn(200);
                this._bindRecentEvent();
            }
            else {
                this._swatchesArea.fadeOut(200);
                this._unBindRecentEvent();
            }
        },
        _buttonText: function (data) {
            $.extend(this.model.buttonText, data);
            if (!ej.isNullOrUndefined(this._buttonTag)) this._buttonTag.html(this.model.buttonText.apply);
            if (!ej.isNullOrUndefined(this._cancelTag)) this._cancelTag.html(this.model.buttonText.cancel);
            this._spnTag.html(this.model.buttonText.swatches);
        },
        _toolTipText: function (data) {
            $.extend(this.model.tooltipText, data);
            this._addTitleText();
        },
        _previewPane: function (showPreview) {
            showPreview ? this._previewTag.removeClass("e-hide") : this._previewTag.addClass("e-hide");
        },
        _previewSlider: function (slider) {
            slider ? this._opacity.enable() : this._opacity.disable();
        },
        _getLocalizedLabels: function () {
            return ej.getLocalizedConstants(this.sfType, this.model.locale);
        },
        _localize: function () {
            this._localizedLabels = this._getLocalizedLabels();
            if (this._options.locale == "en-US" && !ej.isNullOrUndefined(this._options.buttonText) || !ej.isNullOrUndefined(this._options.tooltipText)) {
                if (!ej.isNullOrUndefined(this._options.buttonText))
                    this._buttonText(this._options.buttonText);
                if (!ej.isNullOrUndefined(this._options.tooltipText))
                    this._toolTipText(this._options.tooltipText);
            }
            else if (!ej.isNullOrUndefined(this._localizedLabels)) {
                if (!ej.isNullOrUndefined(this._localizedLabels.buttonText))
                    this._buttonText(this._localizedLabels.buttonText)
                if (!ej.isNullOrUndefined(this._localizedLabels.tooltipText))
                    this._toolTipText(this._localizedLabels.tooltipText)
            }
        },
        _destroy: function () {
            if (this.model.displayInline)
                $(window).off("resize", $.proxy(this._OnWindowResize, this));
            if (this.isPopupOpen) this.hide();
            this.popupContainer.remove();
            if (this.wrapper) {
                this.element.insertAfter(this.wrapper);
                this.wrapper.remove();
                this._presetContainer.parent('.e-menu-wrap').remove();
            }
            this.element.removeClass('e-colorpicker e-input e-widget').removeAttr("style name").val(this.element.attr("value"));
        },
        _init: function (options) {
            this._options = options;
            this._browser = ej.browserInfo();
            this._isFocused = false;
            this.isPopupOpen = false;
            this._dataBind = false;
            this._modelType = "picker";
            if (this._id)
                $("#" + this._id + "_popup").remove();
            if ("#" + this._id + "_Presets")
                $('#' + this._id + "_Presets").parent('.e-menu-wrap').remove();
            this.model.palette === "basicpalette" ? this._presetsId = "e-presets30" : "";
            if (ej.isNullOrUndefined(this.value()) && this.element[0].value !== "") this._tempValue = this.element[0].value;
            else this._tempValue = this.value();
            this._previousValue = this._previousColor = this._tempValue;
            this._renderControl();
            this._tempOpacity = this.opacityValue();
            this.model.palette === "custompalette" && this._presetTag.parents('.e-split.e-widget').addClass('e-hide');
            this.popupContainer.find('button.e-presets').ejSplitButton({ targetID: this._presetContainer.attr('id') });
            if (this._tempValue) {
                this._setValue(this._tempValue);
                if (this._switch) this._rgbValue();
            }
            this._hsvValue();
            this._hueGradient();
            this._addTitleText();
            this._showClearIcon(this.model.showClearButton);
            this._columns = this.model.columns;
            this._temp = this.model.presetType;
            if (!this._tempValue) {
                this._colorSlider.option('value', parseInt(this._hsv.h));
                this._opacity.option('value', this._tempOpacity);
                this._alphaGradient("#fff");
                this._previousValue = "";
            }
            !this.model.enabled && this._enabled(this.model.enabled);
        },
        _renderControl: function () {
            this._createWrapper();
            this._renderPopupPanelWrapper();
            this._selectedButton = this._groupTag.find('.e-click');
            this._buttonContainer();
            this._renderPopupElement();
            this._buttonElement = ej.ColorPicker.ButtonMode.Split == this.model.buttonMode ? this.dropdownbutton : this.wrapper;
            if (this.model.buttonMode == ej.ColorPicker.ButtonMode.Split && this.element.is('input')) this.wrapper.addClass("e-split");
            this._addAttr(this.model.htmlAttributes);
            this._setDisplayInline(this.model.displayInline);
            this._previewPane(this.model.showPreview);
            this._previewColor(this.model.showRecentColors);
            this._localize();
            if (this._switch) this._previewSlider(this.model.enableOpacity);
            this._wireEvents();
            this._switchEvents();
        },

        _createWrapper: function () {
            if (this.element.is("input")) {
                this.element.addClass('e-input e-widget');
                this.element.attr("aria-label","colorpicker");
                this.spanElement = ej.buildTag("span.e-selected-color");
                this.wrapper = ej.buildTag("span.e-colorwidget e-picker e-widget " + this.model.cssClass).attr({ 'tabindex': '0', "aria-expanded": false, "aria-haspopup": true, "aria-owns": "popup" });
                if (this._id) this.wrapper.attr('id', this._id + "Wrapper");
                this.container = ej.buildTag("span.e-in-wrap e-box e-splitarrowright");
                this.drpbtnspan = ej.buildTag("span.e-icon e-arrow-sans-down", "", {}, { "aria-label": "select" });
                this.dropdownbutton = ej.buildTag("span.e-select", "", {}, { "role": "button" }).append(this.drpbtnspan);
                this.iconWrapper = ej.buildTag("span.e-tool-icon " + this.model.toolIcon);
                this.colorContainer = ej.buildTag("span.e-color-container");
                this.colorContainer.append(this.spanElement);
                this.container.insertAfter(this.element);
                if (!ej.isNullOrUndefined(this.model.toolIcon)) {
                    this.colorContainer.prepend(this.iconWrapper);
                    this.container.addClass('e-tool');
                    this.container.append(this.colorContainer);
                }
                else
                    this.container.append(this.colorContainer);
                this.container.append(this.element, this.dropdownbutton);
                this.wrapper.insertBefore(this.container);
                this.wrapper.append(this.container);
                this.element.css("display", "none").val(this.value());
            }
            this._checkNameAttr();
        },
        _addTitleText: function () {
            this._switcher.attr('title', this.model.tooltipText.switcher);
            this._spanTag.attr('title', this.model.tooltipText.addButton);
            this._presetLi.find("#e-presets00").attr('title', this.model.tooltipText.webColors);
            this._presetLi.find("#e-presets01").attr('title', this.model.tooltipText.vintage);
            this._presetLi.find("#e-presets02").attr('title', this.model.tooltipText.seaWolf);
            this._presetLi.find("#e-presets10").attr('title', this.model.tooltipText.sandy);
            this._presetLi.find("#e-presets11").attr('title', this.model.tooltipText.pinkShades);
            this._presetLi.find("#e-presets12").attr('title', this.model.tooltipText.moonLight);
            this._presetLi.find("#e-presets20").attr('title', this.model.tooltipText.monoChrome);
            this._presetLi.find("#e-presets21").attr('title', this.model.tooltipText.misty);
            this._presetLi.find("#e-presets22").attr('title', this.model.tooltipText.flatColors);
            this._presetLi.find("#e-presets30").attr('title', this.model.tooltipText.basic);
            this._presetLi.find("#e-presets31").attr('title', this.model.tooltipText.candyCrush);
            this._presetLi.find("#e-presets32").attr('title', this.model.tooltipText.citrus);
            this._currentTag.attr('title', this.model.tooltipText.currentColor);
            this._previousTag.attr('title', this.model.tooltipText.selectedColor);
        },
        _renderPopupPanelWrapper: function () {
            this.popupContainer = ej.buildTag("div.e-colorpicker e-box e-popup e-widget " + this.model.cssClass, "", {}, { "role": "grid", "aria-readonly": "true", "tabindex": '0', "style": "visibility:hidden" });
            if (this._id) this.popupContainer.attr('id', this._id + "_popup");
            $('body').append(this.popupContainer);

            this.popupList = ej.buildTag("div.e-popupWrapper");

            this._gradient = ej.buildTag("div.e-container");

            this._colorArea = ej.buildTag("div.e-hsv-color");
            this._gradientArea = ej.buildTag("div.e-hsv-gradient")
            this._handleArea = ej.buildTag("div.e-draghandle e-color-image");
            this._browser == "msie" && this._handleArea.addClass('e-pinch');
            this._colorArea.append(this._gradientArea, this._handleArea);

            this._picker = ej.buildTag("div.e-gradient");
            this._hueSlider = ej.buildTag("div.e-widget e-hue e-state-default");
            this._alphaSlider = ej.buildTag("div.e-widget e-opacity e-state-default");
            this._picker.append(this._hueSlider, this._alphaSlider);

            this._gradient.append(this._colorArea, this._picker);

            this.popupList.append(this._gradient);


            this._footerBlock = ej.buildTag("div.e-footerContainer");

            this._templateWrapper = ej.buildTag("div.e-buttons");


            this._groupTag = ej.buildTag("div.e-grpbtn");

            this._formEle = ej.buildTag("div.e-form");
            this._rgb = ej.buildTag("button.e-rgbButton e-click", "", {}, { type: "button" });
            this._hexCode = ej.buildTag("button.e-hexButton", "", {}, { type: "button" });
            this._hsva = ej.buildTag("button.e-hsvButton", "", {}, { type: "button" });
            this._groupTag.append(this._rgb, this._hexCode, this._hsva);


            this._codeEditor = ej.buildTag("div.e-codeeditor");
            this._inputTag = ej.buildTag("input.e-color-code", "", {}, { "type": "text", 'tabindex': '0', "maxLength": "22" });
            this._codeEditor.append(this._inputTag);
            this._inputTag.attr("aria-label", "color-code");
            this._formEle.append(this._groupTag, this._codeEditor);

            this._previewTag = ej.buildTag("div.e-preview").attr({ 'tabindex': '0' });
            this._currentTag = ej.buildTag("div.e-current");
            this._previousTag = ej.buildTag("div.e-previous");
            this._previewTag.append(this._currentTag, this._previousTag);

            this._templateWrapper.append(this._formEle, this._previewTag);

            this._swatchesArea = ej.buildTag("div.e-color-labels");
            var blockCount = 11;
            this._divTag = ej.buildTag("div.e-recent-color");
            this._addTag = ej.buildTag('div.e-colorblock e-block');
            this._spanTag = ej.buildTag('div.e-color e-color-image e-add');
            this._addTag.append(this._spanTag)
            this._divTag.append(this._addTag);
            for (var count = 0; count < blockCount; count++) {
                this._liTag = ej.buildTag('div.e-colorblock e-block');
                var spanTag = ej.buildTag('div.e-color e-color-image e-empty');
                this._liTag.append(spanTag);
                this._divTag.prepend(this._liTag);
            }
            this._swatchesArea.append(this._divTag);

            this._footer = ej.buildTag('div.e-footer');
            this._swatches = ej.buildTag('div.e-element');
            this._changeTag = ej.buildTag('div.e-switcher').attr('tabindex', '0');
            this._switcher = ej.buildTag('div.e-color-image');
            this._presetTag = ej.buildTag('button.e-presets e-colorSplit');
            this._presets = ej.buildTag('div');
            this._changeTag.append(this._switcher);
            this._presetTag.append(this._presets);
            this._swatches.append(this._changeTag, this._presetTag);
            this._footer.append(this._swatches);
            this._footerBlock.append(this._templateWrapper, this._swatchesArea, this._footer);

            this.PaletteWrapper = this._layoutType(this.model.palette);
            this.popupList.append(this.PaletteWrapper, this._footerBlock);
            var oldWrapper = $("#" + this._id + "_Presets").get(0);
            if (oldWrapper) {
                if ($(oldWrapper).parent().hasClass("e-menu-wrap"))
                    $(oldWrapper).parent().remove();
                else
                    $(oldWrapper).remove();
            }
            this._presetContainer = $("<ul id='" + this._id + "_Presets' class='e-presetWrapper' style= top:87px ></ul>");
            this._presetLi = ej.buildTag('li.e-item');
            this._presetLi.append(this._renderPresets());
            this._presetContainer.append(this._presetLi);
            this.popupList.append(this._presetContainer);
            this.popupContainer.append(this.popupList);

            //IE Support
            if (this._browser.name = "msie" && (this._browser.version == "9.0" || this._browser.version == "8.0"))
                this._hueSlider.addClass('e-color-image e-filter');
            else
                this._hueSlider.addClass('e-common');
            this._width = this._gradientArea.width(); this._height = this._gradientArea.height();
        },
        _buttonContainer: function () {
            if (this.model.showApplyCancel) {
                this._buttonTag = ej.buildTag("button.e-applyButton", "", {}, { type: "button" });
                this._cancelTag = ej.buildTag("button.e-cancelButton", "", {}, { type: "button" });
                this._footer.append(this._buttonTag, this._cancelTag);
                this._applyObj = this.popupContainer.find('button.e-applyButton').ejButton({ text: this.model.buttonText.apply, type: "button", cssClass: "e-flat" }).data('ejButton');
                this._cancelObj = this.popupContainer.find('button.e-cancelButton').ejButton({ text: this.model.buttonText.cancel, type: "button", cssClass: "e-flat" }).data('ejButton');
                this._on(this._cancelTag, "click", this._hidePopup);
                this._on(this._buttonTag, "click", this._buttonClick);
            } else if (this._buttonTag !== undefined && this._cancelTag !== undefined) {
                this._buttonTag.remove();
                this._cancelTag.remove();
                this._off(this._cancelTag, "click", this._hidePopup);
                this._off(this._buttonTag, "click", this._buttonClick);
            }
        },
        _addAttr: function (htmlAttr) {
            var proxy = this;
            $.map(htmlAttr, function (value, key) {
                if (key == "class") proxy.wrapper.addClass(value);
                else if (key == "required") proxy.element.attr(key, value);
                else if (key == "disabled" && value == "disabled") proxy._enabled(false);
                else proxy.wrapper.attr(key, value)
            });
        },
        _showClearIcon: function (bool) {
            if (bool) {
                this._clearIcon = ej.buildTag("div", {}, {}, { "class": "e-icon e-close_01" }).hide();
                this._codeEditor.append(this._clearIcon);
                this._on(this._clearIcon, "mousedown", this._clearColor);
                this._on(this._clearIcon, "click", this._clearColor);
            } else {
                this._clearIcon && this._clearIcon.remove();
                this._off(this._clearIcon, "mousedown", this._clearColor);
                this._off(this._clearIcon, "click", this._clearColor);
            }
        },
        _colorPresetsClick: function (e) {
            this._presetsId = e.currentTarget.id;
            if (this._presetsId === "e-presets00") this.model.presetType = "webcolors";
            else if (this._presetsId === "e-presets01") this.model.presetType = "vintage";
            else if (this._presetsId === "e-presets02") this.model.presetType = "seawolf";
            else if (this._presetsId === "e-presets10") this.model.presetType = "sandy";
            else if (this._presetsId === "e-presets11") this.model.presetType = "pinkshades";
            else if (this._presetsId === "e-presets12") this.model.presetType = "moonlight";
            else if (this._presetsId === "e-presets20") this.model.presetType = "monochrome";
            else if (this._presetsId === "e-presets21") this.model.presetType = "misty";
            else if (this._presetsId === "e-presets22") this.model.presetType = "flatcolors";
            else if (this._presetsId === "e-presets30") this.model.presetType = "basic";
            else if (this._presetsId === "e-presets31") this.model.presetType = "candycrush";
            else if (this._presetsId === "e-presets32") this.model.presetType = "citrus";
            this._splitObj.option('prefixIcon', 'e-icon e-color-image e-' + this.model.presetType);
            $("#" + this._id + "_Presets").find("li.e-preset-row").removeClass("e-presetsactive");
            $("#" + this._presetsId).addClass("e-presetsactive");
            this.PaletteWrapper.remove();
            if (this._modelType == "palette") {
                this.PaletteWrapper = this._layoutType(this.model.palette);
                this._gradient.addClass('e-hide');
                this._paletteType();
                this._switcher.addClass('e-pickerModel').removeClass('e-paletteModel');
            }
        },

        _renderPresets: function () {
            var tableDiv = ej.buildTag("div.e-presets-table");
            this._spnTag = ej.buildTag("span.e-presetHeader");
            this._spnTag.html(this.model.buttonText.swatches);
            tableDiv.append(this._spnTag);
            var color = 0, hexCode, rowDiv;
            for (var row = 0; row < 4 ; row++) {
                rowDiv = ej.buildTag("ul.e-tablerow");
                for (var col = 0; col < 3 ; col++) {
                    var tableCell = ej.buildTag("li.e-color-image e-preset-row" + "#" + "e-presets" + [row] + [col]);
                    tableCell.appendTo(rowDiv);
                }
                rowDiv.appendTo(tableDiv);
            }
            return tableDiv;
        },
        _renderPopupElement: function () {
            var proxy = this;
            this._hsv =
            {
                h: 360, s: 0, v: 100
            };
            this._rgb.ejButton({ text: "RGBA", type: "button" });
            this._hexCode.ejButton({ text: "HEX", type: "button" });
            this._hsva.ejButton({ text: "HSVA", type: "button" });
            this._splitObj = this._presetTag.ejSplitButton({ size: "normal", showRoundedCorner: true, contentType: "imageonly" }).data('ejSplitButton');
            this._splitObj.element.attr("aria-label","Presets");
            this._splitObj.dropbutton.attr("aria-label","Select");
            this._splitObj.option("beforeOpen", function (e) { proxy._bindClickOperation(e); });
            this._presetTag.parents('.e-split.e-widget').css({ "height": "27px" });
            this.model.custom.length == 0 ? this._splitObj.option('prefixIcon', "e-icon e-color-image e-" + this.model.presetType) : "";
            $("#" + this._presetsId).addClass("e-presetsactive");
            this._splitObj._getXYpos = function (e) {
                $("#" + this.model.targetID).ejMenu({ animationType: "none" });
                var btnposx, btnposy, btnpos = this.dropbutton.offset();
                btnposx = btnpos.left - this.dropbutton.prev().outerWidth() - 1;
                btnposy = (btnpos.top - $("#" + this.model.targetID).outerHeight()) - 1;
                return { x: btnposx, y: btnposy }
            }
            this._colorSlider = this._hueSlider.ejSlider({ orientation: "Vertical", showTooltip: this.model.showTooltip, minValue: 0, maxValue: 360, change: function (e) { proxy._changeHue(e); }, slide: function (e) { proxy._changeHue(e); } }).data('ejSlider');
            this._opacity = this._alphaSlider.ejSlider({ value: this.opacityValue(), showTooltip: this.model.showTooltip, orientation: "Vertical", incrementStep: 5, value: 100, change: function (e) { proxy._changeAlpha(e); }, slide: function (e) { proxy._changeAlpha(e); } }).data('ejSlider');
            if (this._browser.name = "msie" && this._browser.version == "8.0") {
                this._handleTag = ej.buildTag("div.e-handle-wrapper");
                this._handleTag.appendTo(this._opacity.element.find("a.e-handle"));
            }
            this._colorSlider.firstHandle.css({ "height": "13px", "width": "13px" });
            this._opacity.firstHandle.css({ "height": "13px", "width": "13px" });
            this.popupContainer.css({ "visibility": "visible", "display": "none" });
            if (this.model.modelType == "picker") {
                this._modelType = "picker";
                this._gradient.removeClass('e-hide');
                this.PaletteWrapper.addClass('e-hide');
                this._presetTag.parents('.e-split.e-widget').addClass('e-hide');
                this._showSwitcher();
                this._switch = true;
            } else if (this.model.modelType == "palette") {
                this._modelType = "palette";
                this._presetTag.parents('.e-split.e-widget').removeClass('e-hide');
                this.PaletteWrapper.removeClass('e-hide');
                this._gradient.addClass('e-hide');
                this._hsva.ejButton("disable");
                this._showSwitcher();
                this._switch = false;
            }
        },
        _layoutType: function (type) {
            if (typeof type === "string" && type == "basicpalette")
                this._collection = this._paletteGenerate(Colors[this.model.presetType], this.model.columns);
            else if (typeof type === "string" && type == "custompalette" && this.model.modelType == "palette")
                this._collection = this._paletteGenerate(this.model.custom, this.model.columns);
            type == "custompalette" ? this._collection.addClass('e-custom') : "";
            return this._collection;
        },
        _presetType: function (type) {
            if (type === "e-presets00") this._collection = this._paletteGenerate(Colors.webcolors, this.model.columns);
            else if (type === "e-presets01") this._collection = this._paletteGenerate(Colors.vintage, this.model.columns);
            else if (type === "e-presets02") this._collection = this._paletteGenerate(Colors.seawolf, this.model.columns);
            else if (type === "e-presets10") this._collection = this._paletteGenerate(Colors.sandy, this.model.columns);
            else if (type === "e-presets11") this._collection = this._paletteGenerate(Colors.pinkshades, this.model.columns);
            else if (type === "e-presets12") this._collection = this._paletteGenerate(Colors.moonlight, this.model.columns);
            else if (type === "e-presets20") this._collection = this._paletteGenerate(Colors.monochrome, this.model.columns);
            else if (type === "e-presets21") this._collection = this._paletteGenerate(Colors.misty, this.model.columns);
            else if (type === "e-presets22") this._collection = this._paletteGenerate(Colors.flatcolors, this.model.columns);
            else if (type === "e-presets30") this._collection = this._paletteGenerate(Colors.basic, this.model.columns);
            else if (type === "e-presets31") this._collection = this._paletteGenerate(Colors.candycrush, this.model.columns);
            else if (type === "e-presets32") this._collection = this._paletteGenerate(Colors.citrus, this.model.columns);
            return this._collection;
        },
        _paletteGenerate: function (colors, columns) {
            var color;
            this._PresetTable = ej.buildTag("div.e-palette-color").attr({ "role": "presentation" });
            this._tag = ej.buildTag("div.e-row").attr({"role":"row"});
            for (color = 0; color < colors.length; color++) {
                if (color && color % columns == 0)
                    this._tag = ej.buildTag("div.e-row").attr({"role":"row"});
                this._td = ej.buildTag("div.e-item").attr({ 'role': 'gridcell', "aria-label": "#" + $.trim(colors[color]), "data-value": "#" + $.trim(colors[color]), "style": "background-color:" + "#" + $.trim(colors[color]) });
                this._tag.append(this._td);
                this._PresetTable.append(this._tag);
            }
            return this._PresetTable;
        },
        _checkNameAttr: function () {
            if (!this.element.attr("name")) this.element.attr({ "name": this.element[0].id });
        },
        _enabled: function (bool) {
            if (bool) this.enable();
            else {
                this.model.enabled = true;
                this.disable();
            }
        },
        _setDisplayInline: function (isDisplayInline) {
            this.model.displayInline = isDisplayInline;
            if (isDisplayInline && this.element.is("input")) {
                this.popupContainer.insertAfter(this.wrapper);
                this._footer.css({ "display": "none" });
                this._setPopupPosition();
            }
            else if (isDisplayInline) {
                this.element.append(this.popupContainer);
                this.popupContainer.find('button.e-applyButton').css({ "display": "none" });
                this.popupContainer.find('button.e-cancelButton').css({ "display": "none" });
                this._footer.css({ "display": "none" });
            }
            else {
                this.popupContainer.css('display', 'none');
                $('body').append(this.popupContainer);
                this._isOpen = false;
                if (this.element.is("input")) {
                    this._bindIconClick();
                    if (this.popupContainer.find('button.e-applyButton').length==0) {
                        this._buttonContainer();
                    }
                    this._footer.css({ "display": "block" });
                    this.wrapper.removeClass("e-focus");
                    this._off($(document), "mousedown", this._onDocumentClick);
                }
                this._isFocused = this.isPopupOpen = false;
            }
            if (isDisplayInline) {
                this.show();
                if (this.element.is("input")) this._off($(this._buttonElement), "mousedown", this._iconClick);
                this._off(ej.getScrollableParents(this.wrapper), "scroll", this.hide);
            }
        },
        _bindIconClick: function () {
            var count = $._data($(this._buttonElement)[0], "events");
            if (ej.isNullOrUndefined(count) || ej.isNullOrUndefined(count.mousedown)) this._on(this._buttonElement, "mousedown", this._iconClick);
            else if (count.mousedown.length == 0) this._on(this._buttonElement, "mousedown", this._iconClick);
        },
        _unBindIconClick: function () {
            this._off(this._buttonElement, "mousedown", this._iconClick);
        },
        _setPopupPosition: function () {
            var elementObj = this.element.is('input') ? this.wrapper : this.element;
            var pos = this._getOffset(elementObj), winWidth,
            winBottomHeight = $(document).scrollTop() + $(window).height() - (pos.top + $(elementObj).outerHeight()),
            winTopHeight = pos.top - $(document).scrollTop(),
            popupHeight = this.popupContainer.outerHeight(),
            popupWidth = this.popupContainer.outerWidth(),
            left = pos.left,
            totalHeight = elementObj.outerHeight(),
            border = (totalHeight - elementObj.height()) / 2,
            maxZ = this._getZindexPartial(), popupmargin = 3,
            topPos = ((popupHeight < winBottomHeight || popupHeight > winTopHeight) ? pos.top + totalHeight + popupmargin : pos.top - popupHeight - popupmargin) - border;
            winWidth = $(document).scrollLeft() + $(window).width() - left;
            if (popupWidth > winWidth && (popupWidth < left + elementObj.outerWidth())) left -= this.popupContainer.outerWidth() - elementObj.outerWidth();
            if (popupWidth + elementObj.offset().left > $(window).width()) left = Math.abs(popupWidth - ($(window).width()));
            this.popupContainer.css({
                "left": left + "px",
                'position': 'absolute',
                "top": topPos + "px",
                "z-index": maxZ
            });
        },

        _getOffset: function (ele) {
            return ej.util.getOffset(ele);
        },

        _getZindexPartial: function () {
            return ej.util.getZindexPartial(this.element, this.popupContainer);
        },

        _setValue: function (value, isCode) {
            var reg = "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$";
            if (typeof value == "object" || (typeof value == "number") || ej.isNullOrUndefined(value.match(reg))) value = null;
            this.value(value);
            this._tempValue = value;
            ej.isNullOrUndefined(value) ? this._setEmptyValue() : this._renderModelValue(value);
            this._changeEvent(false, isCode);
            this._selectEvent();
            this.element.is("input") && this._updateValue();
        },
        _renderModelValue: function (value) {
            var color;
            if (value && typeof value === "string") {
                color = this._HexToHSV(value);
                this._oldValue = this.rgb;
                if (this._switch) {
                    this._valueOperation();
                    this._colorSlider.option('value', parseInt(this._hsv.h));
                }
                this._inputTagValue(this._selectedButton);
                if (!this._switch) {
                    this._updateUI();
                    this.element.val(this.value());
                }
                this._hueGradient();
            }
        },
        setValue: function (code) {
            this._setValue(code);
        },

        enable: function () {
            if (this.model.enabled) return false;
            if (this.wrapper && this.wrapper.hasClass("e-disable")) {
                this.wrapper.removeClass("e-disable");
                this.element.prop("disabled", false);
                if (this.container.hasClass("e-disable")) this.container.removeClass('e-disable');
                this.popupList.removeClass('e-disable');
                this.dropdownbutton.removeClass('e-disable');
            } else if (this.model.displayInline) this.element.removeClass('e-disable');
            var temp = this._switch;
            this._switch = true;
            this._cancelObj.enable();
            this._colorSlider.enable();
            this.model.enableOpacity ? this._opacity.enable() : this._opacity.disable();
            this._splitObj.enable();
            this._applyObj.enable();
            this._wireEvents();
            this._switchEvents();
            this._switch = temp;
            $(this._inputTag).prop('readonly', false);
            (this._buttonElement) && this._on(this._buttonElement, "mousedown", this._iconClick);
            this.model.enabled = true;
        },

        disable: function () {
            if (!this.model.enabled) return false;
            if (this.wrapper && !this.wrapper.hasClass("e-disable")) {
                this.wrapper.addClass("e-disable");
                this.element.attr("disabled", "disabled");
                if (!this.container.hasClass("e-disable")) this.container.addClass('e-disable');
                this.popupList.addClass('e-disable');
                this.dropdownbutton.addClass('e-disable');
            } else if (this.model.displayInline) this.element.addClass('e-disable');
            var temp = this._switch;
            this._switch = false;
            this._cancelObj.disable();
            this._colorSlider.disable();
            this._opacity.disable();
            this._splitObj.disable();
            this._applyObj.disable();
            this._unWireEvents();
            this._unSwitchEvents();
            this._switch = temp;
            this._unBindIconClick();
            $(this._inputTag).attr('readonly', 'readonly');
            if (this.isPopupOpen && !this.model.displayInline) this.hide();
            this.model.enabled = false;
        },

        getColor: function () {
            return this.rgb;
        },

        getValue: function () {
            return this.value();
        },
        _alphaGradient: function (value) {
            var browser = ej.browserInfo();
            var value = ej.isNullOrUndefined(value) ? "#000000" : value;
            if (browser.name == "mozilla")
                this._alphaSlider.attr({ "style": "background:-moz-linear-gradient(center top," + value + ",#fff) repeat scroll 0 0 rgba(0, 0, 0, 0);" });
            else if ((browser.name == "msie") || (browser.name == "edge"))
                this._alphaSlider.attr({ "style": "background:-ms-linear-gradient(top," + value + ",#fff) repeat scroll 0 0 rgba(0, 0, 0, 0);" });
            else if (browser.name == "opera" && browser.version <= "11.61")
                this._alphaSlider.attr({ "style": "background:-o-linear-gradient(top," + value + ",#fff) repeat scroll 0 0 rgba(0, 0, 0, 0);" });
            else if (browser.name == "chrome" || browser.name == "safari" || (browser.name == "opera"))
                this._alphaSlider.attr({ "style": "background:-webkit-linear-gradient(top," + value + ",#fff) repeat scroll 0 0 rgba(0, 0, 0, 0);" });
            if ((browser.name == "msie") && (browser.version == "8.0" || browser.version == "9.0"))
                this._alphaSlider.attr({ "style": "progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=" + value + ", endColorstr=#ffffff)"});            
            if (browser.name == "msie" && browser.version == "8.0")
                this._handleTag.css({ "background": this._formRGB(this.rgb), "filter": "alpha(opacity=" + this.rgb.a * 100 + ")" });
        },
        _hueGradient: function () {
            var temp = this._hsv;
            var value = { h: this._hsv.h, s: 100, v: 100 };
            this._hueSlider.children(".e-handle").css({ "background": this._formRGB(this.HSVToRGB(value)) });
            this._hsv = temp;
        },
        _updateColor: function () {
            if (this.model.displayInline || !this.model.showApplyCancel) {
                this.value(this._tempValue);
                if (this.element.is("input")) this._updateValue();
                this._trigger("select", { value: this.value() });
                this._previousColor = this._tempValue;
            }
        },
        _changeEvent: function (element, isCode) {
            if (this._change && this._previousValue !== this._tempValue) {
                this._alphaGradient(this._tempValue);
                this._previousValue = this._tempValue;
                this._trigger("change", { value: this._tempValue, changeFrom: element ? "slider" : "picker", isInteraction: !isCode });
                this._updateColor(element);
            }
        },
        _selectEvent: function () {
            if (this._previousColor !== this._tempValue || this._tempOpacity !== this.opacityValue()) {
                this.value(this._tempValue);
                if (this.element.is("input")) this._updateValue();
                this.element.val(this.value());
                this._trigger("select", { value: this.value() });
                this._previousColor = this._tempValue;
            }
        },
        _changeHue: function (e) {
            this._handleArea.css("visibility", "visible");
            if (parseInt(this._hsv.h) !== parseInt(e.value) && this._switch) {
                this._hsv.h = Math.round(e.value);
                this._hueGradient();
                this._hsvValue();
                this._tempValue = this.RGBToHEX(this.rgb);
                this._changeEvent(true);
            }
        },
        _changeAlpha: function (e) {
            this._handleArea.css("visibility", "visible");
            if (this._switch) {
                this.rgb.a = e.value / 100;
                this._tempOpacity = parseInt(this.rgb.a * 100);
                this._changeOpacity(e);
            }
        },
        _changeOpacity: function (e) {
            this.rgb.a = this._tempOpacity / 100;
            if (this._browser.name = "msie" && this._browser.version == "8.0") {
                this._currentTag.css({ "background-color": this._formRGB(this.rgb), "filter": "alpha(opacity=" + this.rgb.a * 100 + ")" });
                this._handleTag.css({ "background": this._formRGB(this.rgb), "filter": "alpha(opacity=" + this.rgb.a * 100 + ")" });
            }
            else {
                this._currentTag.css("background-color", this._formRGBA(this.rgb));
                this._alphaSlider.children(".e-handle").css({ "background": this._formRGBA(this.rgb) });
            }
            this._inputTagValue(this._selectedButton);
            if (this.model.displayInline) {
                this._trigger("change", { value: this._tempValue, changeFrom: "slider", isInteraction: !ej.isNullOrUndefined(e) ? e.isInteraction : false });
                (this._trigger("select", { value: this.value() }));
            }
        else this._trigger("change", { value: this._tempValue, changeFrom: "slider", isInteraction: !ej.isNullOrUndefined(e) ? e.isInteraction: false });
        },
        _updateValue: function () {
            if (this.value()) {
                if (this._browser.name = "msie" && this._browser.version == "8.0") this.spanElement.css({ "background-color": this._formRGB(this._HexToRGB(this.value())), "filter": "alpha(opacity=" + this.rgb.a * 100 + ")" });
                else this.spanElement.css({ "background-color": this._formRGBA(this._HexToRGB(this.value())) });
            }
            else this.spanElement.removeAttr('style');
        },
        _bindClickOperation: function (e) {
            var proxy = this, splitMenu;
            proxy._on($("#" + this._id + "_Presets").find("li.e-preset-row"), "mousedown", proxy._colorPresetsClick);
            var SplitMenu = $("#" + proxy._presetContainer.attr('id')).ejMenu("instance");
                SplitMenu.model.close = function () {
                proxy._splitObj.contstatus = false;
                proxy._off($("#" + this._id + "_Presets").find("li.e-preset-row"), "mousedown", proxy._colorPresetsClick);
            }
        },
        _wireEvents: function () {
            if (this.element.is('input')) {
                this._on(this.wrapper, "blur", this._targetBlur);
                this._on(this.wrapper, "focus", this._targetFocus);
                this._on(this.wrapper, "keydown", this._popupShown);
                this._on(this.colorContainer, "click", this._containerClick);
            }
            this._on(this._changeTag, "click", this._switchModel);
            this._on(this._groupTag, "click", this._groupButton);
            this._on(this._addTag, "click", this._addColor);
            this._on(this._codeEditor, "mouseenter", this._inputEvent);
            this._on(this._codeEditor, "mouseleave", this._inputEvent);
            this._on(this._inputTag, "blur", this._inputEvent);
            this._on(this._inputTag, "focus", this._inputEvent);
            this._on(this._inputTag, "keyup", this._inputEvent);
            this._on(this.popupContainer, "focus", this._targetFocus);
            this._on(this.popupContainer, "blur", this._targetBlur);
        },
        _unWireEvents: function () {
            if (!this.model.displayInline && this.element.is('input')) {
                this._off(this.wrapper, "blur", this._targetBlur);
                this._off(this.wrapper, "focus", this._targetFocus);
                this._off(this.wrapper, "keydown", this._popupShown);
                this._off(this.colorContainer, "click", this._containerClick);
            }
            this._off(this._changeTag, "click", this._switchModel);
            this._off(this._groupTag, "click", this._groupButton);
            this._off(this._addTag, "click", this._addColor);
            this._off(this._codeEditor, "mouseenter", this._inputEvent);
            this._off(this._codeEditor, "mouseleave", this._inputEvent);
            this._off(this._inputTag, "blur", this._inputEvent);
            this._off(this._inputTag, "focus", this._inputEvent);
            this._off(this._inputTag, "keyup", this._inputEvent);
            this._off(this.popupContainer, "focus", this._targetFocus);
            this._off(this.popupContainer, "blur", this._targetBlur);
        },
        _inputEvent: function (e) {
            if (e.type === "focus") {
                if (e.target.className.indexOf("e-color-code") > -1) {
                    this._codeEditor.addClass("e-focus");
                }
            }
            if (e.type === "blur") {
                if (e.target.className.indexOf("e-color-code") > -1) {
                    this._codeEditor.removeClass("e-focus");
                }
            }
            if (!this._clearIcon) return;
            if (e.type === "focus") this._off(this._codeEditor, "mouseleave", this._inputEvent);
            if (e.type === "blur") this._on(this._codeEditor, "mouseleave", this._inputEvent);
            if (e.type === "keyup") this._inputTag.val() !== "" ? (this._clearIcon.show(), this._handleArea.css("visibility", "visible")) : (this._clearIcon.hide(), this._handleArea.css("visibility", "hidden"));
            if (e.type === "mouseleave" || e.type === "blur" || this._inputTag.val() == "") this._clearIcon.hide();
            else this._clearIcon.show();
        },
        _clearColor: function (e) {
            this._tempValue = "";
            this._inputTag.val("");
            this._setEmptyValue();
            if (e.type == "click") {
                this._clearIcon.hide();
                this._inputTag.focus();
            }
        },
        _containerClick: function () {
            if (this.model.buttonMode == "split") this._trigger("select", { value: this.value() });
        },
        _popupShown: function (e) {
            if (e.keyCode == 13) {
                this._showHidePopup();
                if (!this.isPopupOpen)
                    this._buttonClick(e);
                return false;
            }
        },
        _recentColor: function (e) {
            this._divTag.find('.e-select').removeClass('e-select').addClass('e-block');
            var hexCode = e.target.attributes.getNamedItem("data-value"), value;
            var rgbCode = e.target.attributes.style;
            if (ej.isNullOrUndefined(hexCode) || ej.isNullOrUndefined(rgbCode)) { this._change = false; return false; }
            $(e.target.parentNode).addClass('e-select').removeClass('e-block');
            var alpha = rgbCode.value.replace(/^(background-color:rgb|background-color:rgba)\(/, '').replace(/\)$/, '').replace(/\s/g, '').split(',');
            if (!ej.isNullOrUndefined(alpha[3])) {
                this._opacity.option('value', parseInt((parseFloat(alpha[3]) * 100).toFixed(2)));
                this.rgb.a = parseFloat(parseFloat(alpha[3]).toFixed(2));
            }
            else if (this._browser.name = "msie" && this._browser.version == "8.0") {
                value = parseInt(rgbCode.nodeValue.replace(/^(FILTER: alpha)\(/, '').split('=')[1].split(')')[0]);
                this._opacity.option('value', value);
                this.rgb.a = value / 100;
            }
            else {
                this._opacity.option('value', 100);
                this.rgb.a = 1;
            }
            this._HexToHSV(hexCode.value);
            this._inputTagValue(this._selectedButton);
            this._tempValue = this.RGBToHEX(this.rgb);
            this._valueOperation();
            this._colorSlider.option('value', parseInt(this._hsv.h));
            this._hueGradient();
            this._changeEvent(false);
            if (!this.model.displayInline || this.element.is("input"))
                this.wrapper.focus();
        },

        _handleClick: function (e) {
            e.preventDefault();
            this._width = this._gradientArea.width(); this._height = this._gradientArea.height();
            if (this.model.displayInline)
                this._isFocused = true;
            this._handleArea.css("visibility", "visible");
            this.mouseDownPos = this._handlePos;
            $(document).on("mousemove touchmove", $.proxy(this._handleMovement, this));
            $(document).on("mouseup touchend", $.proxy(this._handleUp, this));
        },
        _handleMove: function (e) {
            this._handleArea.css("visibility", "visible");
            this._handleMovement(e);
            this._focusWrapper(e);
        },
        _handleMovement: function (e) {
            if (!this.model.enabled) return false;
            var clientX = e.pageX, clientY = e.pageY;
            this.element.is("input") && this.wrapper.focus();
            if (e.type == "touchstart" || e.type == "touchmove") {
                clientX = e.originalEvent.changedTouches[0].pageX;
                clientY = e.originalEvent.changedTouches[0].pageY;
            }
            this._hsv.v = parseInt(100 * (this._gradientArea.height() - Math.max(0, Math.min(this._gradientArea.height(), (clientY - this._gradientArea.offset().top)))) / this._gradientArea.height(), 10);
            this._hsv.s = parseInt(100 * (Math.max(0, Math.min(this._gradientArea.width(), (clientX - this._gradientArea.offset().left)))) / this._gradientArea.width(), 10);
            this._hsvValue();
            this._tempValue = this.RGBToHEX(this.rgb);
            this._change = true;
            this._changeEvent(false);
        },
        _handleUp: function (e) {
            $(document).off('mouseup touchend', this._handleUp);
            $(document).off('mousemove touchmove', this._handleMovement);
            this._focusWrapper(e);
            return false;
        },
        _handlePosition: function () {
            this._handlePos = this._handleArea ? {
                left: parseInt(parseInt(this._width) * this._hsv.s / 100, 10) + "px",
                top: parseInt(parseInt(this._height) * (100 - this._hsv.v) / 100, 10) + "px"
            } : "";
            this._handleArea.css({ "left": this._handlePos.left, "top": this._handlePos.top });
        },
        _addColor: function () {
            var value, collection = this._divTag.find('> div');
            value = this._selectedButton.html() != "HSVA" ? this._inputTag.val() : this._formRGBA(this.HSVToRGB(this._hsv));
            if (value !== "" && this._change) {
                if (this.model.showRecentColors && collection.length <= 12) {
                    $($(collection)[collection.length - 2]).remove();
                    this._generateLi();
                }
            }
            if (!this.model.displayInline || this.element.is("input")) this.wrapper.focus();
        },
        _buttonClick: function (e) {
            this._change = true;
            var value = this._inputTag.val(), collection = this._divTag.find('div');
            this._opacity.option('value', this._tempOpacity);
            this._tempValue = this.RGBToHEX(this.rgb);
            this._updatePreviewColor();
            if (this._inputTag.val() === "") {
                this._tempValue = "";
                if (this.model.showClearButton) this._setValue("");
                else {
                    this._inputTag.addClass('e-error');
                    return false;
                }
            }
            this._selectEvent();
            if (this.element.is("input")) {
                this._updateValue();
                this.wrapper.focus();
            }
            !this.model.displayInline && this.hide();
            this._tempOpacity !== this.opacityValue() && this.opacityValue(this._tempOpacity);
        },
        _generateLi: function () {
            this._liTag = ej.buildTag('div.e-colorblock e-block e-colorset').attr({ "data-value": this.RGBToHEX(this.rgb), "tabindex": "0" });
            var spanTag = ej.buildTag('div.e-color e-set').attr({ "data-value": this.RGBToHEX(this.rgb), "title": this.RGBToHEX(this.rgb) });
            if (this._browser.name = "msie" && this._browser.version == "8.0") spanTag.css({ "background-color": this._formRGB(this.rgb), "filter": "alpha(opacity=" + this.rgb.a * 100 + ")" });
            else spanTag.css({ "background-color": this._formRGBA(this.rgb) });
            this._liTag.append(spanTag);
            this._divTag.prepend(this._liTag);
        },
        _colorCodeValue: function (e) {
            var newValue = "", codeValue = this._inputTag.val(), value, code, count;
            value = $.trim(codeValue);
            value.length == 5 ? this._inputTag.removeClass('e-error') : "";
            if ((e.shiftKey && e.keyCode >= 35 && e.keyCode <= 40 || (e.keyCode >= 65 && e.keyCode < 71) ) || (e.keyCode == 51) || (e.ctrlKey && (e.keyCode == 88 || e.keyCode == 86)) || e.keyCode == 190)
                this._keyPressFlag = 1;
            else if ((!e.crtlKey && !e.shiftKey) && ((e.keyCode >= 65 && e.keyCode < 71) || (e.keyCode >= 35 && e.keyCode <= 40) || (e.keyCode >= 96 && e.keyCode <= 105) || (e.keyCode >= 48 && e.keyCode <= 57) || e.keyCode == 13 || e.keyCode == 8 || e.keyCode == 46 || e.type === "blur"))
                this._keyPressFlag = 1;
			else if (e.key == "#" || e.key == "(" || e.key == ")" || e.key == ",")  this._keyPressFlag = 1;
            else this._keyPressFlag = 0;
            if (this.model.enableOpacity && (e.keyCode == 188 || e.keyCode == 71 || e.keyCode == 72 || e.keyCode == 82 || e.keyCode == 83 || e.keyCode == 86) || (e.shiftKey && (e.keyCode == 57 || e.keyCode == 48)))
                this._keyPressFlag = 1;
            if (this._keyPressFlag == 1) {
                this._inputTag.removeClass('e-error');
                if (e.keyCode === 13 || e.type === "blur") {
                    if (value === "") {
                        if (this.model.showClearButton) this._setEmptyValue();
                        else this._inputTag.addClass('e-error');
                    }
                    var regex = /^\#([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$/;
                    code = value.match(regex);
                    if (!ej.isNullOrUndefined(code)) {
                        if (code[1].length === 3) {
                            for (count = 0; count < code[1].length; count++) {
                                newValue += code[1][count] + code[1][count];
                            }
                        }
                        else if (code[1].length === 6)
                            newValue = code[1];
                        value = this.hexCodeToRGB("#" + newValue);
                        this._inputTag.val("#" + newValue);
                        this.rgb = this.HSVToRGB(this.RGBToHSV(value));
                        this._tempValue = this.RGBToHEX(this.rgb);
                        this._change = true;
                    }
                    else {
                        var rgbRegex = /^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/;
                        code = value.match(rgbRegex);
                        if (!ej.isNullOrUndefined(code)) this._rgbaColor(code);
                        else {
                            var hsvRegex = /^hsva?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/;
                            code = value.match(hsvRegex);
                            if (!ej.isNullOrUndefined(code)) {
                                this._hsvColor(code);
                            }
                            else {
                                value != "" && this._inputTag.addClass('e-error');
                                this._change = false;
                                return false;
                            }
                        }
                    }
                    if (this._change) {
                        this._valueOperation();
                        this._colorSlider.option('value', parseInt(this._hsv.h));
                        this._hueGradient();
                        this._changeEvent(false);
                        !this.element.is('input') && this._selectEvent();
                        if (this._inputTag.val() !== "") this._inputTag.removeClass("e-error");
                    }
                }
            }
            else {
                if (e.keyCode != 9) e.preventDefault();
                if (!e.shiftKey && !e.ctrlKey && e.keyCode !== 27 && e.keyCode !=20) this._inputTag.addClass('e-error');
            }
        },
        _setEmptyValue: function () {
            this._handleArea.css("visibility", "hidden");
            this._currentTag.css({ "background-color": "" });
            this._removeClass();
            this._tempValue = null;
            this._inputTag.val(null);
            if (this._previousValue !== this._tempValue) {
                this._trigger("change", { value: null });
                this._previousValue = this._tempValue
            }
        },
        _rgbaColor: function (code) {
            var rgb = {}, color;
            if (code[0].split('(')[0] == "rgba" && !ej.isNullOrUndefined(code[4])) {
                rgb.r = code[1]; rgb.g = code[2]; rgb.b = code[3]; rgb.a = code[4];
            }
            else if (code[0].split('(')[0] == "rgb" && ej.isNullOrUndefined(code[4])) {
                rgb.r = code[1]; rgb.g = code[2]; rgb.b = code[3]; rgb.a = this.rgb.a;
                this._inputTag.val("rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + "," + rgb.a + ")");
            }
            else {
                this._inputTag.addClass('e-error');
                this._change = false;
                return false;
            }
            this.rgb.a = parseFloat(rgb.a);
            this._tempOpacity = this.rgb.a * 100;
            this._opacity.option('value', this._tempOpacity);
            this.opacityValue(this._tempOpacity);
            this._tempValue = this.RGBToHEX(rgb);
            this._HexToHSV(this._tempValue);
            this._inputTag.removeClass("e-error");
            this._change = true;
        },
        _hsvColor: function (code) {
            var hsv = {};
            if (!ej.isNullOrUndefined(code[4])) {
                hsv.h = code[1]; hsv.s = code[2]; hsv.v = code[3]; hsv.a = code[4];
            }
            else {
                this._inputTag.addClass('e-error');
                this._change = false;
                return false;
            }
            this.rgb.a = parseFloat(hsv.a);
            this._tempOpacity = this.rgb.a * 100;
            this._opacity.option('value', this._tempOpacity);
            this.opacityValue(this._tempOpacity);
            this.rgb = this.HSVToRGB(hsv);
            this._tempValue = this.RGBToHEX(this.rgb);
            this._inputTag.removeClass("e-error");
            this._change = true;
        },
        _iconClick: function (e) {
            e.preventDefault();
            this._showHidePopup();
            this.wrapper.focus();
        },
        _showHidePopup: function () {
            if (this.model.displayInline) return false;
            if (!this.isPopupOpen) this.show();
            else {
                this.hide();
                this.wrapper.focus();
            }
        },

        hide: function () {
            var proxy = this;
            if (!this.isPopupOpen||this.model.displayInline) return false;
            this.isPopupOpen = this._dataBind = false;
            if (this.element.is('input')) {
                this.wrapper.focus();
                this.wrapper.removeClass("e-active");
            }
            this._width = this._gradientArea.width(); this._height = this._gradientArea.height();
            this.popupContainer.slideUp(200, function () {
                if (proxy.model) {
                    proxy._tempOpacity = proxy.opacityValue();
                    proxy.rgb.a = proxy._tempOpacity / 100;
                    proxy._tempValue = proxy.value();
                    proxy._renderModelValue(proxy.value());
                    proxy._opacity.option('value', parseInt(proxy.opacityValue()));
                    if (!proxy.model.displayInline)
                        proxy._off($(document), "mousedown", proxy._onDocumentClick);
                    proxy._trigger("close");
                }
            });
            if (!this.model.displayInline)
                this._off($(document), "mousedown", this._onDocumentClick);
            this._off(this._inputTag, "keydown", this._colorCodeValue);
            this._off(this._inputTag, "blur", this._colorCodeValue);
            this._modelType == "palette" ? this._off($(document), "keydown", this._keyDown) : this._off($(document), "keydown", this._onKeyDown);
            this._off(ej.getScrollableParents(this.wrapper), "scroll", this.hide);
            $(window).off("resize", $.proxy(this._OnWindowResize, this));
        },
        _hidePopup: function () {
            !this.model.displayInline && this.hide();
        },

        show: function () {
            if (this.element.is("input")) {
                this.wrapper.focus();
                this.wrapper.addClass("e-active");
            }
            if (this.isPopupOpen || !this.model.enabled) return false;
            this.isPopupOpen = true;
            if (this.model.modelType == "palette") this._cellSelect();
            if (!this.model.displayInline && (this.value() === "" || ej.isNullOrUndefined(this.value())))
                this._setEmptyValue();
            else
                this._handleArea.css("visibility", "visible");
            this._previousColor = this._previousValue = this.value();
            this.popupContainer.children().find('.e-focus').removeClass('e-focus');
            if (!this.model.displayInline) this._setPopupPosition();
            var proxy = this;
            this.popupContainer.slideDown(200, function () {
                proxy.isFocused = true;
                proxy._on($(document), "mousedown", proxy._onDocumentClick);
                proxy._trigger("open");
            });
            if (!this._dataBind)
                this._modelType == "palette" ? this._on($(document), "keydown", this._keyDown) : this._on($(document), "keydown", this._onKeyDown);
            this._on(this._inputTag, "keydown", this._colorCodeValue);
            this._on(this._inputTag, "blur", this._colorCodeValue);
            this._dataBind = true;
            $(window).on("resize", $.proxy(this._OnWindowResize, this));
            if (!this.model.displayInline) this._on(ej.getScrollableParents(this.wrapper), "scroll", this.hide);
            if (this._prevSize !== $(window).width()) this.refresh();
        },
        _showBindEvents: function () {
            this._modelType == "palette" ? this._on($(document), "keydown", this._keyDown) : this._on($(document), "keydown", this._onKeyDown);
        },
        _hideUnBindEvents: function () {
            this._modelType == "palette" ? this._off($(document), "keydown", this._onKeyDown) : this._off($(document), "keydown", this._keyDown);
        },
        _switchEvents: function () {
            if (this._switch) {
                this._on(this._gradientArea, "mousedown touchstart", this._handleMove);
                this._on(this._handleArea, "mousedown touchstart", this._handleClick);
                this._on(this._gradientArea, "mousedown touchstart", this._handleClick);
            }
            else this._on(this._collection, "mousedown", this._onSelect);
        },
        _unSwitchEvents: function () {
            if (!this._switch) {
                this._off(this._gradientArea, "mousedown touchstart", this._handleMove);
                this._off(this._handleArea, "mousedown touchstart", this._handleClick);
                this._off(this._gradientArea, "mousedown touchstart", this._handleClick);
            }
            else this._off(this._collection, "mousedown", this._onSelect);
        },
        _groupButton: function (e) {
            if ($(e.target).hasClass('e-disable')) return false;
            if ($(e.target).hasClass("e-button")) {
                var element = this._groupTag.find('.e-btn.e-select');
                if (this._inputTag.val() !== "") this._inputTagValue($(e.target));
                else this._selectedButton = $(e.target);
                this._selectedButton.html() !== "HEX" ? this._inputTag.attr('maxLength', '22') : this._inputTag.attr('maxLength', '7');
                this._groupTag.find('.e-click').removeClass('e-click');
                $(e.target).addClass('e-click');
                this._inputTag.removeClass('e-error');
            }
        },
        _inputTagValue: function (type) {
            if (type.html() == "RGBA") this._inputTag.val(this._formRGBA(this.rgb));
            else if (type.html() == "HEX") this._inputTag.val(this.RGBToHEX(this.rgb));
            else if (type.html() == "HSVA") {
                if (this._modelType != "palette")
                    this._inputTag.val("hsva(" + Math.round(this._hsv.h) + "," + Math.round(this._hsv.s) + "," + Math.round(this._hsv.v) + "," + this.rgb.a + ")");
            }
            this._selectedButton = type;
        },
        _bindRecentEvent: function () {
            this._on(this._divTag, "click", this._recentColor);
        },
        _unBindRecentEvent: function () {
            this._off(this._divTag, "click", this._recentColor);
        },
        _handlePlacement: function (prop, value, bool) {
            this._handleArea.css("visibility", "visible");
            var hsv = this._hsv;
            hsv[prop] += value * (bool ? 1 : 3);
            if (hsv[prop] < 0) { hsv[prop] = 0; }
            prop === "s" ? this._hsv.s = hsv[prop] : this._hsv.v = hsv[prop];
            this._hsvValue();
            this._tempValue = this.RGBToHEX(this.rgb);
            this._changeEvent(false);
        },
        _onKeyDown: function (e) {
            var key = e.keyCode;
            if (!this.model.enabled) return;
            if (e.shiftKey && key == 9) if ($(this._hueSlider).find('.e-handle').hasClass('e-focus')) this._focusWrapper(e);
            if (!this._isFocused) if (key == 9 && key !== 27) return;
            this._change = true;
            if ((!e.altKey && !e.shiftKey)) {
                switch (key) {
                    case 39:
                        if (this.element.is('input') && $(e.target).is(this.wrapper)) {
                            e.preventDefault();
                            this._handlePlacement("s", 1, e.ctrlKey);
                        }
                        break;
                    case 38:
                        if (this.element.is('input') && $(e.target).is(this.wrapper)) {
                            e.preventDefault();
                            this._handlePlacement("v", 1, e.ctrlKey);
                        }
                        break;
                    case 37:
                        if (this.element.is('input') && $(e.target).is(this.wrapper)) {
                            e.preventDefault();
                            this._handlePlacement("s", -1, e.ctrlKey);
                        }
                        break;
                    case 40:
                        if (this.element.is('input') && $(e.target).is(this.wrapper)) {
                            e.preventDefault();
                            this._handlePlacement("v", -1, e.ctrlKey);
                        }
                        break;
                    case 13:
                        e.preventDefault();
                        if ($(e.target).hasClass('e-switcher')) {
                            this._switchModel();
                            $(e.target).focus();
                        }
                        else if ($(e.target).hasClass('e-applyButton')) this._buttonClick(e);
                        break;
                    case 27:
                        e.preventDefault();
                        !this.model.displayInline && this.hide();
                        this._tempValue = this.value();
                        break;
                    case 9:
                        active = document.activeElement;
                        if ($(active).is(this.wrapper)) this._focusPopup(e);
                        break;
                }
            }
        },
        _focusPopup: function (e) {
            $(this._hueSlider).find('.e-handle').focus();
            e.preventDefault();
        },
        _focusWrapper: function (e) {
            this.element.is('input') && $(this.wrapper).focus();
            e.preventDefault();
        },
        _onDocumentClick: function (e) {
            if (!$(e.target).is(this.popupContainer) && !$(e.target).parents(".e-colorpicker").is(this.popupContainer) &&
              !$(e.target).is(this.wrapper) && !$(e.target).parents(".e-colorpickerwidget").is(this.wrapper) && !$(e.target).parents('.e-presetWrapper').is("#" + this._id + "_Presets")) {
                if (!this.model.displayInline) {
                    this.hide();
                    if (this.element.is('input')) this.wrapper.removeClass('e-focus');
                }
                this._isFocused = false;
            }
        },

        _OnWindowResize: function (e) {
            if (this.element.is('input')) this._setPopupPosition();
            this.refresh();
        },
        refresh: function () {
            var element = $(this._PresetTable.find('.e-item')[1]);
            var count = 10, paddingSize = 36; //paddingSize is fixed for  palette model cells
            if (!this.isPopupOpen) {
                this.popupContainer.css({ "display": "block", "visibility": "hidden" });
                this._modelType == "palette" && this.PaletteWrapper.css({ "display": "block", "visibility": "hidden" });
            } else if (this._modelType == "picker") {
                this.PaletteWrapper.css({ "display": "block", "visibility": "hidden" });
            }
            if (parseFloat(this._tag.outerHeight()) > element.outerHeight(true) || (($(this._tag).outerWidth() - ($(element).outerWidth(true) * count)) > element.outerWidth()) || $(this._tag).outerWidth() == 0) {
                var rowSize = parseFloat($(this._tag).outerWidth()) - paddingSize;
                var cellWidth = (rowSize / count) - (element.outerWidth() - element.width());
                this._PresetTable.find('.e-item').css('width', cellWidth);
                if (element.outerWidth(true) * count > this._tag.outerWidth()) this._PresetTable.find('.e-item').css('width', cellWidth - 1);
            }
            if (!this.isPopupOpen) {
                this.popupContainer.css({ "display": "none", "visibility": "visible" });
                this._modelType == "palette" && this.PaletteWrapper.css({ "visibility": "visible" });
            } else if (this._modelType == "picker") {
                this.PaletteWrapper.css({ "display": "none", "visibility": "visible" });
            }
            this._prevSize = $(window).width();
            this._width = this._gradientArea.width(); this._height = this._gradientArea.height();
        },

        _range: function (range, value) {
            if (value === "") return value = 0;
            else if (value > range) return range;
            else return value;
        },
        _hsvValue: function () {
            var colorCode, hsv;
            this._change = true;
            this._hsv.v = this._hsv.v >= 100 ? 100 : this._hsv.v;
            this._hsv.s = this._hsv.s >= 100 ? 100 : this._hsv.s;
            this.hsv = this._hsv;
            this.rgb = this.HSVToRGB(this.hsv);
            this._valueOperation();
            this._inputTagValue(this._selectedButton);
        },
        _formRGB: function (value) {
            if (!ej.isNullOrUndefined(value)) return "rgb(" + value.r + "," + value.g + "," + value.b + ")";
        },
        _formRGBA: function (value) {
            if (!ej.isNullOrUndefined(value)) return "rgba(" + value.r + "," + value.g + "," + value.b + "," + value.a + ")";
        },
        _rgbValue: function (e) {
            var rgbColor, colorCode, value;
            value = this._HexToRGB(this._tempValue);
            if (!ej.isNullOrUndefined(value)) {
                this.rgb = value;
                this._change = true;
                this.HSVToRGB(this.RGBToHSV(this.rgb));
                this._colorSlider.option('value', parseInt(this._hsv.h));
                this._opacity.option('value', this.rgb.a * 100);
            }
            this._valueOperation();
            this._inputTagValue(this._selectedButton);
        },
        _valueOperation: function () {
            this._handlePosition();
            this._alphaGradient(this._tempValue);
            this._inputTag.removeClass("e-error");
            this._updateUI();
        },
        _HexToHSV: function (hex) {
            return this.HSVToRGB(this.RGBToHSV(this._HexToRGB(hex)));
        },
        _HexToRGB: function (hex) {
            if (!ej.isNullOrUndefined(hex)) {
                var reg = "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$", hex, validate = hex.match(reg);
                if (ej.isNullOrUndefined(validate)) { this._change = false; return false; }
                if (validate[1].length == 3)
                    hex = "#" + validate[1][0] + validate[1][0] + validate[1][1] + validate[1][1] + validate[1][2] + validate[1][2];
                this._change = true;
                hex = parseInt(((hex.indexOf('#') > -1) ? hex.substring(1) : hex), 16);
                var value = ej.isNullOrUndefined(this.rgb) ? parseFloat(this._tempOpacity) / 100 : this.rgb.a;
                return this.rgb = { r: hex >> 16, g: (hex & 0x00FF00) >> 8, b: (hex & 0x0000FF), a: value };
            }
        },

        RGBToHSV: function (rgb) {
            var hsv = { h: 0, s: 0, v: 0 };
            var min = Math.min(rgb.r, rgb.g, rgb.b);
            var max = Math.max(rgb.r, rgb.g, rgb.b);
            var differ = max - min;
            hsv.v = max;
            hsv.v *= 100 / 255;
            if (differ === 0) {
                this._hsv = hsv;
                return hsv;
            }
            hsv.s = max != 0 ? 255 * differ / max : 0;
            if (hsv.s != 0) {
                if (rgb.r == max) hsv.h = (rgb.g - rgb.b) / differ;
                else if (rgb.g == max) hsv.h = 2 + (rgb.b - rgb.r) / differ;
                else hsv.h = 4 + (rgb.r - rgb.g) / differ;
            } else hsv.h = -1;
            hsv.h *= 60;
            if (hsv.h < 0) hsv.h += 360;
            hsv.s *= 100 / 255;
            this._hsv = hsv;
            return hsv;
        },

        HSVToRGB: function (hsv) {
            var rgb = {};
            var h = parseFloat(hsv.h);
            var s = parseFloat(hsv.s * 255 / 100);
            var v = parseFloat(hsv.v * 255 / 100);
            if (s == 0) {
                rgb.r = rgb.g = rgb.b = v;
            } else {
                var t1 = v;
                var t2 = (255 - s) * v / 255;
                var t3 = (t1 - t2) * (h % 60) / 60;
                if (h == 360) h = 0;
                if (h < 60) { rgb.r = t1; rgb.b = t2; rgb.g = t2 + t3 }
                else if (h < 120) { rgb.g = t1; rgb.b = t2; rgb.r = t1 - t3 }
                else if (h < 180) { rgb.g = t1; rgb.r = t2; rgb.b = t2 + t3 }
                else if (h < 240) { rgb.b = t1; rgb.r = t2; rgb.g = t1 - t3 }
                else if (h < 300) { rgb.b = t1; rgb.g = t2; rgb.r = t2 + t3 }
                else if (h < 360) { rgb.r = t1; rgb.g = t2; rgb.b = t1 - t3 }
                else { rgb.r = 0; rgb.g = 0; rgb.b = 0 }
            }
            this._hsv = hsv;
            var value = ej.isNullOrUndefined(this.rgb) ? parseFloat(this._tempOpacity) / 100 : this.rgb.a;
            return { r: Math.round(rgb.r), g: Math.round(rgb.g), b: Math.round(rgb.b), a: value }
        },
        _HSVToHex: function (hsv) {
            return this.RGBToHEX(this.HSVToRGB(hsv));
        },
        _toHEX: function (rgb) {
            if (rgb.indexOf("#") !== -1) return rgb;
            rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
            return "#" + this._hex(rgb[1]) + this._hex(rgb[2]) + this._hex(rgb[3]);
        },



        RGBToHEX: function (rgb) {
            if (!ej.isNullOrUndefined(rgb))
                return "#" + this._hex(rgb.r) + this._hex(rgb.g) + this._hex(rgb.b);
        },
        _hex: function (x) {
            return ("0" + parseInt(x).toString(16)).slice(-2);
        },
        _colorValue: function (value) {
            this._color = value.indexOf("#") != -1 ? this.hexCodeToRGB(value) : "";
            return "rgb(" + this._color.r + ", " + this._color.g + ", " + this._color.b + ")";
        },


        hexCodeToRGB: function (colorCode) {
            var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(colorCode);
            return result ? {
                r: parseInt(result[1], 16),
                g: parseInt(result[2], 16),
                b: parseInt(result[3], 16),
                a: this.rgb.a
            } : null;
        },

        _updatePreviewColor: function () {
            if (this._browser.name = "msie" && this._browser.version == "8.0")
                this._previousTag.css({ "background-color": this._formRGB(this.rgb), "filter": "alpha(opacity=" + this.rgb.a * 100 + ")" });
            else
                this._previousTag.css({ "background-color": this._formRGBA(this.rgb) });
            this._oldValue = this.rgb;
        },
        _updateUI: function () {
            var value = this._hsv;
            if (this._switch) {
                var hsv = { h: this._hsv.h, s: 100, v: 100 };
                this._gradientArea.css({ "background-color": this._colorValue(this._HSVToHex(hsv)) });
            } else this._cellSelect();
            if (this._browser.name = "msie" && this._browser.version == "8.0") {
                this._currentTag.css({ "background-color": this._formRGB(this.rgb), "filter": "alpha(opacity=" + this.rgb.a * 100 + ")" });
                this._previousTag.css({ "background-color": this._formRGB(this._oldValue), "filter": "alpha(opacity=" + this.rgb.a * 100 + ")" });
            }
            else {
                this._currentTag.css({ "background-color": this._formRGBA(this.rgb) });
                this._previousTag.css({ "background-color": this._formRGBA(this._oldValue) });
                this._alphaSlider.children(".e-handle").css({ "background": this._formRGBA(this.rgb) });
            }
            this._hsv = value;
        },

        _targetFocus: function (e) {
            e.preventDefault();
            if (!this._isFocused) {
                this._isFocused = true;
                if (this.element.is("input")) this.wrapper.addClass("e-focus");
            }
        },
        _targetBlur: function (e) {
            this._isFocused = false;
            if (!this.isPopupOpen && this.element.is("input")) this.wrapper.removeClass("e-focus");
        },
        _switchModel: function () {
            this._tempValue = this.RGBToHEX(this.rgb);
            this.refresh();
            var proxy = this;
            this._off(this._changeTag, "click", this._switchModel);
            if (this._modelType == "palette") {
                this._modelType = "picker";
                this._switcher.removeClass("e-pickerModel").addClass("e-paletteModel");
                this.PaletteWrapper.fadeOut(300, function () {
                    proxy._presetTag.parents('.e-split.e-widget').addClass('e-hide');
                    proxy._gradient.fadeIn(300);
                    proxy._on(proxy._changeTag, "click", proxy._switchModel);
                });
                this._switch = true;
                this._rgbValue();
                this._hueGradient();
                this._hsva.ejButton("enable");
            } else {
                this.PaletteWrapper.remove();
                this._modelType = "palette";
                this.PaletteWrapper = this._layoutType(this.model.palette);
                this._gradient.addClass('e-hide');
                this._paletteType();
                this._switcher.removeClass("e-paletteModel").addClass("e-pickerModel");
                this._gradient.fadeOut(300, function () {
                    proxy._presetTag.parents('.e-split.e-widget').removeClass('e-hide');
                    if (ej.isNullOrUndefined(proxy.PaletteWrapper)) {
                        proxy.PaletteWrapper = proxy._layoutType(proxy.model.palette);
                        proxy._splitObj.option('prefixIcon', 'e-color-image e-' + proxy.model.presetType);
                        proxy.popupList.prepend(proxy.PaletteWrapper);
                    }
                    proxy.PaletteWrapper.fadeIn(300);
                    proxy._on(proxy._changeTag, "click", proxy._switchModel);
                });
                if (this.value() !== "")
                    this._cellSelect();
                this._disableHSVButton();
            }
            this.model.palette === "custompalette" && this._presetTag.parents('.e-split.e-widget').addClass('e-hide');
            if (!this.model.displayInline || this.element.is(":input")) this.wrapper.focus();
            this._switchEvents();
            this._unSwitchEvents();
            if (this.isPopupOpen) {
                this._hideUnBindEvents();
                this._showBindEvents();
            }
        },
        _disableHSVButton: function () {
            if ($(this._groupTag.find('.e-click')).hasClass('e-hsvButton')) {
                this._inputTagValue(this._rgb);
                this._rgb.addClass('e-click');
                this._hsva.removeClass('e-click');
            }
            this._hsva.ejButton("disable");
        },

        _cellSelect: function () {
            var code, element, proxy = this;
            this._removeClass();
            this._collection.find('.e-item').each(function () {
                code = $(this).css("background-color");
                if (proxy._browser.name = "msie" && proxy._browser.version == "8.0") {
                    if (code && code.replace(/ /g, '') === proxy.RGBToHEX(proxy.rgb)) {
                        element = this;
                        $(element).addClass("e-filter");
                    }
                } else {
                    if (code && code.replace(/ /g, '') === proxy._formRGB(proxy.rgb)) element = this;
                }
            });
            $(element).addClass("e-state-selected").attr("aria-selected", true);
        },
        _removeClass: function () {
            this._collection.find('.e-item').removeClass('e-state-selected').removeClass("e-filter").removeAttr("aria-selected");
        },
        _position: function (items, element, columns) {
            items = Array.prototype.slice.call(items);
            var n = items.length,
            index = items.indexOf(element);
            if (index < 0) return columns < 0 ? items[n - 1] : items[0];
            index += columns;
            return items[index < 0 ? index += n : index %= n];
        },
        _onSelect: function (e) {
            if (!this.model.enabled) return false;
            this._isFocused = true;
            this._handleArea.css("visibility", "visible");
            if (e.target.style.backgroundColor != "") {
                this._collection.find('.e-item').removeClass("e-state-selected").removeAttr('aria-selected');
                this._HexToRGB(this._toHEX(e.target.style.backgroundColor));
                this._updateUI();
                this._inputTagValue(this._selectedButton);
                if (!this.model.displayInline || this.element.is("input")) this.wrapper.focus();
                this._tempValue = this.RGBToHEX(this.rgb);
                this._changeEvent(false);
            }
            e.preventDefault();
        },
        _keyDown: function (e) {
            if (this._isFocused) {
                this._change = true;
                if (!this.model.enabled) return false;
                var selected = "",
                    key = e.keyCode,
                    items = this._collection.find('.e-item'),
                    element = items.filter(".e-state-selected").get(0),
                    columnSize = this.model.columns;
                if (!e.altKey && (key == 37 || key == 38 || key == 39 || key == 40) && (e.target.className !== "e-color-code"))
                    this._removeClass();
                switch (!e.altKey && key) {
                    case 40:
                        if (e.target.className !== "e-color-code") {
                            e.preventDefault();
                            selected = this._position(items, element, columnSize);
                        }
                        break;
                    case 37:
                        if (e.target.className !== "e-color-code") {
                            e.preventDefault();
                            selected = this._position(items, element, -1);
                        }
                        break;
                    case 38:
                        if (e.target.className !== "e-color-code") {
                            e.preventDefault();
                            selected = this._position(items, element, -columnSize);
                        }
                        break;
                    case 39:
                        if (e.target.className !== "e-color-code") {
                            e.preventDefault();
                            selected = this._position(items, element, 1);
                        }
                        break;
                    case 13:
                        this._collection.find('.e-item').removeClass('e-state-selected').removeAttr("aria-selected");
                        if ($(e.target).hasClass('e-switcher')){
                            this._switchModel();
                            $(e.target).focus();
                        } 
                        else if ($(e.target).hasClass('e-applyButton')) {
                            this._buttonClick(e);
                            this._updateUI();
                            !this.model.displayInline && this.hide();
                            if (this.element.is("input")) this.wrapper.focus();
                        }
                        break;
                    case 27:
                        !this.model.displayInline && this.hide();
                        $(this._presetContainer).hide();
                        if (this.element.is("input")) this.wrapper.focus();
                        break;
                    case 9:
                        active = document.activeElement;
                        if ($(active).is(this.wrapper)) this._focusPalettePopup(e, true);
                        break;
                }
                if (selected) {
                    $(selected).addClass('e-state-selected').attr("aria-selected", true);
                    this._currentTag.css({ "background-color": this._formRGB(this._HexToRGB($(selected).attr("data-value")))});
                    this._inputTagValue(this._selectedButton);
                    this._tempValue = this.RGBToHEX(this.rgb);
                    this._changeEvent(false);
                }
            } else {
                if (e.keyCode == 27) {
                    this.hide();
                    $(this._presetContainer).hide();
                }
            }
        },
        _focusPalettePopup: function (e, type) {
            $(this.popupContainer).focus();
            e.preventDefault();
        },
    })

    ej.ColorPicker.Locale = ej.ColorPicker.Locale || {};

    ej.ColorPicker.Locale["default"] = ej.ColorPicker.Locale["en-US"] = {
        buttonText: {
                apply: "Apply",
                cancel: "Cancel",
                swatches: "Swatches"
            },

            tooltipText: {
                switcher: "Switcher",
                addButton: "Add Color",
                basic: "Basic",
                monoChrome: "Mono Chrome",
                flatColors: "Flat Colors",
                seaWolf: "Sea Wolf",
                webColors: "Web Colors",
                sandy: "Sandy",
                pinkShades: "Pink Shades",
                misty: "Misty",
                citrus: "Citrus",
                vintage: "Vintage",
                moonLight: "Moon Light",
                candyCrush: "Candy Crush",
                currentColor: "Current Color",
                selectedColor: "Selected Color",
            }
    }
    ej.ColorPicker.Palette = {
        /**  Represents the basic Palette. This is default Type*/
        BasicPalette: "basicpalette",
        /**  Represents the custom Palette. User will customize the palette*/
        CustomPalette: "custompalette",
    }

    ej.ColorPicker.ModelType = {
        /**  Represents Palette Type*/
        Palette: "palette",
        /** Represents Picker Type */
        Picker: "picker"
    }

    ej.ColorPicker.ButtonMode = {
        /**  Represents the default bahavior*/
        Default: "dropdown",
        /**  Represents the Split bahavior, to perform the separete operation for each button*/
        Split: "split",
    }

    ej.ColorPicker.PresetType = {
        Basic: "basic",
        MonoChrome: "monochrome",
        FlatColors: "flatcolors",
        SeaWolf: "seawolf",
        WebColors: "webcolors",
        Sandy: "sandy",
        PinkShades: "pinkshades",
        Misty: "misty",
        Citrus: "citrus",
        Vintage: "vintage",
        MoonLight: "moonlight",
        CandyCrush: "candycrush",
    }
    var Colors = {
        basic: ["ffffff", "facbcb", "fccb98", "faf39a", "fbf8cd", "a6d38b", "aadee8", "d1ecf2", "cdcae5", "eecde1", "cccbcb", "f16667", "f69668", "f8ee6b", "f7ec37", "89c987", "75cddd", "8bd3e1", "7f7fcc", "9494c8", "b3b2b3", "ec2024", "f7971d", "ffcb67", "f5ea14", "74bf44", "69c8c9", "46c7f4", "6666ad", "b76cab", "676767", "971b1e", "ca6828", "ca9732", "979937", "0d9948", "339898", "4857a6", "62449a", "973794", "000000", "2f1110", "973620", "663433", "343416", "183319", "023334", "22205f", "3b2f8d", "310e31"],
        monochrome: ["ffffff", "e3e3e3", "c6c6c6", "aaaaaa", "8e8e8e", "717171", "555555", "393939", "1c1c1c", "000000", "f9e6e7", "f4d0d2", "efbabc", "e9a4a7", "e48e92", "df787c", "da6267", "d44c52", "cf363c", "ca2027", "fff4ca", "ffeb9e", "fff0b4", "ffefb1", "ffe788", "ffe272", "ffd947", "ffd531", "ffd01b", "ffcc05", "e4f4eb", "ccead9", "b4e0c7", "9cd6b5", "84cca3", "6dc190", "55b77e", "3dad6c", "25a35a", "0d9948", "e8f4f4", "d6e3eb", "c4d1e3", "b3c0da", "a1aed1", "8f9dc9", "7d8bc0", "6c7ab7", "5a68af", "4857a6"],
        flatcolors: ["7477b8", "488bca", "18b1d4", "1db369", "78c162", "acc063", "ffe84e", "f6b757", "f79853", "ed6346", "E87F3D", "E4C45D", "B7A575", "999999", "67809F", "002228", "00A578", "F9A41F", "F3770B", "D7401B", "FFCB36", "82CC2C", "36B595", "6370AD", "D4264E", "004D8E", "22A04B", "F3A414", "C77405", "F3420B", "1ABC9C", "3498DB", "9B59B6", "E67E22", "E74C3C", "3A738A", "EBD9A7", "89AD78", "FF766D", "C76160", "BF3542", "CDC5BA", "EBE3D6", "3C3C3C", "2E2E2E", "77A7FB", "E57368", "FBCB43", "34B67A", "FFFFFF"],
        seawolf: ["0EEAFF", "15A9FA", "1B76FF", "1C3FFD", "2C1DFF", "0B3C4C", "0E5066", "13647F", "127899", "1A8BB2", "74B8E8", "659EBB", "3C9FFF", "26466F", "2472FF", "0069A4", "009BF2", "004165", "49A0B4", "274C5F", "000000", "7A5848", "E0A088", "F9DEC6", "3A2A22", "DC3522", "D9CB9E", "374140", "2A2C2B", "1E1E20", "CB3937", "FE6B2C", "654E44", "6DD16F", "70FE2C", "275673", "4681A6", "FDDEC9", "F22816", "400101", "071C2F", "388494", "E6A934", "F3DB5F", "534329", "206956", "47683B", "E1BFA6", "BF7950", "903932"],
        webcolors: ["0066aa", "00bbdd", "338800", "77bb00", "ffcc99", "990c0c", "0303c9", "336699", "669933", "cccccc", "EEEEEE", "E7C36F", "F7B230", "E35B20", "000033", "7D7A74", "BD524A", "FCB200", "8CFCC2", "2ACD6B", "666666", "666553", "FFFEEC", "B2B2A4", "AAA4B2", "9CA5E3", "5A668C", "BBA469", "CFC295", "FFFFFF", "DBBF56", "2E94B3", "808080", "E96656", "14A168", "DE185B", "D8806F", "DBE186", "D8CC63", "DCC527", "4E6C89", "E2BDAD", "EC6053", "81BBAD", "DFCDA5", "453394", "66398A", "313E7D", "336694", "788E91"],
        sandy: ["c0a986", "ecd9c3", "dfc79b", "f6d58e", "ecdaad", "fff3e0", "7f6b4a", "ffd694", "7f7a70", "ccac76", "E6E2AF", "A79A71", "EFECCA", "806F4C", "2F2F2E", "997F1A", "CCB65F", "FFD291", "6B674A", "635F3A", "7F693A", "FFEBC1", "FFD275", "7F7561", "CCA85E", "D29854", "4A4034", "C9AD8D", "4A351D", "968169", "E6E39F", "9A9757", "FFFDC9", "94909A", "E2E0E6", "960010", "EB1517", "CD7C29", "9A571C", "1F7A94", "7F6826", "7F724C", "FFE499", "FFD04C", "CCA63D", "FFA669", "92FFB6", "FFF352", "E8C269", "D7E8CB"],
        pinkshades: ["F6B1C3", "F0788C", "DE264C", "BC0D35", "A20D1E", "E12256", "BB1C48", "7B132F", "3B0917", "FA2660", "FFB7B5", "9A423F", "FF6D68", "BB5855", "CC5753", "E88161", "D66C60", "C2646E", "996072", "705262", "FFA1BD", "FF8FB7", "FF82AE", "E9719B", "CC6882", "F250C7", "BF1774", "BF2696", "AC60AA", "BB90C5", "BF1553", "F20775", "F2F2F2", "e5566d", "f2afc1", "f43fa5", "fc8c99", "FF6887", "7F3443", "CC536C", "D06AA9", "E65F41", "650017", "BC1620", "FA427E", "3B1132", "84476E", "B83D65", "E6E0E8", "FF6EE8"],
        misty: ["5C7A84", "3D5372", "7C9196", "50748A", "ADBFBF", "010735", "052159", "194073", "376B8C", "FFFFFF", "985999", "C811CC", "892EFF", "FF6852", "DBA211", "0A0D0C", "85A67C", "46593E", "BBD9AD", "202616", "BF8E63", "734327", "A66C4B", "593A2F", "BFBFBF", "8DB0B6", "1B778A", "F46C1B", "881801", "192129", "81808C", "ABAABF", "0C0E09", "6A7366", "37402F", "5D6663", "84867B", "A4A66A", "BABBB1", "20211C", "6B9695", "646E8C", "6B8196", "61787F", "648C80", "8E9FBA", "89A8C8", "799ED1", "7FAEE7", "849EBD"],
        citrus: ["FAEA41", "E7F03E", "E3C647", "FAC541", "F0AB3E", "CCCA1F", "FFF300", "FFCB0D", "FF9500", "804A00", "6A692A", "FFFCA0", "FFFFFF", "CF664E", "EFAC66", "EFF299", "F2DC6D", "F29727", "F2600C", "592202", "214001", "4F7302", "1A2601", "BCD97E", "C0D904", "AAFEFF", "359D6D", "E5FF45", "65FCCF", "ABDC4B", "42B200", "C6FF00", "F2E304", "FFB200", "FF8600", "52EC04", "04E206", "94D507", "ECE404", "E2C904", "DA321C", "FF7913", "FBD028", "C0D725", "9FC131", "547312", "ADBF26", "DEB329", "F1DB47", "E08214"],
        vintage: ["684132", "fdbe30", "eaac21", "87783c", "3e4028", "ffc706", "cd5648", "5bafa9", "828282", "363636", "424862", "fb9a63", "bfc4d5", "f6fbf4", "febc98", "657050", "FCF082", "D8D98B", "A2AB80", "4D584A", "5ADED4", "4DAAAB", "26596A", "163342", "6C98A1", "010A26", "28403B", "557359", "AEBF8A", "C7D9AD", "AFFCCB", "CB4243", "D2997E", "36857E", "4AC6BB", "28394B", "191313", "AF0A18", "DC373D", "122438", "43734A", "A6A26D", "D9B448", "BF8C2C", "734002", "26010F", "866F53", "ACBD91", "7BAB87", "546859"],
        moonlight: ["241D37", "2A233D", "322B45", "362F49", "D4BA73", "261225", "592040", "8C3063", "A64985", "73345D", "A3C8FF", "85B6FF", "000040", "213190", "050859", "FFFFFF", "6AAED9", "4184BF", "224573", "2e4154", "bcad7e", "955351", "c36a57", "9a8556", "7e6029", "dbd78e", "beae3b", "c3a04c", "58504d", "967644", "CFC496", "B3B391", "889486", "61797B", "366577", "123340", "436E73", "7B8C61", "D7D996", "F0EBB4", "341F36", "D9B5E0", "9889AB", "4D4E66", "1B2129", "5CBBE3", "FCF1BC", "5C8182", "383A47", "B4F257"],
        candycrush: ["0779f4", "30da00", "fb8006", "f9d802", "a71df7", "f70200", "fd49ae", "682e07", "9b2424", "5e7693", "F9AB3B", "EF5627", "FF0000", "00A398", "803C2C", "DE5711", "FFF026", "FF0048", "14A0CC", "00B229", "FFFFBE", "F7CD99", "FF77A1", "9886E8", "97CACB", "EAEDE5", "FFD127", "FF870C", "EC4610", "9A1900", "993460", "CC1464", "C300FF", "FFFFBC", "CCB914", "FFFEE2", "B24C5F", "FF274F", "0A94CC", "679DB2", "C2FFE6", "16B271", "5FFFBC", "B2442F", "FFA190", "E89359", "FFFB75", "F36EFF", "5999E8", "73EB86"],
    }

})(jQuery, Syncfusion);;