﻿/*!
*  filename: ej.sparkline.js
*  version : 16.4.0.52
*  Copyright Syncfusion Inc. 2001 - 2019. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
*/


window.ej = window.Syncfusion = window.Syncfusion || {};


(function ($, ej, undefined) {
    'use strict';

    ej.version = "16.4.0.52";

    ej.consts = {
        NamespaceJoin: '-'
    };
    ej.TextAlign = {
        Center: 'center',
        Justify: 'justify',
        Left: 'left',
        Right: 'right'
    };
    ej.Orientation = { Horizontal: "horizontal", Vertical: "vertical" };

    ej.serverTimezoneOffset = 0;

    ej.parseDateInUTC = false;

    ej.persistStateVersion = null;

    ej.locales = ej.locales || [];

    if (!Object.prototype.hasOwnProperty) {
        Object.prototype.hasOwnProperty = function (obj, prop) {
            return obj[prop] !== undefined;
        };
    }

    //to support toISOString() in IE8
    if (!Date.prototype.toISOString) {
        (function () {
            function pad(number) {
                var r = String(number);
                if (r.length === 1) {
                    r = '0' + r;
                }
                return r;
            }
            Date.prototype.toISOString = function () {
                return this.getUTCFullYear()
                    + '-' + pad(this.getUTCMonth() + 1)
                    + '-' + pad(this.getUTCDate())
                    + 'T' + pad(this.getUTCHours())
                    + ':' + pad(this.getUTCMinutes())
                    + ':' + pad(this.getUTCSeconds())
                    + '.' + String((this.getUTCMilliseconds() / 1000).toFixed(3)).slice(2, 5)
                    + 'Z';
            };
        }());
    }

    String.format = function () {
        var source = arguments[0];
        for (var i = 0; i < arguments.length - 1; i++)
            source = source.replace(new RegExp("\\{" + i + "\\}", "gm"), arguments[i + 1]);

        source = source.replace(/\{[0-9]\}/g, "");
        return source;
    };

    jQuery.uaMatch = function (ua) {
        ua = ua.toLowerCase();

        var match = /(chrome)[ \/]([\w.]+)/.exec(ua) ||
            /(webkit)[ \/]([\w.]+)/.exec(ua) ||
            /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua) ||
            /(msie) ([\w.]+)/.exec(ua) ||
            ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua) ||
            [];

        return {
            browser: match[1] || "",
            version: match[2] || "0"
        };
    };
    // Function to create new class
    ej.defineClass = function (className, constructor, proto, replace) {
        /// <summary>Creates the javascript class with given namespace & class name & constructor etc</summary>
        /// <param name="className" type="String">class name prefixed with namespace</param>
        /// <param name="constructor" type="Function">constructor function</param>
        /// <param name="proto" type="Object">prototype for the class</param>
        /// <param name="replace" type="Boolean">[Optional]Replace existing class if exists</param>
        /// <returns type="Function">returns the class function</returns>
        if (!className || !proto) return undefined;

        var parts = className.split(".");

        // Object creation
        var obj = window, i = 0;
        for (; i < parts.length - 1; i++) {

            if (ej.isNullOrUndefined(obj[parts[i]]))
                obj[parts[i]] = {};

            obj = obj[parts[i]];
        }

        if (replace || ej.isNullOrUndefined(obj[parts[i]])) {

            //constructor
            constructor = typeof constructor === "function" ? constructor : function () {
            };

            obj[parts[i]] = constructor;

            // prototype
            obj[parts[i]].prototype = proto;
        }

        return obj[parts[i]];
    };

    ej.util = {
        getNameSpace: function (className) {
            /// <summary>Internal function, this will create namespace for plugins using class name</summary>
            /// <param name="className" type="String"></param>
            /// <returns type="String"></returns>
            var splits = className.toLowerCase().split(".");
            splits[0] === "ej" && (splits[0] = "e");

            return splits.join(ej.consts.NamespaceJoin);
        },

        getObject: function (nameSpace, from) {
            if (!from || !nameSpace) return undefined;
			(typeof(nameSpace) != "string") && (nameSpace = JSON.stringify(nameSpace));
            var value = from, splits = nameSpace.split('.');

            for (var i = 0; i < splits.length; i++) {

                if (ej.util.isNullOrUndefined(value)) break;

                value = value[splits[i]];
            }

            return value;
        },

        createObject: function (nameSpace, value, initIn) {
            var splits = nameSpace.split('.'), start = initIn || window, from = start, i, t, length = splits.length;

            for (i = 0; i < length; i++) {
                t = splits[i];
                if (i + 1 == length)
                    from[t] = value;
                else if (ej.isNullOrUndefined(from[t]))
                    from[t] = {};

                from = from[t];
            }

            return start;
        },

        isNullOrUndefined: function (value) {
            /// <summary>Util to check null or undefined</summary>
            /// <param name="value" type="Object"></param>
            /// <returns type="Boolean"></returns>
            return value === undefined || value === null;
        },
        exportAll: function (action, controlIds) {
            var inputAttr = [], widget, locale = [], index, controlEle, controlInstance, controlObject, modelClone;
            var attr = { action: action, method: 'post', "data-ajax": "false" };
            var form = ej.buildTag('form', "", null, attr);
            if (controlIds.length != 0) {
                for (var i = 0; i < controlIds.length; i++) {
                    index = i;
                    controlEle = $("#" + controlIds[i]);
                    controlInstance = $("#" + controlIds[i]).data();
                    widget = controlInstance["ejWidgets"];
                    controlObject = $(controlEle).data(widget[0]);
                    locale.push({ id: controlObject._id, locale: controlObject.model.locale });
                    if (!ej.isNullOrUndefined(controlObject)) {
                        modelClone = controlObject._getExportModel(controlObject.model);
                        inputAttr.push({ name: widget[0], type: 'hidden', value: controlObject.stringify(modelClone) });
                        var input = ej.buildTag('input', "", null, inputAttr[index]);
                        form.append(input);
                    }
                }
                $('body').append(form);
                form.submit();
                setTimeout(function () {
                    var ctrlInstance, ctrlObject;
                    if (locale.length) {
                        for (var j = 0; j < locale.length; j++) {
                            if (!ej.isNullOrUndefined(locale[j].locale)) {
                                ctrlInstance = $("#" + locale[j].id).data();
                                widget = ctrlInstance["ejWidgets"];
                                ctrlObject = $("#" + locale[j].id).data(widget[0]);
                                ctrlObject.model.locale = locale[j].locale;
                            }
                        }
                    }
                }, 0);
                form.remove();
            }
            return true;
        },
        print: function (element, printWin) {
            var $div = ej.buildTag('div')
            var elementClone = element.clone();
            $div.append(elementClone);
            if (!printWin)
                var printWin = window.open('', 'print', "height=452,width=1024,tabbar=no");
            printWin.document.write('<!DOCTYPE html>');
            var links = $('head').find('link').add("style");
            if (ej.browserInfo().name === "msie") {
                var a = ""
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.write('<html><head></head><body>' + a + $div[0].innerHTML + '</body></html>');
            }
            else {
                var a = ""
                printWin.document.write('<html><head>')
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.writeln(a + '</head><body>')
                printWin.document.writeln($div[0].innerHTML + '</body></html>')
            }
            printWin.document.close();
            printWin.focus();
            setTimeout(function () {
                if (!ej.isNullOrUndefined(printWin.window)) {
                    printWin.print();
                    setTimeout(function () { printWin.close() }, 1000);
                }
            }, 1000);
        },
        ieClearRemover: function (element) {
            var searchBoxHeight = $(element).height();
            element.style.paddingTop = parseFloat(searchBoxHeight / 2) + "px";
            element.style.paddingBottom = parseFloat(searchBoxHeight / 2) + "px";
            element.style.height = "1px";
            element.style.lineHeight = "1px";
        },
        //To send ajax request
        sendAjaxRequest: function (ajaxOptions) {
            $.ajax({
                type: ajaxOptions.type,
                cache: ajaxOptions.cache,
                url: ajaxOptions.url,
                dataType: ajaxOptions.dataType,
                data: ajaxOptions.data,
                contentType: ajaxOptions.contentType,
                async: ajaxOptions.async,
                success: ajaxOptions.successHandler,
                error: ajaxOptions.errorHandler,
                beforeSend: ajaxOptions.beforeSendHandler,
                complete: ajaxOptions.completeHandler
            });
        },

        buildTag: function (tag, innerHtml, styles, attrs) {
            /// <summary>Helper to build jQuery element</summary>
            /// <param name="tag" type="String">tagName#id.cssClass</param>
            /// <param name="innerHtml" type="String"></param>
            /// <param name="styles" type="Object">A set of key/value pairs that configure styles</param>
            /// <param name="attrs" type="Object">A set of key/value pairs that configure attributes</param>
            /// <returns type="jQuery"></returns>
            var tagName = /^[a-z]*[0-9a-z]+/ig.exec(tag)[0];

           var id = /#([_a-z0-9-&@\/\\,+()$~%:*?<>{}\[\]]+\S)/ig.exec(tag);
            id = id ? id[id.length - 1].replace(/[&@\/\\,+()$~%.:*?<>{}\[\]]/g, ''): undefined;

            var className = /\.([a-z]+[-_0-9a-z ]+)/ig.exec(tag);
            className = className ? className[className.length - 1] : undefined;

            return $(document.createElement(tagName))
                .attr(id ? { "id": id } : {})
                .addClass(className || "")
                .css(styles || {})
                .attr(attrs || {})
                .html(innerHtml || "");
        },
        _preventDefaultException: function (el, exceptions) {
            if (el) {
                for (var i in exceptions) {
                    if (exceptions[i].test(el[i])) {
                        return true;
                    }
                }
            }

            return false;
        },

        //Gets the maximum z-index in the document
        getMaxZindex: function () {
            var maxZ = 1;
            maxZ = Math.max.apply(null, $.map($('body *'), function (e, n) {
                if ($(e).css('position') == 'absolute' || $(e).css('position') == 'fixed')
                    return parseInt($(e).css('z-index')) || 1;
            })
            );
            if (maxZ == undefined || maxZ == null)
                maxZ = 1;
            return maxZ;
        },

        //To prevent default actions for the element
        blockDefaultActions: function (e) {
            e.cancelBubble = true;
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
            if (e.stopPropagation) e.stopPropagation();
        },

        //To get dimensions of the element when its hidden
        getDimension: function (element, method) {
            var value;
            var $hidden = $(element).parents().andSelf().filter(':hidden');
            if ($hidden) {
                var prop = { visibility: 'hidden', display: 'block' };
                var tmp = [];
                $hidden.each(function () {
                    var temp = {}, name;
                    for (name in prop) {
                        temp[name] = this.style[name];
                        this.style[name] = prop[name];
                    }
                    tmp.push(temp);
                });
                value = /(outer)/g.test(method) ?
                $(element)[method](true) :
               $(element)[method]();

                $hidden.each(function (i) {
                    var temp = tmp[i], name;
                    for (name in prop) {
                        this.style[name] = temp[name];
                    }
                });
            }
            return value;
        },
        //Get triggers when transition End
        transitionEndEvent: function () {
            var transitionEnd = {
                '': 'transitionend',
                'webkit': 'webkitTransitionEnd',
                'Moz': 'transitionend',
                'O': 'otransitionend',
                'ms': 'MSTransitionEnd'
            };

            return transitionEnd[ej.userAgent()];
        },
        //Get triggers when transition End
        animationEndEvent: function () {
            var animationEnd = {
                '': 'animationend',
                'webkit': 'webkitAnimationEnd',
                'Moz': 'animationend',
                'O': 'webkitAnimationEnd',
                'ms': 'animationend'
            };

            return animationEnd[ej.userAgent()];
        },
        //To return the start event to bind for element
        startEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchstart" : "mousedown";
        },
        //To return end event to bind for element
        endEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchend" : "mouseup"
        },
        //To return move event to bind for element
        moveEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? ($.support.hasPointer && !ej.isMobile()) ? "ejtouchmove" : "touchmove" : "mousemove";
        },
        //To return cancel event to bind for element
        cancelEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchcancel" : "mousecancel";
        },
        //To return tap event to bind for element
        tapEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "tap" : "click";
        },
        //To return tap hold event to bind for element
        tapHoldEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "taphold" : "click";
        },
        //To check whether its Device
        isDevice: function () {
            if (ej.getBooleanVal($('head'), 'data-ej-forceset', false))
                return ej.getBooleanVal($('head'), 'data-ej-device', this._device());
            else
                return this._device();
        },
        //To check whether its portrait or landscape mode
        isPortrait: function () {
            var elem = document.documentElement;
            return (elem) && ((elem.clientWidth / elem.clientHeight) < 1.1);
        },
        //To check whether its in lower resolution
        isLowerResolution: function () {
            return ((window.innerWidth <= 640 && ej.isPortrait() && ej.isDevice()) || (window.innerWidth <= 800 && !ej.isDevice()) || (window.innerWidth <= 800 && !ej.isPortrait() && ej.isWindows() && ej.isDevice()) || ej.isMobile());
        },
        //To check whether its iOS web view
        isIOSWebView: function () {
            return (/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(navigator.userAgent));
        },
        //To check whether its Android web view
        isAndroidWebView: function () {
            return (!(typeof (Android) === "undefined"));
        },
        //To check whether its windows web view
        isWindowsWebView: function () {
            return location.href.indexOf("x-wmapp") != -1;
        },
        _device: function () {
            return (/Android|BlackBerry|iPhone|iPad|iPod|IEMobile|kindle|windows\sce|palm|smartphone|iemobile|mobile|pad|xoom|sch-i800|playbook/i.test(navigator.userAgent.toLowerCase()));
        },
        //To check whether its Mobile
        isMobile: function () {
            return ((/iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/i.test(navigator.userAgent.toLowerCase()) && /mobile/i.test(navigator.userAgent.toLowerCase()))) || (ej.getBooleanVal($('head'), 'data-ej-mobile', false) === true);
        },
        //To check whether its Tablet
        isTablet: function () {
            return (/ipad|xoom|sch-i800|playbook|tablet|kindle/i.test(navigator.userAgent.toLowerCase())) || (ej.getBooleanVal($('head'), 'data-ej-tablet', false) === true) || (!ej.isMobile() && ej.isDevice());
        },
        //To check whether its Touch Device
        isTouchDevice: function () {
            return (('ontouchstart' in window || (window.navigator.msPointerEnabled && ej.isMobile())) && this.isDevice());
        },
        //To get the outerHTML string for object
        getClearString: function (string) {
            return $.trim(string.replace(/\s+/g, " ").replace(/(\r\n|\n|\r)/gm, "").replace(new RegExp("\>[\n\t ]+\<", "g"), "><"));
        },
        //Get the attribute value with boolean type of element
        getBooleanVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value.toLowerCase() == "true";
            else
                return option;
        },
        //Gets the Skew class based on the element current position
        _getSkewClass: function (item, pageX, pageY) {
            var itemwidth = item.width();
            var itemheight = item.height();
            var leftOffset = item.offset().left;
            var rightOffset = item.offset().left + itemwidth;
            var topOffset = item.offset().top;
            var bottomOffset = item.offset().top + itemheight;
            var widthoffset = itemwidth * 0.3;
            var heightoffset = itemheight * 0.3;
            if (pageX < leftOffset + widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topleft";
            if (pageX > rightOffset - widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topright";
            if (pageX > rightOffset - widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomright";
            if (pageX < leftOffset + widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomleft";
            if (pageX > leftOffset + widthoffset && pageY < topOffset + heightoffset && pageX < rightOffset - widthoffset)
                return "e-m-skew-top";
            if (pageX < leftOffset + widthoffset)
                return "e-m-skew-left";
            if (pageX > rightOffset - widthoffset)
                return "e-m-skew-right";
            if (pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottom";
            return "e-m-skew-center";
        },
        //Removes the added Skew class on the element
        _removeSkewClass: function (element) {
            $(element).removeClass("e-m-skew-top e-m-skew-bottom e-m-skew-left e-m-skew-right e-m-skew-topleft e-m-skew-topright e-m-skew-bottomleft e-m-skew-bottomright e-m-skew-center e-skew-top e-skew-bottom e-skew-left e-skew-right e-skew-topleft e-skew-topright e-skew-bottomleft e-skew-bottomright e-skew-center");
        },
        //Object.keys  method to support all the browser including IE8.
        _getObjectKeys: function (obj) {
            var i, keys = [];
            obj = Object.prototype.toString.call(obj) === Object.prototype.toString() ? obj : {};
            if (!Object.keys) {
                for (i in obj) {
                    if (obj.hasOwnProperty(i))
                        keys.push(i);
                }
                return keys;
            }
            if (Object.keys)
                return Object.keys(obj);
        },
        _touchStartPoints: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt;
                object._distX = 0;
                object._distY = 0;
                object._moved = false;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
            }
        },
        _isTouchMoved: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt,
                deltaX = point.pageX - object._pointX,
                deltaY = point.pageY - object._pointY,
                timestamp = Date.now(),
                newX, newY,
                absDistX, absDistY;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
                object._distX += deltaX;
                object._distY += deltaY;
                absDistX = Math.abs(object._distX);
                absDistY = Math.abs(object._distY);
                return !(absDistX < 5 && absDistY < 5);
            }
        },
        //To bind events for element
        listenEvents: function (selectors, eventTypes, handlers, remove, pluginObj, disableMouse) {
            for (var i = 0; i < selectors.length; i++) {
                ej.listenTouchEvent(selectors[i], eventTypes[i], handlers[i], remove, pluginObj, disableMouse);
            }
        },
        //To bind touch events for element
        listenTouchEvent: function (selector, eventType, handler, remove, pluginObj, disableMouse) {
            var event = remove ? "removeEventListener" : "addEventListener";
            var jqueryEvent = remove ? "off" : "on";
            var elements = $(selector);
            for (var i = 0; i < elements.length; i++) {
                var element = elements[i];
                switch (eventType) {
                    case "touchstart":
                        ej._bindEvent(element, event, eventType, handler, "mousedown", "MSPointerDown", "pointerdown", disableMouse);
                        break;
                    case "touchmove":
                        ej._bindEvent(element, event, eventType, handler, "mousemove", "MSPointerMove", "pointermove", disableMouse);
                        break;
                    case "touchend":
                        ej._bindEvent(element, event, eventType, handler, "mouseup", "MSPointerUp", "pointerup", disableMouse);
                        break;
                    case "touchcancel":
                        ej._bindEvent(element, event, eventType, handler, "mousecancel", "MSPointerCancel", "pointercancel", disableMouse);
                        break;
                    case "tap": case "taphold": case "ejtouchmove": case "click":
                        $(element)[jqueryEvent](eventType, handler);
                        break;
                    default:
                        if (ej.browserInfo().name == "msie" && ej.browserInfo().version < 9)
                            pluginObj["_on"]($(element), eventType, handler);
                        else
                            element[event](eventType, handler, true);
                        break;
                }
            }
        },
        //To bind events for element
        _bindEvent: function (element, event, eventType, handler, mouseEvent, pointerEvent, ie11pointerEvent, disableMouse) {
            if ($.support.hasPointer)
                element[event](window.navigator.pointerEnabled ? ie11pointerEvent : pointerEvent, handler, true);
            else
                element[event](eventType, handler, true);
        },
        _browser: function () {
            return (/webkit/i).test(navigator.appVersion) ? 'webkit' : (/firefox/i).test(navigator.userAgent) ? 'Moz' : (/trident/i).test(navigator.userAgent) ? 'ms' : 'opera' in window ? 'O' : '';
        },
        styles: document.createElement('div').style,
        /**
       * To get the userAgent Name     
       * @example             
       * &lt;script&gt;
       *       ej.userAgent();//return user agent name
       * &lt;/script&gt         
       * @memberof AppView
       * @instance
       */
        userAgent: function () {
            var agents = 'webkitT,t,MozT,msT,OT'.split(','),
            t,
            i = 0,
            l = agents.length;

            for (; i < l; i++) {
                t = agents[i] + 'ransform';
                if (t in ej.styles) {
                    return agents[i].substr(0, agents[i].length - 1);
                }
            }

            return false;
        },
        addPrefix: function (style) {
            if (ej.userAgent() === '') return style;

            style = style.charAt(0).toUpperCase() + style.substr(1);
            return ej.userAgent() + style;
        },
        //To Prevent Default Exception

        //To destroy the mobile widgets
        destroyWidgets: function (element) {
            var dataEl = $(element).find("[data-role *= ejm]");
            dataEl.each(function (index, element) {
                var $element = $(element);
                var plugin = $element.data("ejWidgets");
                if (plugin)
                    $element[plugin]("destroy");
            });
        },
        //Get the attribute value of element
        getAttrVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value;
            else
                return option;
        },

        // Get the offset value of element
        getOffset: function (ele) {
            var pos = {};
            var offsetObj = ele.offset() || { left: 0, top: 0 };
            $.extend(true, pos, offsetObj);
            if ($("body").css("position") != "static") {
                var bodyPos = $("body").offset();
                pos.left -= bodyPos.left;
                pos.top -= bodyPos.top;
            }
            return pos;
        },

        // Z-index calculation for the element
        getZindexPartial: function (element, popupEle) {
            if (!ej.isNullOrUndefined(element) && element.length > 0) {
                var parents = element.parents(), bodyEle;
                bodyEle = $('body').children();
                if (!ej.isNullOrUndefined(element) && element.length > 0)
                    bodyEle.splice(bodyEle.index(popupEle), 1);
                $(bodyEle).each(function (i, ele) { parents.push(ele); });

                var maxZ = Math.max.apply(maxZ, $.map(parents, function (e, n) {
                    if ($(e).css('position') != 'static') return parseInt($(e).css('z-index')) || 1;
                }));
                if (!maxZ || maxZ < 10000) maxZ = 10000;
                else maxZ += 1;
                return maxZ;
            }
        },

        isValidAttr: function (element, attribute) {
            var element = $(element)[0];
            if (typeof element[attribute] != "undefined")
                return true;
            else {
                var _isValid = false;
                $.each(element, function (key) {
                    if (key.toLowerCase() == attribute.toLowerCase()) {
                        _isValid = true;
                        return false;
                    }
                });
            }
            return _isValid;
        }

    };

    $.extend(ej, ej.util);

    // base class for all ej widgets. It will automatically inhertied
    ej.widgetBase = {
        droppables: { 'default': [] },
        resizables: { 'default': [] },

        _renderEjTemplate: function (selector, data, index, prop, ngTemplateType) {
            var type = null;
            if (typeof selector === "object" || selector.startsWith("#") || selector.startsWith("."))
                type = $(selector).attr("type");
            if (type) {
                type = type.toLowerCase();
                if (ej.template[type])
                    return ej.template[type](this, selector, data, index, prop);
            }
            // For ejGrid Angular2 Template Support
            else if (!ej.isNullOrUndefined(ngTemplateType))
                 return ej.template['text/x-'+ ngTemplateType](this, selector, data, index, prop);
            return ej.template.render(this, selector, data, index, prop);
        },

        destroy: function () {

            if (this._trigger("destroy"))
                return;

            if (this.model.enablePersistence) {
                this.persistState();
                $(window).off("unload", this._persistHandler);
            }

            try {
                this._destroy();
            } catch (e) { }

            var arr = this.element.data("ejWidgets") || [];
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] == this.pluginName) {
                    arr.splice(i, 1);
                }
            }
            if (!arr.length)
                this.element.removeData("ejWidgets");

            while (this._events) {
                var item = this._events.pop(), args = [];

                if (!item)
                    break;

                for (var i = 0; i < item[1].length; i++)
                    if (!$.isPlainObject(item[1][i]))
                        args.push(item[1][i]);

                $.fn.off.apply(item[0], args);
            }

            this._events = null;

            this.element
                .removeClass(ej.util.getNameSpace(this.sfType))
                .removeClass("e-js")
                .removeData(this.pluginName);

            this.element = null;
            this.model = null;
        },

        _on: function (element) {
            if (!this._events)
                this._events = [];
            var args = [].splice.call(arguments, 1, arguments.length - 1);

            var handler = {}, i = args.length;
            while (handler && typeof handler !== "function") {
                handler = args[--i];
            }

            args[i] = ej.proxy(args[i], this);

            this._events.push([element, args, handler, args[i]]);

            $.fn.on.apply(element, args);

            return this;
        },

        _off: function (element, eventName, selector, handlerObject) {
            var e = this._events, temp;
            if (!e || !e.length)
                return this;
            if (typeof selector == "function") {
                temp = handlerObject;
                handlerObject = selector;
                selector = temp;
            }
            var t = (eventName.match(/\S+/g) || [""]);
            for (var i = 0; i < e.length; i++) {
                var arg = e[i],
                r = arg[0].length && (!handlerObject || arg[2] === handlerObject) && (arg[1][0] === eventName || t[0]) && (!selector || arg[1][1] === selector) && $.inArray(element[0], arg[0]) > -1;
                if (r) {
                    $.fn.off.apply(element, handlerObject ? [eventName, selector, arg[3]] : [eventName, selector]);
                    e.splice(i, 1);
                    break;
                }
            }

            return this;
        },

        // Client side events wire-up / trigger helper.
        _trigger: function (eventName, eventProp) {
            var fn = null, returnValue, args, clientProp = {};
            $.extend(clientProp, eventProp)

            if (eventName in this.model)
                fn = this.model[eventName];

            if (fn) {
                if (typeof fn === "string") {
                    fn = ej.util.getObject(fn, window);
                }

                if ($.isFunction(fn)) {

                    args = ej.event(eventName, this.model, eventProp);

                    
                    returnValue = fn.call(this, args);

                    // sending changes back - deep copy option should not be enabled for this $.extend 
                    if (eventProp) $.extend(eventProp, args);

                    if (args.cancel || !ej.isNullOrUndefined(returnValue))
                        return returnValue === false || args.cancel;
                }
            }

            var isPropDefined = Boolean(eventProp);
            eventProp = eventProp || {};
            eventProp.originalEventType = eventName;
            eventProp.type = this.pluginName + eventName;

            args = $.Event(eventProp.type, ej.event(eventProp.type, this.model, eventProp));

            this.element && this.element.trigger(args);

            // sending changes back - deep copy option should not be enabled for this $.extend 
            if (isPropDefined) $.extend(eventProp, args);

            if (ej.isOnWebForms && args.cancel == false && this.model.serverEvents && this.model.serverEvents.length)
                ej.raiseWebFormsServerEvents(eventName, eventProp, clientProp);

            return args.cancel;
        },

        setModel: function (options, forceSet) {
            // check for whether to apply values are not. if _setModel function is defined in child,
            //  this will call that function and validate it using return value

            if (this._trigger("modelChange", { "changes": options }))
                return;

            for (var prop in options) {
                if (!forceSet) {
                    if (this.model[prop] === options[prop]) {
                        delete options[prop];
                        continue;
                    }
                    if ($.isPlainObject(options[prop])) {
                        iterateAndRemoveProps(this.model[prop], options[prop]);
                        if ($.isEmptyObject(options[prop])) {
                            delete options[prop];
                            continue;
                        }
                    }
                }

                if (this.dataTypes) {
                    var returnValue = this._isValidModelValue(prop, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + prop + " - " + returnValue;
                }
                if (this.model.notifyOnEachPropertyChanges && this.model[prop] !== options[prop]) {
                    var arg = {
                        oldValue: this.model[prop],
                        newValue: options[prop]
                    };

                    options[prop] = this._trigger(prop + "Change", arg) ? this.model[prop] : arg.newValue;
                }
            }
            if ($.isEmptyObject(options))
                return;

            if (this._setFirst) {
                var ds = options.dataSource;
                if (ds) delete options.dataSource;

                $.extend(true, this.model, options);
                if (ds) {
                    this.model.dataSource = (ds instanceof Array) ? ds.slice() : ds;
                    options["dataSource"] = this.model.dataSource;
                }
                !this._setModel || this._setModel(options);

            } else if (!this._setModel || this._setModel(options) !== false) {
                $.extend(true, this.model, options);
            }
            if ("enablePersistence" in options) {
                this._setState(options.enablePersistence);
            }
        },
        option: function (prop, value, forceSet) {
            if (!prop)
                return this.model;

            if ($.isPlainObject(prop))
                return this.setModel(prop, forceSet);

            if (typeof prop === "string") {
                prop = prop.replace(/^model\./, "");
                var oldValue = ej.getObject(prop, this.model);

                if (value === undefined && !forceSet)
                    return oldValue;

                if (prop === "enablePersistence")
                    return this._setState(value);

                if (forceSet && value === ej.extensions.modelGUID) {
                    return this._setModel(ej.createObject(prop, ej.getObject(prop, this.model), {}));
                }

                if (forceSet || ej.getObject(prop, this.model) !== value)
                    return this.setModel(ej.createObject(prop, value, {}), forceSet);
            }
            return undefined;
        },

        _isValidModelValue: function (prop, types, options) {
            var value = types[prop], option = options[prop], returnValue;

            if (!value)
                return true;

            if (typeof value === "string") {
                if (value == "enum") {
                    options[prop] = option ? option.toString().toLowerCase() : option;
                    value = "string";
                }

                if (value === "array") {
                    if (Object.prototype.toString.call(option) === '[object Array]')
                        return true;
                }
                else if (value === "data") {
                    return true;
                }
                else if (value === "parent") {
                    return true;
                }
                else if (typeof option === value)
                    return true;

                return "Expected type - " + value;
            }

            if (option instanceof Array) {
                for (var i = 0; i < option.length; i++) {
                    returnValue = this._isValidModelValue(prop, types, option[i]);
                    if (returnValue !== true) {
                        return " [" + i + "] - " + returnValue;
                    }
                }
                return true;
            }

            for (var innerProp in option) {
                returnValue = this._isValidModelValue(innerProp, value, option);
                if (returnValue !== true)
                    return innerProp + " : " + returnValue;
            }

            return true;
        },

        _returnFn: function (obj, propName) {
            if (propName.indexOf('.') != -1) {
                this._returnFn(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
            }
            else
                obj[propName] = obj[propName].call(obj.propName);
        },

        _removeCircularRef: function (obj) {
            var seen = [];
            function detect(obj, key, parent) {
                if (typeof obj != 'object') { return; }
                if (!Array.prototype.indexOf) {
                    Array.prototype.indexOf = function (val) {
                        return jQuery.inArray(val, this);
                    };
                }
                if (seen.indexOf(obj) >= 0) {
                    delete parent[key];
                    return;
                }
                seen.push(obj);
                for (var k in obj) { //dive on the object's children
                    if (obj.hasOwnProperty(k)) { detect(obj[k], k, obj); }
                }
                seen.pop();
                return;
            }
            detect(obj, 'obj', null);
            return obj;
        },

        stringify: function (model, removeCircular) {
            var observables = this.observables;
            for (var k = 0; k < observables.length; k++) {
                var val = ej.getObject(observables[k], model);
                if (!ej.isNullOrUndefined(val) && typeof (val) === "function")
                    this._returnFn(model, observables[k]);
            }
            if (removeCircular) model = this._removeCircularRef(model);
            return JSON.stringify(model);
        },

        _setState: function (val) {
            if (val === true) {
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
            } else {
                this.deleteState();
                $(window).off("unload", this._persistHandler);
            }
        },

        _removeProp: function (obj, propName) {
            if (!ej.isNullOrUndefined(obj)) {
                if (propName.indexOf('.') != -1) {
                    this._removeProp(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
                }
                else
                    delete obj[propName];
            }
        },

        persistState: function () {
            var model;

            if (this._ignoreOnPersist) {
                model = copyObject({}, this.model);
                for (var i = 0; i < this._ignoreOnPersist.length; i++) {
                    this._removeProp(model, this._ignoreOnPersist[i]);
                }
                model.ignoreOnPersist = this._ignoreOnPersist;
            } else if (this._addToPersist) {
                model = {};
                for (var i = 0; i < this._addToPersist.length; i++) {
                    ej.createObject(this._addToPersist[i], ej.getObject(this._addToPersist[i], this.model), model);
                }
                model.addToPersist = this._addToPersist;
            } else {
                model = copyObject({}, this.model);
            }

            if (this._persistState) {
                model.customPersists = {};
                this._persistState(model.customPersists);
            }

            if (window.localStorage) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") == null)
                    window.localStorage.setItem("persistKey", ej.persistStateVersion);
                window.localStorage.setItem("$ej$" + this.pluginName + this._id, JSON.stringify(model));
            }
            else if (document.cookie) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") == null)
                    ej.cookie.set("persistKey", ej.persistStateVersion);
                ej.cookie.set("$ej$" + this.pluginName + this._id, model);
            }
        },

        deleteState: function () {
            if (window.localStorage)
                window.localStorage.removeItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                ej.cookie.set("$ej$" + this.pluginName + this._id, model, new Date());
        },

        restoreState: function (silent) {
            var value = null;
            if (window.localStorage)
                value = window.localStorage.getItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                value = ej.cookie.get("$ej$" + this.pluginName + this._id);

            if (value) {
                var model = JSON.parse(value);

                if (this._restoreState) {
                    this._restoreState(model.customPersists);
                    delete model.customPersists;
                }

                if (ej.isNullOrUndefined(model) === false)
                    if (!ej.isNullOrUndefined(model.ignoreOnPersist)) {
                        this._ignoreOnPersist = model.ignoreOnPersist;
                        delete model.ignoreOnPersist;
                    } else if (!ej.isNullOrUndefined(model.addToPersist)) {
                        this._addToPersist = model.addToPersist;
                        delete model.addToPersist;
                    }
            }
            if (!ej.isNullOrUndefined(model) && !ej.isNullOrUndefined(this._ignoreOnPersist)) {
                for(var i = 0, len =  this._ignoreOnPersist.length; i < len; i++) {
					if (this._ignoreOnPersist[i].indexOf('.') !== -1)
                        ej.createObject(this._ignoreOnPersist[i], ej.getObject(this._ignoreOnPersist[i], this.model), model);
                    else
                        model[this._ignoreOnPersist[i]] = this.model[this._ignoreOnPersist[i]];
				}
                this.model = model;
            }
            else
                this.model = $.extend(true, this.model, model);

            if (!silent && value && this._setModel)
                this._setModel(this.model);
        },

        //to prevent persistence
        ignoreOnPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    this._ignoreOnPersist.push(collection[i]);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    var index = this._addToPersist.indexOf(collection[i]);
                    this._addToPersist.splice(index, 1);
                }
            }
        },

        //to maintain persistence
        addToPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    var index = this._ignoreOnPersist.indexOf(collection[i]);
                    this._ignoreOnPersist.splice(index, 1);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    if ($.inArray(collection[i], this._addToPersist) === -1)
                        this._addToPersist.push(collection[i]);
                }
            }
        },

        // Get formatted text 
        formatting: function (formatstring, str, locale) {
            formatstring = formatstring.replace(/%280/g, "\"").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
            locale = ej.preferredCulture(locale) ? locale : "en-US";
            var s = formatstring;
            var frontHtmlidx, FrontHtml, RearHtml, lastidxval;
            frontHtmlidx = formatstring.split("{0:");
            lastidxval = formatstring.split("}");
            FrontHtml = frontHtmlidx[0];
            RearHtml = lastidxval[1];
            if (typeof (str) == "string" && $.isNumeric(str))
                str = Number(str);
            if (formatstring.indexOf("{0:") != -1) {
                var toformat = new RegExp("\\{0(:([^\\}]+))?\\}", "gm");
                var formatVal = toformat.exec(formatstring);
                if (formatVal != null && str != null) {
                    if (FrontHtml != null && RearHtml != null)
                        str = FrontHtml + ej.format(str, formatVal[2], locale) + RearHtml;
                    else
                        str = ej.format(str, formatVal[2], locale);
                } else if (str != null)
                    str = str;
                else
                    str = "";
                return str;
            } else if (s.startsWith("{") && !s.startsWith("{0:")) {
                var fVal = s.split(""), str = (str || "") + "", strSplt = str.split(""), formats = /[0aA\*CN<>\?]/gm;
                for (var f = 0, f, val = 0; f < fVal.length; f++)
                    fVal[f] = formats.test(fVal[f]) ? "{" + val++ + "}" : fVal[f];
                return String.format.apply(String, [fVal.join("")].concat(strSplt)).replace('{', '').replace('}', '');
            } else if (this.data != null && this.data.Value == null) {
                $.each(this.data, function (dataIndex, dataValue) {
                    s = s.replace(new RegExp('\\{' + dataIndex + '\\}', 'gm'), dataValue);
                });
                return s;
            } else {
                return this.data.Value;
            }
        },
    };

    ej.WidgetBase = function () {
    }

    var iterateAndRemoveProps = function (source, target) {
		if(source instanceof Array) {
			for (var i = 0, len = source.length; i < len; i++) {
				prop = source[i];
				if(prop === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(prop))
					iterateAndRemoveProps(prop, target[prop]);
			}
		}
		else {
			for (var prop in source) {
				if (source[prop] === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(source[prop]))
					iterateAndRemoveProps(source[prop], target[prop]);
			}
		}
    }

    ej.widget = function (pluginName, className, proto) {
        /// <summary>Widget helper for developers, this set have predefined function to jQuery plug-ins</summary>
        /// <param name="pluginName" type="String">the plugin name that will be added in jquery.fn</param>
        /// <param name="className" type="String">the class name for your plugin, this will help create default cssClas</param>
        /// <param name="proto" type="Object">prototype for of the plug-in</param>

        if (typeof pluginName === "object") {
            proto = className;
            for (var prop in pluginName) {
                var name = pluginName[prop];

                if (name instanceof Array) {
                    proto._rootCSS = name[1];
                    name = name[0];
                }

                ej.widget(prop, name, proto);

                if (pluginName[prop] instanceof Array)
                    proto._rootCSS = "";
            }

            return;
        }

        var nameSpace = proto._rootCSS || ej.getNameSpace(className);

        proto = ej.defineClass(className, function (element, options) {

            this.sfType = className;
            this.pluginName = pluginName;
            this.instance = pInstance;

            if (ej.isNullOrUndefined(this._setFirst))
                this._setFirst = true;

            this["ob.values"] = {};

            $.extend(this, ej.widgetBase);

            if (this.dataTypes) {
                for (var property in options) {
                    var returnValue = this._isValidModelValue(property, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + property + " - " + returnValue;
                }
            }

            var arr = (element.data("ejWidgets") || []);
            arr.push(pluginName);
            element.data("ejWidgets", arr);

            for (var i = 0; ej.widget.observables && this.observables && i < this.observables.length; i++) {
                var t = ej.getObject(this.observables[i], options);
                if (t) ej.createObject(this.observables[i], ej.widget.observables.register(t, this.observables[i], this, element), options);
            }

            this.element = element.jquery ? element : $(element);
            this.model = copyObject(true, {}, proto.prototype.defaults, options);
            this.model.keyConfigs = copyObject(this.keyConfigs);

            this.element.addClass(nameSpace + " e-js").data(pluginName, this);

            this._id = element[0].id;

            if (this.model.enablePersistence) {
                if (window.localStorage && !ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") != ej.persistStateVersion) {
                    for (var i in window.localStorage) {
                        if (i.indexOf("$ej$") != -1) {
                            window.localStorage.removeItem(i); //removing the previously stored plugin item from local storage
							window.localStorage.setItem("persistKey", ej.persistStateVersion);
						}				
                    }
                }
                else if (document.cookie && !ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") != ej.persistStateVersion) {
                    var splits = document.cookie.split(/; */);
                    for (var k in splits) {
                        if (k.indexOf("$ej$") != -1) {
                            ej.cookie.set(k.split("=")[0], model, new Date()); //removing the previously stored plugin item from local storage
							ej.cookie.set("persistKey", ej.persistStateVersion);
						}		
                    }
                }
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
                this.restoreState(true);
            }

            this._init(options);

            if (typeof this.model.keyConfigs === "object" && !(this.model.keyConfigs instanceof Array)) {
                var requiresEvt = false;
                if (this.model.keyConfigs.focus)
                    this.element.attr("accesskey", this.model.keyConfigs.focus);

                for (var keyProps in this.model.keyConfigs) {
                    if (keyProps !== "focus") {
                        requiresEvt = true;
                        break;
                    }
                }

                if (requiresEvt && this._keyPressed) {
                    var el = element, evt = "keydown";

                    if (this.keySettings) {
                        el = this.keySettings.getElement ? this.keySettings.getElement() || el : el;
                        evt = this.keySettings.event || evt;
                    }

                    this._on(el, evt, function (e) {
                        if (!this.model.keyConfigs) return;

                        var action = keyFn.getActionFromCode(this.model.keyConfigs, e.which, e.ctrlKey, e.shiftKey, e.altKey);
                        var arg = {
                            code: e.which,
                            ctrl: e.ctrlKey,
                            alt: e.altKey,
                            shift: e.shiftKey
                        };
                        if (!action) return;

                        if (this._keyPressed(action, e.target, arg, e) === false)
                            e.preventDefault();
                    });
                }
            }
            this._trigger("create");
        }, proto);

        $.fn[pluginName] = function (options) {
            var opt = options, args;
            for (var i = 0; i < this.length; i++) {

                var $this = $(this[i]),
                    pluginObj = $this.data(pluginName),
                    isAlreadyExists = pluginObj && $this.hasClass(nameSpace),
                    obj = null;

                if (this.length > 0 && $.isPlainObject(opt))
                    options = ej.copyObject({}, opt);

                // ----- plug-in creation/init
                if (!isAlreadyExists) {
                    if (proto.prototype._requiresID === true && !$(this[i]).attr("id")) {
                        $this.attr("id", getUid("ejControl_"));
                    }
                    if (!options || typeof options === "object") {
                        if (proto.prototype.defaults && !ej.isNullOrUndefined(ej.setCulture) && "locale" in proto.prototype.defaults && pluginName != "ejChart") {
                            if (options && !("locale" in options)) options.locale = ej.setCulture().name;
                            else if (ej.isNullOrUndefined(options)) {
                                options = {}; options.locale = ej.setCulture().name;
                            }
                        }
                        new proto($this, options);
                    }
                    else {
                        throwError(pluginName + ": methods/properties can be accessed only after plugin creation");
                    }
                    continue;
                }

                if (!options) continue;

                args = [].slice.call(arguments, 1);

                if (this.length > 0 && args[0] && opt === "option" && $.isPlainObject(args[0])) {
                    args[0] = ej.copyObject({}, args[0]);
                }

                // --- Function/property set/access
                if ($.isPlainObject(options)) {
                    // setModel using JSON object
                    pluginObj.setModel(options);
                }

                    // function/property name starts with "_" is private so ignore it.
                else if (options.indexOf('_') !== 0
                    && !ej.isNullOrUndefined(obj = ej.getObject(options, pluginObj))
                    || options.indexOf("model.") === 0) {

                    if (!obj || !$.isFunction(obj)) {

                        // if property is accessed, then break the jquery chain
                        if (arguments.length == 1)
                            return obj;

                        //setModel using string input
                        pluginObj.option(options, arguments[1]);

                        continue;
                    }

                    var value = obj.apply(pluginObj, args);

                    // If function call returns any value, then break the jquery chain
                    if (value !== undefined)
                        return value;

                } else {
                    throwError(className + ": function/property - " + options + " does not exist");
                }
            }
            if (pluginName.indexOf("ejm") != -1)
                ej.widget.registerInstance($this, pluginName, className, proto.prototype);
            // maintaining jquery chain
            return this;
        };

        ej.widget.register(pluginName, className, proto.prototype);
        ej.loadLocale(pluginName);
    };

    ej.loadLocale = function (pluginName) {
        var i, len, locales = ej.locales;
        for (i = 0, len = locales.length; i < len; i++)
            $.fn["Locale_" + locales[i]](pluginName);
    };


    $.extend(ej.widget, (function () {
        var _widgets = {}, _registeredInstances = [],

        register = function (pluginName, className, prototype) {
            if (!ej.isNullOrUndefined(_widgets[pluginName]))
                throwError("ej.widget : The widget named " + pluginName + " is trying to register twice.");

            _widgets[pluginName] = { name: pluginName, className: className, proto: prototype };

            ej.widget.extensions && ej.widget.extensions.registerWidget(pluginName);
        },
        registerInstance = function (element, pluginName, className, prototype) {
            _registeredInstances.push({ element: element, pluginName: pluginName, className: className, proto: prototype });
        }

        return {
            register: register,
            registerInstance: registerInstance,
            registeredWidgets: _widgets,
            registeredInstances: _registeredInstances
        };

    })());

    ej.widget.destroyAll = function (elements) {
        if (!elements || !elements.length) return;

        for (var i = 0; i < elements.length; i++) {
            var data = elements.eq(i).data(), wds = data["ejWidgets"];
            if (wds && wds.length) {
                for (var j = 0; j < wds.length; j++) {
                    if (data[wds[j]] && data[wds[j]].destroy)
                        data[wds[j]].destroy();
                }
            }
        }
    };

    ej.cookie = {
        get: function (name) {
            var value = RegExp(name + "=([^;]+)").exec(document.cookie);

            if (value && value.length > 1)
                return value[1];

            return undefined;
        },
        set: function (name, value, expiryDate) {
            if (typeof value === "object")
                value = JSON.stringify(value);

            value = escape(value) + ((expiryDate == null) ? "" : "; expires=" + expiryDate.toUTCString());
            document.cookie = name + "=" + value;
        }
    };

    var keyFn = {
        getActionFromCode: function (keyConfigs, keyCode, isCtrl, isShift, isAlt) {
            isCtrl = isCtrl || false;
            isShift = isShift || false;
            isAlt = isAlt || false;

            for (var keys in keyConfigs) {
                if (keys === "focus") continue;

                var key = keyFn.getKeyObject(keyConfigs[keys]);
                for (var i = 0; i < key.length; i++) {
                    if (keyCode === key[i].code && isCtrl == key[i].isCtrl && isShift == key[i].isShift && isAlt == key[i].isAlt)
                        return keys;
                }
            }
            return null;
        },
        getKeyObject: function (key) {
            var res = {
                isCtrl: false,
                isShift: false,
                isAlt: false
            };
            var tempRes = $.extend(true, {}, res);
            var $key = key.split(","), $res = [];
            for (var i = 0; i < $key.length; i++) {
                var rslt = null;
                if ($key[i].indexOf("+") != -1) {
                    var k = $key[i].split("+");
                    for (var j = 0; j < k.length; j++) {
                        rslt = keyFn.getResult($.trim(k[j]), res);
                    }
                }
                else {
                    rslt = keyFn.getResult($.trim($key[i]), $.extend(true, {}, tempRes));
                }
                $res.push(rslt);
            }
            return $res;
        },
        getResult: function (key, res) {
            if (key === "ctrl")
                res.isCtrl = true;
            else if (key === "shift")
                res.isShift = true;
            else if (key === "alt")
                res.isAlt = true;
            else res.code = parseInt(key, 10);
            return res;
        }
    };

    ej.getScrollableParents = function (element) {
        return $(element).parentsUntil("html").filter(function () {
            return $(this).css("overflow") != "visible";
        }).add($(window));
    }
    ej.browserInfo = function () {
        var browser = {}, clientInfo = [],
        browserClients = {
            opera: /(opera|opr)(?:.*version|)[ \/]([\w.]+)/i, edge: /(edge)(?:.*version|)[ \/]([\w.]+)/i, webkit: /(chrome)[ \/]([\w.]+)/i, safari: /(webkit)[ \/]([\w.]+)/i, msie: /(msie|trident) ([\w.]+)/i, mozilla: /(mozilla)(?:.*? rv:([\w.]+)|)/i
        };
        for (var client in browserClients) {
            if (browserClients.hasOwnProperty(client)) {
                clientInfo = navigator.userAgent.match(browserClients[client]);
                if (clientInfo) {
                    browser.name = clientInfo[1].toLowerCase() == "opr" ? "opera" : clientInfo[1].toLowerCase();
                    browser.version = clientInfo[2];
                    browser.culture = {};
                    browser.culture.name = browser.culture.language = navigator.language || navigator.userLanguage;
                    if (typeof (ej.globalize) != 'undefined') {
                        var oldCulture = ej.preferredCulture().name;
                        var culture = (navigator.language || navigator.userLanguage) ? ej.preferredCulture(navigator.language || navigator.userLanguage) : ej.preferredCulture("en-US");
                        for (var i = 0; (navigator.languages) && i < navigator.languages.length; i++) {
                            culture = ej.preferredCulture(navigator.languages[i]);
                            if (culture.language == navigator.languages[i])
                                break;
                        }
                        ej.preferredCulture(oldCulture);
                        $.extend(true, browser.culture, culture);
                    }
                    if (!!navigator.userAgent.match(/Trident\/7\./)) {
                        browser.name = "msie";
                    }
                    break;
                }
            }
        }
        browser.isMSPointerEnabled = (browser.name == 'msie') && browser.version > 9 && window.navigator.msPointerEnabled;
        browser.pointerEnabled = window.navigator.pointerEnabled;
        return browser;
    };
    ej.eventType = {
        mouseDown: "mousedown touchstart",
        mouseMove: "mousemove touchmove",
        mouseUp: "mouseup touchend",
        mouseLeave: "mouseleave touchcancel",
        click: "click touchend"
    };

    ej.event = function (type, data, eventProp) {

        var e = $.extend(eventProp || {},
            {
                "type": type,
                "model": data,
                "cancel": false
            });

        return e;
    };

    ej.proxy = function (fn, context, arg) {
        if (!fn || typeof fn !== "function")
            return null;

        if ('on' in fn && context)
            return arg ? fn.on(context, arg) : fn.on(context);

        return function () {
            var args = arg ? [arg] : []; args.push.apply(args, arguments);
            return fn.apply(context || this, args);
        };
    };

    ej.hasStyle = function (prop) {
        var style = document.documentElement.style;

        if (prop in style) return true;

        var prefixs = ['ms', 'Moz', 'Webkit', 'O', 'Khtml'];

        prop = prop[0].toUpperCase() + prop.slice(1);

        for (var i = 0; i < prefixs.length; i++) {
            if (prefixs[i] + prop in style)
                return true;
        }

        return false;
    };

    Array.prototype.indexOf = Array.prototype.indexOf || function (searchElement) {
        var len = this.length;

        if (len === 0) return -1;

        for (var i = 0; i < len; i++) {
            if (i in this && this[i] === searchElement)
                return i;
        }
        return -1;
    };

    String.prototype.startsWith = String.prototype.startsWith || function (key) {
        return this.slice(0, key.length) === key;
    };
    var copyObject = ej.copyObject = function (isDeepCopy, target) {
        var start = 2, current, source;
        if (typeof isDeepCopy !== "boolean") {
            start = 1;
        }
        var objects = [].slice.call(arguments, start);
        if (start === 1) {
            target = isDeepCopy;
            isDeepCopy = undefined;
        }

        for (var i = 0; i < objects.length; i++) {
            for (var prop in objects[i]) {
                current = target[prop], source = objects[i][prop];

                if (source === undefined || current === source || objects[i] === source || target === source)
                    continue;
                if (source instanceof Array) {
                    if (i === 0 && isDeepCopy) {
                        if (prop === "dataSource" || prop === "data" || prop === "predicates")
                            target[prop] = source.slice();
					  else  {
                        target[prop] = new Array();
                        for (var j = 0; j < source.length; j++) {
                            copyObject(true, target[prop], source);
                        }
					  }
                    }
                    else
                        target[prop] = source.slice();
                }
                else if (ej.isPlainObject(source)) {
                    target[prop] = current || {};
                    if (isDeepCopy)
                        copyObject(isDeepCopy, target[prop], source);
                    else
                        copyObject(target[prop], source);
                } else
                    target[prop] = source;
            }
        }
        return target;
    };
    var pInstance = function () {
        return this;
    }

    var _uid = 0;
    var getUid = function (prefix) {
        return prefix + _uid++;
    }

    ej.template = {};

    ej.template.render = ej.template["text/x-jsrender"] = function (self, selector, data, index, prop) {
        if (selector.slice(0, 1) !== "#")
            selector = ["<div>", selector, "</div>"].join("");
        var property = { prop: prop, index: index };
        return $(selector).render(data, property);
    }

    ej.isPlainObject = function (obj) {
        if (!obj) return false;
        if (ej.DataManager !== undefined && obj instanceof ej.DataManager) return false;
        if (typeof obj !== "object" || obj.nodeType || jQuery.isWindow(obj)) return false;
        try {
            if (obj.constructor &&
                !obj.constructor.prototype.hasOwnProperty("isPrototypeOf")) {
                return false;
            }
        } catch (e) {
            return false;
        }

        var key, ownLast = ej.support.isOwnLast;
        for (key in obj) {
            if (ownLast) break;
        }

        return key === undefined || obj.hasOwnProperty(key);
    };
    var getValueFn = false;
    ej.util.valueFunction = function (prop) {
        return function (value, getObservable) {
            var val = ej.getObject(prop, this.model);

            if (getValueFn === false)
                getValueFn = ej.getObject("observables.getValue", ej.widget);

            if (value === undefined) {
                if (!ej.isNullOrUndefined(getValueFn)) {
                    return getValueFn(val, getObservable);
                }
                return typeof val === "function" ? val.call(this) : val;
            }

            if (typeof val === "function") {
                this["ob.values"][prop] = value;
                val.call(this, value);
            }
            else
                ej.createObject(prop, value, this.model);
        }
    };
    ej.util.getVal = function (val) {
        if (typeof val === "function")
            return val();
        return val;
    };
    ej.support = {
        isOwnLast: function () {
            var fn = function () { this.a = 1; };
            fn.prototype.b = 1;

            for (var p in new fn()) {
                return p === "b";
            }
        }(),
        outerHTML: function () {
            return document.createElement("div").outerHTML !== undefined;
        }()
    };

    var throwError = ej.throwError = function (er) {
        try {
            throw new Error(er);
        } catch (e) {
            throw e.message + "\n" + e.stack;
        }
    };

    ej.getRandomValue = function (min, max) {
        if (min === undefined || max === undefined)
            return ej.throwError("Min and Max values are required for generating a random number");

        var rand;
        if ("crypto" in window && "getRandomValues" in crypto) {
            var arr = new Uint16Array(1);
            window.crypto.getRandomValues(arr);
            rand = arr[0] % (max - min) + min;
        }
        else rand = Math.random() * (max - min) + min;
        return rand | 0;
    }

    ej.extensions = {};
    ej.extensions.modelGUID = "{0B1051BA-1CCB-42C2-A3B5-635389B92A50}";
})(window.jQuery, window.Syncfusion);
(function () {
    $.fn.addEleAttrs = function (json) {
        var $this = $(this);
        $.each(json, function (i, attr) {
            if (attr && attr.specified) {
                $this.attr(attr.name, attr.value);
            }
        });

    };
    $.fn.removeEleAttrs = function (regex) {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && regex.test(attr.name)) {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.fn.attrNotStartsWith = function (regex) {
        var proxy = this;
        var attributes = [], attrs;
        this.each(function () {
            attrs = $(this.attributes).clone();
        });
        for (i = 0; i < attrs.length; i++) {
            if (attrs[i] && attrs[i].specified && regex.test(attrs[i].name)) {
                continue
            }
            else
                attributes.push(attrs[i])
        }
        return attributes;

    }
    $.fn.removeEleEmptyAttrs = function () {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && attr.value === "") {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.extend($.support, {
        has3d: ej.addPrefix('perspective') in ej.styles,
        hasTouch: 'ontouchstart' in window,
        hasPointer: navigator.msPointerEnabled,
        hasTransform: ej.userAgent() !== false,
        pushstate: "pushState" in history &&
        "replaceState" in history,
        hasTransition: ej.addPrefix('transition') in ej.styles
    });
    //Ensuring elements having attribute starts with 'ejm-' 
    $.extend($.expr[':'], {
        attrNotStartsWith: function (element, index, match) {
            var i, attrs = element.attributes;
            for (i = 0; i < attrs.length; i++) {
                if (attrs[i].nodeName.indexOf(match[3]) === 0) {
                    return false;
                }
            }
            return true;
        }
    });
    //addBack() is supported from Jquery >1.8 and andSelf() supports later version< 1.8. support for both the method is provided by extending the JQuery function.
    var oldSelf = $.fn.andSelf || $.fn.addBack;
    $.fn.andSelf = $.fn.addBack = function () {
        return oldSelf.apply(this, arguments);
    };
})();;
;
window.ej = window.Syncfusion = window.Syncfusion || {};

(function ($, ej, doc, undefined) {
    'use strict';

  
    ej.DataManager = function (dataSource, query, adaptor) {
          if (!(this instanceof ej.DataManager))
            return new ej.DataManager(dataSource, query, adaptor);

        if (!dataSource)
            dataSource = [];
        adaptor = adaptor || dataSource.adaptor;

        if (typeof (adaptor) === "string") 
            adaptor = new ej[adaptor]();
        var data = [], self = this;

        if (dataSource instanceof Array) {
            // JSON array
            data = {
                json: dataSource,
                offline: true
            };

        } else if (typeof dataSource === "object") {
            if ($.isPlainObject(dataSource)) {
                if (!dataSource.json)
                    dataSource.json = [];
                if (dataSource.table)
                    dataSource.json = this._getJsonFromElement(dataSource.table, dataSource.headerOption);
                data = {
                    url: dataSource.url,
                    insertUrl: dataSource.insertUrl,
                    removeUrl: dataSource.removeUrl,
                    updateUrl: dataSource.updateUrl,
                    crudUrl: dataSource.crudUrl,
                    batchUrl: dataSource.batchUrl,
                    json: dataSource.json,
                    headers: dataSource.headers,
                    accept: dataSource.accept,
                    data: dataSource.data,
					async : dataSource.async,
                    timeTillExpiration: dataSource.timeTillExpiration,
                    cachingPageSize: dataSource.cachingPageSize,
                    enableCaching: dataSource.enableCaching,
                    requestType: dataSource.requestType,
                    key: dataSource.key,
                    crossDomain: dataSource.crossDomain,
                    antiForgery: dataSource.antiForgery,
                    jsonp: dataSource.jsonp,
                    dataType: dataSource.dataType,
                    enableAjaxCache: dataSource.enableAjaxCache,
                    offline: dataSource.offline !== undefined ? dataSource.offline : dataSource.adaptor == "remoteSaveAdaptor" || dataSource.adaptor instanceof ej.remoteSaveAdaptor ? false : dataSource.url ? false : true,
                    requiresFormat: dataSource.requiresFormat
                };
            } else if (dataSource.jquery || isHtmlElement(dataSource)) {
                data = {
                    json: this._getJsonFromElement(dataSource),
                    offline: true,
                    table: dataSource
                };
            }
        } else if (typeof dataSource === "string") {
            data = {
                url: dataSource,
                offline: false,
                dataType: "json",
                json: []
            };
        }

        if (data.requiresFormat === undefined && !ej.support.cors)
            data.requiresFormat = isNull(data.crossDomain) ? true : data.crossDomain;
         if(data.antiForgery){
        this.antiForgeryToken();
        }
        if (data.dataType === undefined)
            data.dataType = "json";
        this.dataSource = data;
        this.defaultQuery = query;

        if (data.url && data.offline && !data.json.length) {
            this.isDataAvailable = false;
            this.adaptor = adaptor || new ej.ODataAdaptor();
            this.dataSource.offline = false;
            this.ready = this.executeQuery(query || ej.Query()).done(function (e) {
                self.dataSource.offline = true;
                self.isDataAvailable = true;
                data.json = e.result;
                self.adaptor = new ej.JsonAdaptor();
            });
        }
        else
            this.adaptor = data.offline ? new ej.JsonAdaptor() : new ej.ODataAdaptor();
        if (!data.jsonp && this.adaptor instanceof ej.ODataAdaptor)
            data.jsonp = "callback";
        this.adaptor = adaptor || this.adaptor;
        if (data.enableCaching)
            this.adaptor = new ej.CacheAdaptor(this.adaptor, data.timeTillExpiration, data.cachingPageSize);
        return this;
    };

    ej.DataManager.prototype = {
        setDefaultQuery: function (query) {
            this.defaultQuery = query;
        },
	
        executeQuery: function (query, done, fail, always) {
            if (typeof query === "function") {
                always = fail;
                fail = done;
                done = query;
                query = null;
            }

            if (!query)
                query = this.defaultQuery;

            if (!(query instanceof ej.Query))
                throwError("DataManager - executeQuery() : A query is required to execute");

            var deffered = $.Deferred();

            deffered.then(done, fail, always);
            var args = { query: query };

            if (!this.dataSource.offline && this.dataSource.url != undefined) {
				 var result = this.adaptor.processQuery(this, query);
                if (!ej.isNullOrUndefined(result.url))
                    this._makeRequest(result, deffered, args, query);
                else {
                    nextTick(function () {
                        args = this._getDeferedArgs(query, result, args);
                        deffered.resolveWith(this, [args]);;
                    }, this);
                }
            } else {
				if(!ej.isNullOrUndefined(this.dataSource.async) && this.dataSource.async == false)
					this._localQueryProcess(query, args, deffered);
				else{
					nextTick(function () {
						this._localQueryProcess(query, args, deffered);
					}, this);
				}
            }
            return deffered.promise();
        },
		_localQueryProcess: function(query, args, deffered){
			var res = this.executeLocal(query);
			args = this._getDeferedArgs(query, res, args);
			deffered.resolveWith(this, [args]);
		},
        _getDeferedArgs: function (query, result, args) {
            if (query._requiresCount) {
                args.result = result.result;
                args.count = result.count;
            } else
                args.result = result;
            args.getTableModel = getTableModel(query._fromTable, args.result, this);
            args.getKnockoutModel = getKnockoutModel(args.result);
            return args;
        },
	
        executeLocal: function (query) {
            if (!this.defaultQuery && !(query instanceof ej.Query))
                throwError("DataManager - executeLocal() : A query is required to execute");

            if (!this.dataSource.json)
                throwError("DataManager - executeLocal() : Json data is required to execute");

            query = query || this.defaultQuery;

            var result = this.adaptor.processQuery(this, query);

            if (query._subQuery) {
                var from = query._subQuery._fromTable, lookup = query._subQuery._lookup,
                    res = query._requiresCount ? result.result : result;

                if (lookup && lookup instanceof Array) {
                    buildHierarchy(query._subQuery._fKey, from, res, lookup, query._subQuery._key);
                }

                for (var j = 0; j < res.length; j++) {
                    if (res[j][from] instanceof Array) {
                        res[j] = $.extend({}, res[j]);
                        res[j][from] = this.adaptor.processResponse(query._subQuery.using(ej.DataManager(res[j][from].slice(0))).executeLocal(), this, query);
                    }
                }
            }

            return this.adaptor.processResponse(result, this, query);
        },

        _makeRequest: function (url, deffered, args, query) {
            var isSelector = !!query._subQuerySelector;

            var fnFail = $proxy(function (e) {
                args.error = e;
                deffered.rejectWith(this, [args]);
            }, this);

            var process = $proxy(function (data, count, xhr, request, actual, aggregates, virtualSelectRecords) {
                if (isSelector) return;

                args.xhr = xhr;
                args.count = parseInt(count, 10);
                args.result = data;
                args.request = request;
                args.aggregates = aggregates;
                args.getTableModel = getTableModel(query._fromTable, data, this);
                args.getKnockoutModel = getKnockoutModel(data);
                args.actual = actual;
                args.virtualSelectRecords = virtualSelectRecords;
                deffered.resolveWith(this, [args]);

            }, this);

            var fnQueryChild = $proxy(function (data, selector) {
                var subDeffer = $.Deferred(),
                    childArgs = { parent: args };

                query._subQuery._isChild = true;

                var subUrl = this.adaptor.processQuery(this, query._subQuery, data ? this.adaptor.processResponse(data) : selector);

                var childReq = this._makeRequest(subUrl, subDeffer, childArgs, query._subQuery);

                if(!isSelector)
                    subDeffer.then(function (subData) {
                        if (data) {
                            buildHierarchy(query._subQuery._fKey, query._subQuery._fromTable, data, subData, query._subQuery._key);
                            process(data);
                        }
                    }, fnFail);

                return childReq;
            }, this);

            var fnSuccess = proxy(function (data, status, xhr, request) {
                if (xhr.getResponseHeader("Content-Type").indexOf("xml") == -1 && ej.dateParse)
                    data = ej.parseJSON(data);
                var result = this.adaptor.processResponse(data, this, query, xhr, request), count = 0, aggregates = null;
                var virtualSelectRecords = data.virtualSelectRecords;
                if (query._requiresCount) {
                    count = result.count;
                    aggregates = result.aggregates;
                    result = result.result;
                }

                if (!query._subQuery) {
                    process(result, count, xhr, request, data, aggregates, virtualSelectRecords);
                    return;
                }

                if (!isSelector)
                    fnQueryChild(result);

            }, this);

            var req = $.extend({
                type: "GET",
                dataType: this.dataSource.dataType,
                crossDomain: this.dataSource.crossDomain,
                jsonp: this.dataSource.jsonp,
                cache: ej.isNullOrUndefined(this.dataSource.enableAjaxCache) ? true: this.dataSource.enableAjaxCache,
                beforeSend: $proxy(this._beforeSend, this),
                processData: false,
                success: fnSuccess,
                error: fnFail
            }, url);

            if ("async" in this.dataSource)
                req.async = this.dataSource.async;

            req = $.ajax(req);

            if (isSelector) {
                var res = query._subQuerySelector.call(this, { query: query._subQuery, parent: query });

                if (res && res.length) {
                    req = $.when(req, fnQueryChild(null, res));

                    req.then(proxy(function (pData, cData, requests) {
                        var pResult = this.adaptor.processResponse(pData[0], this, query, pData[2], requests[0]), count = 0;
                        if (query._requiresCount) {
                            count = pResult.count;
                            pResult = pResult.result;
                        }
                        var cResult = this.adaptor.processResponse(cData[0], this, query._subQuery, cData[2], requests[1]), count = 0;
                        if (query._subQuery._requiresCount) {
                            count = cResult.count;
                            cResult = cResult.result;
                        }

                        buildHierarchy(query._subQuery._fKey, query._subQuery._fromTable, pResult, cResult, query._subQuery._key);
                        isSelector = false;
                        process(pResult, count, pData[2]);

                    }, this), fnFail);
                } else {
                    isSelector = false;
                }
            }

            return req;
        },

        _beforeSend: function (request, settings) {
            this.adaptor.beforeSend(this, request, settings);

            var headers = this.dataSource.headers, props;
            for (var i = 0; headers && i < headers.length; i++) {
                props = [];
                for (var prop in headers[i]) {
                    props.push(prop);
                    request.setRequestHeader(prop, headers[i][prop]);
                }
            }
        },
	
        saveChanges: function (changes, key, tableName, query) {

            if (tableName instanceof ej.Query) {
                query = tableName;
                tableName = null;
            }

            var args = {
                url: tableName,
                key: key || this.dataSource.key
            };

            var req = this.adaptor.batchRequest(this, changes, args, query);

            if (this.dataSource.offline) {
                return req;
            }

            var deff = $.Deferred();
            $.ajax($.extend({
                beforeSend: $proxy(this._beforeSend, this),
                success: proxy(function (data, status, xhr, request) {
                    deff.resolveWith(this, [this.adaptor.processResponse(data, this, null, xhr, request, changes, key)]);
                }, this),
                error: function (e) {
                    deff.rejectWith(this, [{ error: e }]);
                }
            }, req));

            return deff.promise();
        },
	
        insert: function (data, tableName, query) {       
            // Additional paramater is included based on the task (JS-56499) to prevent addition of serverOffset multiple times
            data = p.replacer(data, true);

            if (tableName instanceof ej.Query) {
                query = tableName;
                tableName = null;
            }

            var res = this.adaptor.insert(this, data, tableName, query);

            if (this.dataSource.offline) {
                return res;
            }            

            var deffer = $.Deferred();

            $.ajax($.extend({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                processData: false,
                beforeSend: $proxy(this._beforeSend, this),
                success: proxy(function (record, status, xhr, request) {
                    try {
                        if (ej.isNullOrUndefined(record))
                            record = [];
                        else
                            p.parseJson(record);
                    }
                    catch (e) {
                        record = [];
                    }
                    record = this.adaptor.processResponse(p.parseJson(record), this, null, xhr, request);
                    deffer.resolveWith(this, [{ record: record, dataManager: this }]);
                }, this),
                error: function (e) {
                    deffer.rejectWith(this, [{ error: e, dataManager: this }]);
                }
            }, res));

            return deffer.promise();
        },
        antiForgeryToken: function () {
           var tokens = {};
           if(ej.isNullOrUndefined($("input[name='_ejRequestVerifyToken']").val()))
                var input = ej.buildTag("input", "", "", { type: "hidden", name: "_ejRequestVerifyToken" , value: ej.getGuid()}).appendTo("body"); 
           else
               $("input[name='_ejRequestVerifyToken']").val(ej.getGuid());
            ej.cookie.set("_ejRequestVerifyToken", $("input[name='_ejRequestVerifyToken']").val());
            tokens ={name: "_ejRequestVerifyToken", value: $("input[name='_ejRequestVerifyToken']").val()}
            return tokens;
        },
        remove: function (keyField, value, tableName, query) {
            if (typeof value === "object")
                value = value[keyField];

            if (tableName instanceof ej.Query) {
                query = tableName;
                tableName = null;
            }

            var res = this.adaptor.remove(this, keyField, value, tableName, query);

            if (this.dataSource.offline)
                return res;          

            var deffer = $.Deferred();
            $.ajax($.extend({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                beforeSend: $proxy(this._beforeSend, this),
                success: proxy(function (record, status, xhr, request) {
                    try {
                        if (ej.isNullOrUndefined(record))
                            record = [];
                        else
                            p.parseJson(record);
                    }
                    catch (e) {
                        record = [];
                    }
                    record = this.adaptor.processResponse(p.parseJson(record), this, null, xhr, request);
                    deffer.resolveWith(this, [{ record: record, dataManager: this }]);
                }, this),
                error: function (e) {
                    deffer.rejectWith(this, [{ error: e, dataManager: this }]);
                }
            }, res));
            return deffer.promise();
        },
	
        update: function (keyField, value, tableName, query) {
            // Additional paramater is included based on this task (JS-56499) to prevent addition of serverOffset multiple times
            value = p.replacer(value, true);

            if (tableName instanceof ej.Query) {
                query = tableName;
                tableName = null;
            }

            var res = this.adaptor.update(this, keyField, value, tableName, query);

            if (this.dataSource.offline) {
                return res;
            }           

            var deffer = $.Deferred();

           $.ajax($.extend({
                contentType: "application/json; charset=utf-8",
                beforeSend: $proxy(this._beforeSend, this),
                success: proxy(function (record, status, xhr, request) {
                    try {
                        if (ej.isNullOrUndefined(record))
                            record = [];
                        else
                            p.parseJson(record);
                    }
                    catch (e) {
                        record = [];
                    }
                    record = this.adaptor.processResponse(p.parseJson(record), this, null, xhr, request);
                    deffer.resolveWith(this, [{ record: record, dataManager: this }]);
                }, this),
                error: function (e) {
                    deffer.rejectWith(this, [{ error: e, dataManager: this }]);
                }
           }, res));

           return deffer.promise();
        },

        _getJsonFromElement: function (ds) {
            if (typeof (ds) == "string")
                ds = $($(ds).html());

            ds = ds.jquery ? ds[0] : ds;

            var tagName = ds.tagName.toLowerCase();

            if (tagName !== "table")
                throwError("ej.DataManager : Unsupported htmlElement : " + tagName);

            return ej.parseTable(ds);
        }
    };

    var buildHierarchy = function (fKey, from, source, lookup, pKey) {
        var i, grp = {}, t;
        if (lookup.result) lookup = lookup.result;

        if (lookup.GROUPGUID)
            throwError("ej.DataManager: Do not have support Grouping in hierarchy");

        for (i = 0; i < lookup.length; i++) {
            var fKeyData = ej.getObject(fKey, lookup[i]);
            t = grp[fKeyData] || (grp[fKeyData] = []);

            t.push(lookup[i]);
        }

        for (i = 0; i < source.length; i++) {
            source[i][from] = grp[ej.getObject(pKey || fKey, source[i])];
        }
    };

    var oData = {
        accept: "application/json;odata=light;q=1,application/json;odata=verbose;q=0.5",
        multipartAccept: "multipart/mixed",
        batch: "$batch",
        changeSet: "--changeset_",
        batchPre: "batch_",
        contentId: "Content-Id: ",
        batchContent: "Content-Type: multipart/mixed; boundary=",
        changeSetContent: "Content-Type: application/http\nContent-Transfer-Encoding: binary ",
        batchChangeSetContentType: "Content-Type: application/json; charset=utf-8 "
    };
    var p = {
        parseJson: function (jsonText) {
            var type = typeof jsonText;
            if (type === "string") {
                jsonText = JSON.parse(jsonText, p.jsonReviver);
            } else if (jsonText instanceof Array) {
                p.iterateAndReviveArray(jsonText);
            } else if (type === "object")
                p.iterateAndReviveJson(jsonText);
            return jsonText;
        },
        iterateAndReviveArray: function (array) {
            for (var i = 0; i < array.length; i++) {
                if (typeof array[i] === "object")
                    p.iterateAndReviveJson(array[i]);
                else if (typeof array[i] === "string" && !/^[\s]*\[|^[\s]*\{|\"/g.test(array[i]))
                    array[i] = p.jsonReviver("",array[i]);
                else
                    array[i] = p.parseJson(array[i]);
            }
        },
        iterateAndReviveJson: function (json) {
            var value;
            for (var prop in json) {
                if (prop.startsWith("__"))
                    continue;

                value = json[prop];
                if (typeof value === "object") {
                    if (value instanceof Array)
                        p.iterateAndReviveArray(value);
                    else
                        p.iterateAndReviveJson(value);
                } else
                    json[prop] = p.jsonReviver(prop, value);
            }
        },
        jsonReviver: function (field, value) {
            var s = value;
            if (typeof value === "string") {
                var ms = /^\/Date\(([+-]?[0-9]+)([+-][0-9]{4})?\)\/$/.exec(value);
                if (ms)
                    return ej.parseDateInUTC ? p.isValidDate(ms[0]) : p.replacer(new Date(parseInt(ms[1])));
                else if (/^(\d{4}\-\d\d\-\d\d)|(\d{4}\-\d\d\-\d\d([tT][\d:\.]*){1})([zZ]|([+\-])(\d\d):?(\d\d))?$/.test(value)) {
                    value = ej.parseDateInUTC ? p.isValidDate(value) : p.replacer(new Date(value));
                    if (isNaN(value)) {
                        var a = s.split(/[^0-9]/);
                        value = p.replacer(new Date(a[0], a[1] - 1, a[2], a[3], a[4], a[5]));
                    }
                }
            }
            return value;
        },
        isValidDate: function (value) {
            var prop = value;
            if (typeof (prop) === "string" && prop.indexOf("/Date(") == 0) {
                value = prop.replace(/\d+/, function (n) {
                    var offsetMiliseconds = new Date(parseInt(n)).getTimezoneOffset() * 60000;
                    var ticks = parseInt(n) + offsetMiliseconds;
                    return p.replacer(new Date(parseInt(ticks)));
                });
            }
            if (typeof value === "string") {
                value = value.replace("/Date(", function () { return ""; });
                value = value.replace(")/", function () { return ""; })
                var ms = new Date(value) instanceof Date;
                if (ms)
                    return new Date(value);
                else return value;
            }
            return value;
        },
        isJson: function (jsonData) {
            if(typeof jsonData[0]== "string")
                return jsonData;
            return ej.parseJSON(jsonData);
        },
        isGuid: function (value) {
            var regex = /[A-Fa-f0-9]{8}(?:-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}/i;
            var match = regex.exec(value);
            return match != null;
        },
        // Additional paramater is included based on this task (JS-56499) to prevent addition of serverOffset multiple times
        replacer: function (value, serverOffset) {

            if (ej.isPlainObject(value))
                return p.jsonReplacer(value, serverOffset);

            if (value instanceof Array)
                return p.arrayReplacer(value);

            if (value instanceof Date)
                return p.jsonReplacer({ val: value }, serverOffset).val;

            return value;
        },
        jsonReplacer: function (val, serverOffset) {
            var value;
            for (var prop in val) {
                value = val[prop];

                if (!(value instanceof Date))
                    continue;
                // checking for update and insert operation and then including the proper offset, based on this task (JS-56499) 
                var offset = ej.serverTimezoneOffset * 60 * 60 * 1000 * (ej.isNullOrUndefined(serverOffset) || (serverOffset === false) ? (1) : -(1));
                val[prop] = new Date(+value + offset);
            }

            return val;
        },
        arrayReplacer: function (val) {

            for (var i = 0; i < val.length; i++) {            
                if (ej.isPlainObject(val[i]))
                    val[i] = p.jsonReplacer(val[i]);
                else if (val[i] instanceof Date)
                    val[i] = p.jsonReplacer({ date: val[i] }).date;
            }

            return val;
        }
    };

    ej.isJSON = p.isJson;
    ej.parseJSON = p.parseJson;
    ej.dateParse = true;
    ej.isGUID = p.isGuid;
    ej.Query = function (from) {
        if (!(this instanceof ej.Query))
            return new ej.Query(from);

        this.queries = [];
        this._key = "";
        this._fKey = "";

        if (typeof from === "string")
            this._fromTable = from || "";
        else if (from && from instanceof Array)
            this._lookup = from;

        this._expands = [];
        this._sortedColumns = [];
        this._groupedColumns = [];
        this._subQuery = null;
        this._isChild = false;
        this._params = [];
        return this;
    };

    ej.Query.prototype = {
        key: function (field) {
            if (typeof field === "string")
                this._key = field;

            return this;
        },
	
        using: function (dataManager) {
            if (dataManager instanceof ej.DataManager) {
                this.dataManagar = dataManager;
                return this;
            }

            return throwError("Query - using() : 'using' function should be called with parameter of instance ej.DataManager");
        },
	
        execute: function (dataManager, done, fail, always) {
            dataManager = dataManager || this.dataManagar;

            if (dataManager && dataManager instanceof ej.DataManager)
                return dataManager.executeQuery(this, done, fail, always);

            return throwError("Query - execute() : dataManager needs to be is set using 'using' function or should be passed as argument");
        },
	
        executeLocal: function (dataManager) {
            // this does not support for URL binding
            

            dataManager = dataManager || this.dataManagar;

            if (dataManager && dataManager instanceof ej.DataManager)
                return dataManager.executeLocal(this);

            return throwError("Query - executeLocal() : dataManager needs to be is set using 'using' function or should be passed as argument");
        },
	
        clone: function () {
            var cl = new ej.Query();
            cl.queries = this.queries.slice(0);
            cl._key = this._key;
            cl._isChild = this._isChild;
            cl.dataManagar = this.dataManager;
            cl._fromTable = this._fromTable;
            cl._params = this._params.slice(0);
            cl._expands = this._expands.slice(0);
            cl._sortedColumns = this._sortedColumns.slice(0);
            cl._groupedColumns = this._groupedColumns.slice(0);
            cl._subQuerySelector = this._subQuerySelector;
            cl._subQuery = this._subQuery;
            cl._fKey = this._fKey;
            cl._requiresCount = this._requiresCount;
            return cl;
        },
	
        from: function (tableName) {
            if (typeof tableName === "string")
                this._fromTable = tableName;

            return this;
        },
	
        addParams: function (key, value) {
            if (typeof value !== "function" && !ej.isPlainObject(value))
                this._params.push({ key: key, value: value });
            else if (typeof value === "function")
                this._params.push({ key: key, fn: value });

            return this;
        },
	
        expand: function (tables) {
            if (typeof tables === "string")
                this._expands = [].slice.call(arguments, 0);
            else
                this._expands = tables.slice(0);

            return this;
        },
	
        where: function (fieldName, operator, value, ignoreCase,ignoreAccent) {
            operator = (operator || ej.FilterOperators.equal).toLowerCase();
            var predicate = null;

            if (typeof fieldName === "string")
                predicate = new ej.Predicate(fieldName, operator, value, ignoreCase,ignoreAccent);
            else if (fieldName instanceof ej.Predicate)
                predicate = fieldName;
            else
                throwError("Query - where : Invalid arguments");

            this.queries.push({
                fn: "onWhere", 
                e: predicate
            });
            return this;
        },
	
        search: function (searchKey, fieldNames, operator, ignoreCase, ignoreAccent) {
            if (!fieldNames || typeof fieldNames === "boolean") {
                fieldNames = [];
                ignoreCase = fieldNames;
            } else if (typeof fieldNames === "string")
                fieldNames = [fieldNames];

            if (typeof operator === "boolean") {
                ignoreCase = operator;
                operator = null;
            }
            operator = operator || ej.FilterOperators.contains;
            if (operator.length < 3)
                operator = ej.data.operatorSymbols[operator];

            var comparer = ej.data.fnOperators[operator] || ej.data.fnOperators.processSymbols(operator);

            this.queries.push({
                fn: "onSearch",
                e: {
                    fieldNames: fieldNames,
                    operator: operator,
                    searchKey: searchKey,
                    ignoreCase: ignoreCase,
                    ignoreAccent: ignoreAccent,
                    comparer: comparer
                }
            });
            return this;
        },
		
        sortBy: function (fieldName, comparer, isFromGroup) {
            var order = ej.sortOrder.Ascending, sorts, t;

            if (typeof fieldName === "string" && fieldName.toLowerCase().endsWith(" desc")) {
                fieldName = fieldName.replace(/ desc$/i, '');
                comparer = ej.sortOrder.Descending;
            }
            if (fieldName instanceof Array) {
                for(var i=0;i<fieldName.length;i++)
                   this.sortBy(fieldName[i],comparer,isFromGroup);
                return this;
            }
            if (typeof comparer === "boolean")
                comparer = !comparer ? ej.sortOrder.Ascending : ej.sortOrder.Descending;
            else if (typeof comparer === "function")
                order = "custom";

            if (!comparer || typeof comparer === "string") {
                order = comparer ? comparer.toLowerCase() : ej.sortOrder.Ascending;
                comparer = ej.pvt.fnSort(comparer);
            }
            if (isFromGroup) {
                sorts = filterQueries(this.queries, "onSortBy");

                for (var i = 0; i < sorts.length; i++) {
                    t = sorts[i].e.fieldName;
                    if (typeof t === "string") {
                        if (t === fieldName) return this;
                    } else if (t instanceof Array) {
                        for (var j = 0; j < t.length; j++)
                            if (t[j] === fieldName || fieldName.toLowerCase() === t[j] + " desc")
                                return this;
                    }
                }
            }

            this.queries.push({
                fn: "onSortBy",
                e: {
                    fieldName: fieldName,
                    comparer: comparer,
                    direction: order
                }
            });

            return this;
        },
		
        sortByDesc: function (fieldName) {
            return this.sortBy(fieldName, ej.sortOrder.Descending);
        },
		
        group: function (fieldName,fn) {
            this.sortBy(fieldName, null, true);

            this.queries.push({
                fn: "onGroup",
                e: {
                    fieldName: fieldName,
                    fn: fn
                }
            });
            return this;
        },
	
        page: function (pageIndex, pageSize) {
            this.queries.push({
                fn: "onPage",
                e: {
                    pageIndex: pageIndex,
                    pageSize: pageSize
                }
            });
            return this;
        },
	
        range: function (start, end) {
            if (typeof start !== "number" || typeof end !== "number")
                throwError("Query() - range : Arguments type should be a number");

            this.queries.push({
                fn: "onRange",
                e: {
                    start: start,
                    end: end
                }
            });
            return this;
        },
	

        take: function (nos) {
            if (typeof nos !== "number")
                throwError("Query() - Take : Argument type should be a number");

            this.queries.push({
                fn: "onTake",
                e: {
                    nos: nos
                }
            });
            return this;
        },
	
        skip: function (nos) {
            if (typeof nos !== "number")
                throwError("Query() - Skip : Argument type should be a number");

            this.queries.push({
                fn: "onSkip",
                e: { nos: nos }
            });
            return this;
        },
	
        select: function (fieldNames) {
            if (typeof fieldNames === "string")
                fieldNames = [].slice.call(arguments, 0);

            if (!(fieldNames instanceof Array)) {
                throwError("Query() - Select : Argument type should be String or Array");
            }

            this.queries.push({
                fn: "onSelect",
                e: { fieldNames: fieldNames }
            });
            return this;
        },
	
        hierarchy: function (query, selectorFn) {
            if (!query || !(query instanceof ej.Query))
                throwError("Query() - hierarchy : query must be instance of ej.Query");

            if (typeof selectorFn === "function")
                this._subQuerySelector = selectorFn;

            this._subQuery = query;
            return this;
        },
	
        foreignKey: function (key) {
            if (typeof key === "string")
                this._fKey = key;

            return this;
        },
	
        requiresCount: function () {
            this._requiresCount = true;

            return this;
        },
        //type - sum, avg, min, max
        aggregate: function (type, field) {
            this.queries.push({
                fn: "onAggregates",
                e: { field: field, type: type }
            });
        }
    };

    ej.Adaptor = function (ds) {
        this.dataSource = ds;
        this.pvt = {};
		this.init.apply(this, [].slice.call(arguments, 1));
    };

    ej.Adaptor.prototype = {
        options: {
            from: "table",
            requestType: "json",
            sortBy: "sorted",
            select: "select",
            skip: "skip",
            group: "group",
            take: "take",
            search: "search",
            count: "requiresCounts",
            where: "where",
            aggregates: "aggregates",
            antiForgery: "antiForgery"
        },
        init: function () {
        },
        extend: function (overrides) {
            var fn = function (ds) {
                this.dataSource = ds;

                if (this.options)
                    this.options = $.extend({}, this.options);
				this.init.apply(this, [].slice.call(arguments, 0));

                this.pvt = {};
            };
            fn.prototype = new this.type();
            fn.prototype.type = fn;

            var base = fn.prototype.base = {};
            for (var p in overrides) {
                if (fn.prototype[p])
                    base[p] = fn.prototype[p];
            }
            $.extend(true, fn.prototype, overrides);
            return fn;
        },
        processQuery: function (dm, query) {
            // this needs to be overridden
        },
        processResponse: function (data, ds, query, xhr) {
            if (data.d)
               return data.d;
            return data;
        },
        convertToQueryString: function (req, query, dm) {
            return $.param(req);
        },
        type: ej.Adaptor
    };

    ej.UrlAdaptor = new ej.Adaptor().extend({
        processQuery: function (dm, query, hierarchyFilters) {
            var sorted = filterQueries(query.queries, "onSortBy"),
                grouped = filterQueries(query.queries, "onGroup"),
                filters = filterQueries(query.queries, "onWhere"),
                searchs = filterQueries(query.queries, "onSearch"),
                aggregates = filterQueries(query.queries, "onAggregates"),
                singles = filterQueryLists(query.queries, ["onSelect", "onPage", "onSkip", "onTake", "onRange"]),
                params = query._params,
                url = dm.dataSource.url, tmp, skip, take = null,
                op = this.options;

            var r = {
                sorted: [],
                grouped: [],
                filters: [],
                searches: [],
                aggregates: []
            };

            // calc Paging & Range
            if (singles["onPage"]) {
                tmp = singles["onPage"];
                skip = getValue(tmp.pageIndex, query);
                take = getValue(tmp.pageSize, query);
				skip = (skip - 1) * take;
            } else if (singles["onRange"]) {
                tmp = singles["onRange"];
                skip = tmp.start;
                take = tmp.end - tmp.start;
            }

            // Sorting
            for (var i = 0; i < sorted.length; i++) {
                tmp = getValue(sorted[i].e.fieldName, query);

                r.sorted.push(callAdaptorFunc(this, "onEachSort", { name: tmp, direction: sorted[i].e.direction }, query));
            }

            // hierarchy
            if (hierarchyFilters) {
                tmp = this.getFiltersFrom(hierarchyFilters, query);
                if (tmp)
                    r.filters.push(callAdaptorFunc(this, "onEachWhere", tmp.toJSON(), query));
            }

            // Filters
            for (var i = 0; i < filters.length; i++) {
                r.filters.push(callAdaptorFunc(this, "onEachWhere", filters[i].e.toJSON(), query));

                for (var prop in r.filters[i]) {
                    if (isNull(r[prop]))
                        delete r[prop];
                }
            }

            // Searches
            for (var i = 0; i < searchs.length; i++) {
                tmp = searchs[i].e;
                r.searches.push(callAdaptorFunc(this, "onEachSearch", {
                    fields: tmp.fieldNames,
                    operator: tmp.operator,
                    key: tmp.searchKey,
                    ignoreCase: tmp.ignoreCase
                }, query));
            }

            // Grouping
            for (var i = 0; i < grouped.length; i++) {
                r.grouped.push(getValue(grouped[i].e.fieldName, query));
            }

            // aggregates
            for (var i = 0; i < aggregates.length; i++) {
                tmp = aggregates[i].e; 
                r.aggregates.push({ type: tmp.type, field: getValue(tmp.field, query) });
            }

            var req = {};
            req[op.from] = query._fromTable;
            if (op.expand) req[op.expand] = query._expands;
            req[op.select] = singles["onSelect"] ? callAdaptorFunc(this, "onSelect", getValue(singles["onSelect"].fieldNames, query), query) : "";
            req[op.count] = query._requiresCount ? callAdaptorFunc(this, "onCount", query._requiresCount, query) : "";
            req[op.search] = r.searches.length ? callAdaptorFunc(this, "onSearch", r.searches, query) : "";
            req[op.skip] = singles["onSkip"] ? callAdaptorFunc(this, "onSkip", getValue(singles["onSkip"].nos, query), query) : "";
            req[op.take] = singles["onTake"] ? callAdaptorFunc(this, "onTake", getValue(singles["onTake"].nos, query), query) : "";
            req[op.antiForgery] = (dm.dataSource.antiForgery) ? dm.antiForgeryToken().value : "";
            req[op.where] = r.filters.length || r.searches.length ? callAdaptorFunc(this, "onWhere", r.filters, query) : "";
            req[op.sortBy] = r.sorted.length ? callAdaptorFunc(this, "onSortBy", r.sorted, query) : "";
            req[op.group] = r.grouped.length ? callAdaptorFunc(this, "onGroup", r.grouped, query) : "";
            req[op.aggregates] = r.aggregates.length ? callAdaptorFunc(this, "onAggregates", r.aggregates, query) : "";
			req["param"] = [];
			
            // Params
			callAdaptorFunc(this, "addParams", { dm: dm, query: query, params: params, reqParams: req });

            // cleanup
            for (var prop in req) {
                if (isNull(req[prop]) || req[prop] === "" || req[prop].length === 0 || prop === "params")
                    delete req[prop];
            }

            if (!(op.skip in req && op.take in req) && take !== null) {
                req[op.skip] = callAdaptorFunc(this, "onSkip", skip, query);
                req[op.take] = callAdaptorFunc(this, "onTake", take, query);
            }
            var p = this.pvt;
            this.pvt = {};

            if (this.options.requestType === "json") {
                return {
                    data: JSON.stringify(req),
                    url: url,
                    ejPvtData: p,
                    type: "POST",
                    contentType: "application/json; charset=utf-8"
                }
            }
            tmp = this.convertToQueryString(req, query, dm);
            tmp =  (dm.dataSource.url.indexOf("?")!== -1 ? "&" : "/") + tmp;
            return {
                type: "GET",
                url: tmp.length ? url.replace(/\/*$/, tmp) : url,
                ejPvtData: p
            };
        },
        convertToQueryString: function (req, query, dm) {
            if (dm.dataSource.url && dm.dataSource.url.indexOf("?") !== -1)
                return $.param(req);
            return "?" + $.param(req);
        },
        processResponse: function (data, ds, query, xhr, request, changes) {
            var pvt = request.ejPvtData || {};
			var groupDs= data.groupDs;
			if (xhr && xhr.getResponseHeader("Content-Type") && xhr.getResponseHeader("Content-Type").indexOf("xml") != -1 && data.nodeType == 9)
                return query._requiresCount ? { result: [], count: 0 } : [];
            var d = JSON.parse(request.data);
            if (d && d.action === "batch" && data.added) {
                changes.added = data.added;
                return changes;
            }
            if (data.d)
                data = data.d;

            if (pvt && pvt.aggregates && pvt.aggregates.length) {
                var agg = pvt.aggregates, args = {}, fn, res = {};
                if ('count' in data) args.count = data.count;
                if (data["result"]) args.result = data.result;
                if (data["aggregate"]) data = data.aggregate;
                for (var i = 0; i < agg.length; i++) {
                    fn = ej.aggregates[agg[i].type];
                    if (fn)
                        res[agg[i].field + " - " + agg[i].type] = fn(data, agg[i].field);
                }
                args["aggregates"] = res;
                data = args;
            }

            if (pvt && pvt.groups && pvt.groups.length) {
                var groups = pvt.groups, args = {};
                if ('count' in data) args.count = data.count;
                if (data["aggregates"]) args.aggregates = data.aggregates;
                if (data["result"]) data = data.result;
                for (var i = 0; i < groups.length; i++){
                    var level = null;
                    var format = getColFormat(groups[i], query.queries);
                    if (!ej.isNullOrUndefined(groupDs))
                        groupDs = ej.group(groupDs, groups[i], null, format);
                    data = ej.group(data, groups[i], pvt.aggregates, format, level, groupDs);
                }
                if (args.count != undefined)
                    args.result = data;
                else
                    args = data;
                return args;
            }
            return data;
        },
        onGroup: function (e) {
            this.pvt.groups = e;
        },
        onAggregates: function (e) {
            this.pvt.aggregates = e;
        },
        batchRequest: function (dm, changes, e, query) {
            var res = {
                changed: changes.changed,
                added: changes.added,
                deleted: changes.deleted,
                action: "batch",
                table: e.url,
                key: e.key,
				antiForgery: (dm.dataSource.antiForgery) ? dm.antiForgeryToken().value : ""
            };
            if (query)
                this.addParams({ dm: dm, query: query, params: query._params, reqParams: res });

            return {
                type: "POST",
                url: dm.dataSource.batchUrl || dm.dataSource.crudUrl || dm.dataSource.removeUrl || dm.dataSource.url,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify(res)
            };
        },
        beforeSend: function (dm, request) {
        },
        insert: function (dm, data, tableName, query) {
            var res = {
                value: data,
                table: tableName,
                action: "insert",
                antiForgery: (dm.dataSource.antiForgery) ? dm.antiForgeryToken().value : ""
            };
            if (query)
                this.addParams({ dm: dm, query: query, params: query._params, reqParams: res });

            return {
                url: dm.dataSource.insertUrl || dm.dataSource.crudUrl || dm.dataSource.url,
                data: JSON.stringify(res)
            };
        },
        remove: function (dm, keyField, value, tableName, query) {
            var res = {
                key: value,
                keyColumn: keyField,
                table: tableName,
                action: "remove",
                antiForgery: (dm.dataSource.antiForgery) ? dm.antiForgeryToken().value : ""
            };
            if (query)
                this.addParams({ dm: dm, query: query, params: query._params, reqParams: res });

            return {
                type: "POST",
                url: dm.dataSource.removeUrl || dm.dataSource.crudUrl || dm.dataSource.url,
                data: JSON.stringify(res)
            };
        },
        update: function (dm, keyField, value, tableName, query) {
            var res = {
                value: value,
                action: "update",
                keyColumn: keyField,
                key: value[keyField],
                table: tableName,
                antiForgery: (dm.dataSource.antiForgery) ? dm.antiForgeryToken().value : ""
            };
            if (query)
                this.addParams({ dm: dm, query: query, params: query._params, reqParams: res });

            return {
                type: "POST",
                url: dm.dataSource.updateUrl || dm.dataSource.crudUrl || dm.dataSource.url,
                data: JSON.stringify(res)
            };
        },
        getFiltersFrom: function (data, query) {
            if (!(data instanceof Array) || !data.length)
                throwError("ej.SubQuery: Array of key values required");
            var key = query._fKey, value, prop = key, pKey = query._key, predicats = [],
                isValues = typeof data[0] !== "object";

            if (typeof data[0] !== "object") prop = null;

            for (var i = 0; i < data.length; i++) {
                value = !isValues ? ej.pvt.getObject(pKey || prop, data[i]) : data[i];
                predicats.push(new ej.Predicate(key, "==", value));
            }

            return ej.Predicate.or(predicats);
        },
        addParams: function (options) {
            var dm = options.dm, query = options.query, params = options.params, req = options.reqParams; req["params"] = {};
            for (var i = 0, tmp; tmp = params[i]; i++) {
                if (req[tmp.key]) throwError("ej.Query: Custom Param is conflicting other request arguments");
                req[tmp.key] = tmp.value;
                if (tmp.fn)
                    req[tmp.key] = tmp.fn.call(query, tmp.key, query, dm);                
                req["params"][tmp.key] = req[tmp.key];
            }
        }
    });
    ej.WebMethodAdaptor = new ej.UrlAdaptor().extend({
        processQuery: function (dm, query, hierarchyFilters) {
            var obj = ej.UrlAdaptor.prototype.processQuery(dm, query, hierarchyFilters);
            var data = ej.parseJSON(obj.data), result = {};

            result["value"] = data;

            //Params             
            callAdaptorFunc(this, "addParams", { dm: dm, query: query, params: query._params, reqParams: result });

            return {
                data: JSON.stringify(result),
                url: obj.url,
                ejPvtData: obj.ejPvtData,
                type: "POST",
                contentType: "application/json; charset=utf-8"
            }
        },
        addParams: function (options) {
            var dm = options.dm, query = options.query, params = options.params, req = options.reqParams; req["params"] = {};
            for (var i = 0, tmp; tmp = params[i]; i++) {
                if (req[tmp.key]) throwError("ej.Query: Custom Param is conflicting other request arguments");
                var webkey = tmp.key, webvalue = tmp.value;
                if (tmp.fn)
                    webvalue = tmp.fn.call(query, tmp.key, query, dm);
                req[webkey] = webvalue;
                req["params"][webkey] = req[webkey];
            }
        }
    });
    ej.CacheAdaptor = new ej.UrlAdaptor().extend({
        init: function (adaptor, timeStamp, pageSize) {
            if (!ej.isNullOrUndefined(adaptor)) {
                this.cacheAdaptor = adaptor;
            }
            this.pageSize = pageSize;
            this.guidId = ej.getGuid("cacheAdaptor");
            var obj = { keys: [], results: [] };
            if (window.localStorage)
                window.localStorage.setItem(this.guidId, JSON.stringify(obj));
            var guid = this.guidId;
            if (!ej.isNullOrUndefined(timeStamp)) {
                setInterval(function () {
                    var data = ej.parseJSON(window.localStorage.getItem(guid));
                    var forDel = [];
                    for (var i = 0; i < data.results.length; i++) {
                        data.results[i].timeStamp = new Date() - new Date(data.results[i].timeStamp)
                        if (new Date() - new Date(data.results[i].timeStamp) > timeStamp)
                            forDel.push(i);
                    }
                    var d = forDel;
                    for (var i = 0; i < forDel.length; i++) {
                        data.results.splice(forDel[i], 1);
                        data.keys.splice(forDel[i], 1);
                    }
                    window.localStorage.removeItem(guid);
                    window.localStorage.setItem(guid, JSON.stringify(data));
                }, timeStamp);
            }
        },
        generateKey: function (url, query) {
            var sorted = filterQueries(query.queries, "onSortBy"),
                grouped = filterQueries(query.queries, "onGroup"),
                filters = filterQueries(query.queries, "onWhere"),
                searchs = filterQueries(query.queries, "onSearch"),
				pageQuery = filterQueries(query.queries, "onPage"),
                singles = filterQueryLists(query.queries, ["onSelect", "onPage", "onSkip", "onTake", "onRange"]),
                params = query._params;
            var key = url;
            if (singles["onPage"])
              key += singles["onPage"].pageIndex;
              sorted.forEach(function (obj) {
                   key += obj.e.direction + obj.e.fieldName;
              });
                grouped.forEach(function (obj) {
                    key += obj.e.fieldName;
                });
                searchs.forEach(function (obj) {
                    key += obj.e.searchKey;
                });
            
            for (var filter = 0; filter < filters.length; filter++) {
                var currentFilter = filters[filter];
                if (currentFilter.e.isComplex) {
                    var newQuery = query.clone();
                    newQuery.queries = [];
                    for (var i = 0; i < currentFilter.e.predicates.length; i++) {
                        newQuery.queries.push({ fn: "onWhere", e: currentFilter.e.predicates[i], filter: query.queries.filter });
                    }
                    key += currentFilter.e.condition + this.generateKey(url, newQuery);
                }
                else
                    key += currentFilter.e.field + currentFilter.e.operator + currentFilter.e.value
            }
            return key;
        },
        processQuery: function (dm, query, hierarchyFilters) {
            var key = this.generateKey(dm.dataSource.url, query);
            var cachedItems;
            if (window.localStorage)
                cachedItems = ej.parseJSON(window.localStorage.getItem(this.guidId));
            var data = cachedItems ? cachedItems.results[cachedItems.keys.indexOf(key)] : null;
            if (data != null && !this._crudAction && !this._insertAction) {
                return data;
            }
            this._crudAction = null; this._insertAction = null;
            return this.cacheAdaptor.processQuery.apply(this.cacheAdaptor, [].slice.call(arguments, 0))
        },
        processResponse: function (data, ds, query, xhr, request, changes) {
            if (this._insertAction || (request && this.cacheAdaptor.options.batch && request.url.endsWith(this.cacheAdaptor.options.batch) && request.type.toLowerCase() === "post")) {
                return this.cacheAdaptor.processResponse(data, ds, query, xhr, request, changes);
            }
            var data = this.cacheAdaptor.processResponse.apply(this, [].slice.call(arguments, 0));
            var key = this.generateKey(ds.dataSource.url, query)
            var obj = {};
            if (window.localStorage)
                obj = ej.parseJSON(window.localStorage.getItem(this.guidId));
            var index = $.inArray(key, obj.keys);
            if (index != -1) {
                obj.results.splice(index, 1);
                obj.keys.splice(index, 1);
            }
            obj.results[obj.keys.push(key) - 1] = { keys: key, result: data.result, timeStamp: new Date(), count: data.count }
            while (obj.results.length > this.pageSize) {
                obj.results.splice(0, 1);
                obj.keys.splice(0, 1);
            }
            window.localStorage.setItem(this.guidId, JSON.stringify(obj));
            return data;
        },
        update: function (dm, keyField, value, tableName) {
            this._crudAction = true;
            return this.cacheAdaptor.update(dm, keyField, value, tableName);
        },
        insert: function (dm, data, tableName) {
            this._insertAction = true;
            return this.cacheAdaptor.insert(dm, data, tableName);
        },
        remove: function (dm, keyField, value, tableName) {
            this._crudAction = true;
            return this.cacheAdaptor.remove(dm, keyField, value, tableName);
        },
        batchRequest: function (dm, changes, e) {
            return this.cacheAdaptor.batchRequest(dm, changes, e);
        }
    });
    var filterQueries = function (queries, name) {
        return queries.filter(function (q) {
            return q.fn === name;
        }) || [];
    };
    var filterQueryLists = function (queries, singles) {
        var filtered = queries.filter(function (q) {
            return singles.indexOf(q.fn) !== -1;
        }), res = {};
        for (var i = 0; i < filtered.length; i++) {
            if (!res[filtered[i].fn])
                res[filtered[i].fn] = filtered[i].e;
        }
        return res;
    };
    var callAdaptorFunc = function (obj, fnName, param, param1) {
        if (obj[fnName]) {
            var res = obj[fnName](param, param1);
            if (!isNull(res)) param = res;
        }
        return param;
    };

    ej.ODataAdaptor = new ej.UrlAdaptor().extend({
        options: {
            requestType: "get",
            accept: "application/json;odata=light;q=1,application/json;odata=verbose;q=0.5",
            multipartAccept: "multipart/mixed",
            sortBy: "$orderby",
            select: "$select",
            skip: "$skip",
            take: "$top",
            count: "$inlinecount",
            where: "$filter",
            expand: "$expand",
            batch: "$batch",
            changeSet: "--changeset_",
            batchPre: "batch_",
            contentId: "Content-Id: ",
            batchContent: "Content-Type: multipart/mixed; boundary=",
            changeSetContent: "Content-Type: application/http\nContent-Transfer-Encoding: binary ",
            batchChangeSetContentType: "Content-Type: application/json; charset=utf-8 "
        },
        onEachWhere: function (filter, requiresCast) {
            return filter.isComplex ? this.onComplexPredicate(filter, requiresCast) : this.onPredicate(filter, requiresCast);
        },
		_typeStringQuery: function (pred, requiresCast,val,field,guid) {
			if(val.indexOf("'") != -1)
			    val = val.replace(new RegExp(/'/g), "''");
			var specialCharFormat = /[ !@@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/; 
			if (specialCharFormat.test(val)) { 
			    val = encodeURIComponent(val)
			}
            val = "'" + val + "'";
            if (requiresCast) {
                field = "cast(" + field + ", 'Edm.String')";
            }
            if (ej.isGUID(val))
                guid = 'guid';
            if (pred.ignoreCase) {
                !guid ? field = "tolower(" + field + ")" : field;
                val = val.toLowerCase();
            }
			return {"val":val,"guid":guid ,"field":field};
		},
        onPredicate: function (pred, query, requiresCast) {
            var returnValue = "",
                operator,guid,
                val = pred.value,
                type = typeof val,
                field = this._p(pred.field);

            if (val instanceof Date)
                val = "datetime'" + p.replacer(val).toJSON() + "'";

            if (type === "string") {
				var args = this._typeStringQuery(pred,requiresCast,val,field , guid);
				val = args["val"]; field = args["field"]; guid = args["guid"];
            }

            operator = ej.data.odBiOperator[pred.operator];
			if(pred.anyCondition != "" && operator) {
				returnValue += val["table"];
				returnValue += ("/"+pred.anyCondition);
				returnValue += "(d:d/";
				returnValue += field;
				returnValue += operator;
				returnValue += val["value"];
				returnValue += ")";
				return returnValue;
			}
			if( pred.operator == "in" || pred.operator == "notin" ) {
				returnValue += "(";
				for(var index = 0; index < val.length; index++ ) {
					if (val[index] instanceof Date)
						val[index] = "datetime'" + p.replacer(val[index]).toJSON() + "'";
					if (typeof val[index] === "string") {
						var args = this._typeStringQuery(pred,requiresCast,val[index],field , guid);
						val[index] = args["val"]; field = args["field"]; guid = args["guid"];
					}
					returnValue += field;
					returnValue += operator;
					returnValue += val[index];
					if( index != val.length -1 ) returnValue += ( pred.operator == "in") ? " or " : " and ";
				}
				returnValue += ")";
				return returnValue;
			}
		    if (operator) {
		        return this.onOperation(returnValue, operator, field, val, guid);
		    }

            operator = ej.data.odUniOperator[pred.operator];
            if (!operator || type !== "string") return "";

            if (operator === "substringof") {
                var t = val;
                val = field;
                field = t;
            }

            returnValue += operator + "(";
            returnValue += field + ",";
            if (guid) returnValue += guid;
            returnValue += val + ")";
			
			if( pred.operator == "notcontains" ) {
				returnValue += " eq false"
			}
			if(pred.anyCondition != "" && operator) {
				var returnValue1;
				returnValue1 += val["table"];
				returnValue1 += ("/"+pred.anyCondition);
				returnValue1 += "(d:d/";
				returnValue += returnValue;
				returnValue1 += ")";
				return returnValue1;
			}
            return returnValue;
		},
		onOperation: function (returnValue, operator, field, val, guid) {
		        returnValue += field;
		        returnValue += operator;
		        if (guid)
		            returnValue += guid;
		        return returnValue + val;
        },
        onComplexPredicate: function (pred, requiresCast) {
            var res = [];
            for (var i = 0; i < pred.predicates.length; i++) {
                res.push("(" + this.onEachWhere(pred.predicates[i], requiresCast) + ")");
            }
            return res.join(" " + pred.condition + " ");
        },
        onWhere: function (filters) {
            if (this.pvt.searches)
                filters.push(this.onEachWhere(this.pvt.searches, null, true));

            return filters.join(" and ");
        },
        onEachSearch: function (e) {
            if (e.fields.length === 0)
                throwError("Query() - Search : oData search requires list of field names to search");

            var filter = this.pvt.searches || [];
            for (var i = 0; i < e.fields.length; i++) {
                filter.push(new ej.Predicate(e.fields[i], e.operator, e.key, e.ignoreCase));
            }
            this.pvt.searches = filter;
        },
        onSearch: function (e) {
            this.pvt.searches = ej.Predicate.or(this.pvt.searches);
            return "";
        },
        onEachSort: function (e) {
            var res = [];
            if (e.name instanceof Array) {
                for (var i = 0; i < e.name.length; i++)
                    res.push(this._p(e.name[i]));
            } else {
                res.push(this._p(e.name) + (e.direction === "descending" ? " desc" : ""));
            }
            return res.join(",");
        },
        onSortBy: function (e) {
            return e.reverse().join(",");
        },
        onGroup: function (e) {
            this.pvt.groups = e;
            return "";
        },
        onSelect: function (e) {
            for (var i = 0; i < e.length; i++)
                e[i] = this._p(e[i]);

            return e.join(',');
        },
        onAggregates: function(e){
            this.pvt.aggregates = e;
            return "";
        },
        onCount: function (e) {
            return e === true ? "allpages" : "";
        },
        beforeSend: function (dm, request, settings) {
            if (settings.url.endsWith(this.options.batch) && settings.type.toLowerCase() === "post") {
                request.setRequestHeader("Accept", oData.multipartAccept);
                request.setRequestHeader("DataServiceVersion", "2.0");
                request.overrideMimeType("text/plain; charset=x-user-defined");
            }

            if (!dm.dataSource.crossDomain) {
                request.setRequestHeader("DataServiceVersion", "2.0");
                request.setRequestHeader("MaxDataServiceVersion", "2.0");
            }
        },
        processResponse: function (data, ds, query, xhr, request, changes) {
            if (!ej.isNullOrUndefined(data.d)) {
                var dataCopy = (query && query._requiresCount) ? data.d.results : data.d;
                if (!ej.isNullOrUndefined(dataCopy))
                    for (var i = 0; i < dataCopy.length; i++) {
                        !ej.isNullOrUndefined(dataCopy[i].__metadata) && delete dataCopy[i].__metadata;
                    }
            }
            var pvt = request && request.ejPvtData;
            if (xhr && xhr.getResponseHeader("Content-Type") && xhr.getResponseHeader("Content-Type").indexOf("xml") != -1 && data.nodeType == 9)
                return query._requiresCount ? { result: [], count: 0 } : [];
            if (request && this.options.batch && request.url.endsWith(this.options.batch) && request.type.toLowerCase() === "post") {
                var guid = xhr.getResponseHeader("Content-Type"), cIdx, jsonObj;
                guid = guid.substring(guid.indexOf("=batchresponse") + 1);
                data = data.split(guid);
                if (data.length < 2) return;

                data = data[1];
                var exVal = /(?:\bContent-Type.+boundary=)(changesetresponse.+)/i.exec(data);
                data.replace(exVal[0], "");

                var changeGuid = exVal[1];
                data = data.split(changeGuid);

                for (var i = data.length; i > -1; i--) {
                    if (!/\bContent-ID:/i.test(data[i]) || !/\bHTTP.+201/.test(data[i]))
                        continue;

                    cIdx = parseInt(/\bContent-ID: (\d+)/i.exec(data[i])[1]);

                    if (changes.added[cIdx]) {
                        jsonObj = p.parseJson(/^\{.+\}/m.exec(data[i])[0]);
                        $.extend(changes.added[cIdx], this.processResponse(jsonObj));
                    }
                }
                return changes;
            }
            var version = xhr && xhr.getResponseHeader("DataServiceVersion"), count = null, aggregateResult = {};
            version = (version && parseInt(version, 10)) || 2;

            if (query && query._requiresCount) {
                if (data.__count || data['odata.count']) count = data.__count || data['odata.count'];
                if (data.d) data = data.d;
                if (data.__count || data['odata.count']) count = data.__count || data['odata.count'];
            }

            if (version === 3 && data.value) data = data.value;
            if (data.d) data = data.d;
            if (version < 3 && data.results) data = data.results;

            if (pvt && pvt.aggregates && pvt.aggregates.length) {
                var agg = pvt.aggregates, args = {}, fn, res = {};
                for (var i = 0; i < agg.length; i++) {
                    fn = ej.aggregates[agg[i].type];
                    if (fn)
                        res[agg[i].field + " - " + agg[i].type] = fn(data, agg[i].field);
                }
                aggregateResult = res;
            }
            if (pvt && pvt.groups && pvt.groups.length) {
                var groups = pvt.groups;
                for (var i = 0; i < groups.length; i++) {
                    var format = getColFormat(groups[i], query.queries)
                    data = ej.group(data, groups[i], pvt.aggregates, format);
                }
            }
            return isNull(count) ? data : { result: data, count: count, aggregates: aggregateResult };
        },
        convertToQueryString: function (req, query, dm) {
            var res = [], tableName = req.table || "";
            delete req.table;

            if (dm.dataSource.requiresFormat)
                req["$format"] = "json";

            for (var prop in req)
                res.push(prop + "=" + req[prop]);

            res = res.join("&");

            if (dm.dataSource.url && dm.dataSource.url.indexOf("?") !== -1 && !tableName)
                return res;

            return res.length ? tableName + "?" + res : tableName || "";
        },
        insert: function (dm, data, tableName) {
            return {
                url: dm.dataSource.url.replace(/\/*$/, tableName ? '/' + tableName : ''),
                data: JSON.stringify(data)
            }
        },
        remove: function (dm, keyField, value, tableName) {
            if(typeof(value) == "string"){
                return {
                    type: "DELETE",
                    url: ej.isGUID(value) ? dm.dataSource.url.replace(/\/*$/, tableName ? '/' + tableName : '') + "(" + value + ")" : dm.dataSource.url.replace(/\/*$/, tableName ? '/' + tableName : '') + "('" + value + "')"
                };
            }
            return {
                type: "DELETE",
                url: dm.dataSource.url.replace(/\/*$/, tableName ? '/' + tableName : '') + '(' + value + ')'
            };
        },
        update: function (dm, keyField, value, tableName) {
			var url;
			if(typeof value[keyField] === "string")
			    url = ej.isGUID(value[keyField]) ? dm.dataSource.url.replace(/\/*$/, tableName ? '/' + tableName : '') + "(" + value[keyField] + ")" : dm.dataSource.url.replace(/\/*$/, tableName ? '/' + tableName : '') + "('" + value[keyField] + "')";
			else 
				url = dm.dataSource.url.replace(/\/*$/, tableName ? '/' + tableName : '') + '(' + value[keyField] + ')';
            return {
                type: "PUT",
                url: url,
                data: JSON.stringify(value),
                accept: this.options.accept
            };
        },
        batchRequest: function (dm, changes, e) {
            var initialGuid = e.guid = ej.getGuid(oData.batchPre);
            var url = dm.dataSource.url.replace(/\/*$/, '/' + this.options.batch);
            var args = {
                url: e.url,
                key: e.key,
                cid: 1,
                cSet: ej.getGuid(oData.changeSet)
            };
            var req = "--" + initialGuid + "\n";

            req += "Content-Type: multipart/mixed; boundary=" + args.cSet.replace("--", "") + "\n";

            this.pvt.changeSet = 0;

            req += this.generateInsertRequest(changes.added, args);
            req += this.generateUpdateRequest(changes.changed, args);
            req += this.generateDeleteRequest(changes.deleted, args);

            req += args.cSet + "--\n";
            req += "--" + initialGuid + "--";

            return {
                type: "POST",
                url: url,
                contentType: "multipart/mixed; charset=UTF-8;boundary=" + initialGuid,
                data: req
            };
        },
        generateDeleteRequest: function (arr, e) {
            if (!arr) return "";
            var req = "", val;

            for (var i = 0; i < arr.length; i++) {
                req += "\n" + e.cSet + "\n";
                req += oData.changeSetContent + "\n\n";
                req += "DELETE ";
                val = typeof arr[i][e.key] == "string" ? "'" + arr[i][e.key] + "'" : arr[i][e.key];
                req += e.url + "(" + val + ") HTTP/1.1\n";
                req += "If-Match : * \n"
                req += "Accept: " + oData.accept + "\n";
                req += "Content-Id: " + this.pvt.changeSet++ + "\n";
                req += oData.batchChangeSetContentType + "\n";
            }

            return req + "\n";
        },
        generateInsertRequest: function (arr, e) {
            if (!arr) return "";
            var req = "";

            for (var i = 0; i < arr.length; i++) {
                req += "\n" + e.cSet + "\n";
                req += oData.changeSetContent + "\n\n";
                req += "POST ";
                req += e.url + " HTTP/1.1\n";
                req += "Accept: " + oData.accept + "\n";
                req += "Content-Id: " + this.pvt.changeSet++ + "\n";
                req += oData.batchChangeSetContentType + "\n\n";

                req += JSON.stringify(arr[i]) + "\n";
            }

            return req;
        },
        generateUpdateRequest: function (arr, e) {
            if (!arr) return "";
            var req = "", val;

            for (var i = 0; i < arr.length; i++) {
                req += "\n" + e.cSet + "\n";
                req += oData.changeSetContent + "\n\n";
                req += "PUT ";
                val = typeof arr[i][e.key] == "string" ? "'" + arr[i][e.key] + "'" : arr[i][e.key];
                req += e.url + "(" + val + ")" + " HTTP/1.1\n";
                req += "If-Match : * \n"
                req += "Accept: " + oData.accept + "\n";
                req += "Content-Id: " + this.pvt.changeSet++ + "\n";
                req += oData.batchChangeSetContentType + "\n\n";

                req += JSON.stringify(arr[i]) + "\n\n";
            }

            return req;
        },
        _p: function (prop) {
            return prop.replace(/\./g, "/");
        }
    });
    ej.ODataV4Adaptor = new ej.ODataAdaptor().extend({
        options: {
            requestType: "get",
            accept: "application/json;odata=light;q=1,application/json;odata=verbose;q=0.5",
            multipartAccept: "multipart/mixed",
            sortBy: "$orderby",
            select: "$select",
            skip: "$skip",
            take: "$top",
            count: "$count",
            search: "$search",
            where: "$filter",
            expand: "$expand",
            batch: "$batch",
            changeSet: "--changeset_",
            batchPre: "batch_",
            contentId: "Content-Id: ",
            batchContent: "Content-Type: multipart/mixed; boundary=",
            changeSetContent: "Content-Type: application/http\nContent-Transfer-Encoding: binary ",
            batchChangeSetContentType: "Content-Type: application/json; charset=utf-8 "
        },
        onCount: function (e) {
            return e === true ? "true" : "";
        },
        onPredicate: function (pred, query, requiresCast) {
            var returnValue = "",
                val = pred.value,
                isDate = val instanceof Date;               
            ej.data.odUniOperator["contains"] = "contains";
            returnValue = ej.ODataAdaptor.prototype.onPredicate.call(this, pred, query, requiresCast);
            ej.data.odUniOperator["contains"] = "substringof";
                if (isDate)
                    returnValue = returnValue.replace(/datetime'(.*)'$/, "$1");

            return returnValue;
        },
        onOperation: function (returnValue, operator, field, val, guid) {
            if (guid) {
                returnValue += "(" + field;
                returnValue += operator;
                returnValue += val.replace(/["']/g, "") + ")";
            } else {
                returnValue += field;
                returnValue += operator;
                returnValue += val;
            }
            return returnValue;
        },
        onEachSearch: function (e) {
			 var search = this.pvt.search || [];
			 search.push(e.key);
			 this.pvt.search = search;
		},
		onSearch: function (e) {
			 return this.pvt.search.join(" OR ");
		},
        beforeSend: function (dm, request, settings) {
 
        },
        processQuery: function (ds, query) {
            var digitsWithSlashesExp = /\/[\d*\/]*/g;
            var poppedExpand = "";
            for (var i = query._expands.length - 1; i > 0; i--) {
                if (poppedExpand.indexOf(query._expands[i]) >= 0) { // If current expand is child of previous
                    query._expands.pop(); // Just remove it because its in the expand already
                }
                else {
                    if (digitsWithSlashesExp.test(query._expands[i])) { //If expanded to subentities
                        poppedExpand = query._expands.pop();
                        var r = poppedExpand.replace(digitsWithSlashesExp, "($expand="); //Rewrite into odata v4 expand
                        for (var j = 0; j < poppedExpand.split(digitsWithSlashesExp).length - 1; j++) {
                            r = r + ")"; // Add closing brackets
                        }
                        query._expands.unshift(r); // Add to the front of the array
                        i++;
                    }
                }
            }
            return ej.ODataAdaptor.prototype.processQuery.apply(this, [ds, query]);
        },
        processResponse: function (data, ds, query, xhr, request, changes) {
            var pvt = request && request.ejPvtData;
            if (xhr && xhr.getResponseHeader("Content-Type") && xhr.getResponseHeader("Content-Type").indexOf("xml") != -1 && data.nodeType == 9)
                return query._requiresCount ? { result: [], count: 0 } : [];
            if (request && this.options.batch && request.url.endsWith(this.options.batch) && request.type.toLowerCase() === "post") {
                var guid = xhr.getResponseHeader("Content-Type"), cIdx, jsonObj;
                guid = guid.substring(guid.indexOf("=batchresponse") + 1);
                data = data.split(guid);
                if (data.length < 2) return;

                data = data[1];
                var exVal = /(?:\bContent-Type.+boundary=)(changesetresponse.+)/i.exec(data);
                data.replace(exVal[0], "");

                var changeGuid = exVal[1];
                data = data.split(changeGuid);

                for (var i = data.length; i > -1; i--) {
                   if (!/\bContent-ID:/i.test(data[i]) || !/\bHTTP.+201/.test(data[i]))
                        continue;

                    cIdx = parseInt(/\bContent-ID: (\d+)/i.exec(data[i])[1]);

                    if (changes.added[cIdx]) {
                        jsonObj = p.parseJson(/^\{.+\}/m.exec(data[i])[0]);
                        $.extend(changes.added[cIdx], this.processResponse(jsonObj));
                    }
                }
                return changes;
           }
            var count = null, aggregateResult = {};
            if (query && query._requiresCount)
                if ('@odata.count' in data) count = data['@odata.count'];

            data = ej.isNullOrUndefined(data.value) ? data : data.value;
           if (pvt && pvt.aggregates && pvt.aggregates.length) {
               var agg = pvt.aggregates, args = {}, fn, res = {};
               for (var i = 0; i < agg.length; i++) {
                   fn = ej.aggregates[agg[i].type];
                   if (fn)
                       res[agg[i].field + " - " + agg[i].type] = fn(data, agg[i].field);
               }
               aggregateResult = res;
           }
            if (pvt && pvt.groups && pvt.groups.length) {
                var groups = pvt.groups;
                for (var i = 0; i < groups.length; i++) {
                    var format = getColFormat(groups[i], query.queries);
                    data = ej.group(data, groups[i], pvt.aggregates, format);
                }
            }
            return isNull(count) ? data : { result: data, count: count, aggregates: aggregateResult };
        },
    });
    ej.JsonAdaptor = new ej.Adaptor().extend({
        processQuery: function (ds, query) {
            var result = ds.dataSource.json.slice(0), count = result.length, cntFlg = true, ret, key, agg = {};

            for (var i = 0; i < query.queries.length; i++) {
                key = query.queries[i];
                ret = this[key.fn].call(this, result, key.e, query);
                if (key.fn == "onAggregates")
                    agg[key.e.field + " - " + key.e.type] = ret;
                else
                result = ret !== undefined ? ret : result;

                if (key.fn === "onPage" || key.fn === "onSkip" || key.fn === "onTake" || key.fn === "onRange") cntFlg = false;

                if (cntFlg) count = result.length;
            }

            if (query._requiresCount) {
                result = {
                    result: result,
                    count: count,
                    aggregates: agg
                };
            }

            return result;
        },
        batchRequest: function (dm, changes, e) {
            var i;
            for (i = 0; i < changes.added.length; i++)
                this.insert(dm, changes.added[i]);
            for (i = 0; i < changes.changed.length; i++)
                this.update(dm, e.key, changes.changed[i]);
            for (i = 0; i < changes.deleted.length; i++)
                this.remove(dm, e.key, changes.deleted[i]);
            return changes;
        },
        onWhere: function (ds, e) {
            if (!ds) return ds;

            return ds.filter(function (obj) {
                return e.validate(obj);
            });
        },
        onAggregates: function(ds, e){
            var fn = ej.aggregates[e.type];
            if (!ds || !fn || ds.length == 0) return null;
            return fn(ds, e.field);
        },
        onSearch: function (ds, e) {
            if (!ds || !ds.length) return ds;

            if (e.fieldNames.length === 0) {
                ej.pvt.getFieldList(ds[0], e.fieldNames);
            }

            return ds.filter(function (obj) {
                for (var j = 0; j < e.fieldNames.length; j++) {
                    if (e.comparer.call(obj, ej.pvt.getObject(e.fieldNames[j], obj), e.searchKey, e.ignoreCase,e.ignoreAccent))
                        return true;
                }
                return false;
            });
        },
        onSortBy: function (ds, e, query) {
            if (!ds) return ds;
            var fnCompare, field = getValue(e.fieldName, query);
            if (!field)
                return ds.sort(e.comparer);

            if (field instanceof Array) {
                field = field.slice(0);

                for (var i = field.length - 1; i >= 0; i--) {
                    if (!field[i]) continue;

                    fnCompare = e.comparer;

                    if (field[i].endsWith(" desc")) {
                        fnCompare = ej.pvt.fnSort(ej.sortOrder.Descending);
                        field[i] = field[i].replace(" desc", "");
                    }

                    ds = stableSort(ds, field[i], fnCompare, []);
                }
                return ds;
            }
            return stableSort(ds, field, e.comparer, query ? query.queries : []);
        },
        onGroup: function (ds, e, query) {
            if (!ds) return ds;
            var aggQuery = filterQueries(query.queries, "onAggregates"), agg = [];
            if (aggQuery.length) {
                var tmp;
                for (var i = 0; i < aggQuery.length; i++) {
                    tmp = aggQuery[i].e;
                    agg.push({ type: tmp.type, field: getValue(tmp.field, query) });
                }
            }
            var format = getColFormat(e.fieldName, query.queries);
            return ej.group(ds, getValue(e.fieldName, query), agg, format);
        },
        onPage: function (ds, e, query) {
            var size = getValue(e.pageSize, query),
                start = (getValue(e.pageIndex, query) - 1) * size, end = start + size;

            if (!ds) return ds;

            return ds.slice(start, end);
        },
        onRange: function (ds, e) {
            if (!ds) return ds;
            return ds.slice(getValue(e.start), getValue(e.end));
        },
        onTake: function (ds, e) {
            if (!ds) return ds;

            return ds.slice(0, getValue(e.nos));
        },
        onSkip: function (ds, e) {
            if (!ds) return ds;
            return ds.slice(getValue(e.nos));
        },
        onSelect: function (ds, e) {
            if (!ds) return ds;
            return ej.select(ds, getValue(e.fieldNames));
        },
        insert: function (dm, data) {
            return dm.dataSource.json.push(data);
        },
        remove: function (dm, keyField, value, tableName) {
            var ds = dm.dataSource.json, i;
            if (typeof value === "object")
                value = ej.getObject(keyField, value);
            for (i = 0; i < ds.length; i++) {
                if (ej.getObject(keyField, ds[i]) === value) break;
            }

            return i !== ds.length ? ds.splice(i, 1) : null;
        },
        update: function (dm, keyField, value, tableName) {
            var ds = dm.dataSource.json, i, key = ej.getObject(keyField, value);

            for (i = 0; i < ds.length; i++) {
                if (ej.getObject(keyField, ds[i]) === key) break;
            }

            return i < ds.length ? $.extend(ds[i], value) : null;
        }
    });
    ej.ForeignKeyAdaptor = function (data, type) {
        var foreignObj = new ej[type || "JsonAdaptor"]().extend({
            init: function () {
                this.foreignData = [];
                this.key = [];
                this.adaptorType = type;
                this.value = [];
                this.fValue = [];
                this.keyField = [];
                var dataObj = data;
                for (var i = 0; i < dataObj.length; i++) {
                    this.foreignData[i] = dataObj[i].dataSource;
                    this.key[i] = dataObj[i].foreignKeyField;
                    this.fValue[i] = ej.isNullOrUndefined(dataObj[i].field)? dataObj[i].foreignKeyValue : dataObj[i].field + "_" + dataObj[i].foreignKeyValue;
                    this.value[i] = dataObj[i].foreignKeyValue;
                    this.keyField[i] = dataObj[i].field || dataObj[i].foreignKeyField;
                    this.initial = true;
                }
            },
            processQuery: function (ds, query) {
                var data = ds.dataSource.json;
                if (this.initial) {
                    for (var i = 0; i < data.length; i++) {
                        var proxy = this;
                        for (var j = 0; j < this.foreignData.length; j++) {
                            this.foreignData[j].filter(function (col) { //filtering the foreignKey dataSource
                                if (ej.getObject(proxy.key[j], col) == ej.getObject(proxy.keyField[j], data[i]))
                                    data[i][proxy.fValue[j]] = ej.getObject(proxy.value[j], col);
                            });
                        }
                    }
                    this.initial = false;
                }
                return this.base.processQuery.apply(this, [ds, query]);
            },
            setValue: function (value) {
                for (var i = 0; i < this.foreignData.length; i++) {
                    var proxy = this;
                    var keyValue = value[this.fValue[i]];
                    if (typeof keyValue == "string" && !isNaN(keyValue))
                        keyValue = ej.parseFloat(keyValue);
                    var data = $.grep(proxy.foreignData[i], function (e) {
                        return e[proxy.value[i]] == keyValue;
                    })[0];
                    if (ej.isNullOrUndefined(data)) {
                        data = $.grep(proxy.foreignData[i], function (e) {
                            return e[proxy.key[i]] == keyValue;
                        })[0];
                        if (ej.getObject(this.value[i], data) != undefined)
                            ej.createObject(proxy.value[i], ej.getObject(this.value[i], data), value);
                    }
                    if (ej.getObject(this.value[i], data) != undefined)
                        ej.createObject(this.keyField[i], ej.getObject(this.key[i], data), value);
                }
            },
            insert: function (dm, data, tableName) {
                this.setValue(data);
                return {
                    url: dm.dataSource.insertUrl || dm.dataSource.crudUrl || dm.dataSource.url,
                    data: JSON.stringify({
                        value: data,
                        table: tableName,
                        action: "insert",
                        antiForgery: (dm.dataSource.antiForgery) ? dm.antiForgeryToken().value : ""
                    })
                };
            },
            update: function (dm, keyField, value, tableName) {
                this.setValue(value);
                ej.JsonAdaptor.prototype.update(dm, keyField, value, tableName);
                return {
                    type: "POST",
                    url: dm.dataSource.updateUrl || dm.dataSource.crudUrl || dm.dataSource.url,
                    data: JSON.stringify({
                        value: value,
                        action: "update",
                        keyColumn: keyField,
                        key: value[keyField],
                        table: tableName,
                        antiForgery: (dm.dataSource.antiForgery) ? dm.antiForgeryToken().value : ""
                    })
                };
            }
        });
        $.extend(this, new foreignObj());
        return this;
    }
    ej.remoteSaveAdaptor = new ej.JsonAdaptor().extend({
        beforeSend: ej.UrlAdaptor.prototype.beforeSend,
        insert: ej.UrlAdaptor.prototype.insert,
        update: ej.UrlAdaptor.prototype.update,
        remove: ej.UrlAdaptor.prototype.remove,
        addParams: ej.UrlAdaptor.prototype.addParams,
        batchRequest: function (dm, changes, e, query) { 
			var res = {
                changed: changes.changed,
                added: changes.added,
                deleted: changes.deleted,
                action: "batch",
                table: e.url,
                key: e.key,
                antiForgery: (dm.dataSource.antiForgery) ? dm.antiForgeryToken().value : ""
            };
            if (query)
                this.addParams({ dm: dm, query: query, params: query._params, reqParams: res });
            return {
                type: "POST",
                url: dm.dataSource.batchUrl || dm.dataSource.crudUrl || dm.dataSource.url,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify(res)
            };
        },
        processResponse: function (data, ds, query, xhr, request, changes, key) {
            if(!ej.isNullOrUndefined(changes)){
            if (data.d)
                data = data.d;
            if(data.added)changes.added = ej.parseJSON(data.added);
            if(data.changed)changes.changed = ej.parseJSON(data.changed);
            if(data.deleted)changes.deleted = ej.parseJSON(data.deleted);
            var i;
            for (i = 0; i < changes.added.length; i++)
                ej.JsonAdaptor.prototype.insert(ds, changes.added[i]);
            for (i = 0; i < changes.changed.length; i++)
                ej.JsonAdaptor.prototype.update(ds, key, changes.changed[i]);
            for (i = 0; i < changes.deleted.length; i++)
                ej.JsonAdaptor.prototype.remove(ds, key, changes.deleted[i]);
            return data;
             }
            else{
                if (data.d)
               return data.d;
            return data;
            }
        }
    });
    ej.WebApiAdaptor = new ej.ODataAdaptor().extend({
        insert: function (dm, data, tableName) {
            return {
                type: "POST",
                url: dm.dataSource.url,
                data: JSON.stringify(data)
            };
        },
        remove: function (dm, keyField, value, tableName) {
            return {
                type: "DELETE",
                url: dm.dataSource.url + "/" + value,
                data: JSON.stringify(value)
            };
        },
        update: function (dm, keyField, value, tableName) {
            return {
                type: "PUT",
                url: dm.dataSource.url,
                data: JSON.stringify(value)
            };
        },
		batchRequest: function (dm, changes, e) {
            var initialGuid = e.guid = ej.getGuid(oData.batchPre);
            var req = [];

		    //insertion 
		
			$.each(changes.added, function (i, d) {
			    req.push('--' + initialGuid);
			    req.push('Content-Type: application/http; msgtype=request', '');
			    req.push('POST' + ' ' + dm.dataSource.insertUrl + ' HTTP/1.1');
			    req.push('Content-Type: ' + 'application/json; charset=utf-8');
			    req.push('Host: ' + location.host);
			    req.push('', d ? JSON.stringify(d) : '');
			});
			
			//updation
			$.each(changes.changed, function (i, d) {
			    req.push('--' + initialGuid);
			    req.push('Content-Type: application/http; msgtype=request', '');
			    req.push('PUT' + ' ' + dm.dataSource.updateUrl + ' HTTP/1.1');
			    req.push('Content-Type: ' + 'application/json; charset=utf-8');
			    req.push('Host: ' + location.host);
			    req.push('', d ? JSON.stringify(d) : '');
			});
			
			//deletion
			$.each(changes.deleted, function (i, d) {
			    req.push('--' + initialGuid);
                req.push('Content-Type: application/http; msgtype=request', '');
                req.push('DELETE' + ' ' + dm.dataSource.removeUrl +"/"+ d[e.key] + ' HTTP/1.1');
                req.push('Content-Type: ' + 'application/json; charset=utf-8');
                req.push('Host: ' + location.host);
                req.push('', d ? JSON.stringify(d) : '');		
			});
			req.push('--' + initialGuid + '--', '');
            return {
				type: 'POST',
				url: dm.dataSource.batchUrl || dm.dataSource.crudUrl || dm.dataSource.url,
                data: req.join('\r\n'),
                contentType: 'multipart/mixed; boundary="' + initialGuid + '"',
            };
        },
        processResponse: function (data, ds, query, xhr, request, changes) {

            var pvt = request && request.ejPvtData;
            if (request && request.type.toLowerCase() != "post") {
                var version = xhr && xhr.getResponseHeader("DataServiceVersion"), count = null, aggregateResult = {};
                version = (version && parseInt(version, 10)) || 2;

                if (query && query._requiresCount) {
                     if (!isNull(data.Count)) count = data.Count;
                }

                if (version < 3 && data.Items) data = data.Items;

                if (pvt && pvt.aggregates && pvt.aggregates.length) {
                    var agg = pvt.aggregates, args = {}, fn, res = {};
                    for (var i = 0; i < agg.length; i++) {
                        fn = ej.aggregates[agg[i].type];
                        if (fn)
                            res[agg[i].field + " - " + agg[i].type] = fn(data, agg[i].field);
                    }
                    aggregateResult = res;
                }
                if (pvt && pvt.groups && pvt.groups.length) {
                    var groups = pvt.groups;
                    for (var i = 0; i < groups.length; i++) {
                        var format = getColFormat(groups[i], query.queries);
                        data = ej.group(data, groups[i], pvt.aggregates, format);
                    }
                }
                return isNull(count) ? data : { result: data, count: count, aggregates: aggregateResult };
            }
        }
    });
    var getValue = function (value, inst) {
        if (typeof value === "function")
            return value.call(inst || {});
        return value;
    }

    ej.TableModel = function (name, jsonArray, dataManager, modelComputed) {
        if (!instance(this, ej.TableModel))
            return new ej.TableModel(jsonArray);

        if (!instance(jsonArray, Array))
            throwError("ej.TableModel - Json Array is required");

        var rows = [], model, dirtyFn = $proxy(setDirty, this);

        for (var i = 0; i < jsonArray.length; i++) {
            model = new ej.Model(jsonArray[i], this);
            model.state = "unchanged";
            model.on("stateChange", dirtyFn);
            if (modelComputed)
                model.computes(modelComputed);
            rows.push(model);
        }

        this.name = name || "table1";

        this.rows = ej.NotifierArray(rows);
        this._deleted = [];

        this._events = $({});

        this.dataManager = dataManager;

        this._isDirty = false;

        return this;
    };

    ej.TableModel.prototype = {
        on: function (eventName, handler) {
            this._events.on(eventName, handler);
        },

        off: function (eventName, handler) {
            this._events.off(eventName, handler);
        },

        setDataManager: function (dataManager) {
            this.dataManagar = dataManager;
        },

        saveChanges: function () {
            if (!this.dataManager || !instance(this.dataManager, ej.DataManager))
                throwError("ej.TableModel - saveChanges : Set the dataManager using setDataManager function");

            if (!this.isDirty())
                return;

            var promise = this.dataManager.saveChanges(this.getChanges(), this.key, this.name);

            promise.done($proxy(function (changes) {
                var rows = this.toArray();
                for (var i = 0; i < rows.length; i++) {
                    if (rows.state === "added") {
                        rows.set(this.key, changes.added.filter(function (e) {
                            return e[this.key] === rows.get(this.key);
                        })[0][this.key]);
                    }
                    rows[i].markCommit();
                }

                this._events.triggerHandler({ type: "save", table: this });

            }, this));

            promise.fail($proxy(function (e) {
                this.rejectChanges();
                this._events.triggerHandler({ type: "reject", table: this, error: e });
            }, this));

            this._isDirty = false;
        },

        rejectChanges: function () {
            var rows = this.toArray();
            for (var i = 0; i < rows.length; i++)
                rows[i].revert(true);

            this._isDirty = false;
            this._events.triggerHandler({ type: "reject", table: this });
        },

        insert: function (json) {
            var model = new ej.Model(json);
            model._isDirty = this._isDirty = true;

            this.rows.push(model);

            this._events.triggerHandler({ type: "insert", model: model, table: this });
        },

        update: function (value) {
            if (!this.key)
                throwError("TableModel - update : Primary key should be assigned to TableModel.key");

            var row = value, model, key = this.key, keyValue = row[key];

            model = this.rows.array.filter(function (obj) {
                return obj.get(key) === keyValue;
            });

            model = model[0];

            for (var col in row) {
                model.set(col, row[col]);
            }

            this._isDirty = true;

            this._events.triggerHandler({ type: "update", model: model, table: this });
        },

        remove: function (key) {
            if (!this.key)
                throwError("TableModel - update : Primary key should be assigned to TableModel.key");

            var field = this.key;

            var index = -1, model;

            if (key && typeof key === "object") {
                key = key[field] !== undefined ? key[field] : key.get(field);
            }

            for (var i = 0; i < this.rows.length() ; i++) {
                if (this.rows.array[i].get(field) === key) {
                    index = i;
                    break;
                }
            }

            if (index > -1) {
                model = this.rows.removeAt(index);
                model.markDelete();

                this._deleted.push({ model: model, position: index });

                this._isDirty = true;
                this._events.triggerHandler({ type: "remove", model: model, table: this });
            }
        },

        isDirty: function () {
            return this._isDirty;
        },

        getChanges: function () {

            var changes = {
                added: [],
                changed: []
            };
            var rows = this.toArray();
            for (var i = 0; i < rows.length; i++) {
                if (changes[rows[i].state])
                    changes[rows[i].state].push(rows[i].json);
            }

            changes.deleted = ej.select(this._deleted, ["model"]);

            return changes;
        },

        toArray: function () {
            return this.rows.toArray();
        },

        setDirty: function (dirty, model) {
            if (this._isDirty === !!dirty) return;

            this._isDirty = !!dirty;

            this._events.triggerHandler({ type: "dirty", table: this, model: model });
        },
        get: function (index) {
            return this.rows.array[index];
        },
        length: function () {
            return this.rows.array.length;
        },

        bindTo: function (element) {
            var marker = tDiv, template = $(element.html()), rows = this.toArray(), cur;
            if ($.inArray(element.prop("tagName").toLowerCase(), ["table", "tbody"]))
                marker = tTR;

            marker.insertBefore(element);
            element.detach().empty();

            for (var i = 0; i < rows.length; i++) {
                cur = template.clone();
                rows[i].bindTo(cur);
                element.append(cur);
            }

            element.insertAfter(marker);
            marker.remove();
        }
    };

    var tDiv = doc ? $(document.createElement("div")) : {},
        tTR = doc ? $(document.createElement("tr")) : {};

    ej.Model = function (json, table, name) {
        if (typeof table === "string") {
            name = table;
            table = null;
        }
        this.$id = getUid("m");

        this.json = json;
        this.table = table instanceof ej.TableModel ? table : null;
        this.name = name || (this.table && this.table.name);
        this.dataManager = (table instanceof ej.DataManager) ? table : table.dataManagar;
        this.actual = {};
        this._events = $({});
        this.isDirty = false;
        this.state = "added";
        this._props = [];
        this._computeEls = {};
        this._fields = {};
        this._attrEls = {};
        this._updates = {};
        this.computed = {};
    };

    ej.Model.prototype = {
        computes: function (value) {
            $.extend(this.computed, value);
        },
        on: function (eventName, handler) {
            this._events.on(eventName, handler);
        },
        off: function (eventName, handler) {
            this._events.off(eventName, handler);
        },
        set: function (field, value) {
            var obj = this.json, actual = field, prev;
            field = field.split('.');

            for (var i = 0; i < field.length - 1; i++) {
                field = field[0];
                obj = obj[field[0]];
            }

            this.isDirty = true;
            this.changeState("changed", { from: "set" });

            prev = obj[field];

            if (this.actual[field] === undefined && !(field in this.actual))
                this.actual[field] = value; // Complex property ?

            obj[field] = value;

            this._updateValues(field, value);
            this._events.triggerHandler({ type: actual, current: value, previous: prev, model: this });
        },
        get: function (field) {
            return ej.pvt.getObject(field, this.json);
        },
        revert: function (suspendEvent) {
            for (var prop in this.actual) {
                this.json[prop] = this.actual[prop];
            }

            this.isDirty = false;

            if (suspendEvent)
                this.state = "unchanged";
            else
                this.changeState("unchanged", { from: "revert" });
        },
        save: function (dm, key) {
            dm = dm || this.dataManagar;
            key = key || dm.dataSource.key;
            if (!dm) throwError("ej.Model - DataManager is required to commit the changes");
            if (this.state === "added") {
                return dm.insert(this.json, this.name).done(ej.proxy(function (e) {
                    $.extend(this.json, e.record);
                }, this));
            }
            else if (this.state === "changed") {
                return dm.update(key, this.json, this.name);
            }
            else if (this.state === "deleted") {
                return dm.remove(key, this.json, this.name);
            }
        },
        markCommit: function () {
            this.isDirty = false;
            this.changeState("unchanged", { from: "commit" });
        },
        markDelete: function () {
            this.changeState("deleted", { from: "delete" });
        },
        changeState: function (state, args) {
            if (this.state === state) return;

            if (this.state === "added") {
                if (state === "deleted")
                    state = "unchanged";
                else return;
            }

            var prev = state;
            args = args || {};

            this.state = state;
            this._events.triggerHandler($.extend({ type: "stateChange", current: state, previous: prev, model: this }, args));
        },
        properties: function () {
            if (this._props.length)
                return this._props;

            for (var pr in this.json) {
                this._props.push(pr);
                this._updates[pr] = { read: [], input: [] };
            }

            return this._props;
        },
        bindTo: function (element) {
            var el = $(element), ctl, field,
                elements = el.find("[ej-observe], [ej-computed], [ej-prop]"), len = elements.length;

            el.data("ejModel", this);
            var unbindData = { fields: [], props: [], computes: [] };
            for (var i = 0; i < len; i++) {
                ctl = elements.eq(i);

                field = ctl.attr("ej-prop");
                if (field) {
                    this._processAttrib(field, ctl, unbindData);
                }
                field = ctl.attr("ej-observe");
                if (field && this._props.indexOf(field) !== -1) {
                    this._processField(ctl, field, unbindData);
                    continue;
                }

                field = ctl.attr("ej-computed");
                if (field) {
                    this._processComputed(field, ctl, unbindData);
                    continue;
                }
            }
            el.data("ejModelBinding" + this.$id, unbindData);
        },
        unbind: function (element) {
            var tmp, data = {
                props: this._attrEls,
                computes: this._computeEls
            }, isCustom = false;

            if (element) {
                data = $(element).removeData("ejModel").data("ejModelBinding" + this.$id) || data;
                isCustom = true;
            }

            for (var p in this.computed) {
                tmp = data.computes[p], p = this.computed[p];
                if (tmp && p.deps) {
                    this.off(p.deps.join(' '), tmp.handle);
                    if (isCustom)
                        delete this._computeEls[p];
                }
            }
            if (!isCustom)
                this._computeEls = {};

            for (var p in data.props) {
                tmp = data.props[p];
                if (tmp) {
                    this.off(tmp.deps.join(' '), tmp.handle);
                    delete data.props[p];
                    if (isCustom)
                        delete this._attrEls[p];
                }
            }
            if (!isCustom)
                this._attrEls = {};

            if (data.fields && data.fields.length) {
                var len = data.fields.length, ctl, idx, ty;
                for (var i = 0; i < len; i++) {
                    ctl = data.fields[i];
                    $(ctl).off("change", null, this._changeHandler);

                    ty = this.formElements.indexOf(ctl.tagName.toLowerCase()) !== -1 ? "input" : "read";
                    idx = this._updates[ty].indexOf(ctl);
                    if (idx !== -1)
                        this._updates[ty].splice(idx, 1);
                }
            }
        },
        _processComputed: function (value, element, data) {
            if (!value) return;

            var val, deps, safeVal = safeStr(value),
            type = this.formElements.indexOf(element[0].tagName.toLowerCase()) !== -1 ? "val" : "html";

            if (!this.computed[value] || !this.computed[safeVal]) {
                this.computed[safeVal] = {
                    value: new Function("var e = this; return " + value),
                    deps: this._generateDeps(value)
                }
                value = safeVal;
            }

            val = this.computed[value];
            if (!val.get) {
                val.get = function () {
                    val.value.call(this.json);
                }
            }

            deps = val.deps;
            val = val.value;

            this._updateDeps(deps);
            this._updateElement(element, type, val);

            val = { el: element, handle: $proxy(this._computeHandle, this, { value: value, type: type }) };
            this._computeEls[value] = val;
            data.computes[value] = val;

            this.on(deps.join(' '), val.handle);
        },
        _computeHandle: function (e) {
            var el = this._computeEls[e.value];
            if (el && this.computed[e.value])
                this._updateElement(el.el, e.type, this.computed[e.value].value);
        },
        _updateElement: function (el, type, val) {
            el[type](val.call($.extend({}, this.json, this.computed)));
        },
        _updateDeps: function (deps) {
            for (var i = 0; i < deps.length; i++) {
                if (!(deps[i] in this.json) && deps[i] in this.computed)
                    ej.merge(deps, this.computed[deps[i]].deps);
            }
        },
        _generateDeps: function (value) {
            var splits = value.replace(/(^e\.)|( e\.)/g, '#%^*##ej.#').split("#%^*#"),
                field, deps = [];

            for (var i = 0; i < splits.length; i++) {
                if (splits[i].startsWith("#ej.#")) {
                    field = splits[i].replace("#ej.#", "").split(' ')[0];
                    if (field && this._props.indexOf(field) !== -1)
                        deps.push(field);
                }
            }

            return deps;
        },
        _processAttrib: function (value, el, data) {
            var prop, val, res = {};
            value = value.replace(/^ +| +$/g, "").split(";");
            for (var i = 0; i < value.length; i++) {
                value[i] = value[i].split(":");
                if (value[i].length < 2) continue;

                prop = value[i][0].replace(/^ +| +$/g, "").replace(/^'|^"|'$|"$/g, "");
                res[prop] = value[i][1].replace(/^ +| +$/g, "").replace(/^'|^"|'$|"$/g, "");
            }
            value = res;
            var deps = [];
            for (prop in value)
                deps.push(value[prop]);

            this._updateDeps(deps);
            this._updateProps(el, value);

            res = getUid("emak");
            val = { el: el, handle: $proxy(this._attrHandle, this, res), value: value, deps: deps };
            el.prop("ejmodelattrkey", res);

            data.props[res] = val;
            this._attrEls[res] = val;

            this.on(deps.join(' '), val.handle);
        },
        _attrHandle: function (res) {
            var el = this._attrEls[res];
            if (el)
                this._updateProps(el.el, el.value);
        },
        _updateProps: function (element, value) {
            var json = this.json, t, c = this.computed;
            for (var prop in value) {
                t = value[prop];
                if (t in json)
                    t = json[t];
                else if (t in c) {
                    t = c[t];
                    if (t) {
                        t = t.value.call($.extend({}, this.json, c));
                    }
                }

                if (!isNull(t)) {
                    element.prop(prop, t);
                }
            }
        },
        _updateValues: function (prop, value) {
            var arr = this._updates[prop];

            if (!arr || (!arr.read && !arr.input)) return;

            this._ensureItems(arr.read, "html", value);
            this._ensureItems(arr.input, "val", value);
        },
        _ensureItems: function (a, type, value) {
            if (!a) return;

            for (var i = a.length - 1; i > -1; i--) {
                if (!a[i].offsetParent) {
                    a.splice(i, 1);
                    continue;
                }
                $(a[i])[type](value);
            }
        },
        _changeHandler: function (e) {
            e.data.self.set(e.data.prop, $(this).val());
        },
        _processField: function (ctl, field, data) {
            var e = { self: this, prop: field }, val = this.get(field);

            data.fields.push(ctl[0]);

            if (this.formElements.indexOf(ctl[0].tagName.toLowerCase()) === -1) {
                ctl.html(val);
                return this._updates[field].read.push(ctl[0]);
            }

            ctl.val(val)
                    .off("change", null, this._changeHandler)
                    .on("change", null, e, this._changeHandler);

            return this._updates[field].input.push(ctl[0]);
        },
        formElements: ["input", "select", "textarea"]
    };

    var safeReg = /[^\w]+/g;
    var safeStr = function (value) {
        return value.replace(safeReg, "_");
    };
    var setDirty = function (e) {
        this.setDirty(true, e.model);
    };

    ej.Predicate = function (field, operator, value, ignoreCase, ignoreAccent) {
        if (!(this instanceof ej.Predicate))
            return new ej.Predicate(field, operator, value, ignoreCase,ignoreAccent);

        this.ignoreAccent = false;

        if (typeof field === "string") {
			var checkAny = "";
			if(operator.toLowerCase().indexOf(" any") != -1) {
				operator = operator.replace(" any","");
				checkAny = "any";
			} 
			else if(operator.toLowerCase().indexOf(" all") != -1) {
				operator = operator.replace(" all","");
				checkAny = "all";
			} 
            this.field = field;
            this.operator = operator;
            this.value = value;
            this.ignoreCase = ignoreCase;
            this.ignoreAccent = ignoreAccent;
            this.isComplex = false;
			this.anyCondition = checkAny;

            this._comparer = ej.data.fnOperators.processOperator(checkAny != "" ? checkAny:this.operator);

        } else if (field instanceof ej.Predicate && value instanceof ej.Predicate || value instanceof Array) {
            this.isComplex = true;
            this.condition = operator.toLowerCase();
            this.predicates = [field];
            if (value instanceof Array)
                [].push.apply(this.predicates, value);
            else
                this.predicates.push(value);
        }
        return this;
    };

    ej.Predicate.and = function () {
        return pvtPredicate._combinePredicates([].slice.call(arguments, 0), "and");
    };

    ej.Predicate.or = function () {
        return pvtPredicate._combinePredicates([].slice.call(arguments, 0), "or");
    };

    ej.Predicate.fromJSON = function (json) {
        if (instance(json, Array)) {
            var res = [];
            for (var i = 0, len = json.length; i < len; i++)
                res.push(pvtPredicate._fromJSON(json[i]));
            return res;
        }

        return pvtPredicate._fromJSON(json);
    };

    // Private fn
    var pvtPredicate = {
        _combinePredicates: function (predicates, operator) {
            if (!predicates.length) return undefined;
            if (predicates.length === 1) {
                if (!instance(predicates[0], Array))
                    return predicates[0];
                predicates = predicates[0];
            }
            return new ej.Predicate(predicates[0], operator, predicates.slice(1));
        },

        _combine: function (pred, field, operator, value, condition, ignoreCase, ignoreAccent) {
            if (field instanceof ej.Predicate)
                return ej.Predicate[condition](pred, field);

            if (typeof field === "string")
                return ej.Predicate[condition](pred, new ej.Predicate(field, operator, value, ignoreCase,ignoreAccent));

            return throwError("Predicate - " + condition + " : invalid arguments");
        },

        _fromJSON: function (json) {

            if (!json || instance(json, ej.Predicate))
                return json;

            var preds = json.predicates || [], len = preds.length, predicates = [], result;

            for (var i = 0; i < len; i++)
                predicates.push(pvtPredicate._fromJSON(preds[i]));                     

            if(!json.isComplex)
                result = new ej.Predicate(json.field, json.operator, ej.parseJSON({ val: json.value }).val, json.ignoreCase,json.ignoreAccent);
            else
                result = new ej.Predicate(predicates[0], json.condition, predicates.slice(1));

            return result;
        }
    };

    ej.Predicate.prototype = {
        and: function (field, operator, value, ignoreCase,ignoreAccent) {
            return pvtPredicate._combine(this, field, operator, value, "and", ignoreCase,ignoreAccent);
        },
        or: function (field, operator, value, ignoreCase,ignoreAccent) {
            return pvtPredicate._combine(this, field, operator, value, "or", ignoreCase,ignoreAccent);
        },
        validate: function (record) {
            var p = this.predicates, isAnd, ret;

            if (!this.isComplex) {
                return this._comparer.call(this, ej.pvt.getObject(this.field, record), this.value, this.ignoreCase,this.ignoreAccent);
            }

            isAnd = this.condition === "and";

            for (var i = 0; i < p.length; i++) {
                ret = p[i].validate(record);
                if (isAnd) {
                    if (!ret) return false;
                } else {
                    if (ret) return true;
                }
            }

            return isAnd;
        },
        toJSON: function () {
            var predicates, p;
            if (this.isComplex) {
                predicates = [], p = this.predicates;
                for (var i = 0; i < p.length; i++)
                    predicates.push(p[i].toJSON());
            }
            return {
                isComplex: this.isComplex,
                field: this.field,
                operator: this.operator,
                value: this.value,
                ignoreCase: this.ignoreCase,
                ignoreAccent: this.ignoreAccent,
                condition: this.condition,
                predicates: predicates,
				anyCondition: this.anyCondition
            }
        }
    };

    ej.dataUtil = {
        swap: function (array, x, y) {
            if (x == y) return;

            var tmp = array[x];
            array[x] = array[y];
            array[y] = tmp;
        },

        mergeSort: function (jsonArray, fieldName, comparer) {
            if (!comparer || typeof comparer === "string")
                comparer = ej.pvt.fnSort(comparer, true);

            if (typeof fieldName === "function") {
                comparer = fieldName;
                fieldName = null;
            }

            return ej.pvt.mergeSort(jsonArray, fieldName, comparer);
        },

        max: function (jsonArray, fieldName, comparer) {
            if (typeof fieldName === "function") {
                comparer = fieldName;
                fieldName = null;
            }

            return ej.pvt.getItemFromComparer(jsonArray, fieldName, comparer || ej.pvt.fnDescending);
        },

        min: function (jsonArray, fieldName, comparer) {
            if (typeof fieldName === "function") {
                comparer = fieldName;
                fieldName = null;
            }

            return ej.pvt.getItemFromComparer(jsonArray, fieldName, comparer || ej.pvt.fnAscending);
        },

        distinct: function (json, fieldName, requiresCompleteRecord) {
            var result = [], val, tmp = {};
            for (var i = 0; i < json.length; i++) {
                val = getVal(json, fieldName, i);
                if (!(val in tmp)) {
                    result.push(!requiresCompleteRecord ? val : json[i]);
                    tmp[val] = 1;
                }
            }
            return result;
        },

        sum: function (json, fieldName) {
            var result = 0, val, castRequired = typeof getVal(json, fieldName, 0) !== "number";

            for (var i = 0; i < json.length; i++) {
                val = getVal(json, fieldName, i);
                if (!isNaN(val) && val !== null) {
                    if (castRequired)
                       val = +val;
                   result += val;
                }
            }
            return result;
        },

        avg: function (json, fieldName) {
            return ej.sum(json, fieldName) / json.length;
        },

        select: function (jsonArray, fields) {
            var newData = [];

            for (var i = 0; i < jsonArray.length; i++) {
                newData.push(ej.pvt.extractFields(jsonArray[i], fields));
            }

            return newData;
        },

        group: function (jsonArray, field, agg, format,/* internal */ level,groupDs) {
            level = level || 1;

            if (jsonArray.GROUPGUID == ej.pvt.consts.GROUPGUID) {
                for (var j = 0; j < jsonArray.length; j++) {
                    if(!ej.isNullOrUndefined(groupDs)){
                        var indx = -1;
                        var temp = $.grep(groupDs,function(e){return e.key==jsonArray[j].key});
                        indx = groupDs.indexOf(temp[0]);
                        jsonArray[j].items = ej.group(jsonArray[j].items, field, agg, format, jsonArray.level + 1, groupDs[indx].items);
                        jsonArray[j].count = groupDs[indx].count;
                    }
                    else{
                        jsonArray[j].items = ej.group(jsonArray[j].items, field, agg, format, jsonArray.level + 1);
                        jsonArray[j].count = jsonArray[j].items.length;
                    }  
                }

                jsonArray.childLevels += 1;
                return jsonArray;
            }

            var grouped = {}, groupedArray = [];

            groupedArray.GROUPGUID = ej.pvt.consts.GROUPGUID;
            groupedArray.level = level;
            groupedArray.childLevels = 0;
            groupedArray.records = jsonArray;

            for (var i = 0; i < jsonArray.length; i++) {
                var val = getVal(jsonArray, field, i);
                if (!ej.isNullOrUndefined(format)) val = format(val, field);

                if (!grouped[val]) {
                    grouped[val] = {
                        key: val,
                        count: 0,
                        items: [],
                        aggregates: {},
                        field: field
                    };
                    groupedArray.push(grouped[val]);
					if(!ej.isNullOrUndefined(groupDs)) {
                        var tempObj = $.grep(groupDs,function(e){return e.key==grouped[val].key});
                       grouped[val].count = tempObj[0].count
                    }
                }

                grouped[val].count = !ej.isNullOrUndefined(groupDs) ? grouped[val].count :  grouped[val].count += 1;
                grouped[val].items.push(jsonArray[i]);
            }
            if (agg && agg.length) {

                for (var i = 0; i < groupedArray.length; i++) {
                    var res = {}, fn;
                    for (var j = 0; j < agg.length; j++) {

                        fn = ej.aggregates[agg[j].type];
                        if(!ej.isNullOrUndefined(groupDs)) {
                            var temp = $.grep(groupDs,function(e){return e.key==groupedArray[i].key});
                            if(fn)
                                res[agg[j].field + " - " + agg[j].type] = fn(temp[0].items, agg[j].field);
                        }
                        else{
                            if (fn)
                                res[agg[j].field + " - " + agg[j].type] = fn(groupedArray[i].items, agg[j].field);
                        }

                    }
                    groupedArray[i]["aggregates"] = res;
                }
            }
            return groupedArray;
        },

        parseTable: function (table, headerOption, headerRowIndex) {
            var tr = table.rows, headerRow, headerTds = [], data = [], i;

            if (!tr.length) return [];

            headerRowIndex = headerRowIndex || 0;

            switch ((headerOption || "").toLowerCase()) {
                case ej.headerOption.tHead:
                    headerRow = table.tHead.rows[headerRowIndex];
                    break;
                case ej.headerOption.row:
                default:
                    headerRow = table.rows[headerRowIndex];
                    break;
            }

            var hTd = headerRow.cells;

            for (i = 0; i < hTd.length; i++)
                headerTds.push($.trim(hTd[i].innerHTML));

            for (i = headerRowIndex + 1; i < tr.length; i++) {
                var json = {}, td = tr[i].cells;
                for (var j = 0; j < td.length; j++) {
                    var temp = td[j].innerHTML;
                    if (typeof temp == "string" && $.isNumeric(temp))
                       json[headerTds[j]] = Number(temp);
				    else
                       json[headerTds[j]] = temp;
                }
                data.push(json);
            }
            return data;
        }
    };

    ej.headerOption = {
        tHead: "thead",
        row: "row"
    };

    ej.aggregates = {
        sum: function (ds, field) {
            return ej.sum(ds, field);
        },
        average: function (ds, field) {
            return ej.avg(ds, field);
        },
        minimum: function (ds, field) {
            return ej.getObject(field, ej.min(ds, field));
        },
        maximum: function (ds, field) {
            return  ej.getObject(field, ej.max(ds, field));
        },
        truecount: function (ds, field){
            var predicate = ej.Predicate(field, "equal", true);
            return ej.DataManager(ds).executeLocal(ej.Query().where(predicate)).length;
        },
        falsecount: function (ds, field) {
            var predicate = ej.Predicate(field, "equal", false);
            return ej.DataManager(ds).executeLocal(ej.Query().where(predicate)).length;
        },
        count: function (ds, field) {
            return ds.length;
        }

    };
    ej.pvt = {
        filterQueries: filterQueries,
        mergeSort: function (jsonArray, fieldName, comparer) {
            if (jsonArray.length <= 1)
                return jsonArray;

            // else list size is > 1, so split the list into two sublists
            var middle = parseInt(jsonArray.length / 2, 10);

            var left = jsonArray.slice(0, middle),
                right = jsonArray.slice(middle);

            left = ej.pvt.mergeSort(left, fieldName, comparer);
            right = ej.pvt.mergeSort(right, fieldName, comparer);

            return ej.pvt.merge(left, right, fieldName, comparer);
        },

        getItemFromComparer: function (array, field, comparer) {
            var keyVal, current, key, i = 0,castRequired = typeof getVal(array, field, 0) == "string";
            if (array.length)
            while (ej.isNullOrUndefined(keyVal) && i < array.length) {
                keyVal = getVal(array, field, i);
                key = array[i++];
            }
            for (; i < array.length; i++) {
                current = getVal(array, field, i);
                if (ej.isNullOrUndefined(current))
                    continue;
                if (castRequired) {
                    keyVal = +keyVal;
                    current = +current;
                }
                if (comparer(keyVal, current) > 0) {
                    keyVal = current;
                    key = array[i];
                }
            }
            return key;
        },

        quickSelect: function (array, fieldName, left, right, k, comparer) {
            if (left == right)
                return array[left];

            var pivotNewIndex = ej.pvt.partition(array, fieldName, left, right, comparer);

            var pivotDist = pivotNewIndex - left + 1;

            if (pivotDist == k)
                return array[pivotNewIndex];

            else if (k < pivotDist)
                return ej.pvt.quickSelect(array, fieldName, left, pivotNewIndex - 1, k, comparer);
            else
                return ej.pvt.quickSelect(array, fieldName, pivotNewIndex + 1, right, k - pivotDist, comparer);
        },

        extractFields: function (obj, fields) {
            var newObj = {};

            if (fields.length == 1)
                return ej.pvt.getObject(fields[0], obj);

            for (var i = 0; i < fields.length; i++) {
                newObj[fields[i].replace('.', ej.pvt.consts.complexPropertyMerge)] = ej.pvt.getObject(fields[i], obj);
            }

            return newObj;
        },

        partition: function (array, field, left, right, comparer) {

            var pivotIndex = parseInt((left + right) / 2, 10),
                pivot = getVal(array, field, pivotIndex);

            ej.swap(array, pivotIndex, right);

            pivotIndex = left;

            for (var i = left; i < right; i++) {
                if (comparer(getVal(array, field, i), pivot)) {
                    ej.swap(array, i, pivotIndex);
                    pivotIndex++;
                }
            }

            ej.swap(array, pivotIndex, right);

            return pivotIndex;
        },

        fnSort: function (order) {
            order = order ? order.toLowerCase() : ej.sortOrder.Ascending;

            if (order == ej.sortOrder.Ascending)
                return ej.pvt.fnAscending;

            return ej.pvt.fnDescending;
        },

        fnGetComparer: function (field, fn) {
            return function (x, y) {
                return fn(ej.pvt.getObject(field, x), ej.pvt.getObject(field, y));
            }
        },

        fnAscending: function (x, y) {
            if(ej.isNullOrUndefined(y) && ej.isNullOrUndefined(x))
                return -1;
                        
            if (y === null || y === undefined)
                return -1;

            if (typeof x === "string")
                return x.localeCompare(y);

            if (x === null || x === undefined)
                return 1;

            return x - y;
        },

        fnDescending: function (x, y) {
            if(ej.isNullOrUndefined(y) && ej.isNullOrUndefined(x))
                return -1;            

            if (y === null || y === undefined)
                return 1;

            if (typeof x === "string")
                return x.localeCompare(y) * -1;

            if (x === null || x === undefined)
                return -1;

            return y - x;
        },

        merge: function (left, right, fieldName, comparer) {
            var result = [], current;

            while (left.length > 0 || right.length > 0) {
                if (left.length > 0 && right.length > 0) {
                    if (comparer)
                        current = comparer(getVal(left, fieldName, 0), getVal(right, fieldName, 0)) <= 0 ? left : right;
                    else
                        current = left[0][fieldName] < left[0][fieldName] ? left : right;
                } else {
                    current = left.length > 0 ? left : right;
                }

                result.push(current.shift());
            }

            return result;
        },

        getObject: function (nameSpace, from) {
            if (!from) return undefined;
            if (!nameSpace) return from;

            if (nameSpace.indexOf('.') === -1) return from[nameSpace];

            var value = from, splits = nameSpace.split('.');

            for (var i = 0; i < splits.length; i++) {

                if (value == null) break;

                value = value[splits[i]];
            }

            return value;
        },

        createObject: function (nameSpace, value, initIn) {
            var splits = nameSpace.split('.'), start = initIn || window, from = start, i;

            for (i = 0; i < splits.length; i++) {

                if (i + 1 == splits.length)
                    from[splits[i]] = value === undefined ? {} : value;
                else if (from[splits[i]] == null)
                    from[splits[i]] = {};

                from = from[splits[i]];
            }

            return start;
        },

        ignoreDiacritics :function (value) {
            if (typeof value !== 'string') {
                return value;
            }
            var result = value.split('');
            var newValue = result.map(function (temp) { return temp in ej.data.diacritics ? ej.data.diacritics[temp] : temp; });
            return newValue.join('');
        },


        getFieldList: function (obj, fields, prefix) {
            if (prefix === undefined)
                prefix = "";

            if (fields === undefined || fields === null)
                return ej.pvt.getFieldList(obj, [], prefix);

            for (var prop in obj) {
                if (typeof obj[prop] === "object" && !(obj[prop] instanceof Array))
                    ej.pvt.getFieldList(obj[prop], fields, prefix + prop + ".");
                else
                    fields.push(prefix + prop);
            }

            return fields;
        }
    };

    ej.FilterOperators = {
        lessThan: "lessthan",
        greaterThan: "greaterthan",
        lessThanOrEqual: "lessthanorequal",
        greaterThanOrEqual: "greaterthanorequal",
        equal: "equal",
        contains: "contains",
        startsWith: "startswith",
        endsWith: "endswith",
        notEqual: "notequal"
    };

    ej.data = {};

    ej.data.operatorSymbols = {
        "<": "lessthan",
        ">": "greaterthan",
        "<=": "lessthanorequal",
        ">=": "greaterthanorequal",
        "==": "equal",
        "!=": "notequal",
        "*=": "contains",
        "$=": "endswith",
        "^=": "startswith"
    };

    ej.data.odBiOperator = {
        "<": " lt ",
        ">": " gt ",
        "<=": " le ",
        ">=": " ge ",
        "==": " eq ",
        "!=": " ne ",
        "lessthan": " lt ",
        "lessthanorequal": " le ",
        "greaterthan": " gt ",
        "greaterthanorequal": " ge ",
        "equal": " eq ",
        "notequal": " ne ",
		"in":" eq ",
		"notin": " ne "
    };

    ej.data.odUniOperator = {
        "$=": "endswith",
        "^=": "startswith",
        "*=": "substringof",
        "endswith": "endswith",
        "startswith": "startswith",
        "contains": "substringof",
		"notcontains":"substringof"
    };
    ej.data.diacritics = {
        '\u24B6': 'A',
        '\uFF21': 'A',
        '\u00C0': 'A',
        '\u00C1': 'A',
        '\u00C2': 'A',
        '\u1EA6': 'A',
        '\u1EA4': 'A',
        '\u1EAA': 'A',
        '\u1EA8': 'A',
        '\u00C3': 'A',
        '\u0100': 'A',
        '\u0102': 'A',
        '\u1EB0': 'A',
        '\u1EAE': 'A',
        '\u1EB4': 'A',
        '\u1EB2': 'A',
        '\u0226': 'A',
        '\u01E0': 'A',
        '\u00C4': 'A',
        '\u01DE': 'A',
        '\u1EA2': 'A',
        '\u00C5': 'A',
        '\u01FA': 'A',
        '\u01CD': 'A',
        '\u0200': 'A',
        '\u0202': 'A',
        '\u1EA0': 'A',
        '\u1EAC': 'A',
        '\u1EB6': 'A',
        '\u1E00': 'A',
        '\u0104': 'A',
        '\u023A': 'A',
        '\u2C6F': 'A',
        '\uA732': 'AA',
        '\u00C6': 'AE',
        '\u01FC': 'AE',
        '\u01E2': 'AE',
        '\uA734': 'AO',
        '\uA736': 'AU',
        '\uA738': 'AV',
        '\uA73A': 'AV',
        '\uA73C': 'AY',
        '\u24B7': 'B',
        '\uFF22': 'B',
        '\u1E02': 'B',
        '\u1E04': 'B',
        '\u1E06': 'B',
        '\u0243': 'B',
        '\u0182': 'B',
        '\u0181': 'B',
        '\u24B8': 'C',
        '\uFF23': 'C',
        '\u0106': 'C',
        '\u0108': 'C',
        '\u010A': 'C',
        '\u010C': 'C',
        '\u00C7': 'C',
        '\u1E08': 'C',
        '\u0187': 'C',
        '\u023B': 'C',
        '\uA73E': 'C',
        '\u24B9': 'D',
        '\uFF24': 'D',
        '\u1E0A': 'D',
        '\u010E': 'D',
        '\u1E0C': 'D',
        '\u1E10': 'D',
        '\u1E12': 'D',
        '\u1E0E': 'D',
        '\u0110': 'D',
        '\u018B': 'D',
        '\u018A': 'D',
        '\u0189': 'D',
        '\uA779': 'D',
        '\u01F1': 'DZ',
        '\u01C4': 'DZ',
        '\u01F2': 'Dz',
        '\u01C5': 'Dz',
        '\u24BA': 'E',
        '\uFF25': 'E',
        '\u00C8': 'E',
        '\u00C9': 'E',
        '\u00CA': 'E',
        '\u1EC0': 'E',
        '\u1EBE': 'E',
        '\u1EC4': 'E',
        '\u1EC2': 'E',
        '\u1EBC': 'E',
        '\u0112': 'E',
        '\u1E14': 'E',
        '\u1E16': 'E',
        '\u0114': 'E',
        '\u0116': 'E',
        '\u00CB': 'E',
        '\u1EBA': 'E',
        '\u011A': 'E',
        '\u0204': 'E',
        '\u0206': 'E',
        '\u1EB8': 'E',
        '\u1EC6': 'E',
        '\u0228': 'E',
        '\u1E1C': 'E',
        '\u0118': 'E',
        '\u1E18': 'E',
        '\u1E1A': 'E',
        '\u0190': 'E',
        '\u018E': 'E',
        '\u24BB': 'F',
        '\uFF26': 'F',
        '\u1E1E': 'F',
        '\u0191': 'F',
        '\uA77B': 'F',
        '\u24BC': 'G',
        '\uFF27': 'G',
        '\u01F4': 'G',
        '\u011C': 'G',
        '\u1E20': 'G',
        '\u011E': 'G',
        '\u0120': 'G',
        '\u01E6': 'G',
        '\u0122': 'G',
        '\u01E4': 'G',
        '\u0193': 'G',
        '\uA7A0': 'G',
        '\uA77D': 'G',
        '\uA77E': 'G',
        '\u24BD': 'H',
        '\uFF28': 'H',
        '\u0124': 'H',
        '\u1E22': 'H',
        '\u1E26': 'H',
        '\u021E': 'H',
        '\u1E24': 'H',
        '\u1E28': 'H',
        '\u1E2A': 'H',
        '\u0126': 'H',
        '\u2C67': 'H',
        '\u2C75': 'H',
        '\uA78D': 'H',
        '\u24BE': 'I',
        '\uFF29': 'I',
        '\u00CC': 'I',
        '\u00CD': 'I',
        '\u00CE': 'I',
        '\u0128': 'I',
        '\u012A': 'I',
        '\u012C': 'I',
        '\u0130': 'I',
        '\u00CF': 'I',
        '\u1E2E': 'I',
        '\u1EC8': 'I',
        '\u01CF': 'I',
        '\u0208': 'I',
        '\u020A': 'I',
        '\u1ECA': 'I',
        '\u012E': 'I',
        '\u1E2C': 'I',
        '\u0197': 'I',
        '\u24BF': 'J',
        '\uFF2A': 'J',
        '\u0134': 'J',
        '\u0248': 'J',
        '\u24C0': 'K',
        '\uFF2B': 'K',
        '\u1E30': 'K',
        '\u01E8': 'K',
        '\u1E32': 'K',
        '\u0136': 'K',
        '\u1E34': 'K',
        '\u0198': 'K',
        '\u2C69': 'K',
        '\uA740': 'K',
        '\uA742': 'K',
        '\uA744': 'K',
        '\uA7A2': 'K',
        '\u24C1': 'L',
        '\uFF2C': 'L',
        '\u013F': 'L',
        '\u0139': 'L',
        '\u013D': 'L',
        '\u1E36': 'L',
        '\u1E38': 'L',
        '\u013B': 'L',
        '\u1E3C': 'L',
        '\u1E3A': 'L',
        '\u0141': 'L',
        '\u023D': 'L',
        '\u2C62': 'L',
        '\u2C60': 'L',
        '\uA748': 'L',
        '\uA746': 'L',
        '\uA780': 'L',
        '\u01C7': 'LJ',
        '\u01C8': 'Lj',
        '\u24C2': 'M',
        '\uFF2D': 'M',
        '\u1E3E': 'M',
        '\u1E40': 'M',
        '\u1E42': 'M',
        '\u2C6E': 'M',
        '\u019C': 'M',
        '\u24C3': 'N',
        '\uFF2E': 'N',
        '\u01F8': 'N',
        '\u0143': 'N',
        '\u00D1': 'N',
        '\u1E44': 'N',
        '\u0147': 'N',
        '\u1E46': 'N',
        '\u0145': 'N',
        '\u1E4A': 'N',
        '\u1E48': 'N',
        '\u0220': 'N',
        '\u019D': 'N',
        '\uA790': 'N',
        '\uA7A4': 'N',
        '\u01CA': 'NJ',
        '\u01CB': 'Nj',
        '\u24C4': 'O',
        '\uFF2F': 'O',
        '\u00D2': 'O',
        '\u00D3': 'O',
        '\u00D4': 'O',
        '\u1ED2': 'O',
        '\u1ED0': 'O',
        '\u1ED6': 'O',
        '\u1ED4': 'O',
        '\u00D5': 'O',
        '\u1E4C': 'O',
        '\u022C': 'O',
        '\u1E4E': 'O',
        '\u014C': 'O',
        '\u1E50': 'O',
        '\u1E52': 'O',
        '\u014E': 'O',
        '\u022E': 'O',
        '\u0230': 'O',
        '\u00D6': 'O',
        '\u022A': 'O',
        '\u1ECE': 'O',
        '\u0150': 'O',
        '\u01D1': 'O',
        '\u020C': 'O',
        '\u020E': 'O',
        '\u01A0': 'O',
        '\u1EDC': 'O',
        '\u1EDA': 'O',
        '\u1EE0': 'O',
        '\u1EDE': 'O',
        '\u1EE2': 'O',
        '\u1ECC': 'O',
        '\u1ED8': 'O',
        '\u01EA': 'O',
        '\u01EC': 'O',
        '\u00D8': 'O',
        '\u01FE': 'O',
        '\u0186': 'O',
        '\u019F': 'O',
        '\uA74A': 'O',
        '\uA74C': 'O',
        '\u01A2': 'OI',
        '\uA74E': 'OO',
        '\u0222': 'OU',
        '\u24C5': 'P',
        '\uFF30': 'P',
        '\u1E54': 'P',
        '\u1E56': 'P',
        '\u01A4': 'P',
        '\u2C63': 'P',
        '\uA750': 'P',
        '\uA752': 'P',
        '\uA754': 'P',
        '\u24C6': 'Q',
        '\uFF31': 'Q',
        '\uA756': 'Q',
        '\uA758': 'Q',
        '\u024A': 'Q',
        '\u24C7': 'R',
        '\uFF32': 'R',
        '\u0154': 'R',
        '\u1E58': 'R',
        '\u0158': 'R',
        '\u0210': 'R',
        '\u0212': 'R',
        '\u1E5A': 'R',
        '\u1E5C': 'R',
        '\u0156': 'R',
        '\u1E5E': 'R',
        '\u024C': 'R',
        '\u2C64': 'R',
        '\uA75A': 'R',
        '\uA7A6': 'R',
        '\uA782': 'R',
        '\u24C8': 'S',
        '\uFF33': 'S',
        '\u1E9E': 'S',
        '\u015A': 'S',
        '\u1E64': 'S',
        '\u015C': 'S',
        '\u1E60': 'S',
        '\u0160': 'S',
        '\u1E66': 'S',
        '\u1E62': 'S',
        '\u1E68': 'S',
        '\u0218': 'S',
        '\u015E': 'S',
        '\u2C7E': 'S',
        '\uA7A8': 'S',
        '\uA784': 'S',
        '\u24C9': 'T',
        '\uFF34': 'T',
        '\u1E6A': 'T',
        '\u0164': 'T',
        '\u1E6C': 'T',
        '\u021A': 'T',
        '\u0162': 'T',
        '\u1E70': 'T',
        '\u1E6E': 'T',
        '\u0166': 'T',
        '\u01AC': 'T',
        '\u01AE': 'T',
        '\u023E': 'T',
        '\uA786': 'T',
        '\uA728': 'TZ',
        '\u24CA': 'U',
        '\uFF35': 'U',
        '\u00D9': 'U',
        '\u00DA': 'U',
        '\u00DB': 'U',
        '\u0168': 'U',
        '\u1E78': 'U',
        '\u016A': 'U',
        '\u1E7A': 'U',
        '\u016C': 'U',
        '\u00DC': 'U',
        '\u01DB': 'U',
        '\u01D7': 'U',
        '\u01D5': 'U',
        '\u01D9': 'U',
        '\u1EE6': 'U',
        '\u016E': 'U',
        '\u0170': 'U',
        '\u01D3': 'U',
        '\u0214': 'U',
        '\u0216': 'U',
        '\u01AF': 'U',
        '\u1EEA': 'U',
        '\u1EE8': 'U',
        '\u1EEE': 'U',
        '\u1EEC': 'U',
        '\u1EF0': 'U',
        '\u1EE4': 'U',
        '\u1E72': 'U',
        '\u0172': 'U',
        '\u1E76': 'U',
        '\u1E74': 'U',
        '\u0244': 'U',
        '\u24CB': 'V',
        '\uFF36': 'V',
        '\u1E7C': 'V',
        '\u1E7E': 'V',
        '\u01B2': 'V',
        '\uA75E': 'V',
        '\u0245': 'V',
        '\uA760': 'VY',
        '\u24CC': 'W',
        '\uFF37': 'W',
        '\u1E80': 'W',
        '\u1E82': 'W',
        '\u0174': 'W',
        '\u1E86': 'W',
        '\u1E84': 'W',
        '\u1E88': 'W',
        '\u2C72': 'W',
        '\u24CD': 'X',
        '\uFF38': 'X',
        '\u1E8A': 'X',
        '\u1E8C': 'X',
        '\u24CE': 'Y',
        '\uFF39': 'Y',
        '\u1EF2': 'Y',
        '\u00DD': 'Y',
        '\u0176': 'Y',
        '\u1EF8': 'Y',
        '\u0232': 'Y',
        '\u1E8E': 'Y',
        '\u0178': 'Y',
        '\u1EF6': 'Y',
        '\u1EF4': 'Y',
        '\u01B3': 'Y',
        '\u024E': 'Y',
        '\u1EFE': 'Y',
        '\u24CF': 'Z',
        '\uFF3A': 'Z',
        '\u0179': 'Z',
        '\u1E90': 'Z',
        '\u017B': 'Z',
        '\u017D': 'Z',
        '\u1E92': 'Z',
        '\u1E94': 'Z',
        '\u01B5': 'Z',
        '\u0224': 'Z',
        '\u2C7F': 'Z',
        '\u2C6B': 'Z',
        '\uA762': 'Z',
        '\u24D0': 'a',
        '\uFF41': 'a',
        '\u1E9A': 'a',
        '\u00E0': 'a',
        '\u00E1': 'a',
        '\u00E2': 'a',
        '\u1EA7': 'a',
        '\u1EA5': 'a',
        '\u1EAB': 'a',
        '\u1EA9': 'a',
        '\u00E3': 'a',
        '\u0101': 'a',
        '\u0103': 'a',
        '\u1EB1': 'a',
        '\u1EAF': 'a',
        '\u1EB5': 'a',
        '\u1EB3': 'a',
        '\u0227': 'a',
        '\u01E1': 'a',
        '\u00E4': 'a',
        '\u01DF': 'a',
        '\u1EA3': 'a',
        '\u00E5': 'a',
        '\u01FB': 'a',
        '\u01CE': 'a',
        '\u0201': 'a',
        '\u0203': 'a',
        '\u1EA1': 'a',
        '\u1EAD': 'a',
        '\u1EB7': 'a',
        '\u1E01': 'a',
        '\u0105': 'a',
        '\u2C65': 'a',
        '\u0250': 'a',
        '\uA733': 'aa',
        '\u00E6': 'ae',
        '\u01FD': 'ae',
        '\u01E3': 'ae',
        '\uA735': 'ao',
        '\uA737': 'au',
        '\uA739': 'av',
        '\uA73B': 'av',
        '\uA73D': 'ay',
        '\u24D1': 'b',
        '\uFF42': 'b',
        '\u1E03': 'b',
        '\u1E05': 'b',
        '\u1E07': 'b',
        '\u0180': 'b',
        '\u0183': 'b',
        '\u0253': 'b',
        '\u24D2': 'c',
        '\uFF43': 'c',
        '\u0107': 'c',
        '\u0109': 'c',
        '\u010B': 'c',
        '\u010D': 'c',
        '\u00E7': 'c',
        '\u1E09': 'c',
        '\u0188': 'c',
        '\u023C': 'c',
        '\uA73F': 'c',
        '\u2184': 'c',
        '\u24D3': 'd',
        '\uFF44': 'd',
        '\u1E0B': 'd',
        '\u010F': 'd',
        '\u1E0D': 'd',
        '\u1E11': 'd',
        '\u1E13': 'd',
        '\u1E0F': 'd',
        '\u0111': 'd',
        '\u018C': 'd',
        '\u0256': 'd',
        '\u0257': 'd',
        '\uA77A': 'd',
        '\u01F3': 'dz',
        '\u01C6': 'dz',
        '\u24D4': 'e',
        '\uFF45': 'e',
        '\u00E8': 'e',
        '\u00E9': 'e',
        '\u00EA': 'e',
        '\u1EC1': 'e',
        '\u1EBF': 'e',
        '\u1EC5': 'e',
        '\u1EC3': 'e',
        '\u1EBD': 'e',
        '\u0113': 'e',
        '\u1E15': 'e',
        '\u1E17': 'e',
        '\u0115': 'e',
        '\u0117': 'e',
        '\u00EB': 'e',
        '\u1EBB': 'e',
        '\u011B': 'e',
        '\u0205': 'e',
        '\u0207': 'e',
        '\u1EB9': 'e',
        '\u1EC7': 'e',
        '\u0229': 'e',
        '\u1E1D': 'e',
        '\u0119': 'e',
        '\u1E19': 'e',
        '\u1E1B': 'e',
        '\u0247': 'e',
        '\u025B': 'e',
        '\u01DD': 'e',
        '\u24D5': 'f',
        '\uFF46': 'f',
        '\u1E1F': 'f',
        '\u0192': 'f',
        '\uA77C': 'f',
        '\u24D6': 'g',
        '\uFF47': 'g',
        '\u01F5': 'g',
        '\u011D': 'g',
        '\u1E21': 'g',
        '\u011F': 'g',
        '\u0121': 'g',
        '\u01E7': 'g',
        '\u0123': 'g',
        '\u01E5': 'g',
        '\u0260': 'g',
        '\uA7A1': 'g',
        '\u1D79': 'g',
        '\uA77F': 'g',
        '\u24D7': 'h',
        '\uFF48': 'h',
        '\u0125': 'h',
        '\u1E23': 'h',
        '\u1E27': 'h',
        '\u021F': 'h',
        '\u1E25': 'h',
        '\u1E29': 'h',
        '\u1E2B': 'h',
        '\u1E96': 'h',
        '\u0127': 'h',
        '\u2C68': 'h',
        '\u2C76': 'h',
        '\u0265': 'h',
        '\u0195': 'hv',
        '\u24D8': 'i',
        '\uFF49': 'i',
        '\u00EC': 'i',
        '\u00ED': 'i',
        '\u00EE': 'i',
        '\u0129': 'i',
        '\u012B': 'i',
        '\u012D': 'i',
        '\u00EF': 'i',
        '\u1E2F': 'i',
        '\u1EC9': 'i',
        '\u01D0': 'i',
        '\u0209': 'i',
        '\u020B': 'i',
        '\u1ECB': 'i',
        '\u012F': 'i',
        '\u1E2D': 'i',
        '\u0268': 'i',
        '\u0131': 'i',
        '\u24D9': 'j',
        '\uFF4A': 'j',
        '\u0135': 'j',
        '\u01F0': 'j',
        '\u0249': 'j',
        '\u24DA': 'k',
        '\uFF4B': 'k',
        '\u1E31': 'k',
        '\u01E9': 'k',
        '\u1E33': 'k',
        '\u0137': 'k',
        '\u1E35': 'k',
        '\u0199': 'k',
        '\u2C6A': 'k',
        '\uA741': 'k',
        '\uA743': 'k',
        '\uA745': 'k',
        '\uA7A3': 'k',
        '\u24DB': 'l',
        '\uFF4C': 'l',
        '\u0140': 'l',
        '\u013A': 'l',
        '\u013E': 'l',
        '\u1E37': 'l',
        '\u1E39': 'l',
        '\u013C': 'l',
        '\u1E3D': 'l',
        '\u1E3B': 'l',
        '\u017F': 'l',
        '\u0142': 'l',
        '\u019A': 'l',
        '\u026B': 'l',
        '\u2C61': 'l',
        '\uA749': 'l',
        '\uA781': 'l',
        '\uA747': 'l',
        '\u01C9': 'lj',
        '\u24DC': 'm',
        '\uFF4D': 'm',
        '\u1E3F': 'm',
        '\u1E41': 'm',
        '\u1E43': 'm',
        '\u0271': 'm',
        '\u026F': 'm',
        '\u24DD': 'n',
        '\uFF4E': 'n',
        '\u01F9': 'n',
        '\u0144': 'n',
        '\u00F1': 'n',
        '\u1E45': 'n',
        '\u0148': 'n',
        '\u1E47': 'n',
        '\u0146': 'n',
        '\u1E4B': 'n',
        '\u1E49': 'n',
        '\u019E': 'n',
        '\u0272': 'n',
        '\u0149': 'n',
        '\uA791': 'n',
        '\uA7A5': 'n',
        '\u01CC': 'nj',
        '\u24DE': 'o',
        '\uFF4F': 'o',
        '\u00F2': 'o',
        '\u00F3': 'o',
        '\u00F4': 'o',
        '\u1ED3': 'o',
        '\u1ED1': 'o',
        '\u1ED7': 'o',
        '\u1ED5': 'o',
        '\u00F5': 'o',
        '\u1E4D': 'o',
        '\u022D': 'o',
        '\u1E4F': 'o',
        '\u014D': 'o',
        '\u1E51': 'o',
        '\u1E53': 'o',
        '\u014F': 'o',
        '\u022F': 'o',
        '\u0231': 'o',
        '\u00F6': 'o',
        '\u022B': 'o',
        '\u1ECF': 'o',
        '\u0151': 'o',
        '\u01D2': 'o',
        '\u020D': 'o',
        '\u020F': 'o',
        '\u01A1': 'o',
        '\u1EDD': 'o',
        '\u1EDB': 'o',
        '\u1EE1': 'o',
        '\u1EDF': 'o',
        '\u1EE3': 'o',
        '\u1ECD': 'o',
        '\u1ED9': 'o',
        '\u01EB': 'o',
        '\u01ED': 'o',
        '\u00F8': 'o',
        '\u01FF': 'o',
        '\u0254': 'o',
        '\uA74B': 'o',
        '\uA74D': 'o',
        '\u0275': 'o',
        '\u01A3': 'oi',
        '\u0223': 'ou',
        '\uA74F': 'oo',
        '\u24DF': 'p',
        '\uFF50': 'p',
        '\u1E55': 'p',
        '\u1E57': 'p',
        '\u01A5': 'p',
        '\u1D7D': 'p',
        '\uA751': 'p',
        '\uA753': 'p',
        '\uA755': 'p',
        '\u24E0': 'q',
        '\uFF51': 'q',
        '\u024B': 'q',
        '\uA757': 'q',
        '\uA759': 'q',
        '\u24E1': 'r',
        '\uFF52': 'r',
        '\u0155': 'r',
        '\u1E59': 'r',
        '\u0159': 'r',
        '\u0211': 'r',
        '\u0213': 'r',
        '\u1E5B': 'r',
        '\u1E5D': 'r',
        '\u0157': 'r',
        '\u1E5F': 'r',
        '\u024D': 'r',
        '\u027D': 'r',
        '\uA75B': 'r',
        '\uA7A7': 'r',
        '\uA783': 'r',
        '\u24E2': 's',
        '\uFF53': 's',
        '\u00DF': 's',
        '\u015B': 's',
        '\u1E65': 's',
        '\u015D': 's',
        '\u1E61': 's',
        '\u0161': 's',
        '\u1E67': 's',
        '\u1E63': 's',
        '\u1E69': 's',
        '\u0219': 's',
        '\u015F': 's',
        '\u023F': 's',
        '\uA7A9': 's',
        '\uA785': 's',
        '\u1E9B': 's',
        '\u24E3': 't',
        '\uFF54': 't',
        '\u1E6B': 't',
        '\u1E97': 't',
        '\u0165': 't',
        '\u1E6D': 't',
        '\u021B': 't',
        '\u0163': 't',
        '\u1E71': 't',
        '\u1E6F': 't',
        '\u0167': 't',
        '\u01AD': 't',
        '\u0288': 't',
        '\u2C66': 't',
        '\uA787': 't',
        '\uA729': 'tz',
        '\u24E4': 'u',
        '\uFF55': 'u',
        '\u00F9': 'u',
        '\u00FA': 'u',
        '\u00FB': 'u',
        '\u0169': 'u',
        '\u1E79': 'u',
        '\u016B': 'u',
        '\u1E7B': 'u',
        '\u016D': 'u',
        '\u00FC': 'u',
        '\u01DC': 'u',
        '\u01D8': 'u',
        '\u01D6': 'u',
        '\u01DA': 'u',
        '\u1EE7': 'u',
        '\u016F': 'u',
        '\u0171': 'u',
        '\u01D4': 'u',
        '\u0215': 'u',
        '\u0217': 'u',
        '\u01B0': 'u',
        '\u1EEB': 'u',
        '\u1EE9': 'u',
        '\u1EEF': 'u',
        '\u1EED': 'u',
        '\u1EF1': 'u',
        '\u1EE5': 'u',
        '\u1E73': 'u',
        '\u0173': 'u',
        '\u1E77': 'u',
        '\u1E75': 'u',
        '\u0289': 'u',
        '\u24E5': 'v',
        '\uFF56': 'v',
        '\u1E7D': 'v',
        '\u1E7F': 'v',
        '\u028B': 'v',
        '\uA75F': 'v',
        '\u028C': 'v',
        '\uA761': 'vy',
        '\u24E6': 'w',
        '\uFF57': 'w',
        '\u1E81': 'w',
        '\u1E83': 'w',
        '\u0175': 'w',
        '\u1E87': 'w',
        '\u1E85': 'w',
        '\u1E98': 'w',
        '\u1E89': 'w',
        '\u2C73': 'w',
        '\u24E7': 'x',
        '\uFF58': 'x',
        '\u1E8B': 'x',
        '\u1E8D': 'x',
        '\u24E8': 'y',
        '\uFF59': 'y',
        '\u1EF3': 'y',
        '\u00FD': 'y',
        '\u0177': 'y',
        '\u1EF9': 'y',
        '\u0233': 'y',
        '\u1E8F': 'y',
        '\u00FF': 'y',
        '\u1EF7': 'y',
        '\u1E99': 'y',
        '\u1EF5': 'y',
        '\u01B4': 'y',
        '\u024F': 'y',
        '\u1EFF': 'y',
        '\u24E9': 'z',
        '\uFF5A': 'z',
        '\u017A': 'z',
        '\u1E91': 'z',
        '\u017C': 'z',
        '\u017E': 'z',
        '\u1E93': 'z',
        '\u1E95': 'z',
        '\u01B6': 'z',
        '\u0225': 'z',
        '\u0240': 'z',
        '\u2C6C': 'z',
        '\uA763': 'z',
        '\u0386': '\u0391',
        '\u0388': '\u0395',
        '\u0389': '\u0397',
        '\u038A': '\u0399',
        '\u03AA': '\u0399',
        '\u038C': '\u039F',
        '\u038E': '\u03A5',
        '\u03AB': '\u03A5',
        '\u038F': '\u03A9',
        '\u03AC': '\u03B1',
        '\u03AD': '\u03B5',
        '\u03AE': '\u03B7',
        '\u03AF': '\u03B9',
        '\u03CA': '\u03B9',
        '\u0390': '\u03B9',
        '\u03CC': '\u03BF',
        '\u03CD': '\u03C5',
        '\u03CB': '\u03C5',
        '\u03B0': '\u03C5',
        '\u03C9': '\u03C9',
        '\u03C2': '\u03C3'
    };


    ej.data.fnOperators = {
        equal: function (actual, expected, ignoreCase,ignoreAccent) {
            if (ignoreAccent) {
                actual = ej.pvt.ignoreDiacritics(actual);
                expected = ej.pvt.ignoreDiacritics(expected);
            }
            if (ignoreCase)
                return toLowerCase(actual) == toLowerCase(expected);

            return actual == expected;
        },
        notequal: function (actual, expected, ignoreCase,ignoreAccent) {
            if (ignoreAccent) {
                actual = ej.pvt.ignoreDiacritics(actual);
                expected = ej.pvt.ignoreDiacritics(expected);
            }
            return !ej.data.fnOperators.equal(actual, expected, ignoreCase);
        },
		notin: function (actual, expected, ignoreCase) {
			for(var i = 0; i < expected.length; i++) 
				if(ej.data.fnOperators.notequal(actual, expected[i], ignoreCase) == false) return false;
            return true;
        },
        lessthan: function (actual, expected, ignoreCase) {
            if (ignoreCase)
                return toLowerCase(actual) < toLowerCase(expected);

            return actual < expected;
        },
        greaterthan: function (actual, expected, ignoreCase) {
            if (ignoreCase)
                return toLowerCase(actual) > toLowerCase(expected);

            return actual > expected;
        },
        lessthanorequal: function (actual, expected, ignoreCase) {
            if (ignoreCase)
                return toLowerCase(actual) <= toLowerCase(expected);

            return actual <= expected;
        },
        greaterthanorequal: function (actual, expected, ignoreCase) {
            if (ignoreCase)
                return toLowerCase(actual) >= toLowerCase(expected);

            return actual >= expected;
        },
        contains: function (actual, expected, ignoreCase,ignoreAccent) {
            if (ignoreAccent) {
                actual = ej.pvt.ignoreDiacritics(actual);
                expected = ej.pvt.ignoreDiacritics(expected);
            }
            if (ignoreCase)
                return !isNull(actual) && !isNull(expected) && toLowerCase(actual).indexOf(toLowerCase(expected)) != -1;

            return !isNull(actual) && !isNull(expected) && actual.toString().indexOf(expected) != -1;
        },
		notcontains: function (actual, expected, ignoreCase,ignoreAccent) {
            if (ignoreAccent) {
                actual = ej.pvt.ignoreDiacritics(actual);
                expected = ej.pvt.ignoreDiacritics(expected);
            }
			 return !ej.data.fnOperators.contains(actual, expected, ignoreCase);
		},
        notnull: function (actual) {
            return actual !== null;
        },
        isnull: function (actual) {
            return actual === null;
        },
        startswith: function (actual, expected, ignoreCase,ignoreAccent) {
            if (ignoreAccent) {
                actual = ej.pvt.ignoreDiacritics(actual);
                expected = ej.pvt.ignoreDiacritics(expected);
            }
            if (ignoreCase)
                return actual && expected && toLowerCase(actual).startsWith(toLowerCase(expected));

            return actual && expected && actual.startsWith(expected);
        },
        endswith: function (actual, expected, ignoreCase,ignoreAccent) {
            if (ignoreAccent) {
                actual = ej.pvt.ignoreDiacritics(actual);
                expected = ej.pvt.ignoreDiacritics(expected);
            }
            if (ignoreCase)
                return actual && expected && toLowerCase(actual).endsWith(toLowerCase(expected));

            return actual && expected && actual.endsWith(expected);
        },
		all: function (actual, expected, ignoreCase ) {
			for(var i = 0; i < expected.length; i++)
				if (ej.data.fnOperators[this.operator](actual, expected[i], ignoreCase) == false) return false;
            return true;
		},
		any: function (actual, expected, ignoreCase ) {
			for(var i = 0; i < expected.length; i++)
				if (ej.data.fnOperators[this.operator](actual, expected[i], ignoreCase) == true) return true;
            return false;
		},
        processSymbols: function (operator) {
            var fnName = ej.data.operatorSymbols[operator];
            if (fnName) {
                var fn = ej.data.fnOperators[fnName];
                if (fn) return fn;
            }

            return throwError("Query - Process Operator : Invalid operator");
        },

        processOperator: function (operator) {
            var fn = ej.data.fnOperators[operator];
            if (fn) return fn;
            return ej.data.fnOperators.processSymbols(operator);
        }
    };

    ej.data.fnOperators["in"] = function (actual, expected, ignoreCase) {
        for(var i = 0; i < expected.length; i++)
            if (ej.data.fnOperators.equal(actual, expected[i], ignoreCase) == true) return true;
        return false;
    };

    ej.NotifierArray = function (array) {
        if (!instance(this, ej.NotifierArray))
            return new ej.NotifierArray(array);

        this.array = array;

        this._events = $({});
        this._isDirty = false;

        return this;
    };

    ej.NotifierArray.prototype = {
        on: function (eventName, handler) {
            this._events.on(eventName, handler);
        },
        off: function (eventName, handler) {
            this._events.off(eventName, handler);
        },
        push: function (item) {
            var ret;

            if (instance(item, Array))
                ret = [].push.apply(this.array, item);
            else
                ret = this.array.push(item);

            this._raise("add", { item: item, index: this.length() - 1 });

            return ret;
        },
        pop: function () {
            var ret = this.array.pop();

            this._raise("remove", { item: ret, index: this.length() - 1 });

            return ret;
        },
        addAt: function (index, item) {
            this.array.splice(index, 0, item);

            this._raise("add", { item: item, index: index });

            return item;
        },
        removeAt: function (index) {
            var ret = this.array.splice(index, 1)[0];

            this._raise("remove", { item: ret, index: index });

            return ret;
        },
        remove: function (item) {
            var index = this.array.indexOf(item);

            if (index > -1) {
                this.array.splice(index, 1);
                this._raise("remove", { item: item, index: index });
            }

            return index;
        },
        length: function () {
            return this.array.length;
        },
        _raise: function (e, args) {
            this._events.triggerHandler($.extend({ type: e }, args));
            this._events.triggerHandler({ type: "all", name: e, args: args });
        },
        toArray: function () {
            return this.array;
        }
    };

    $.extend(ej, ej.dataUtil);

    // For IE8
    Array.prototype.forEach = Array.prototype.forEach || function (fn, scope) {
        for (var i = 0, len = this.length; i < len; ++i) {
            fn.call(scope, this[i], i, this);
        }
    };

    Array.prototype.indexOf = Array.prototype.indexOf || function (searchElement) {
        var len = this.length;

        if (len === 0) return -1;

        for (var i = 0; i < len; i++) {
            if (i in this && this[i] === searchElement)
                return i;
        }
        return -1;
    };

    Array.prototype.filter = Array.prototype.filter || function (fn) {
        if (typeof fn != "function")
            throw new TypeError();

        var res = [];
        var thisp = arguments[1] || this;
        for (var i = 0; i < this.length; i++) {
            var val = this[i]; // in case fun mutates this
            if (fn.call(thisp, val, i, this))
                res.push(val);
        }

        return res;
    };

    String.prototype.endsWith = String.prototype.endsWith || function (key) {
        return this.slice(-key.length) === key;
    };

    String.prototype.startsWith = String.prototype.startsWith || function (key) {
        return this.slice(0, key.length) === key;
    };

    if (!ej.support) ej.support = {};
    ej.support.stableSort = function () {
        var res = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16].sort(function () { return 0; });
		for(var i = 0; i < 17; i++){
		    if(i !== res[i]) return false;
		}
        return true;
    }();
    ej.support.cors = $.support.cors;

    if (!$.support.cors && window.XDomainRequest) {
        var httpRegEx = /^https?:\/\//i;
        var getOrPostRegEx = /^get|post$/i;
        var sameSchemeRegEx = new RegExp('^' + location.protocol, 'i');
        var xmlRegEx = /\/xml/i;

        // ajaxTransport exists in jQuery 1.5+
        $.ajaxTransport('text html xml json', function (options, userOptions, jqXHR) {
            // XDomainRequests must be: asynchronous, GET or POST methods, HTTP or HTTPS protocol, and same scheme as calling page
            if (options.crossDomain && options.async && getOrPostRegEx.test(options.type) && httpRegEx.test(userOptions.url) && sameSchemeRegEx.test(userOptions.url)) {
                var xdr = null;
                var userType = (userOptions.dataType || '').toLowerCase();
                return {
                    send: function (headers, complete) {
                        xdr = new XDomainRequest();
                        if (/^\d+$/.test(userOptions.timeout)) {
                            xdr.timeout = userOptions.timeout;
                        }
                        xdr.ontimeout = function () {
                            complete(500, 'timeout');
                        };
                        xdr.onload = function () {
                            var allResponseHeaders = 'Content-Length: ' + xdr.responseText.length + '\r\nContent-Type: ' + xdr.contentType;
                            var status = {
                                code: 200,
                                message: 'success'
                            };
                            var responses = {
                                text: xdr.responseText
                            };

                            try {
                                if (userType === 'json') {
                                    try {
                                        responses.json = JSON.parse(xdr.responseText);
                                    } catch (e) {
                                        status.code = 500;
                                        status.message = 'parseerror';
                                        //throw 'Invalid JSON: ' + xdr.responseText;
                                    }
                                } else if ((userType === 'xml') || ((userType !== 'text') && xmlRegEx.test(xdr.contentType))) {
                                    var doc = new ActiveXObject('Microsoft.XMLDOM');
                                    doc.async = false;
                                    try {
                                        doc.loadXML(xdr.responseText);
                                    } catch (e) {
                                        doc = undefined;
                                    }
                                    if (!doc || !doc.documentElement || doc.getElementsByTagName('parsererror').length) {
                                        status.code = 500;
                                        status.message = 'parseerror';
                                        throw 'Invalid XML: ' + xdr.responseText;
                                    }
                                    responses.xml = doc;
                                }
                            } catch (parseMessage) {
                                throw parseMessage;
                            } finally {
                                complete(status.code, status.message, responses, allResponseHeaders);
                            }
                        };
                        xdr.onerror = function () {
                            complete(500, 'error', {
                                text: xdr.responseText
                            });
                        };
						if(navigator.userAgent.indexOf("MSIE 9.0") != -1)
							xdr.onprogress = function() {};
                        xdr.open(options.type, options.url);
                        xdr.send(userOptions.data);
                        //xdr.send();
                    },
                    abort: function () {
                        if (xdr) {
                            xdr.abort();
                        }
                    }
                };
            }
        });
    }

    $.support.cors = true;

    ej.sortOrder = {
        Ascending: "ascending",
        Descending: "descending"
    };

    // privates
    ej.pvt.consts = {
        GROUPGUID: "{271bbba0-1ee7}",
        complexPropertyMerge: "_"
    };

    // private utils
    var nextTick = function (fn, context) {
        if (context) fn = $proxy(fn, context);
        (window.setImmediate || window.setTimeout)(fn, 0);
    };

    ej.support.enableLocalizedSort = false;

    var stableSort = function (ds, field, comparer, queries) {
        if (ej.support.stableSort) {
            if(!ej.support.enableLocalizedSort && typeof ej.pvt.getObject(field, ds[0] || {}) == "string" 
                && (comparer === ej.pvt.fnAscending || comparer === ej.pvt.fnDescending)
                && queries.filter(function(e){return e.fn === "onSortBy";}).length === 1)
                return fastSort(ds, field, comparer === ej.pvt.fnDescending);
            return ds.sort(ej.pvt.fnGetComparer(field, comparer));
        }
        return ej.mergeSort(ds, field, comparer);
    };
    var getColFormat = function (field, query) {
        var grpQuery = $.grep(query, function (args) { return args.fn == "onGroup" });
        for (var grp = 0; grp < grpQuery.length; grp++) {
            if (ej.getObject("fieldName", grpQuery[grp].e) == field) {
                return ej.getObject("fn", grpQuery[grp].e);
            }
        }
    };
    var fastSort = function(ds, field, isDesc){
        var old = Object.prototype.toString;
        Object.prototype.toString = (field.indexOf('.') === -1) ? function(){
            return this[field];
        }:function(){
            return ej.pvt.getObject(field, this);
        };
        ds = ds.sort();
        Object.prototype.toString = old;
        if(isDesc)
            ds.reverse();
    }

    var toLowerCase = function (val) {
        return val ? val.toLowerCase ? val.toLowerCase() : val.toString().toLowerCase() : (val === 0 || val === false) ? val.toString() : "";
    };

    var getVal = function (array, field, index) {
        return field ? ej.pvt.getObject(field, array[index]) : array[index];
    };

    var isHtmlElement = function (e) {
        return typeof HTMLElement === "object" ? e instanceof HTMLElement :
            e && e.nodeType === 1 && typeof e === "object" && typeof e.nodeName === "string";
    };

    var instance = function (obj, element) {
        return obj instanceof element;
    };

    var getTableModel = function (name, result, dm, computed) {
        return function (tName) {
            if (typeof tName === "object") {
                computed = tName;
                tName = null;
            }
            return new ej.TableModel(tName || name, result, dm, computed);
        };
    };

    var getKnockoutModel = function (result) {
        return function (computedObservables, ko) {
            ko = ko || window.ko;

            if (!ko) throwError("Knockout is undefined");

            var model, koModels = [], prop, ob;
            for (var i = 0; i < result.length; i++) {
                model = {};
                for (prop in result[i]) {
                    if (!prop.startsWith("_"))
                        model[prop] = ko.observable(result[i][prop]);
                }
                for (prop in computedObservables) {
                    ob = computedObservables[prop];

                    if ($.isPlainObject(ob)) {
                        if (!ob.owner) ob.owner = model;
                        ob = ko.computed(ob);
                    } else
                        ob = ko.computed(ob, model);

                    model[prop] = ob;
                }
                koModels.push(model);
            }

            return ko.observableArray(koModels);
        };
    };

    var uidIndex = 0;
    var getUid = function (prefix) {
        uidIndex += 1;
        return prefix + uidIndex;
    };

    ej.getGuid = function (prefix) {
        var hexs = '0123456789abcdef', rand;
        return (prefix || "") + '00000000-0000-4000-0000-000000000000'.replace(/0/g, function (val, i) {
            if ("crypto" in window && "getRandomValues" in crypto) {
                var arr = new Uint8Array(1)
                window.crypto.getRandomValues(arr);
                rand = arr[0] % 16|0
            }
            else rand = Math.random() * 16 | 0;
            return hexs[i === 19 ? rand & 0x3 | 0x8 : rand];
        });
    };

    var proxy = function (fn, context) {
        return function () {
            var args = [].slice.call(arguments, 0);
            args.push(this);

            return fn.apply(context || this, args);
        };
    };

    var $proxy = function (fn, context, arg) {
        if ('bind' in fn)
            return arg ? fn.bind(context, arg) : fn.bind(context);

        return function () {
            var args = arg ? [arg] : []; args.push.apply(args, arguments);
            return fn.apply(context || this, args);
        };
    };

    ej.merge = function (first, second) {
        if (!first || !second) return;

        Array.prototype.push.apply(first, second);
    };

    var isNull = function (val) {
        return val === undefined || val === null;
    };

    var throwError = function (er) {
        try {
            throw new Error(er);
        } catch (e) {
            throw e.message + "\n" + e.stack;
        }
    };

})(window.jQuery, window.Syncfusion, window.document);;
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ejSparkline;
(function (ejSparkline) {
    (function (Type) {
        Type[Type["Line"] = "line"] = "Line";
        Type[Type["Column"] = "column"] = "Column";
        Type[Type["Area"] = "area"] = "Area";
        Type[Type["WinLoss"] = "winloss"] = "WinLoss";
        Type[Type["Pie"] = 'pie'] = "Pie";
    })(ejSparkline.Type || (ejSparkline.Type = {}));
    var Type = ejSparkline.Type;
    (function (Themes) {
        Themes[Themes["flatlight"] = "flatlight"] = "flatlight";
        Themes[Themes["azurelight"] = "azurelight"] = "azurelight";
        Themes[Themes["limelight"] = "limelight"] = "limelight";
        Themes[Themes["saffronlight"] = "saffronlight"] = "saffronlight";
        Themes[Themes["gradientlight"] = "gradientlight"] = "gradientlight";
        Themes[Themes["flatdark"] = "flatdark"] = "flatdark";
        Themes[Themes["azuredark"] = "azuredark"] = "azuredark";
        Themes[Themes["limedark"] = "limedark"] = "limedark";
        Themes[Themes["saffrondark"] = "saffrondark"] = "saffrondark";
        Themes[Themes["gradientdark"] = "gradientdark"] = "gradientdark";
    })(ejSparkline.Themes || (ejSparkline.Themes = {}));
    var Themes = ejSparkline.Themes;
    (function ($) {
        var Sparkline = (function (_super) {
            __extends(Sparkline, _super);
            function Sparkline(id, options) {
                _super.call(this);
                this.defaults = {
                    locale: null,
                    enableGroupSeparator: false,
                    enableCanvasRendering: false,
                    padding: 8,
                    palette: ["#8A2BE2", "#ff1a75", "#99cc00", "#4d4dff", "#660066", "#FFA500", "#FFD700", "#FF00FF", "#808000", "#990000"],
                    isResponsive: true,
                    dataSource: null,
                    xName: "",
                    yName: "",
                    type: Type.Line,
                    width: 1,
                    stroke: null,
                    opacity: 1,
                    fill: "#33ccff",
                    border: {
                        color: "transparent",
                        width: 1,
                    },
                    rangeBandSettings: {
                        startRange: null,
                        endRange: null,
                        opacity: 0.4,
                        color: "transparent"
                    },
                    highPointColor: null,
                    lowPointColor: null,
                    negativePointColor: null,
                    startPointColor: null,
                    endPointColor: null,
                    tooltip: {
                        visible: false,
                        template: null,
                        fill: "white",
                        border: {
                            width: 1,
                            color: null,
                        },
                        font: {
                            fontFamily: "Segoe UI",
                            fontStyle: "Normal",
                            fontWeight: "Regular",
                            color: "#111111",
                            opacity: 1,
                            size: "8px"
                        }
                    },
                    markerSettings: {
                        visible: false,
                        fill: null,
                        width: 2,
                        opacity: 1,
                        border: {
                            color: "white",
                            width: 1,
                        }
                    },
                    background: "transparent",
                    size: {
                        height: "",
                        width: ""
                    },
                    axisLineSettings: {
                        visible: false,
                        color: "#111111",
                        width: 1,
                        dashArray: "",
                    },
                    theme: Themes.flatlight,
                    load: null,
                    loaded: null,
                    doubleClick: null,
                    rightClick: null,
                    click: null,
                    sparklineMouseMove: null,
                    sparklineMouseLeave: null,
                    seriesRendering: null,
                    pointRegionMouseMove: null,
                    pointRegionMouseClick: null,
                    tooltipInitialize: null,
                };
                this.dataTypes = {
                    dataSource: "data",
                    palette: "array",
                    type: "enum",
                    theme: "enum",
                };
                this.model = null;
                this.svgLink = "http://www.w3.org/2000/svg";
                this._id = null;
                this.negativePointIndexes = [];
                this.validTags = ['div'];
                this._id = id;
                if (!!options)
                    this.model = ejSparkline.compareExtend({}, options, this.defaults);
            }
            Sparkline.prototype.isTouch = function (evt) {
                var event = evt.originalEvent ? evt.originalEvent : evt;
                if ((event.pointerType == "touch") || (event.pointerType == 2) || (event.type.indexOf("touch") > -1))
                    return true;
                return false;
            };
            Sparkline.prototype.browserInfo = function () {
                var browser = {}, clientInfo = [], browserClients = {
                    webkit: /(chrome)[ \/]([\w.]+)/i, safari: /(webkit)[ \/]([\w.]+)/i, msie: /(msie) ([\w.]+)/i,
                    opera: /(opera)(?:.*version|)[ \/]([\w.]+)/i, mozilla: /(mozilla)(?:.*? rv:([\w.]+)|)/i
                };
                for (var client in browserClients) {
                    if (browserClients.hasOwnProperty(client)) {
                        clientInfo = navigator.userAgent.match(browserClients[client]);
                        if (clientInfo) {
                            browser.name = clientInfo[1].toLowerCase();
                            browser.version = clientInfo[2];
                            if (!!navigator.userAgent.match(/Trident\/7\./)) {
                                browser.name = "msie";
                            }
                            break;
                        }
                    }
                }
                browser.isMSPointerEnabled = (browser.name == 'msie') && browser.version > 9 && window.navigator.msPointerEnabled;
                browser.pointerEnabled = window.navigator.pointerEnabled;
                return browser;
            };
            Sparkline.prototype.fadeOut = function (tooltip) {
                var op = 1;
                var timer = setInterval(function () {
                    if (op <= 0.1) {
                        clearInterval(timer);
                        tooltip.parentNode ? tooltip.parentNode.removeChild(tooltip) : tooltip;
                    }
                    tooltip.style.opacity = op;
                    tooltip.style.filter = 'alpha(opacity=' + op * 100 + ")";
                    op -= op * 0.1;
                }, 50);
            };
            Sparkline.prototype._setModel = function (options) {
                for (var prop in options) {
                    var $content;
                    switch (prop) {
                        default:
                            ejSparkline.deepExtend(true, this.model, {}, options[prop]);
                    }
                }
                this.redraw();
            };
            Sparkline.prototype.unBindEvents = function () {
                var sparklineEle = document.getElementById(this.rootId), insideEvents = "", browserInfo = this.browserInfo(), isPointer = browserInfo.isMSPointerEnabled, isIE11Pointer = browserInfo.pointerEnabled, touchStopEvent = isPointer ? (isIE11Pointer ? "pointerup" : "MSPointerUp") : "touchend mouseup", touchMoveEvent = isPointer ? (isIE11Pointer ? "pointermove" : "MSPointerMove") : "touchmove mousemove";
                insideEvents = touchStopEvent + " " + touchMoveEvent;
                insideEvents = insideEvents.split(" ");
                for (var event = 0; event < insideEvents.length; event++) {
                    sparklineEle.removeEventListener(insideEvents[event], this.sparkMouseMove);
                }
                sparklineEle.removeEventListener("mouseout", this.sparkMouseLeave);
            };
            Sparkline.prototype.bindClickEvents = function (ele) {
                this.sparkClick = this.sparkClick.bind(this);
                if (ej.isTouchDevice()) {
                    this.sparkTouchStart = this.sparkTouchStart.bind(this);
                    ele.addEventListener("touchend", this.sparkClick);
                    ele.addEventListener("touchstart", this.sparkTouchStart);
                }
                else {
                    this.sparkDoubleClick = this.sparkDoubleClick.bind(this);
                    this.sparkRightClick = this.sparkRightClick.bind(this);
                    ele.addEventListener("click", this.sparkClick);
                    ele.addEventListener("dblclick", this.sparkDoubleClick);
                    ele.addEventListener("contextmenu", this.sparkRightClick);
                }
            };
            Sparkline.prototype.unBindClickEvents = function (ele) {
                if (ej.isTouchDevice()) {
                    ele.removeEventListener("touchend", this.sparkClick);
                    ele.removeEventListener("touchstart", this.sparkTouchStart);
                }
                else {
                    ele.removeEventListener("click", this.sparkClick);
                    ele.removeEventListener("dblclick", this.sparkDoubleClick);
                    ele.removeEventListener("contextmenu", this.sparkRightClick);
                }
            };
            Sparkline.prototype.bindEvents = function (ele) {
                this.sparkMouseMove = this.sparkMouseMove.bind(this);
                this.sparkMouseLeave = this.sparkMouseLeave.bind(this);
                var insideEvents = "", browserInfo = this.browserInfo(), isPointer = browserInfo.isMSPointerEnabled, isIE11Pointer = browserInfo.pointerEnabled, touchStopEvent = isPointer ? (isIE11Pointer ? "pointerup" : "MSPointerUp") : "touchend mouseup", touchMoveEvent = isPointer ? (isIE11Pointer ? "pointermove" : "MSPointerMove") : "touchmove mousemove";
                insideEvents = touchStopEvent + " " + touchMoveEvent;
                insideEvents = insideEvents.split(" ");
                for (var event = 0; event < insideEvents.length; event++) {
                    ele.addEventListener(insideEvents[event], this.sparkMouseMove);
                }
                ele.addEventListener("mouseout", this.sparkMouseLeave);
            };
            Sparkline.prototype.sparkTouchStart = function (event) {
                this._longPressTimer = new Date();
            };
            Sparkline.prototype.sparkClick = function (event) {
                var end = new Date();
                if (this.model.click != null)
                    this._trigger("click", { data: { event: event } });
                if (ej.isTouchDevice() && event.type != 'click') {
                    if (this._doubleTapTimer != null && ((end - this._doubleTapTimer) < 300))
                        this.sparkDoubleClick(event);
                    this._doubleTapTimer = end;
                    if (this._longPressTimer != null && end - this._longPressTimer > 1000)
                        this.sparkRightClick(event);
                }
            };
            Sparkline.prototype.sparkDoubleClick = function (event) {
                if (this.model.doubleClick != null)
                    this._trigger("doubleClick", { data: { event: event } });
            };
            Sparkline.prototype.sparkRightClick = function (event) {
                if (this.model.rightClick != null)
                    this._trigger("rightClick", { data: { event: event } });
            };
            Sparkline.prototype.sparkMouseMove = function (evt) {
                var isTouch = this.isTouch(evt);
                if (!(isTouch && (evt.type.toString().toLowerCase().indexOf("move") > -1))) {
                    var model = this.model, currentObj = this, locale = model.locale, localizedText = locale && model.enableGroupSeparator, tooltipXValue, tooltipYValue, pointsLocations = this.visiblePoints, markerId = this.container.id + "_markerExplode", pointIndex, text, labelText, markerOptions, tooltipOptions, textOptions, textPad = model.enableCanvasRendering ? 0 : 3, tooltipShape = '', tooltipHeight, tooltipWidth, eventArgs, tooltip, markerFill, containerHeight = parseInt(model.size.height), containerWidth = parseInt(model.size.width), font = model.tooltip.font, xFormat = "#point.x#", yFormat = "#point.y#", tooltipId = this.container.id + "_tooltip", tracker = document.getElementById(tooltipId), trackerPosX, tooltipBorder = model.tooltip.border.color, trackballOptions, rootele = document.getElementById(this.container.id), height = rootele.clientHeight, parent = rootele.parentNode, offset = rootele.getClientRects()[0], trackerTop = offset.top, trackerLeft = offset.left, mouseX = evt.clientX || (evt.changedTouches ? evt.changedTouches[0].clientX : evt.touches ? evt.touches[0].clientX : 0), mouseY = evt.clientY || (evt.changedTouches ? evt.changedTouches[0].clientY : evt.touches ? evt.touches[0].clientY : 0), trackerPositions = pointsLocations.map(function (obj) { return obj['location']['X'] + offset.left; }), tooltipPos = pointsLocations.map(function (obj) { return obj['location']['markerPos'] + offset.top; }), temp = Infinity, measure = this.measureText, pad, spMarker = this.model.markerSettings, mousePos, canvasTracker, canvasContext, canvasOptions, X, Y, canTracker = document.getElementById(this.container.id + "_canvasTracker");
                    for (var i = 0, diff, len = trackerPositions.length; i < len; i++) {
                        diff = Math.abs(mouseX - trackerPositions[i]);
                        if (temp > diff) {
                            temp = diff;
                            mousePos = trackerPositions[i];
                            this.pointIndex = i;
                        }
                    }
                    if ((mouseX > trackerLeft && mouseX < (trackerLeft + offset.width)) && (mouseY > trackerTop && mouseY < (trackerTop + offset.height))) {
                        temp = pointsLocations[this.pointIndex]['location'];
                        var trackTooltipModify = function (text) {
                            pad = text.length / 2;
                            var size = measure(text, font);
                            tooltipHeight = size.height + 4;
                            tooltipWidth = size.width + pad;
                            X = temp['X'];
                            Y = temp['markerPos'];
                            if ((Y - tooltipHeight / 2) < 0)
                                Y += (tooltipHeight / 2);
                            else if ((Y + tooltipHeight / 2) > containerHeight)
                                Y -= (tooltipHeight / 2);
                            if ((X + tooltipWidth + (tooltipWidth / 10)) > (containerWidth - model.padding)) {
                                X = (temp['X'] - Number(model.markerSettings.width) - Number(model.markerSettings.border.width) - 4);
                                tooltipShape = 'M ' + (X) + " " + temp['markerPos'] + " L " + (X - tooltipWidth / 10) + " " + (Y - 4) + " L " + (X - tooltipWidth / 10) + " " + (Y - (tooltipHeight / 2)) + " L " + (X - tooltipWidth - tooltipWidth / 10) + " " + (Y - (tooltipHeight / 2)) + " L " + (X - tooltipWidth - tooltipWidth / 10) + " " + (Y + (tooltipHeight / 2)) + " L " + (X - tooltipWidth / 10) + " " + (Y + (tooltipHeight / 2)) + " L " + (X - tooltipWidth / 10) + " " + (Y + 4) + " Z";
                            }
                            else {
                                X = (temp['X'] + Number(model.markerSettings.width) + Number(model.markerSettings.border.width) + 4);
                                tooltipShape = 'M ' + (X) + " " + temp['markerPos'] + " L " + (X + tooltipWidth / 10) + " " + (Y - 4) + " L " + (X + tooltipWidth / 10) + " " + (Y - (tooltipHeight / 2)) + " L " + (X + tooltipWidth + tooltipWidth / 10) + " " + (Y - (tooltipHeight / 2)) + " L " + (X + tooltipWidth + tooltipWidth / 10) + " " + (Y + (tooltipHeight / 2)) + " L " + (X + tooltipWidth / 10) + " " + (Y + (tooltipHeight / 2)) + " L " + (X + tooltipWidth / 10) + " " + (Y + 4) + " Z";
                            }
                        };
                        if (model.tooltip.template == null || model.tooltip.template == "") {
                            tooltipXValue = localizedText && temp['Xval'] ? temp['Xval'].toLocaleString(locale) : temp['Xval'];
                            tooltipYValue = localizedText && temp['Yval'] ? temp['Yval'].toLocaleString(locale) : temp['Yval'];
                            labelText = " X : " + tooltipXValue + " Y : " + tooltipYValue + " ";
                            trackTooltipModify(labelText);
                        }
                        pointIndex = this.pointIndex;
                        if (this.prevMousePos == undefined) {
                            this.prevMousePos = mousePos;
                        }
                        var checkPointFill = function (index) {
                            var mFill, highIndex = currentObj.highPointIndex, lowIndex = currentObj.lowPointIndex, negatives = currentObj.negativePointIndexes, startIndex = currentObj.startPointIndex, endIndex = currentObj.endPointIndex;
                            if (index == highIndex)
                                mFill = model.highPointColor;
                            else if (index == lowIndex)
                                mFill = model.lowPointColor;
                            else if (index == startIndex && (model.startPointColor != null))
                                mFill = model.startPointColor;
                            else if (index == endIndex && (model.endPointColor != null))
                                mFill = model.endPointColor;
                            else if (negatives.indexOf(index) >= 0 && model.negativePointColor != null)
                                mFill = model.negativePointColor;
                            else
                                mFill = spMarker.fill ? spMarker.fill : model.fill;
                            return mFill;
                        };
                        if (tracker || canTracker) {
                            if (this.prevMousePos != mousePos) {
                                eventArgs = {
                                    data: {
                                        "pointIndex": pointIndex,
                                        "currentText": labelText,
                                        "location": temp
                                    }
                                };
                                if (this.model.tooltipInitialize != null)
                                    this._trigger("tooltipInitialize", eventArgs);
                                trackerPosX = (temp['X'] - (model.width / 2));
                                if (labelText != eventArgs.data.currentText) {
                                    labelText = eventArgs.data.currentText;
                                    trackTooltipModify(labelText);
                                }
                                this.prevMousePos = mousePos;
                                markerFill = checkPointFill(pointIndex);
                                markerOptions = {
                                    'id': markerId,
                                    'cx': temp['X'],
                                    'cy': temp['markerPos'],
                                    'r': Number(spMarker.width),
                                    'fill': spMarker.border.color,
                                    'stroke': markerFill,
                                    'stroke-width': Number(spMarker.border.width),
                                };
                                if (model.tooltip.template == null || model.tooltip.template == "") {
                                    tooltipOptions = {
                                        'id': tooltipId,
                                        'fill': model.tooltip.fill,
                                        'stroke': (tooltipBorder != null) ? tooltipBorder : markerFill,
                                        'stroke-width': model.tooltip.border.width,
                                        'd': tooltipShape
                                    };
                                    textOptions = {
                                        'x': (temp['X'] + tooltipWidth + (tooltipWidth / 10)) > (containerWidth - model.padding) ? (X + textPad - (tooltipWidth) - (tooltipWidth / 10)) : X + textPad + (tooltipWidth / 10),
                                        'y': Y + tooltipHeight / 4,
                                        'fill': font.color,
                                        'font-size': font.size,
                                        'font-family': font.fontFamily,
                                        'font-weight': font.fontWeight,
                                        'font-style': font.fontStyle,
                                    };
                                }
                                else {
                                    var ele = document.getElementById(model.tooltip.template), html = ele.innerHTML, dataValue;
                                    if (typeof model.dataSource[pointIndex] === 'object') {
                                        dataValue = model.dataSource[pointIndex];
                                        dataValue.x = temp.Xval;
                                        dataValue.y = temp.Yval;
                                    }
                                    else {
                                        dataValue = { x: temp.Xval, y: temp.Yval };
                                    }
                                    var tooltipData = { point: dataValue }, html = this.parseTemplate(ele, tooltipData), text1 = ele.innerText, gap = Number(model.markerSettings.width), text1 = this.parseTemplate(ele, tooltipData), template = measure(text1, font), toolX = temp['X'] + Number(spMarker.width) + Number(spMarker.border.width) + gap;
                                    Y = (trackerTop + temp['markerPos'] - template['height'] / 2);
                                    X = (trackerLeft + toolX);
                                    if ((temp['markerPos'] - template['height'] / 2) < model.padding)
                                        Y += (template['height'] / 2);
                                    else if ((temp['markerPos'] + template['height'] / 2) > (containerHeight - model.padding))
                                        Y -= (template['height'] / 2);
                                    if ((toolX + template['width']) > (containerWidth - model.padding))
                                        X = (X - template['width']) - ((Number(spMarker.width) + Number(spMarker.border.width) + gap) * 2);
                                    tooltipOptions = {
                                        'background': model.tooltip.fill,
                                        'border': model.tooltip.border.width + 'px solid ' + ((tooltipBorder != null) ? tooltipBorder : markerFill),
                                        'left': X + 'px',
                                        'top': Y + 'px',
                                    };
                                    tooltip = document.getElementById(tooltipId),
                                        tooltip.innerHTML = html;
                                    this.setStyles(tooltipOptions, tooltip);
                                }
                                if (!model.enableCanvasRendering) {
                                    var groupTooltip = document.getElementById(tooltipId + "_g");
                                    this.drawCircle(markerOptions, groupTooltip);
                                    if (model.tooltip.template == null) {
                                        this.drawPath(tooltipOptions, groupTooltip);
                                        text = rootele.getElementsByTagName('text')[0];
                                        text.textContent = labelText;
                                        this.setAttributes(textOptions, text);
                                        groupTooltip.appendChild(text);
                                    }
                                }
                                else {
                                    canvasTracker = document.getElementById(this.container.id + "_canvasTracker");
                                    canvasContext = canvasTracker.getContext('2d');
                                    canvasContext.clearRect(0, 0, containerWidth, containerHeight);
                                    this.canvasDrawCircle(markerOptions, canvasContext);
                                    if (model.tooltip.template == null || model.tooltip.template == "") {
                                        this.canvasDrawPath(tooltipOptions, canvasContext);
                                        textOptions.font = font.size + " " + font.fontFamily;
                                        this.canvasDrawText(textOptions, labelText, canvasContext);
                                    }
                                }
                            }
                        }
                        else {
                            eventArgs = {
                                data: {
                                    "pointIndex": pointIndex,
                                    "currentText": labelText,
                                    "location": temp
                                }
                            };
                            if (this.model.tooltipInitialize != null)
                                this._trigger("tooltipInitialize", eventArgs);
                            trackerPosX = (temp['X'] - (model.width / 2));
                            if (labelText != eventArgs.data.currentText) {
                                labelText = eventArgs.data.currentText;
                                trackTooltipModify(labelText);
                            }
                            var tooltipElements = document.getElementsByClassName("ej-sparkline-tooltip");
                            if (tooltipElements[0]) {
                                tooltipElements[0].parentNode.removeChild(tooltipElements[0]);
                            }
                            markerFill = checkPointFill(pointIndex);
                            markerOptions = {
                                'id': markerId,
                                'cx': temp['X'],
                                'cy': temp['markerPos'],
                                'r': Number(spMarker.width),
                                'fill': spMarker.border.color,
                                'stroke': markerFill,
                                'stroke-width': Number(spMarker.border.width),
                            };
                            if (model.tooltip.template == null || model.tooltip.template == "") {
                                tooltipOptions = {
                                    'id': tooltipId,
                                    'fill': model.tooltip.fill,
                                    'stroke': (tooltipBorder != null) ? tooltipBorder : markerFill,
                                    'stroke-width': model.tooltip.border.width,
                                    'd': tooltipShape
                                };
                                textOptions = {
                                    'x': (temp['X'] + tooltipWidth + (tooltipWidth / 10)) > (containerWidth - model.padding) ? (X + textPad - (tooltipWidth) - (tooltipWidth / 10)) : X + textPad + (tooltipWidth / 10),
                                    'y': Y + tooltipHeight / 4,
                                    'fill': font.color,
                                    'opacity': font.opacity,
                                    'font-size': font.size,
                                    'font-family': font.fontFamily,
                                    'font-weight': font.fontWeight,
                                    'font-style': font.fontStyle,
                                };
                            }
                            else {
                                var ele = document.getElementById(model.tooltip.template), html = ele.innerHTML, dataValue;
                                if (typeof model.dataSource[pointIndex] === 'object') {
                                    dataValue = model.dataSource[pointIndex];
                                    dataValue.x = temp.Xval;
                                    dataValue.y = temp.Yval;
                                }
                                else {
                                    dataValue = { x: temp.Xval, y: temp.Yval };
                                }
                                var tooltipData = { point: dataValue }, html = this.parseTemplate(ele, tooltipData), text1 = ele.innerText, gap = Number(model.markerSettings.width), text1 = this.parseTemplate(ele, tooltipData), template = measure(text1, font);
                                var toolX = temp['X'] + Number(spMarker.width) + Number(spMarker.border.width) + gap;
                                Y = (trackerTop + temp['markerPos'] - template['height'] / 2);
                                X = (trackerLeft + toolX);
                                if ((temp['markerPos'] - template['height'] / 2) < model.padding)
                                    Y += (template['height'] / 2);
                                else if ((temp['markerPos'] + template['height'] / 2) > (containerHeight - model.padding))
                                    Y -= (template['height'] / 2);
                                if ((toolX + template['width']) > (containerWidth - model.padding))
                                    X = (X - template['width']) - ((Number(spMarker.width) + Number(spMarker.border.width) + gap) * 2);
                                tooltipOptions = {
                                    'background': model.tooltip.fill,
                                    'border': model.tooltip.border.width + 'px solid ' + ((tooltipBorder != null) ? tooltipBorder : markerFill),
                                    'left': X + 'px',
                                    'top': Y + 'px',
                                    'position': 'fixed',
                                    'height': 'auto',
                                    'width': 'auto',
                                    'display': 'block',
                                    'opacity': font.opacity,
                                    'font': font.size + " " + font.fontFamily,
                                };
                                tooltip = document.createElement('div');
                                this.setAttributes({ 'id': tooltipId, 'class': 'ej-sparkline-tooltip' }, tooltip);
                                this.setStyles(tooltipOptions, tooltip);
                                tooltip.innerHTML = html;
                                parent.appendChild(tooltip);
                            }
                            if (!model.enableCanvasRendering) {
                                var tooltipGroup = document.createElementNS(this.svgLink, "g");
                                this.setAttributes({ "id": tooltipId + "_g", 'class': 'ej-sparkline-tooltip' }, tooltipGroup);
                                this.container.appendChild(tooltipGroup);
                                this.drawCircle(markerOptions, tooltipGroup);
                                if (model.tooltip.template == null) {
                                    this.drawPath(tooltipOptions, tooltipGroup);
                                    text = this.createText(textOptions, labelText);
                                    tooltipGroup.appendChild(text);
                                }
                            }
                            else {
                                canvasTracker = document.createElement('canvas');
                                canvasOptions =
                                    {
                                        'id': this.container.id + "_canvasTracker",
                                        'fill': 'transparent',
                                        'class': 'ej-sparkline-tooltip',
                                        'height': model.size.height,
                                        'width': model.size.width,
                                    };
                                this.setAttributes(canvasOptions, canvasTracker);
                                this.setStyles({ 'left': (trackerLeft) + 'px', 'top': (trackerTop) + 'px', 'position': 'fixed' }, canvasTracker);
                                canvasContext = canvasTracker.getContext('2d');
                                this.canvasDrawCircle(markerOptions, canvasContext);
                                if (model.tooltip.template == null || model.tooltip.template == "") {
                                    this.canvasDrawPath(tooltipOptions, canvasContext);
                                    textOptions.font = font.size + " " + font.fontFamily;
                                    this.canvasDrawText(textOptions, labelText, canvasContext);
                                }
                                this.container.parentNode.appendChild(canvasTracker);
                            }
                        }
                    }
                    if (isTouch) {
                        var eleId = (model.tooltip.template == null || model.tooltip.template == "") ? ((model.enableCanvasRendering) ? (this.container.id + "_canvasTracker") : (tooltipId + "_g")) : (tooltipId);
                        var touchtooltip = document.getElementById(eleId);
                        var sparklineObj = this;
                        setTimeout(function () {
                            sparklineObj.fadeOut(touchtooltip);
                        }, 1000);
                    }
                }
            };
            Sparkline.prototype.sparkMouseLeave = function (evt) {
                var mouseX = evt.clientX || (evt.touches[0] ? evt.touches[0].clientX : evt.changedTouches[0].clientX), mouseY = evt.clientY || (evt.touches[0] ? evt.touches[0].clientY : evt.changedTouches[0].clientY), rootele = this.container, height = rootele.clientHeight, offset = rootele.getClientRects()[0], trackerTop = offset.top, trackerLeft = offset.left, model = this.model, tooltipId = this.container.id + "_tooltip";
                if ((mouseX < trackerLeft || mouseX > (trackerLeft + offset.width)) || (mouseY < trackerTop || mouseY > (trackerTop + offset.height)) || this.touchEnd) {
                    if (model.tooltip.template != null && model.tooltip.template != "") {
                        var tooltemp = document.getElementById(tooltipId);
                        tooltemp ? tooltemp.parentNode.removeChild(tooltemp) : tooltemp;
                    }
                    if (!this.model.enableCanvasRendering) {
                        var trackerId = tooltipId + "_g", tracker = document.getElementById(trackerId);
                        tracker ? this.container.removeChild(tracker) : tracker;
                    }
                    else {
                        var canEle = document.getElementById(this.container.id + '_canvasTracker');
                        canEle ? canEle.parentNode.removeChild(canEle) : canEle;
                    }
                }
            };
            Sparkline.prototype.bindPieEvents = function (ele) {
                this.pieTooltip = this.pieTooltip.bind(this);
                this.pieTooltipHide = this.pieTooltipHide.bind(this);
                var insideEvents = "", browserInfo = this.browserInfo(), isPointer = browserInfo.isMSPointerEnabled, isIE11Pointer = browserInfo.pointerEnabled, touchStopEvent = isPointer ? (isIE11Pointer ? "pointerup" : "MSPointerUp") : "touchend mouseup", touchMoveEvent = isPointer ? (isIE11Pointer ? "pointermove" : "MSPointerMove") : "touchmove mousemove";
                insideEvents = touchStopEvent + " " + touchMoveEvent;
                insideEvents = insideEvents.split(" ");
                for (var event = 0; event < insideEvents.length; event++) {
                    ele.addEventListener(insideEvents[event], this.pieTooltip);
                }
                ele.addEventListener("mouseout", this.pieTooltipHide);
                if (this.model.pointRegionMouseClick != null) {
                    ele.addEventListener("click", this.pieTooltip);
                    ele.addEventListener("touchstart", this.pieTooltip);
                }
            };
            Sparkline.prototype.unbindPieEvents = function () {
                var insideEvents = "", browserInfo = this.browserInfo(), isPointer = browserInfo.isMSPointerEnabled, isIE11Pointer = browserInfo.pointerEnabled, touchStopEvent = isPointer ? (isIE11Pointer ? "pointerup" : "MSPointerUp") : "touchend mouseup", touchMoveEvent = isPointer ? (isIE11Pointer ? "pointermove" : "MSPointerMove") : "touchmove mousemove", sparklineEle = document.getElementById(this.rootId);
                insideEvents = touchStopEvent + " " + touchMoveEvent;
                insideEvents = insideEvents.split(" ");
                for (var event = 0; event < insideEvents.length; event++) {
                    sparklineEle.removeEventListener(insideEvents[event], this.pieTooltip);
                }
                sparklineEle.removeEventListener("mouseout", this.pieTooltipHide);
            };
            Sparkline.prototype.pieTooltip = function (evt) {
                var isTouch = this.isTouch(evt);
                if (isTouch)
                    evt.stopImmediatePropagation();
                if (!(isTouch && (evt.type.toString().toLowerCase().indexOf("move") > -1))) {
                    if (this.model.sparklineMouseMove != null)
                        this._trigger("sparklineMouseMove");
                    var model = this.model, mouseX = evt.clientX || (evt.changedTouches ? evt.changedTouches[0].clientX : evt.touches ? evt.touches[0].clientX : 0), containerHeight = parseInt(model.size.height), containerWidth = parseInt(model.size.width), font = model.tooltip.font, mouseY = evt.clientY || (evt.changedTouches ? evt.changedTouches[0].clientY : evt.touches ? evt.touches[0].clientY : 0), rootele = document.getElementById(this.container.id), parent = rootele.parentNode, offset = rootele.getClientRects()[0], containerTop = offset.top, containerLeft = offset.left, visiblePos = this.visiblePoints.map(function (a) { return a['coordinates']; }), data = this.visiblePoints.map(function (a) { return a['location']; }), radius = this.visiblePoints['radius'], centerPos = this.visiblePoints['centerPos'], angles = this.visiblePoints, currStDeg, currEdDeg, sliceIndex, dx = mouseX - (centerPos.X + containerLeft), dy = mouseY - (centerPos.Y + containerTop), angle = Math.atan2(dy, dx), pietipId = this.container.id + "_pieTooltip", tooltip = document.getElementById(pietipId), tooltipOptions, tooltipBorder = model.tooltip.border.color, pointRadius = Math.sqrt(dx * dx + dy * dy), eventType = (model.pointRegionMouseClick != null) ? "pointRegionMouseClick" : (model.pointRegionMouseMove != null) ? "pointRegionMouseMove" : null, colors = model.palette, locale = model.locale, localizedText = model.enableGroupSeparator;
                    if (Math.abs(pointRadius) <= radius) {
                        for (var i = 0, len = angles.length; i < len; i++) {
                            currStDeg = angles[i]['stAng'];
                            currEdDeg = angles[i]['endAng'];
                            angle = angle < 0 ? (6.283 + angle) : angle;
                            if (angle <= currEdDeg && angle >= currStDeg) {
                                sliceIndex = i;
                                if ((eventType == "pointRegionMouseClick" && (evt.type == "click" || evt.type == "touchstart")) || eventType == "pointRegionMouseMove")
                                    this._trigger(eventType, {
                                        data: {
                                            "pointIndex": i,
                                            "seriesType": "Pie",
                                            'locationX': mouseX,
                                            'locationY': mouseY
                                        }
                                    });
                            }
                        }
                    }
                    else if (tooltip)
                        tooltip.parentNode.removeChild(tooltip);
                    if (tooltip && sliceIndex != null) {
                        var text = data[sliceIndex]['Percent'].toFixed(2);
                        text = localizedText ? "&nbsp" + parseFloat(text).toLocaleString(locale) : text + "&nbsp%&nbsp";
                        var size = this.measureText(text, font);
                        tooltipOptions = {
                            'left': mouseX + 12 + "px",
                            'top': mouseY + "px",
                            'border': model.tooltip.border.width + "px solid " + ((tooltipBorder != null) ? tooltipBorder : colors[sliceIndex % colors.length]),
                            'background-color': model.tooltip.fill,
                            'height': size.height + "px",
                            'width': size.width + "px",
                        };
                        this.setStyles(tooltipOptions, tooltip);
                        tooltip.innerHTML = text;
                    }
                    else if (sliceIndex != null) {
                        tooltip = document.createElement('div');
                        var text = data[sliceIndex]['Percent'].toFixed(2);
                        text = localizedText ? "&nbsp" + parseFloat(text).toLocaleString(locale) : text + "&nbsp%&nbsp";
                        var size = this.measureText(text, font);
                        tooltipOptions = {
                            'left': mouseX + 12 + "px",
                            'top': mouseY + "px",
                            'background-color': model.tooltip.fill,
                            'color': font.color,
                            'border': model.tooltip.border.width + "px solid " + ((tooltipBorder != null) ? tooltipBorder : colors[sliceIndex % colors.length]),
                            'height': size.height + "px",
                            'width': size.width + "px",
                            'font-size': font.size,
                            'opacity': font.opacity,
                            'font-weight': font.fontWeight,
                            'font-family': font.fontFamily,
                            'font-style': font.fontStyle,
                            'z-index': "100000",
                            'position': "fixed"
                        };
                        tooltip.setAttribute('id', pietipId);
                        this.setStyles(tooltipOptions, tooltip);
                        tooltip.innerHTML = text;
                        document.body.appendChild(tooltip);
                    }
                    if (isTouch) {
                        this.touchEnd = true;
                        var touchtooltip = document.getElementById(this.container.id + "_pieTooltip");
                        var sparklineObj = this;
                        setTimeout(function () {
                            sparklineObj.fadeOut(touchtooltip);
                        }, 500);
                    }
                }
            };
            Sparkline.prototype.pieTooltipHide = function (evt) {
                if (!this.touchEnd) {
                    if (this.model.sparklineMouseLeave != null)
                        this._trigger("sparklineMouseLeave");
                    var pietipId = this.container.id + "_pieTooltip", tooltip = document.getElementById(pietipId);
                    tooltip ? document.body.removeChild(tooltip) : tooltip;
                }
            };
            Sparkline.prototype.bindRegionEvents = function (ele) {
                this.sparklineEvent = this.sparklineEvent.bind(this);
                var browser = this.findBrowser();
                if (browser == "IE" || browser == 'firefox') {
                    ele.style['touch-action'] = 'none';
                }
                if (this.model.pointRegionMouseMove != null) {
                    ele.addEventListener("mousemove", this.sparklineEvent, true);
                    ele.addEventListener("touchmove", this.sparklineEvent, true);
                }
                if (this.model.pointRegionMouseClick != null) {
                    ele.addEventListener("click", this.sparklineEvent, true);
                    ele.addEventListener("touchstart", this.sparklineEvent, true);
                }
                if (this.model.sparklineMouseMove != null) {
                    ele.addEventListener("mousemove", this.sparklineEvent, true);
                    ele.addEventListener("touchmove", this.sparklineEvent, true);
                }
                if (this.model.sparklineMouseLeave != null) {
                    this.sparklineLeave = this.sparklineLeave.bind(this);
                    ele.addEventListener('mouseout', this.sparklineLeave, true);
                    if (browser == 'firefox') {
                        ele.addEventListener('mouseup', this.sparklineLeave, true);
                    }
                    ele.addEventListener('touchend', this.sparklineLeave, true);
                }
            };
            Sparkline.prototype.sparklineLeave = function () {
                if (this.model.sparklineMouseLeave != null)
                    this._trigger("sparklineMouseLeave");
            };
            Sparkline.prototype.sparklineEvent = function (evt) {
                if (this.model.sparklineMouseMove != null)
                    this._trigger("sparklineMouseMove");
                var model = this.model, mouseX = evt.clientX || evt.touches[0].clientX, mouseY = evt.clientY || evt.touches[0].clientY, stype = model.type, pointLoc = this.visiblePoints, rX1, rY1, rX2, rY2, width, height, rootele = document.getElementById(this.container.id), parent = rootele.parentNode, offset = rootele.getClientRects()[0], containerTop = offset.top, containerLeft = offset.left, eventType;
                eventType = (model.pointRegionMouseClick != null) ? "pointRegionMouseClick" : (model.pointRegionMouseMove != null) ? "pointRegionMouseMove" : null;
                if (stype == Type.Line || stype == Type.Area) {
                    width = 2 * (model.markerSettings.width + model.markerSettings.border.width);
                    height = width;
                    for (var i = 0, len = pointLoc.length; i < len; i++) {
                        rX1 = containerLeft + pointLoc[i]['location'].X - (width / 2);
                        rY1 = containerTop + pointLoc[i]['location'].Y - (height / 2);
                        rX2 = rX1 + width;
                        rY2 = rY1 + height;
                        if (mouseX >= rX1 && mouseX <= rX2 && mouseY >= rY1 && mouseY <= rY2) {
                            if (eventType != null)
                                this._trigger(eventType, {
                                    data: {
                                        "pointIndex": i,
                                        "seriesType": stype,
                                        'locationX': pointLoc[i]['location'].X,
                                        'locationY': pointLoc[i]['location'].Y
                                    }
                                });
                        }
                    }
                }
                else if (stype == Type.Column || stype == Type.WinLoss) {
                    width = pointLoc[0]['location'].width;
                    for (var i = 0, len = pointLoc.length; i < len; i++) {
                        height = pointLoc[i]['location'].height;
                        rX1 = containerLeft + pointLoc[i]['location'].X - (width / 2);
                        rY1 = containerTop + pointLoc[i]['location'].Y;
                        rX2 = rX1 + width;
                        rY2 = rY1 + height;
                        if (mouseX >= rX1 && mouseX <= rX2 && mouseY >= rY1 && mouseY <= rY2) {
                            if (eventType != null)
                                this._trigger(eventType, {
                                    data: {
                                        "pointIndex": i,
                                        "seriesType": stype,
                                        'locationX': pointLoc[i]['location'].X,
                                        'locationY': pointLoc[i]['location'].Y
                                    }
                                });
                        }
                    }
                }
            };
            Sparkline.prototype.findBrowser = function () {
                var browser;
                if (navigator.userAgent.indexOf("Firefox") != -1) {
                    browser = 'firefox';
                }
                else if ((navigator.userAgent.indexOf("MSIE") != -1) || (!!document['documentMode'] == true)) {
                    browser = 'IE';
                }
                else {
                    browser = null;
                }
                return browser;
            };
            Sparkline.prototype.resize = function (evt) {
                var currentObj = this;
                var element = document.getElementById(this.rootId);
                if (element != null || element != undefined) {
                    window.removeEventListener("resize", this.resize);
                    this.isResized = true;
                    this._destroy();
                    this.createSvg();
                    this.renderSparkline();
                    this.isResized = false;
                }
                else {
                    window.removeEventListener("resize", this.resize);
                }
            };
            Sparkline.prototype.supportsSvg = function () {
                return !!document.createElementNS && !!document.createElementNS('http://www.w3.org/2000/svg', "svg");
            };
            Sparkline.prototype._init = function (options) {
                if (this.supportsSvg()) {
                    this.rootId = (this.rootId != null) ? this.rootId : this._id;
                    this.parentElement = (this.parentElement != null) ? this.parentElement : document.getElementById(this.rootId);
                    if (this.model.load != null)
                        this._trigger("load");
                    this.setTheme(this.model);
                    this.height = parseInt(this.model.size.height);
                    this.width = parseInt(this.model.size.width);
                    this.createSvg();
                    this.renderSparkline();
                    if (this.model.loaded != null)
                        this._trigger("loaded");
                }
            };
            Sparkline.prototype.redraw = function () {
                this.emptyContainer();
                this.renderSparkline();
            };
            Sparkline.prototype.touchCheck = function (event) {
                this.touchEnd = true;
                if (this.model.type.toString().toLocaleLowerCase() != "pie") {
                    this.sparkMouseLeave(event);
                }
                else
                    this.pieTooltipHide(event);
            };
            Sparkline.prototype.emptyContainer = function () {
                var model = this.model;
                if (model.enableCanvasRendering) {
                    this.ctx.clearRect(0, 0, this.height, this.width);
                }
                else {
                    var container = this.container;
                    while (container.firstChild) {
                        container.removeChild(container.firstChild);
                    }
                }
            };
            Sparkline.prototype._destroy = function () {
                var container = document.getElementById(this.container.id);
                if (container != null) {
                    this.unBindEvents();
                    this.unbindPieEvents();
                    window.removeEventListener("resize", this.resize);
                    container.parentNode.removeChild(container);
                }
                else {
                    window.removeEventListener("resize", this.resize);
                }
            };
            Sparkline.prototype.renderSparkline = function () {
                this.setStyles({ 'background': this.model.background }, this.container);
                this.calculatePoints();
                this.seriesRender();
                this.resize = this.resize.bind(this);
                if (this.model.isResponsive) {
                    window.addEventListener("resize", this.resize);
                }
                else {
                    window.removeEventListener("resize", this.resize);
                }
                if ((this.model.type != Type.WinLoss && this.model.type != Type.Pie) && this.model.tooltip.visible)
                    this.bindEvents(this.parentElement);
                else
                    this.unBindEvents();
                if (this.model.type == Type.Pie && this.model.tooltip.visible)
                    this.bindPieEvents(this.parentElement);
                else
                    this.unbindPieEvents();
                this.bindRegionEvents(this.parentElement);
                this.unBindClickEvents(this.parentElement);
                this.bindClickEvents(this.parentElement);
            };
            Sparkline.prototype.animateSparkline = function () {
                var model = this.model, sparkObj = this, stype = model.type, padding = model.padding, axisHeight = this.axisHeight, width = parseInt(model.size.width), height = parseInt(model.size.height), i, temp, timer, def = document.createElementNS(this.svgLink, "defs"), clipRect = document.createElementNS(this.svgLink, "clipPath"), animOption, clipOption, rect;
                if (stype == Type.Pie)
                    rect = document.createElementNS(this.svgLink, "path");
                else
                    rect = document.createElementNS(this.svgLink, "rect");
                if (stype == Type.Line || stype == Type.Area) {
                    animOption = {
                        "id": "clipRectSparkline",
                        "x": 0,
                        "y": 0,
                        "width": 0,
                        "height": height
                    };
                    timer = width / 10;
                    var animater = setInterval(animate, 120);
                    i = timer;
                }
                else if (stype == Type.Column || stype == Type.WinLoss) {
                    if (axisHeight == padding) {
                        animOption = {
                            "id": "clipRectSparkline",
                            "x": 0,
                            "y": 0,
                            "width": width,
                            "height": 0
                        };
                        timer = height / 10;
                        i = timer;
                        var ngtiveRectAnimater = setInterval(animateNegtiveRect, 120);
                    }
                    else if (axisHeight == (height - padding)) {
                        animOption = {
                            "id": "clipRectSparkline",
                            "x": 0,
                            "y": height,
                            "width": width,
                            "height": 0
                        };
                        timer = height / 10;
                        i = height;
                        var rectAnimater = setInterval(animateRect, 120);
                    }
                    else {
                        animOption = {
                            "id": "clipRectSparkline",
                            "x": 0,
                            "y": axisHeight,
                            "width": width,
                            "height": 0
                        };
                        timer = height / 10;
                        i = axisHeight;
                        var upperAnimater = setInterval(animateUpper, 120);
                    }
                }
                else {
                    var values = this.visiblePoints, centerPos = values['centerPos'], area = values['radius'], deg, stRad, edRad, pathArc = "", stDeg = 90, edDeg = 0, flag;
                    i = 0;
                    animOption = {
                        "id": "clipRectSparkline",
                        "d": pathArc,
                    };
                    var pieAnimater = setInterval(pieAnimate, 120);
                }
                clipOption = {
                    "id": this.container.id + "_sparklineRect",
                };
                this.setAttributes(animOption, rect);
                this.setAttributes(clipOption, clipRect);
                clipRect.appendChild(rect);
                def.appendChild(clipRect);
                this.container.appendChild(def);
                function animate() {
                    if (i <= width) {
                        rect.setAttribute("width", i.toString());
                    }
                    else {
                        clearInterval(animater);
                        sparkObj._trigger("animationComplete");
                    }
                    i = i + timer;
                }
                function animateRect() {
                    temp = height - i;
                    if (i >= 0) {
                        rect.setAttribute("y", i.toString());
                        rect.setAttribute("height", temp);
                    }
                    else {
                        clearInterval(rectAnimater);
                        sparkObj._trigger("animationComplete");
                    }
                    i = i - timer;
                }
                ;
                function animateNegtiveRect() {
                    if (i <= height) {
                        rect.setAttribute("height", i.toString());
                    }
                    else {
                        clearInterval(ngtiveRectAnimater);
                        sparkObj._trigger("animationComplete");
                    }
                    i = i + timer;
                }
                ;
                function animateUpper() {
                    temp = (axisHeight - i) * 2;
                    if (i >= -timer) {
                        rect.setAttribute("y", i < 0 ? 0 : i.toString());
                        rect.setAttribute("height", temp);
                    }
                    else {
                        clearInterval(upperAnimater);
                        sparkObj._trigger("animationComplete");
                    }
                    i = i - timer;
                }
                ;
                function pieAnimate() {
                    if (i <= (values.length - 1)) {
                        stDeg = 90;
                        deg = values[i]['location']['Degree'];
                        edDeg += deg + (i == 0 ? stDeg : 0);
                        stRad = (stDeg - 90) * Math.PI / 180.0;
                        edRad = (edDeg - 90) * Math.PI / 180.0;
                        if (i == values.length - 1)
                            edRad -= 0.0001;
                        temp = { sX: centerPos.X + (area * Math.cos(stRad)), sY: centerPos.Y + (area * Math.sin(stRad)), eX: centerPos.X + (area * Math.cos(edRad)), eY: centerPos.Y + (area * Math.sin(edRad)) };
                        pathArc = "M " + centerPos.X + " " + centerPos.Y + " L " + temp.eX + " " + temp.eY + " A " + area + " " + area + " 0 " + 1 + ",0 " + temp.sX + " " + temp.sY + " Z";
                        rect.setAttribute("d", pathArc);
                    }
                    else {
                        clearInterval(pieAnimater);
                        sparkObj._trigger("animationComplete");
                    }
                    i += 1;
                }
            };
            Sparkline.prototype.setTheme = function (model) {
                var theme = model.theme, defaults = this.defaults;
                if (theme == Themes.flatdark) {
                    model.background = (model.background == defaults.background) ? "#111111" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#B5B5B5" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#F6D321" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#AAAAAA" : model.axisLineSettings.color;
                }
                else if (theme == Themes.gradientlight) {
                    model.background = (model.background == defaults.background) ? "transparent" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#F34649" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#597B15" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#8E8E8E" : model.axisLineSettings.color;
                }
                else if (theme == Themes.gradientdark) {
                    model.background = (model.background == defaults.background) ? "#111111" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#005378" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#6A9319" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#AAAAAA" : model.axisLineSettings.color;
                }
                else if (theme == Themes.azuredark) {
                    model.background = (model.background == defaults.background) ? "#111111" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#007fff" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#f0ffff" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#336699" : model.axisLineSettings.color;
                }
                else if (theme == Themes.azurelight) {
                    model.background = (model.background == defaults.background) ? "transparent" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#336699" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#007fff" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#336699" : model.axisLineSettings.color;
                }
                else if (theme == Themes.limedark) {
                    model.background = (model.background == defaults.background) ? "#111111" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#238f23" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#32CD32" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#43da21" : model.axisLineSettings.color;
                }
                else if (theme == Themes.limelight) {
                    model.background = (model.background == defaults.background) ? "transparent" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#238f23" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#32CD32" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#43da21" : model.axisLineSettings.color;
                }
                else if (theme == Themes.saffrondark) {
                    model.background = (model.background == defaults.background) ? "#111111" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#ffaa33" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#ffdba9" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#ffc26e" : model.axisLineSettings.color;
                }
                else if (theme == Themes.saffronlight) {
                    model.background = (model.background == defaults.background) ? "transparent" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#ffaa33" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#ffdba9" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#ffc26e" : model.axisLineSettings.color;
                }
                else if (theme == null || theme == Themes.flatlight) {
                    model.background = (model.background == defaults.background) ? "transparent" : model.background;
                    model.fill = (model.fill == defaults.fill) ? "#33ccff" : model.fill;
                    model.stroke = (model.stroke == defaults.stroke) ? "#33ccff" : model.stroke;
                    model.axisLineSettings.color = (model.axisLineSettings.color) == defaults.axisLineSettings.color ? "#FF0000" : model.axisLineSettings.color;
                }
            };
            Sparkline.prototype.createSvg = function () {
                var model = this.model, parentElement = this.parentElement.clientWidth > 0 ? this.parentElement : this.parentElement.parentElement, options, parentHeight = (parseInt(parentElement.style.height) > parentElement.clientHeight) ? parseInt(parentElement.style.height) : parentElement.clientHeight, parentWidth = (parseInt(parentElement.style.width) > parentElement.clientWidth) ? parseInt(parentElement.style.width) : parentElement.clientWidth, width = model.size.width == "" ? parentWidth : parseInt(model.size.width), height = model.size.height == "" ? parentHeight : parseInt(model.size.height);
                height = (height > 0) ? height : (parentHeight > 0) ? parentHeight : 30;
                width = this.model.isResponsive && this.isResized ? (parentWidth > 0) ? parentWidth : width : width;
                width = width <= 0 ? 50 : width;
                model.size.height = height.toString();
                model.size.width = width.toString();
                this.height = height;
                this.width = width;
                options = {
                    "id": this.rootId + "_sparkline_svg",
                    "width": width,
                    "height": height,
                };
                if (!model.enableCanvasRendering) {
                    this.container = document.createElementNS(this.svgLink, "svg");
                }
                else {
                    this.container = document.createElement("canvas");
                    this.ctx = this.container.getContext('2d');
                }
                this.setAttributes(options, this.container);
                this.parentElement.appendChild(this.container);
            };
            Sparkline.prototype.setStyles = function (Options, element) {
                var properties = Object.keys(Options), temp;
                var values = properties.map(function (property) { return Options[property]; });
                for (var i = 0, len = properties.length; i < len; i++) {
                    temp = properties[i];
                    element.style[temp] = values[i];
                }
            };
            Sparkline.prototype.setAttributes = function (Options, element) {
                var properties = Object.keys(Options);
                var values = properties.map(function (property) { return Options[property]; });
                for (var i = 0, len = properties.length; i < len; i++) {
                    element.setAttribute(properties[i], values[i]);
                }
            };
            Sparkline.prototype.getDefaultPoints = function (count) {
                var data = [], i = 1;
                for (; i <= count; i++) {
                    if ((Math.random() * 10) > 5)
                        data.push(-Math.round(Math.random() * 100));
                    data.push(Math.round(Math.random() * 100));
                }
                return data;
            };
            Sparkline.prototype.calculatePoints = function () {
                var model = this.model, stype = model.type, data = (model.dataSource != null) ? model.dataSource : this.getDefaultPoints(12), x, y, max, min, minX, maxX, visiblePoints = [], maxPointsLength = data.length, temp, sumofValues = 0;
                if (Array.isArray(data) && typeof data[0] != 'object') {
                    if (model.type == Type.Pie) {
                        for (var i = 0; i < maxPointsLength; i++) {
                            sumofValues += Math.abs(data[i]);
                        }
                    }
                    else {
                        max = Math.max.apply(null, data);
                        min = Math.min.apply(null, data);
                        minX = 0;
                        maxX = maxPointsLength - 1;
                    }
                }
                else {
                    if (model.type == Type.Pie) {
                        for (var i = 0; i < maxPointsLength; i++) {
                            sumofValues += Math.abs(data[i][model.yName]);
                        }
                    }
                    else {
                        if (!data[0][model.xName]) {
                            var x = data.map(function (z) { return z[model.yName]; });
                            max = Math.max.apply(null, x);
                            min = Math.min.apply(null, x);
                        }
                        else {
                            temp = data;
                            temp = temp.sort(function (a, b) { return a[model.yName] - b[model.yName]; });
                            max = temp[temp.length - 1][model.yName];
                            min = temp[0][model.yName];
                        }
                        if (data[0][model.xName]) {
                            temp = temp.sort(function (a, b) { return a[model.xName] - b[model.xName]; });
                            maxX = temp[temp.length - 1][model.xName];
                            minX = temp[0][model.xName];
                        }
                        else {
                            minX = 0;
                            maxX = maxPointsLength - 1;
                        }
                    }
                }
                if (model.type != Type.Pie) {
                    this.maxLength = maxPointsLength;
                    var location, padding = Number(model.padding), height = parseInt(model.size.height) - (padding * 2), width = parseInt(model.size.width) - (padding * 2), unitX = maxX - minX, unitY = max - min, unitX = unitX == 0 ? 1 : unitX;
                    unitY = unitY == 0 ? 1 : unitY;
                    this.min = min;
                    this.unitX = unitX;
                    this.minX = minX;
                    this.unitY = unitY;
                    this.max = max;
                    this.maxX = maxX;
                    var X1 = 0, Y1 = height - ((height / unitY) * (-min)), Y2, Y1 = (min < 0 && max <= 0) ? 0 : (min < 0 && max > 0) ? Y1 : height;
                    this.axisHeight = Y1 + padding;
                    if (stype != Type.WinLoss && model.axisLineSettings.visible)
                        this.drawAxis();
                }
                else
                    var percent, location;
                for (var i = 0; i < maxPointsLength; i++) {
                    if (!(data[i][model.xName]) && !(data[i][model.yName]) && (data[i][model.yName]) != 0) {
                        x = i;
                        y = data[i];
                    }
                    else if (!(data[i][model.xName])) {
                        x = i;
                        y = data[i][model.yName];
                    }
                    else {
                        x = data[i][model.xName];
                        y = data[i][model.yName];
                    }
                    if (stype == Type.Line || stype == Type.Area) {
                        Y2 = (maxPointsLength != 1) ? height - Math.round(height * ((y - min) / unitY)) : 0;
                        location = { X: (maxPointsLength != 1) ? Math.round(width * ((x - minX) / unitX)) : width / 2, Y: Y2, markerPos: Y2 };
                    }
                    else if (stype == Type.Column || stype == Type.WinLoss) {
                        var colWidth = width / maxPointsLength, calSpace = 0.5, space = (calSpace * 2);
                        colWidth -= (space);
                        X1 = (i * (colWidth + space)) + (space / 2);
                        if (stype == Type.WinLoss) {
                            var winLossFactor = 0.5, drawHeightFactor = 40;
                            Y2 = (y > 0) ? height / 4 : (y < 0) ? (height * winLossFactor) : (height * winLossFactor) - (height / drawHeightFactor);
                            location = { X: X1, Y: Y2, height: (y != 0) ? (height / 4) : height / 20, width: colWidth };
                        }
                        else {
                            var z = ((height / unitY) * (y - min));
                            var z1 = (y == min && y > 0) ? (maxPointsLength != 1 && unitY != 1) ? (height / unitY) * (min / 2) : (height / unitY) :
                                (y == max && y < 0 && maxPointsLength != 1 && unitY != 1) ? (height / unitY) * (-max / 2) : z;
                            Y2 = Math.abs(height - z1);
                            location = { X: X1, Y: (Y2 > Y1) ? Y1 : Y2, height: Math.abs(Y2 - Y1), width: colWidth, markerPos: (Y2 > Y1) ? (Y1 + Math.abs(Y2 - Y1)) : Y2 };
                        }
                    }
                    else if (stype == Type.Pie) {
                        percent = (Math.abs(y) / sumofValues) * 100;
                        location = {
                            Percent: percent, Degree: ((Math.abs(y) / sumofValues) * 360)
                        };
                    }
                    if (stype != Type.Pie) {
                        location.X += padding;
                        location.Y += padding;
                    }
                    if (stype != Type.WinLoss)
                        location.markerPos += padding;
                    location['Xval'] = x;
                    location['Yval'] = y;
                    visiblePoints.push({ location: location });
                }
                this.visiblePoints = visiblePoints;
            };
            Sparkline.prototype.seriesRender = function () {
                var model = this.model, visiblePoints = this.visiblePoints, points_length = visiblePoints.length, eventArgs, seriesType = model.type;
                eventArgs = {
                    data: {
                        "minX": this.minX,
                        "minY": this.min,
                        "maxX": this.maxX,
                        "maxY": this.max,
                        "xName": model.xName,
                        "yName": model.yName,
                        "pointsCount": points_length,
                        "seriesType": seriesType,
                        "visiblePoints": this.visiblePoints
                    }
                };
                if (this.model.seriesRendering != null)
                    this._trigger("seriesRendering", eventArgs);
                if (seriesType == Type.Line) {
                    this.drawLineSeries(visiblePoints);
                }
                else if (seriesType == Type.Area) {
                    this.drawAreaSeries(visiblePoints);
                }
                else if (seriesType == Type.Column) {
                    this.drawColumnSeries(visiblePoints);
                }
                else if (seriesType == Type.WinLoss) {
                    this.drawWinlossSeries(visiblePoints);
                }
                else if (seriesType == Type.Pie) {
                    this.drawPieSeries();
                }
                if (model.markerSettings.visible && (seriesType != Type.WinLoss) && (seriesType != Type.Pie))
                    this.drawMarker(visiblePoints);
                if ((model.rangeBandSettings.startRange != null) && (model.rangeBandSettings.endRange != null) && (seriesType != Type.WinLoss) && (seriesType != Type.Pie))
                    this.drawRangeBand();
            };
            Sparkline.prototype.drawPieSeries = function () {
                var model = this.model, values = this.visiblePoints;
                model.padding = (model.padding == this.defaults.padding) ? 2 : model.padding;
                var len = values.length, height = parseInt(model.size.height) - (model.padding * 2), width = parseInt(model.size.width) - (model.padding * 2), area = (height <= width) ? height / 2 : width / 2, stRad, edRad, centerPos = { X: width / 2, Y: height / 2 }, temp, pathArc, pathOptions, colors = model.palette, deg = 0, stroke = model.border.color, opacity = model.opacity, strokeWidth = model.border.width, gEle;
                values['centerPos'] = centerPos;
                values['radius'] = area;
                for (var i = 0, stDeg = 90, edDeg, flag; i < values.length; i++) {
                    stDeg += deg;
                    deg = values[i]['location']['Degree'];
                    edDeg = stDeg + deg;
                    stRad = (stDeg - 90) * Math.PI / 180.0;
                    edRad = (edDeg - 90) * Math.PI / 180.0;
                    values[i]['stAng'] = stRad;
                    values[i]['endAng'] = edRad;
                    flag = (deg < 180) ? "0" : "1";
                    temp = values[i]['coordinates'] = { sX: centerPos.X + (area * Math.cos(stRad)), sY: centerPos.Y + (area * Math.sin(stRad)), eX: centerPos.X + (area * Math.cos(edRad)), eY: centerPos.Y + (area * Math.sin(edRad)) };
                    pathArc = "M " + centerPos.X + " " + centerPos.Y + " L " + temp.eX + " " + temp.eY + " A " + area + " " + area + " 0 " + flag + ",0 " + temp.sX + " " + temp.sY + " Z";
                    pathOptions = {
                        'id': this.container.id + "_pieBase" + i,
                        'fill': colors[i % colors.length],
                        'stroke': stroke,
                        'opacity': opacity,
                        'stroke-width': strokeWidth,
                        'd': pathArc,
                        'start': edRad,
                        'end': stRad,
                        'x': centerPos.X,
                        'y': centerPos.Y,
                        'counterClockWise': flag,
                        'radius': area
                    };
                    if (model.enableCanvasRendering)
                        this.canvasDrawPath(pathOptions);
                    else {
                        gEle = this.createGroup({ "id": "sparkpieSeries" });
                        this.setStyles({ "clip-path": "url(#" + this.container.id + "_sparklineRect)" }, gEle);
                        this.container.appendChild(gEle);
                        this.drawPath(pathOptions, gEle);
                    }
                }
            };
            Sparkline.prototype.drawRangeBand = function () {
                var model = this.model, height = (parseInt(model.size.height) - model.padding * 2), width = (parseInt(model.size.width) - model.padding * 2), stValue = model.rangeBandSettings.startRange, edValue = model.rangeBandSettings.endRange, stHeight = Number(height - ((height / this.unitY) * (stValue - this.min))) + model.padding, edHeight = Number(height - ((height / this.unitY) * (edValue - this.min))) + model.padding, options;
                edHeight = edHeight > Number(height + model.padding) ? Number(height + model.padding) : edHeight < (0 + model.padding) ? (0 + model.padding) : edHeight;
                stHeight = stHeight > Number(height + model.padding) ? Number(height + model.padding) : stHeight < (0 + model.padding) ? (0 + model.padding) : stHeight;
                var path = 'M ' + model.padding + " " + stHeight + " L " + (width + Number(model.padding)) + " " + stHeight + " L " + (width + Number(model.padding)) + " " + edHeight + " L " + model.padding + " " + edHeight + " Z";
                options = {
                    'id': this.container.id + "_rangeBand",
                    'fill': model.rangeBandSettings.color,
                    'opacity': model.rangeBandSettings.opacity,
                    'stroke': "transparent",
                    'stroke-width': model.border.width,
                    'd': path,
                };
                if (model.enableCanvasRendering)
                    this.canvasDrawPath(options);
                else
                    this.drawPath(options);
            };
            Sparkline.prototype.drawAxis = function () {
                var model = this.model, height = this.axisHeight, strclr = model.axisLineSettings.color, seriesType = model.type;
                if ((seriesType != Type.WinLoss) && (seriesType != Type.Pie)) {
                    if (!model.axisLineSettings.visible)
                        strclr = 'transparent';
                    var xAxis = {
                        'id': this.container.id + "_Sparkline_XAxis",
                        'x1': 0 + model.padding,
                        'y1': height,
                        'x2': parseInt(model.size.width) - model.padding,
                        'y2': height,
                        'stroke': strclr,
                        'stroke-dasharray': model.axisLineSettings.dashArray,
                        'stroke-width': model.axisLineSettings.width,
                    };
                    if (model.enableCanvasRendering)
                        this.canvasDrawLine(xAxis);
                    else
                        this.drawLine(xAxis);
                }
            };
            Sparkline.prototype.drawColumnSeries = function (points) {
                var rectOptions, temp, model = this.model, mod = [], len = points.length, locations = ejSparkline.compareExtend({}, mod, points), strwd = model.border.width, lowPos, opacity = model.opacity, highPos, fill = model.fill, stroke = model.border.color, highPointColor = model.highPointColor, lowPointColor = model.lowPointColor, startPointColor = model.startPointColor, endPointColor = model.endPointColor, negativePointColor = model.negativePointColor, gEle;
                if (highPointColor || lowPointColor) {
                    var pointsYPos = locations.map(function (a) { return a['location']['markerPos']; });
                    highPos = Math.min.apply(null, pointsYPos);
                    lowPos = Math.max.apply(null, pointsYPos);
                }
                if (model.enableCanvasRendering == false) {
                    gEle = this.createGroup({ "id": this.container.id + "sparkcolumnSeries" });
                    this.setStyles({ "clip-path": "url(#" + this.container.id + "_sparklineRect)" }, gEle);
                    this.container.appendChild(gEle);
                }
                for (var i = 0; i < len; i++) {
                    temp = points[i].location;
                    rectOptions = {
                        'id': this.container.id + "_column_series_" + i,
                        'x': temp.X,
                        'y': temp.Y,
                        'height': temp.height,
                        'width': temp.width,
                        'fill': fill,
                        'stroke': stroke,
                        'opacity': opacity,
                        "stroke-width": strwd,
                    };
                    if (temp.markerPos == highPos && highPointColor) {
                        rectOptions.fill = highPointColor;
                        this.highPointIndex = i;
                    }
                    else if (temp.markerPos == lowPos && lowPointColor) {
                        rectOptions.fill = lowPointColor;
                        this.lowPointIndex = i;
                    }
                    else if (i == 0 && startPointColor) {
                        rectOptions.fill = startPointColor;
                        this.startPointIndex = i;
                    }
                    else if ((i == (len - 1)) && endPointColor) {
                        rectOptions.fill = endPointColor;
                        this.endPointIndex = i;
                    }
                    else if (temp.markerPos >= this.axisHeight && negativePointColor) {
                        rectOptions.fill = negativePointColor;
                        this.negativePointIndexes.push(i);
                    }
                    if (model.enableCanvasRendering)
                        this.canvasDrawRectangle(rectOptions);
                    else {
                        this.drawRect(rectOptions, gEle);
                    }
                    temp.X += temp.width / 2;
                }
            };
            Sparkline.prototype.drawWinlossSeries = function (points) {
                var rectOptions, temp, model = this.model, strwd = model.border.width, padding = model.padding, stroke = model.border.color, opacity = model.opacity, tieColor = "#EE82EE", len = points.length, height = parseInt(model.size.height) - (padding * 2), gEle;
                if (model.enableCanvasRendering == false) {
                    gEle = this.createGroup({ "id": this.container.id + "sparkwinlossSeries" });
                    this.setStyles({ "clip-path": "url(#" + this.container.id + "_sparklineRect)" }, gEle);
                    this.container.appendChild(gEle);
                }
                for (var i = 0; i < len; i++) {
                    temp = points[i].location;
                    rectOptions = {
                        'id': this.container.id + "_winloss_series_" + i,
                        'x': temp.X,
                        'y': temp.Y,
                        'height': temp.height,
                        'width': temp.width,
                        'fill': (temp.Y < (height / 2 + padding)) ? (temp.Y > (height / 4 + padding)) ? tieColor : model.fill : model.negativePointColor ? model.negativePointColor : "#FF0000",
                        'stroke': stroke,
                        'opacity': opacity,
                        "stroke-width": strwd
                    };
                    if (model.enableCanvasRendering)
                        this.canvasDrawRectangle(rectOptions);
                    else {
                        this.drawRect(rectOptions, gEle);
                    }
                }
            };
            Sparkline.prototype.drawAreaSeries = function (points) {
                var linepath = "", totHeight = this.axisHeight, model = this.model, options, gEle;
                for (var i = 0, len = points.length; i < len; i++) {
                    if (i == 0) {
                        linepath = "M " + points[0].location.X + " " + totHeight + " ";
                    }
                    linepath += "L " + points[i].location.X + " " + points[i].location.Y + " ";
                    if (i == len - 1) {
                        linepath += "L " + points[i].location.X + " " + totHeight + " Z";
                    }
                }
                options = {
                    "id": this.container.id + "_area_series_fill",
                    "fill": model.fill,
                    "stroke": model.stroke ? model.stroke : model.fill,
                    'fill-opacity': model.opacity,
                    "stroke-width": model.width,
                    "d": linepath
                };
                if (model.enableCanvasRendering)
                    this.canvasDrawPath(options);
                else {
                    gEle = this.createGroup({ "id": "sparkAreaSeries" });
                    this.container.appendChild(gEle);
                    this.drawPath(options, gEle);
                    this.setStyles({ "clip-path": "url(#" + this.container.id + "_sparklineRect)" }, gEle);
                }
            };
            Sparkline.prototype.drawLineSeries = function (points) {
                var linepath = '', model = this.model, gEle;
                for (var i = 0, len = points.length; i < len; i++) {
                    if (i == 0)
                        linepath = "M " + points[0].location.X + " " + points[i].location.Y + " ";
                    linepath += "L " + points[i].location.X + " " + points[i].location.Y + " ";
                }
                var line_options = {
                    'id': this.container.id + "_Line_series",
                    'fill': 'transparent',
                    'stroke': model.stroke ? model.stroke : model.fill,
                    'opacity': model.opacity,
                    'stroke-width': model.width,
                    'd': linepath
                };
                if (model.enableCanvasRendering)
                    this.canvasDrawPath(line_options);
                else {
                    gEle = this.createGroup({ "id": "sparklineSeries" });
                    this.container.appendChild(gEle);
                    this.drawPath(line_options, gEle);
                    this.setStyles({ "clip-path": "url(#" + this.container.id + "_sparklineRect)" }, gEle);
                }
            };
            Sparkline.prototype.drawMarker = function (points) {
                var length = points.length, marker_options, marker = this.model.markerSettings, mod = [], model = this.model, locations = ejSparkline.compareExtend({}, mod, points), fill = marker.fill ? marker.fill : model.fill, stroke = marker.border.color, strwid = marker.width, opacity = marker.opacity, brdwid = marker.border.width, temp, lowPos, highPos, highPointColor = model.highPointColor, lowPointColor = model.lowPointColor, startPointColor = model.startPointColor, endPointColor = model.endPointColor, negativePointColor = model.negativePointColor, gEle;
                if (model.enableCanvasRendering == false) {
                    gEle = this.createGroup({ "id": this.container.id + "sparkmarkers" });
                    this.setStyles({ "clip-path": "url(#" + this.container.id + "_sparklineRect)" }, gEle);
                    this.container.appendChild(gEle);
                }
                if (marker.visible == false || (model.type == Type.Pie || model.type == Type.WinLoss)) {
                    strwid = 0;
                    brdwid = 0;
                }
                if (highPointColor || lowPointColor) {
                    var pointsYPos = locations.map(function (a) { return a['location']['markerPos']; });
                    highPos = Math.min.apply(null, pointsYPos);
                    lowPos = Math.max.apply(null, pointsYPos);
                }
                for (var i = 0, wid; i < length; i++) {
                    temp = points[i].location;
                    wid = (temp.width != undefined) ? (temp.width / 2) : 0;
                    marker_options = {
                        'id': this.container.id + "_marker_" + i,
                        'cx': temp.X,
                        'cy': temp.markerPos,
                        'r': strwid,
                        'fill': fill,
                        'stroke': stroke,
                        'opacity': opacity,
                        'stroke-width': brdwid
                    };
                    if (temp.markerPos == highPos && highPointColor) {
                        marker_options.fill = highPointColor;
                        this.highPointIndex = i;
                    }
                    else if (temp.markerPos == lowPos && lowPointColor) {
                        marker_options.fill = lowPointColor;
                        this.lowPointIndex = i;
                    }
                    else if (i == 0 && startPointColor) {
                        marker_options.fill = startPointColor;
                        this.startPointIndex = i;
                    }
                    else if ((i == (length - 1)) && endPointColor) {
                        marker_options.fill = endPointColor;
                        this.endPointIndex = i;
                    }
                    else if (temp.markerPos > this.axisHeight && negativePointColor) {
                        marker_options.fill = negativePointColor;
                        this.negativePointIndexes.push(i);
                    }
                    if (this.model.enableCanvasRendering)
                        this.canvasDrawCircle(marker_options);
                    else
                        this.drawCircle(marker_options, gEle);
                }
            };
            Sparkline.prototype.drawLine = function (Options) {
                var svgshape = document.getElementById(Options['id']);
                if (!svgshape)
                    svgshape = document.createElementNS(this.svgLink, "line");
                this.setAttributes(Options, svgshape);
                this.container.appendChild(svgshape);
            };
            Sparkline.prototype.drawCircle = function (Options, element) {
                element = (!!element) ? element : this.container;
                var svgshape = document.getElementById(Options['id']);
                if (!svgshape)
                    svgshape = document.createElementNS(this.svgLink, "circle");
                this.setAttributes(Options, svgshape);
                element.appendChild(svgshape);
            };
            Sparkline.prototype.drawPolyLine = function (Options) {
                var svgshape = document.getElementById(Options['id']);
                if (!svgshape)
                    svgshape = document.createElementNS(this.svgLink, "polyline");
                this.setAttributes(Options, svgshape);
                this.container.appendChild(svgshape);
            };
            Sparkline.prototype.drawPath = function (Options, element) {
                element = (!!element) ? element : this.container;
                var svgshape = document.getElementById(Options['id']);
                if (!svgshape)
                    svgshape = document.createElementNS(this.svgLink, "path");
                this.setAttributes(Options, svgshape);
                element.appendChild(svgshape);
            };
            Sparkline.prototype.drawRect = function (Options, element) {
                element = (!!element) ? element : this.container;
                var svgshape = document.getElementById(Options['id']);
                if (!svgshape)
                    svgshape = document.createElementNS(this.svgLink, "rect");
                this.setAttributes(Options, svgshape);
                element.appendChild(svgshape);
            };
            Sparkline.prototype.createGroup = function (options) {
                var group = document.createElementNS(this.svgLink, "g");
                this.setAttributes(options, group);
                return group;
            };
            Sparkline.prototype.createText = function (options, label) {
                var text = document.createElementNS(this.svgLink, "text");
                this.setAttributes(options, text);
                if (label)
                    text.textContent = label;
                return text;
            };
            Sparkline.prototype.canvasDrawLine = function (options, canvasContext) {
                var context2d = canvasContext ? canvasContext : this.ctx;
                context2d.save();
                context2d.beginPath();
                context2d.lineWidth = options["stroke-width"];
                context2d.strokeStyle = options["stroke"];
                context2d.moveTo(options["x1"], options["y1"]);
                context2d.lineTo(options["x2"], options["y2"]);
                context2d.stroke();
                context2d.restore();
                this.dataURL = this.container.toDataURL();
            };
            Sparkline.prototype.canvasDrawRectangle = function (options, canvasContext) {
                var context2d = canvasContext ? canvasContext : this.ctx, canvasCtx = canvasContext ? canvasContext : this.ctx;
                context2d.save();
                context2d.beginPath();
                context2d.globalAlpha = options["opacity"];
                context2d.lineWidth = options["stroke-width"];
                var dashArray = options["stroke-dasharray"] ? options["stroke-dasharray"].split(",") : false;
                if (dashArray)
                    this.ctx.setLineDash(dashArray);
                context2d.strokeStyle = options["stroke"];
                context2d.rect(options["x"], options["y"], options["width"], options["height"]);
                if (options["fill"] == "none")
                    options["fill"] = "transparent";
                context2d.fillStyle = options["fill"];
                context2d.fillRect(options["x"], options["y"], options["width"], options["height"]);
                context2d.stroke();
                context2d.restore();
                context2d = canvasCtx;
                this.dataURL = this.container.toDataURL();
            };
            Sparkline.prototype.canvasDrawPath = function (options, canvasContext) {
                var path = options["d"];
                var dataSplit = path.split(" ");
                var borderWidth = options["stroke-width"];
                var context2d = canvasContext ? canvasContext : this.ctx, canvasCtx = canvasContext ? canvasContext : this.ctx;
                context2d.save();
                context2d.beginPath();
                context2d.globalAlpha = options["opacity"] ? options["opacity"] : options["fill-opacity"];
                var flag = true;
                context2d.lineWidth = borderWidth;
                var dashArray = options["stroke-dasharray"] ? options["stroke-dasharray"].split(",") : false;
                if (dashArray)
                    context2d.setLineDash(dashArray);
                context2d.strokeStyle = options["stroke"];
                for (var i = 0; i < dataSplit.length; i = i + 3) {
                    var x1 = parseFloat(dataSplit[i + 1]);
                    var y1 = parseFloat(dataSplit[i + 2]);
                    switch (dataSplit[i]) {
                        case "M":
                            if (!options["innerR"] && !options["cx"])
                                context2d.moveTo(x1, y1);
                            break;
                        case "L":
                            if (!options["innerR"])
                                context2d.lineTo(x1, y1);
                            break;
                        case "C":
                            context2d.bezierCurveTo(x1, y1, parseFloat(dataSplit[i + 3]), parseFloat(dataSplit[i + 4]), parseFloat(dataSplit[i + 5]), parseFloat(dataSplit[i + 6]));
                            i = i + 4;
                            break;
                        case "A":
                            if (!options["innerR"]) {
                                if (options["cx"]) {
                                    context2d.arc(options["cx"], options["cy"], options["radius"], 0, 2 * Math.PI, options["counterClockWise"]);
                                }
                                else {
                                    context2d.moveTo(options["x"], options["y"]);
                                    context2d.arc(options["x"], options["y"], options["radius"], options["start"], options["end"], options["counterClockWise"]);
                                    context2d.lineTo(options["x"], options["y"]);
                                }
                            }
                            else if (flag) {
                                context2d.arc(options["x"], options["y"], options["radius"], options["start"], options["end"], options["counterClockWise"]);
                                context2d.arc(options["x"], options["y"], options["innerR"], options["end"], options["start"], !options["counterClockWise"]);
                                flag = false;
                            }
                            i = i + 5;
                            break;
                        case "Z":
                            context2d.closePath();
                            break;
                    }
                }
                if (options["fill"] != "none" && options["fill"] != undefined) {
                    context2d.fillStyle = options["fill"];
                    context2d.fill();
                }
                if (borderWidth > 0)
                    context2d.stroke();
                context2d.restore();
                context2d = canvasCtx;
                this.dataURL = this.container.toDataURL();
            };
            Sparkline.prototype.canvasDrawCircle = function (options, canvasContext) {
                var context2d = canvasContext ? canvasContext : this.ctx, canvasCtx = canvasContext ? canvasContext : this.ctx, dashArray;
                context2d.save();
                context2d.beginPath();
                context2d.arc(options["cx"], options["cy"], options["r"], 0, 2 * Math.PI);
                context2d.fillStyle = options["fill"];
                context2d.globalAlpha = options["opacity"];
                context2d.fill();
                context2d.lineWidth = options["stroke-width"];
                dashArray = options["stroke-dasharray"] ? options["stroke-dasharray"].split(",") : false;
                if (dashArray)
                    context2d.setLineDash(dashArray);
                context2d.strokeStyle = options["stroke"];
                context2d.stroke();
                context2d.restore();
                context2d = canvasCtx;
                this.dataURL = this.container.toDataURL();
            };
            Sparkline.prototype.canvasDrawPolyline = function (options, canvasContext) {
                var context2d = canvasContext ? canvasContext : this.ctx;
                context2d.save();
                context2d.beginPath();
                var points = options["points"].split(" ");
                for (var i = 0; i < points.length - 1; i++) {
                    var point = points[i].split(",");
                    var x = point[0];
                    var y = point[1];
                    if (i == 0)
                        context2d.moveTo(x, y);
                    else
                        context2d.lineTo(x, y);
                }
                context2d.lineWidth = options["stroke-width"];
                context2d.strokeStyle = options["stroke"];
                context2d.stroke();
                context2d.restore();
                this.dataURL = this.container.toDataURL();
            };
            Sparkline.prototype.canvasDrawText = function (options, label, canvasContext) {
                var font = options['font'];
                var anchor = options["text-anchor"];
                var opacity = options["opacity"] !== undefined ? options["opacity"] : 1;
                if (anchor == "middle")
                    anchor = "center";
                var context2d = canvasContext ? canvasContext : this.ctx;
                context2d.save();
                context2d.fillStyle = options["fill"];
                context2d.font = font;
                context2d.textAlign = anchor;
                context2d.globalAlpha = opacity;
                if (options["baseline"])
                    context2d.textBaseline = options["baseline"];
                var txtlngth = 0;
                if (options["labelRotation"] == 90 && options["id"].indexOf("XLabel") != -1)
                    txtlngth = context2d.measureText(label).width;
                context2d.translate(options["x"] + (txtlngth / 2), options["y"]);
                context2d.rotate(options["labelRotation"] * Math.PI / 180);
                context2d.fillText(label, 0, 0);
                context2d.restore();
                this.dataURL = this.container.toDataURL();
            };
            Sparkline.prototype.parseTemplate = function (clonenode, point) {
                var str;
                str = clonenode.innerHTML;
                var properties = Object.values(point), tempValues, format;
                tempValues = properties[0];
                for (var _i = 0, _a = Object.entries(tempValues); _i < _a.length; _i++) {
                    var _b = _a[_i], key = _b[0], value = _b[1];
                    format = '#point.' + key + '#';
                    if (str.search(format) != -1) {
                        str = str.replace(format, value);
                    }
                }
                return str;
            };
            Sparkline.prototype.measureText = function (text, font) {
                var element = document.getElementById("measureTex"), textObj;
                if (!element || element.clientHeight == 0) {
                    textObj = document.createElement('text');
                    textObj.setAttribute('id', 'measureTex');
                    document.body.appendChild(textObj);
                }
                else {
                    textObj = element;
                }
                var style = null, size = null, family = null, weight = null;
                if (typeof (text) == "string" && (text.indexOf("<") > -1 || text.indexOf(">") > -1)) {
                    var textArray = text.split(" ");
                    for (var i = 0; i < textArray.length; i++) {
                        if (textArray[i].indexOf("<br/>") == -1)
                            textArray[i] = textArray[i].replace(/[<>]/g, '&');
                    }
                    text = textArray.join(' ');
                }
                textObj.innerHTML = text;
                if (font != undefined && font.size == undefined) {
                    var fontarray = font;
                    fontarray = fontarray.split(" ");
                    style = fontarray[0];
                    size = fontarray[1];
                    family = fontarray[2];
                    weight = fontarray[3];
                }
                if (font != null) {
                    textObj.style.fontSize = (font.size > 0) ? (font.size + "px") : font.size ? font.size : size;
                    if (textObj.style.fontStyle)
                        textObj.style.fontStyle = (font.fontStyle) ? font.fontStyle : style;
                    textObj.style.fontFamily = font.fontFamily ? font.fontFamily : family;
                    if (window.navigator.userAgent.indexOf('MSIE 8.0') == -1)
                        textObj.style.fontWeight = font.fontWeight ? font.fontWeight : weight;
                }
                textObj.style.backgroundColor = 'white';
                textObj.style.position = 'absolute';
                textObj.style.top = -100 + "px";
                textObj.style.left = 0 + 'px';
                textObj.style.visibility = 'hidden';
                textObj.style.whiteSpace = 'nowrap';
                var bounds = { width: textObj.offsetWidth, height: textObj.offsetHeight };
                return bounds;
            };
            return Sparkline;
        }(ej.WidgetBase));
        ejSparkline.Sparkline = Sparkline;
        ej.widget("ejSparkline", "ej.Sparkline", new Sparkline());
    })(jQuery);
    ejSparkline.deepExtend = function (out) {
        out = out || {};
        for (var i = 1; i < arguments.length; i++) {
            var obj = arguments[i];
            if (!obj)
                continue;
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    if (typeof obj[key] === 'object')
                        out[key] = ejSparkline.deepExtend(out[key], obj[key]);
                    else
                        out[key] = obj[key];
                }
            }
        }
        return out;
    };
    ejSparkline.compareExtend = function (temp, src, def) {
        if (typeof def === 'object' && def !== null) {
            var defProp = Object.keys(def), len = defProp.length, currPro;
            for (var i = 0; i < len; i++) {
                currPro = defProp[i];
                if (src.hasOwnProperty(currPro) && src[currPro] != null) {
                    if (Array.isArray(src[currPro]) || typeof src[currPro] === 'object' && src[currPro] !== null) {
                        ejSparkline.compareExtend({}, src[currPro], def[currPro]);
                    }
                }
                else {
                    src[currPro] = def[currPro];
                }
            }
        }
        return src;
    };
})(ejSparkline || (ejSparkline = {}));
;