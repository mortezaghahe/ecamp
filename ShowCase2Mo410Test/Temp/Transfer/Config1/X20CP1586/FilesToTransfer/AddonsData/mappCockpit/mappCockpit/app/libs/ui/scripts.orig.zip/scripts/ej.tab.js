﻿/*!
*  filename: ej.tab.js
*  version : 16.4.0.52
*  Copyright Syncfusion Inc. 2001 - 2019. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
*/


window.ej = window.Syncfusion = window.Syncfusion || {};


(function ($, ej, undefined) {
    'use strict';

    ej.version = "16.4.0.52";

    ej.consts = {
        NamespaceJoin: '-'
    };
    ej.TextAlign = {
        Center: 'center',
        Justify: 'justify',
        Left: 'left',
        Right: 'right'
    };
    ej.Orientation = { Horizontal: "horizontal", Vertical: "vertical" };

    ej.serverTimezoneOffset = 0;

    ej.parseDateInUTC = false;

    ej.persistStateVersion = null;

    ej.locales = ej.locales || [];

    if (!Object.prototype.hasOwnProperty) {
        Object.prototype.hasOwnProperty = function (obj, prop) {
            return obj[prop] !== undefined;
        };
    }

    //to support toISOString() in IE8
    if (!Date.prototype.toISOString) {
        (function () {
            function pad(number) {
                var r = String(number);
                if (r.length === 1) {
                    r = '0' + r;
                }
                return r;
            }
            Date.prototype.toISOString = function () {
                return this.getUTCFullYear()
                    + '-' + pad(this.getUTCMonth() + 1)
                    + '-' + pad(this.getUTCDate())
                    + 'T' + pad(this.getUTCHours())
                    + ':' + pad(this.getUTCMinutes())
                    + ':' + pad(this.getUTCSeconds())
                    + '.' + String((this.getUTCMilliseconds() / 1000).toFixed(3)).slice(2, 5)
                    + 'Z';
            };
        }());
    }

    String.format = function () {
        var source = arguments[0];
        for (var i = 0; i < arguments.length - 1; i++)
            source = source.replace(new RegExp("\\{" + i + "\\}", "gm"), arguments[i + 1]);

        source = source.replace(/\{[0-9]\}/g, "");
        return source;
    };

    jQuery.uaMatch = function (ua) {
        ua = ua.toLowerCase();

        var match = /(chrome)[ \/]([\w.]+)/.exec(ua) ||
            /(webkit)[ \/]([\w.]+)/.exec(ua) ||
            /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua) ||
            /(msie) ([\w.]+)/.exec(ua) ||
            ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua) ||
            [];

        return {
            browser: match[1] || "",
            version: match[2] || "0"
        };
    };
    // Function to create new class
    ej.defineClass = function (className, constructor, proto, replace) {
        /// <summary>Creates the javascript class with given namespace & class name & constructor etc</summary>
        /// <param name="className" type="String">class name prefixed with namespace</param>
        /// <param name="constructor" type="Function">constructor function</param>
        /// <param name="proto" type="Object">prototype for the class</param>
        /// <param name="replace" type="Boolean">[Optional]Replace existing class if exists</param>
        /// <returns type="Function">returns the class function</returns>
        if (!className || !proto) return undefined;

        var parts = className.split(".");

        // Object creation
        var obj = window, i = 0;
        for (; i < parts.length - 1; i++) {

            if (ej.isNullOrUndefined(obj[parts[i]]))
                obj[parts[i]] = {};

            obj = obj[parts[i]];
        }

        if (replace || ej.isNullOrUndefined(obj[parts[i]])) {

            //constructor
            constructor = typeof constructor === "function" ? constructor : function () {
            };

            obj[parts[i]] = constructor;

            // prototype
            obj[parts[i]].prototype = proto;
        }

        return obj[parts[i]];
    };

    ej.util = {
        getNameSpace: function (className) {
            /// <summary>Internal function, this will create namespace for plugins using class name</summary>
            /// <param name="className" type="String"></param>
            /// <returns type="String"></returns>
            var splits = className.toLowerCase().split(".");
            splits[0] === "ej" && (splits[0] = "e");

            return splits.join(ej.consts.NamespaceJoin);
        },

        getObject: function (nameSpace, from) {
            if (!from || !nameSpace) return undefined;
			(typeof(nameSpace) != "string") && (nameSpace = JSON.stringify(nameSpace));
            var value = from, splits = nameSpace.split('.');

            for (var i = 0; i < splits.length; i++) {

                if (ej.util.isNullOrUndefined(value)) break;

                value = value[splits[i]];
            }

            return value;
        },

        createObject: function (nameSpace, value, initIn) {
            var splits = nameSpace.split('.'), start = initIn || window, from = start, i, t, length = splits.length;

            for (i = 0; i < length; i++) {
                t = splits[i];
                if (i + 1 == length)
                    from[t] = value;
                else if (ej.isNullOrUndefined(from[t]))
                    from[t] = {};

                from = from[t];
            }

            return start;
        },

        isNullOrUndefined: function (value) {
            /// <summary>Util to check null or undefined</summary>
            /// <param name="value" type="Object"></param>
            /// <returns type="Boolean"></returns>
            return value === undefined || value === null;
        },
        exportAll: function (action, controlIds) {
            var inputAttr = [], widget, locale = [], index, controlEle, controlInstance, controlObject, modelClone;
            var attr = { action: action, method: 'post', "data-ajax": "false" };
            var form = ej.buildTag('form', "", null, attr);
            if (controlIds.length != 0) {
                for (var i = 0; i < controlIds.length; i++) {
                    index = i;
                    controlEle = $("#" + controlIds[i]);
                    controlInstance = $("#" + controlIds[i]).data();
                    widget = controlInstance["ejWidgets"];
                    controlObject = $(controlEle).data(widget[0]);
                    locale.push({ id: controlObject._id, locale: controlObject.model.locale });
                    if (!ej.isNullOrUndefined(controlObject)) {
                        modelClone = controlObject._getExportModel(controlObject.model);
                        inputAttr.push({ name: widget[0], type: 'hidden', value: controlObject.stringify(modelClone) });
                        var input = ej.buildTag('input', "", null, inputAttr[index]);
                        form.append(input);
                    }
                }
                $('body').append(form);
                form.submit();
                setTimeout(function () {
                    var ctrlInstance, ctrlObject;
                    if (locale.length) {
                        for (var j = 0; j < locale.length; j++) {
                            if (!ej.isNullOrUndefined(locale[j].locale)) {
                                ctrlInstance = $("#" + locale[j].id).data();
                                widget = ctrlInstance["ejWidgets"];
                                ctrlObject = $("#" + locale[j].id).data(widget[0]);
                                ctrlObject.model.locale = locale[j].locale;
                            }
                        }
                    }
                }, 0);
                form.remove();
            }
            return true;
        },
        print: function (element, printWin) {
            var $div = ej.buildTag('div')
            var elementClone = element.clone();
            $div.append(elementClone);
            if (!printWin)
                var printWin = window.open('', 'print', "height=452,width=1024,tabbar=no");
            printWin.document.write('<!DOCTYPE html>');
            var links = $('head').find('link').add("style");
            if (ej.browserInfo().name === "msie") {
                var a = ""
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.write('<html><head></head><body>' + a + $div[0].innerHTML + '</body></html>');
            }
            else {
                var a = ""
                printWin.document.write('<html><head>')
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.writeln(a + '</head><body>')
                printWin.document.writeln($div[0].innerHTML + '</body></html>')
            }
            printWin.document.close();
            printWin.focus();
            setTimeout(function () {
                if (!ej.isNullOrUndefined(printWin.window)) {
                    printWin.print();
                    setTimeout(function () { printWin.close() }, 1000);
                }
            }, 1000);
        },
        ieClearRemover: function (element) {
            var searchBoxHeight = $(element).height();
            element.style.paddingTop = parseFloat(searchBoxHeight / 2) + "px";
            element.style.paddingBottom = parseFloat(searchBoxHeight / 2) + "px";
            element.style.height = "1px";
            element.style.lineHeight = "1px";
        },
        //To send ajax request
        sendAjaxRequest: function (ajaxOptions) {
            $.ajax({
                type: ajaxOptions.type,
                cache: ajaxOptions.cache,
                url: ajaxOptions.url,
                dataType: ajaxOptions.dataType,
                data: ajaxOptions.data,
                contentType: ajaxOptions.contentType,
                async: ajaxOptions.async,
                success: ajaxOptions.successHandler,
                error: ajaxOptions.errorHandler,
                beforeSend: ajaxOptions.beforeSendHandler,
                complete: ajaxOptions.completeHandler
            });
        },

        buildTag: function (tag, innerHtml, styles, attrs) {
            /// <summary>Helper to build jQuery element</summary>
            /// <param name="tag" type="String">tagName#id.cssClass</param>
            /// <param name="innerHtml" type="String"></param>
            /// <param name="styles" type="Object">A set of key/value pairs that configure styles</param>
            /// <param name="attrs" type="Object">A set of key/value pairs that configure attributes</param>
            /// <returns type="jQuery"></returns>
            var tagName = /^[a-z]*[0-9a-z]+/ig.exec(tag)[0];

           var id = /#([_a-z0-9-&@\/\\,+()$~%:*?<>{}\[\]]+\S)/ig.exec(tag);
            id = id ? id[id.length - 1].replace(/[&@\/\\,+()$~%.:*?<>{}\[\]]/g, ''): undefined;

            var className = /\.([a-z]+[-_0-9a-z ]+)/ig.exec(tag);
            className = className ? className[className.length - 1] : undefined;

            return $(document.createElement(tagName))
                .attr(id ? { "id": id } : {})
                .addClass(className || "")
                .css(styles || {})
                .attr(attrs || {})
                .html(innerHtml || "");
        },
        _preventDefaultException: function (el, exceptions) {
            if (el) {
                for (var i in exceptions) {
                    if (exceptions[i].test(el[i])) {
                        return true;
                    }
                }
            }

            return false;
        },

        //Gets the maximum z-index in the document
        getMaxZindex: function () {
            var maxZ = 1;
            maxZ = Math.max.apply(null, $.map($('body *'), function (e, n) {
                if ($(e).css('position') == 'absolute' || $(e).css('position') == 'fixed')
                    return parseInt($(e).css('z-index')) || 1;
            })
            );
            if (maxZ == undefined || maxZ == null)
                maxZ = 1;
            return maxZ;
        },

        //To prevent default actions for the element
        blockDefaultActions: function (e) {
            e.cancelBubble = true;
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
            if (e.stopPropagation) e.stopPropagation();
        },

        //To get dimensions of the element when its hidden
        getDimension: function (element, method) {
            var value;
            var $hidden = $(element).parents().andSelf().filter(':hidden');
            if ($hidden) {
                var prop = { visibility: 'hidden', display: 'block' };
                var tmp = [];
                $hidden.each(function () {
                    var temp = {}, name;
                    for (name in prop) {
                        temp[name] = this.style[name];
                        this.style[name] = prop[name];
                    }
                    tmp.push(temp);
                });
                value = /(outer)/g.test(method) ?
                $(element)[method](true) :
               $(element)[method]();

                $hidden.each(function (i) {
                    var temp = tmp[i], name;
                    for (name in prop) {
                        this.style[name] = temp[name];
                    }
                });
            }
            return value;
        },
        //Get triggers when transition End
        transitionEndEvent: function () {
            var transitionEnd = {
                '': 'transitionend',
                'webkit': 'webkitTransitionEnd',
                'Moz': 'transitionend',
                'O': 'otransitionend',
                'ms': 'MSTransitionEnd'
            };

            return transitionEnd[ej.userAgent()];
        },
        //Get triggers when transition End
        animationEndEvent: function () {
            var animationEnd = {
                '': 'animationend',
                'webkit': 'webkitAnimationEnd',
                'Moz': 'animationend',
                'O': 'webkitAnimationEnd',
                'ms': 'animationend'
            };

            return animationEnd[ej.userAgent()];
        },
        //To return the start event to bind for element
        startEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchstart" : "mousedown";
        },
        //To return end event to bind for element
        endEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchend" : "mouseup"
        },
        //To return move event to bind for element
        moveEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? ($.support.hasPointer && !ej.isMobile()) ? "ejtouchmove" : "touchmove" : "mousemove";
        },
        //To return cancel event to bind for element
        cancelEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchcancel" : "mousecancel";
        },
        //To return tap event to bind for element
        tapEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "tap" : "click";
        },
        //To return tap hold event to bind for element
        tapHoldEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "taphold" : "click";
        },
        //To check whether its Device
        isDevice: function () {
            if (ej.getBooleanVal($('head'), 'data-ej-forceset', false))
                return ej.getBooleanVal($('head'), 'data-ej-device', this._device());
            else
                return this._device();
        },
        //To check whether its portrait or landscape mode
        isPortrait: function () {
            var elem = document.documentElement;
            return (elem) && ((elem.clientWidth / elem.clientHeight) < 1.1);
        },
        //To check whether its in lower resolution
        isLowerResolution: function () {
            return ((window.innerWidth <= 640 && ej.isPortrait() && ej.isDevice()) || (window.innerWidth <= 800 && !ej.isDevice()) || (window.innerWidth <= 800 && !ej.isPortrait() && ej.isWindows() && ej.isDevice()) || ej.isMobile());
        },
        //To check whether its iOS web view
        isIOSWebView: function () {
            return (/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(navigator.userAgent));
        },
        //To check whether its Android web view
        isAndroidWebView: function () {
            return (!(typeof (Android) === "undefined"));
        },
        //To check whether its windows web view
        isWindowsWebView: function () {
            return location.href.indexOf("x-wmapp") != -1;
        },
        _device: function () {
            return (/Android|BlackBerry|iPhone|iPad|iPod|IEMobile|kindle|windows\sce|palm|smartphone|iemobile|mobile|pad|xoom|sch-i800|playbook/i.test(navigator.userAgent.toLowerCase()));
        },
        //To check whether its Mobile
        isMobile: function () {
            return ((/iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/i.test(navigator.userAgent.toLowerCase()) && /mobile/i.test(navigator.userAgent.toLowerCase()))) || (ej.getBooleanVal($('head'), 'data-ej-mobile', false) === true);
        },
        //To check whether its Tablet
        isTablet: function () {
            return (/ipad|xoom|sch-i800|playbook|tablet|kindle/i.test(navigator.userAgent.toLowerCase())) || (ej.getBooleanVal($('head'), 'data-ej-tablet', false) === true) || (!ej.isMobile() && ej.isDevice());
        },
        //To check whether its Touch Device
        isTouchDevice: function () {
            return (('ontouchstart' in window || (window.navigator.msPointerEnabled && ej.isMobile())) && this.isDevice());
        },
        //To get the outerHTML string for object
        getClearString: function (string) {
            return $.trim(string.replace(/\s+/g, " ").replace(/(\r\n|\n|\r)/gm, "").replace(new RegExp("\>[\n\t ]+\<", "g"), "><"));
        },
        //Get the attribute value with boolean type of element
        getBooleanVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value.toLowerCase() == "true";
            else
                return option;
        },
        //Gets the Skew class based on the element current position
        _getSkewClass: function (item, pageX, pageY) {
            var itemwidth = item.width();
            var itemheight = item.height();
            var leftOffset = item.offset().left;
            var rightOffset = item.offset().left + itemwidth;
            var topOffset = item.offset().top;
            var bottomOffset = item.offset().top + itemheight;
            var widthoffset = itemwidth * 0.3;
            var heightoffset = itemheight * 0.3;
            if (pageX < leftOffset + widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topleft";
            if (pageX > rightOffset - widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topright";
            if (pageX > rightOffset - widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomright";
            if (pageX < leftOffset + widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomleft";
            if (pageX > leftOffset + widthoffset && pageY < topOffset + heightoffset && pageX < rightOffset - widthoffset)
                return "e-m-skew-top";
            if (pageX < leftOffset + widthoffset)
                return "e-m-skew-left";
            if (pageX > rightOffset - widthoffset)
                return "e-m-skew-right";
            if (pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottom";
            return "e-m-skew-center";
        },
        //Removes the added Skew class on the element
        _removeSkewClass: function (element) {
            $(element).removeClass("e-m-skew-top e-m-skew-bottom e-m-skew-left e-m-skew-right e-m-skew-topleft e-m-skew-topright e-m-skew-bottomleft e-m-skew-bottomright e-m-skew-center e-skew-top e-skew-bottom e-skew-left e-skew-right e-skew-topleft e-skew-topright e-skew-bottomleft e-skew-bottomright e-skew-center");
        },
        //Object.keys  method to support all the browser including IE8.
        _getObjectKeys: function (obj) {
            var i, keys = [];
            obj = Object.prototype.toString.call(obj) === Object.prototype.toString() ? obj : {};
            if (!Object.keys) {
                for (i in obj) {
                    if (obj.hasOwnProperty(i))
                        keys.push(i);
                }
                return keys;
            }
            if (Object.keys)
                return Object.keys(obj);
        },
        _touchStartPoints: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt;
                object._distX = 0;
                object._distY = 0;
                object._moved = false;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
            }
        },
        _isTouchMoved: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt,
                deltaX = point.pageX - object._pointX,
                deltaY = point.pageY - object._pointY,
                timestamp = Date.now(),
                newX, newY,
                absDistX, absDistY;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
                object._distX += deltaX;
                object._distY += deltaY;
                absDistX = Math.abs(object._distX);
                absDistY = Math.abs(object._distY);
                return !(absDistX < 5 && absDistY < 5);
            }
        },
        //To bind events for element
        listenEvents: function (selectors, eventTypes, handlers, remove, pluginObj, disableMouse) {
            for (var i = 0; i < selectors.length; i++) {
                ej.listenTouchEvent(selectors[i], eventTypes[i], handlers[i], remove, pluginObj, disableMouse);
            }
        },
        //To bind touch events for element
        listenTouchEvent: function (selector, eventType, handler, remove, pluginObj, disableMouse) {
            var event = remove ? "removeEventListener" : "addEventListener";
            var jqueryEvent = remove ? "off" : "on";
            var elements = $(selector);
            for (var i = 0; i < elements.length; i++) {
                var element = elements[i];
                switch (eventType) {
                    case "touchstart":
                        ej._bindEvent(element, event, eventType, handler, "mousedown", "MSPointerDown", "pointerdown", disableMouse);
                        break;
                    case "touchmove":
                        ej._bindEvent(element, event, eventType, handler, "mousemove", "MSPointerMove", "pointermove", disableMouse);
                        break;
                    case "touchend":
                        ej._bindEvent(element, event, eventType, handler, "mouseup", "MSPointerUp", "pointerup", disableMouse);
                        break;
                    case "touchcancel":
                        ej._bindEvent(element, event, eventType, handler, "mousecancel", "MSPointerCancel", "pointercancel", disableMouse);
                        break;
                    case "tap": case "taphold": case "ejtouchmove": case "click":
                        $(element)[jqueryEvent](eventType, handler);
                        break;
                    default:
                        if (ej.browserInfo().name == "msie" && ej.browserInfo().version < 9)
                            pluginObj["_on"]($(element), eventType, handler);
                        else
                            element[event](eventType, handler, true);
                        break;
                }
            }
        },
        //To bind events for element
        _bindEvent: function (element, event, eventType, handler, mouseEvent, pointerEvent, ie11pointerEvent, disableMouse) {
            if ($.support.hasPointer)
                element[event](window.navigator.pointerEnabled ? ie11pointerEvent : pointerEvent, handler, true);
            else
                element[event](eventType, handler, true);
        },
        _browser: function () {
            return (/webkit/i).test(navigator.appVersion) ? 'webkit' : (/firefox/i).test(navigator.userAgent) ? 'Moz' : (/trident/i).test(navigator.userAgent) ? 'ms' : 'opera' in window ? 'O' : '';
        },
        styles: document.createElement('div').style,
        /**
       * To get the userAgent Name     
       * @example             
       * &lt;script&gt;
       *       ej.userAgent();//return user agent name
       * &lt;/script&gt         
       * @memberof AppView
       * @instance
       */
        userAgent: function () {
            var agents = 'webkitT,t,MozT,msT,OT'.split(','),
            t,
            i = 0,
            l = agents.length;

            for (; i < l; i++) {
                t = agents[i] + 'ransform';
                if (t in ej.styles) {
                    return agents[i].substr(0, agents[i].length - 1);
                }
            }

            return false;
        },
        addPrefix: function (style) {
            if (ej.userAgent() === '') return style;

            style = style.charAt(0).toUpperCase() + style.substr(1);
            return ej.userAgent() + style;
        },
        //To Prevent Default Exception

        //To destroy the mobile widgets
        destroyWidgets: function (element) {
            var dataEl = $(element).find("[data-role *= ejm]");
            dataEl.each(function (index, element) {
                var $element = $(element);
                var plugin = $element.data("ejWidgets");
                if (plugin)
                    $element[plugin]("destroy");
            });
        },
        //Get the attribute value of element
        getAttrVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value;
            else
                return option;
        },

        // Get the offset value of element
        getOffset: function (ele) {
            var pos = {};
            var offsetObj = ele.offset() || { left: 0, top: 0 };
            $.extend(true, pos, offsetObj);
            if ($("body").css("position") != "static") {
                var bodyPos = $("body").offset();
                pos.left -= bodyPos.left;
                pos.top -= bodyPos.top;
            }
            return pos;
        },

        // Z-index calculation for the element
        getZindexPartial: function (element, popupEle) {
            if (!ej.isNullOrUndefined(element) && element.length > 0) {
                var parents = element.parents(), bodyEle;
                bodyEle = $('body').children();
                if (!ej.isNullOrUndefined(element) && element.length > 0)
                    bodyEle.splice(bodyEle.index(popupEle), 1);
                $(bodyEle).each(function (i, ele) { parents.push(ele); });

                var maxZ = Math.max.apply(maxZ, $.map(parents, function (e, n) {
                    if ($(e).css('position') != 'static') return parseInt($(e).css('z-index')) || 1;
                }));
                if (!maxZ || maxZ < 10000) maxZ = 10000;
                else maxZ += 1;
                return maxZ;
            }
        },

        isValidAttr: function (element, attribute) {
            var element = $(element)[0];
            if (typeof element[attribute] != "undefined")
                return true;
            else {
                var _isValid = false;
                $.each(element, function (key) {
                    if (key.toLowerCase() == attribute.toLowerCase()) {
                        _isValid = true;
                        return false;
                    }
                });
            }
            return _isValid;
        }

    };

    $.extend(ej, ej.util);

    // base class for all ej widgets. It will automatically inhertied
    ej.widgetBase = {
        droppables: { 'default': [] },
        resizables: { 'default': [] },

        _renderEjTemplate: function (selector, data, index, prop, ngTemplateType) {
            var type = null;
            if (typeof selector === "object" || selector.startsWith("#") || selector.startsWith("."))
                type = $(selector).attr("type");
            if (type) {
                type = type.toLowerCase();
                if (ej.template[type])
                    return ej.template[type](this, selector, data, index, prop);
            }
            // For ejGrid Angular2 Template Support
            else if (!ej.isNullOrUndefined(ngTemplateType))
                 return ej.template['text/x-'+ ngTemplateType](this, selector, data, index, prop);
            return ej.template.render(this, selector, data, index, prop);
        },

        destroy: function () {

            if (this._trigger("destroy"))
                return;

            if (this.model.enablePersistence) {
                this.persistState();
                $(window).off("unload", this._persistHandler);
            }

            try {
                this._destroy();
            } catch (e) { }

            var arr = this.element.data("ejWidgets") || [];
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] == this.pluginName) {
                    arr.splice(i, 1);
                }
            }
            if (!arr.length)
                this.element.removeData("ejWidgets");

            while (this._events) {
                var item = this._events.pop(), args = [];

                if (!item)
                    break;

                for (var i = 0; i < item[1].length; i++)
                    if (!$.isPlainObject(item[1][i]))
                        args.push(item[1][i]);

                $.fn.off.apply(item[0], args);
            }

            this._events = null;

            this.element
                .removeClass(ej.util.getNameSpace(this.sfType))
                .removeClass("e-js")
                .removeData(this.pluginName);

            this.element = null;
            this.model = null;
        },

        _on: function (element) {
            if (!this._events)
                this._events = [];
            var args = [].splice.call(arguments, 1, arguments.length - 1);

            var handler = {}, i = args.length;
            while (handler && typeof handler !== "function") {
                handler = args[--i];
            }

            args[i] = ej.proxy(args[i], this);

            this._events.push([element, args, handler, args[i]]);

            $.fn.on.apply(element, args);

            return this;
        },

        _off: function (element, eventName, selector, handlerObject) {
            var e = this._events, temp;
            if (!e || !e.length)
                return this;
            if (typeof selector == "function") {
                temp = handlerObject;
                handlerObject = selector;
                selector = temp;
            }
            var t = (eventName.match(/\S+/g) || [""]);
            for (var i = 0; i < e.length; i++) {
                var arg = e[i],
                r = arg[0].length && (!handlerObject || arg[2] === handlerObject) && (arg[1][0] === eventName || t[0]) && (!selector || arg[1][1] === selector) && $.inArray(element[0], arg[0]) > -1;
                if (r) {
                    $.fn.off.apply(element, handlerObject ? [eventName, selector, arg[3]] : [eventName, selector]);
                    e.splice(i, 1);
                    break;
                }
            }

            return this;
        },

        // Client side events wire-up / trigger helper.
        _trigger: function (eventName, eventProp) {
            var fn = null, returnValue, args, clientProp = {};
            $.extend(clientProp, eventProp)

            if (eventName in this.model)
                fn = this.model[eventName];

            if (fn) {
                if (typeof fn === "string") {
                    fn = ej.util.getObject(fn, window);
                }

                if ($.isFunction(fn)) {

                    args = ej.event(eventName, this.model, eventProp);

                    
                    returnValue = fn.call(this, args);

                    // sending changes back - deep copy option should not be enabled for this $.extend 
                    if (eventProp) $.extend(eventProp, args);

                    if (args.cancel || !ej.isNullOrUndefined(returnValue))
                        return returnValue === false || args.cancel;
                }
            }

            var isPropDefined = Boolean(eventProp);
            eventProp = eventProp || {};
            eventProp.originalEventType = eventName;
            eventProp.type = this.pluginName + eventName;

            args = $.Event(eventProp.type, ej.event(eventProp.type, this.model, eventProp));

            this.element && this.element.trigger(args);

            // sending changes back - deep copy option should not be enabled for this $.extend 
            if (isPropDefined) $.extend(eventProp, args);

            if (ej.isOnWebForms && args.cancel == false && this.model.serverEvents && this.model.serverEvents.length)
                ej.raiseWebFormsServerEvents(eventName, eventProp, clientProp);

            return args.cancel;
        },

        setModel: function (options, forceSet) {
            // check for whether to apply values are not. if _setModel function is defined in child,
            //  this will call that function and validate it using return value

            if (this._trigger("modelChange", { "changes": options }))
                return;

            for (var prop in options) {
                if (!forceSet) {
                    if (this.model[prop] === options[prop]) {
                        delete options[prop];
                        continue;
                    }
                    if ($.isPlainObject(options[prop])) {
                        iterateAndRemoveProps(this.model[prop], options[prop]);
                        if ($.isEmptyObject(options[prop])) {
                            delete options[prop];
                            continue;
                        }
                    }
                }

                if (this.dataTypes) {
                    var returnValue = this._isValidModelValue(prop, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + prop + " - " + returnValue;
                }
                if (this.model.notifyOnEachPropertyChanges && this.model[prop] !== options[prop]) {
                    var arg = {
                        oldValue: this.model[prop],
                        newValue: options[prop]
                    };

                    options[prop] = this._trigger(prop + "Change", arg) ? this.model[prop] : arg.newValue;
                }
            }
            if ($.isEmptyObject(options))
                return;

            if (this._setFirst) {
                var ds = options.dataSource;
                if (ds) delete options.dataSource;

                $.extend(true, this.model, options);
                if (ds) {
                    this.model.dataSource = (ds instanceof Array) ? ds.slice() : ds;
                    options["dataSource"] = this.model.dataSource;
                }
                !this._setModel || this._setModel(options);

            } else if (!this._setModel || this._setModel(options) !== false) {
                $.extend(true, this.model, options);
            }
            if ("enablePersistence" in options) {
                this._setState(options.enablePersistence);
            }
        },
        option: function (prop, value, forceSet) {
            if (!prop)
                return this.model;

            if ($.isPlainObject(prop))
                return this.setModel(prop, forceSet);

            if (typeof prop === "string") {
                prop = prop.replace(/^model\./, "");
                var oldValue = ej.getObject(prop, this.model);

                if (value === undefined && !forceSet)
                    return oldValue;

                if (prop === "enablePersistence")
                    return this._setState(value);

                if (forceSet && value === ej.extensions.modelGUID) {
                    return this._setModel(ej.createObject(prop, ej.getObject(prop, this.model), {}));
                }

                if (forceSet || ej.getObject(prop, this.model) !== value)
                    return this.setModel(ej.createObject(prop, value, {}), forceSet);
            }
            return undefined;
        },

        _isValidModelValue: function (prop, types, options) {
            var value = types[prop], option = options[prop], returnValue;

            if (!value)
                return true;

            if (typeof value === "string") {
                if (value == "enum") {
                    options[prop] = option ? option.toString().toLowerCase() : option;
                    value = "string";
                }

                if (value === "array") {
                    if (Object.prototype.toString.call(option) === '[object Array]')
                        return true;
                }
                else if (value === "data") {
                    return true;
                }
                else if (value === "parent") {
                    return true;
                }
                else if (typeof option === value)
                    return true;

                return "Expected type - " + value;
            }

            if (option instanceof Array) {
                for (var i = 0; i < option.length; i++) {
                    returnValue = this._isValidModelValue(prop, types, option[i]);
                    if (returnValue !== true) {
                        return " [" + i + "] - " + returnValue;
                    }
                }
                return true;
            }

            for (var innerProp in option) {
                returnValue = this._isValidModelValue(innerProp, value, option);
                if (returnValue !== true)
                    return innerProp + " : " + returnValue;
            }

            return true;
        },

        _returnFn: function (obj, propName) {
            if (propName.indexOf('.') != -1) {
                this._returnFn(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
            }
            else
                obj[propName] = obj[propName].call(obj.propName);
        },

        _removeCircularRef: function (obj) {
            var seen = [];
            function detect(obj, key, parent) {
                if (typeof obj != 'object') { return; }
                if (!Array.prototype.indexOf) {
                    Array.prototype.indexOf = function (val) {
                        return jQuery.inArray(val, this);
                    };
                }
                if (seen.indexOf(obj) >= 0) {
                    delete parent[key];
                    return;
                }
                seen.push(obj);
                for (var k in obj) { //dive on the object's children
                    if (obj.hasOwnProperty(k)) { detect(obj[k], k, obj); }
                }
                seen.pop();
                return;
            }
            detect(obj, 'obj', null);
            return obj;
        },

        stringify: function (model, removeCircular) {
            var observables = this.observables;
            for (var k = 0; k < observables.length; k++) {
                var val = ej.getObject(observables[k], model);
                if (!ej.isNullOrUndefined(val) && typeof (val) === "function")
                    this._returnFn(model, observables[k]);
            }
            if (removeCircular) model = this._removeCircularRef(model);
            return JSON.stringify(model);
        },

        _setState: function (val) {
            if (val === true) {
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
            } else {
                this.deleteState();
                $(window).off("unload", this._persistHandler);
            }
        },

        _removeProp: function (obj, propName) {
            if (!ej.isNullOrUndefined(obj)) {
                if (propName.indexOf('.') != -1) {
                    this._removeProp(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
                }
                else
                    delete obj[propName];
            }
        },

        persistState: function () {
            var model;

            if (this._ignoreOnPersist) {
                model = copyObject({}, this.model);
                for (var i = 0; i < this._ignoreOnPersist.length; i++) {
                    this._removeProp(model, this._ignoreOnPersist[i]);
                }
                model.ignoreOnPersist = this._ignoreOnPersist;
            } else if (this._addToPersist) {
                model = {};
                for (var i = 0; i < this._addToPersist.length; i++) {
                    ej.createObject(this._addToPersist[i], ej.getObject(this._addToPersist[i], this.model), model);
                }
                model.addToPersist = this._addToPersist;
            } else {
                model = copyObject({}, this.model);
            }

            if (this._persistState) {
                model.customPersists = {};
                this._persistState(model.customPersists);
            }

            if (window.localStorage) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") == null)
                    window.localStorage.setItem("persistKey", ej.persistStateVersion);
                window.localStorage.setItem("$ej$" + this.pluginName + this._id, JSON.stringify(model));
            }
            else if (document.cookie) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") == null)
                    ej.cookie.set("persistKey", ej.persistStateVersion);
                ej.cookie.set("$ej$" + this.pluginName + this._id, model);
            }
        },

        deleteState: function () {
            if (window.localStorage)
                window.localStorage.removeItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                ej.cookie.set("$ej$" + this.pluginName + this._id, model, new Date());
        },

        restoreState: function (silent) {
            var value = null;
            if (window.localStorage)
                value = window.localStorage.getItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                value = ej.cookie.get("$ej$" + this.pluginName + this._id);

            if (value) {
                var model = JSON.parse(value);

                if (this._restoreState) {
                    this._restoreState(model.customPersists);
                    delete model.customPersists;
                }

                if (ej.isNullOrUndefined(model) === false)
                    if (!ej.isNullOrUndefined(model.ignoreOnPersist)) {
                        this._ignoreOnPersist = model.ignoreOnPersist;
                        delete model.ignoreOnPersist;
                    } else if (!ej.isNullOrUndefined(model.addToPersist)) {
                        this._addToPersist = model.addToPersist;
                        delete model.addToPersist;
                    }
            }
            if (!ej.isNullOrUndefined(model) && !ej.isNullOrUndefined(this._ignoreOnPersist)) {
                for(var i = 0, len =  this._ignoreOnPersist.length; i < len; i++) {
					if (this._ignoreOnPersist[i].indexOf('.') !== -1)
                        ej.createObject(this._ignoreOnPersist[i], ej.getObject(this._ignoreOnPersist[i], this.model), model);
                    else
                        model[this._ignoreOnPersist[i]] = this.model[this._ignoreOnPersist[i]];
				}
                this.model = model;
            }
            else
                this.model = $.extend(true, this.model, model);

            if (!silent && value && this._setModel)
                this._setModel(this.model);
        },

        //to prevent persistence
        ignoreOnPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    this._ignoreOnPersist.push(collection[i]);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    var index = this._addToPersist.indexOf(collection[i]);
                    this._addToPersist.splice(index, 1);
                }
            }
        },

        //to maintain persistence
        addToPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    var index = this._ignoreOnPersist.indexOf(collection[i]);
                    this._ignoreOnPersist.splice(index, 1);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    if ($.inArray(collection[i], this._addToPersist) === -1)
                        this._addToPersist.push(collection[i]);
                }
            }
        },

        // Get formatted text 
        formatting: function (formatstring, str, locale) {
            formatstring = formatstring.replace(/%280/g, "\"").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
            locale = ej.preferredCulture(locale) ? locale : "en-US";
            var s = formatstring;
            var frontHtmlidx, FrontHtml, RearHtml, lastidxval;
            frontHtmlidx = formatstring.split("{0:");
            lastidxval = formatstring.split("}");
            FrontHtml = frontHtmlidx[0];
            RearHtml = lastidxval[1];
            if (typeof (str) == "string" && $.isNumeric(str))
                str = Number(str);
            if (formatstring.indexOf("{0:") != -1) {
                var toformat = new RegExp("\\{0(:([^\\}]+))?\\}", "gm");
                var formatVal = toformat.exec(formatstring);
                if (formatVal != null && str != null) {
                    if (FrontHtml != null && RearHtml != null)
                        str = FrontHtml + ej.format(str, formatVal[2], locale) + RearHtml;
                    else
                        str = ej.format(str, formatVal[2], locale);
                } else if (str != null)
                    str = str;
                else
                    str = "";
                return str;
            } else if (s.startsWith("{") && !s.startsWith("{0:")) {
                var fVal = s.split(""), str = (str || "") + "", strSplt = str.split(""), formats = /[0aA\*CN<>\?]/gm;
                for (var f = 0, f, val = 0; f < fVal.length; f++)
                    fVal[f] = formats.test(fVal[f]) ? "{" + val++ + "}" : fVal[f];
                return String.format.apply(String, [fVal.join("")].concat(strSplt)).replace('{', '').replace('}', '');
            } else if (this.data != null && this.data.Value == null) {
                $.each(this.data, function (dataIndex, dataValue) {
                    s = s.replace(new RegExp('\\{' + dataIndex + '\\}', 'gm'), dataValue);
                });
                return s;
            } else {
                return this.data.Value;
            }
        },
    };

    ej.WidgetBase = function () {
    }

    var iterateAndRemoveProps = function (source, target) {
		if(source instanceof Array) {
			for (var i = 0, len = source.length; i < len; i++) {
				prop = source[i];
				if(prop === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(prop))
					iterateAndRemoveProps(prop, target[prop]);
			}
		}
		else {
			for (var prop in source) {
				if (source[prop] === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(source[prop]))
					iterateAndRemoveProps(source[prop], target[prop]);
			}
		}
    }

    ej.widget = function (pluginName, className, proto) {
        /// <summary>Widget helper for developers, this set have predefined function to jQuery plug-ins</summary>
        /// <param name="pluginName" type="String">the plugin name that will be added in jquery.fn</param>
        /// <param name="className" type="String">the class name for your plugin, this will help create default cssClas</param>
        /// <param name="proto" type="Object">prototype for of the plug-in</param>

        if (typeof pluginName === "object") {
            proto = className;
            for (var prop in pluginName) {
                var name = pluginName[prop];

                if (name instanceof Array) {
                    proto._rootCSS = name[1];
                    name = name[0];
                }

                ej.widget(prop, name, proto);

                if (pluginName[prop] instanceof Array)
                    proto._rootCSS = "";
            }

            return;
        }

        var nameSpace = proto._rootCSS || ej.getNameSpace(className);

        proto = ej.defineClass(className, function (element, options) {

            this.sfType = className;
            this.pluginName = pluginName;
            this.instance = pInstance;

            if (ej.isNullOrUndefined(this._setFirst))
                this._setFirst = true;

            this["ob.values"] = {};

            $.extend(this, ej.widgetBase);

            if (this.dataTypes) {
                for (var property in options) {
                    var returnValue = this._isValidModelValue(property, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + property + " - " + returnValue;
                }
            }

            var arr = (element.data("ejWidgets") || []);
            arr.push(pluginName);
            element.data("ejWidgets", arr);

            for (var i = 0; ej.widget.observables && this.observables && i < this.observables.length; i++) {
                var t = ej.getObject(this.observables[i], options);
                if (t) ej.createObject(this.observables[i], ej.widget.observables.register(t, this.observables[i], this, element), options);
            }

            this.element = element.jquery ? element : $(element);
            this.model = copyObject(true, {}, proto.prototype.defaults, options);
            this.model.keyConfigs = copyObject(this.keyConfigs);

            this.element.addClass(nameSpace + " e-js").data(pluginName, this);

            this._id = element[0].id;

            if (this.model.enablePersistence) {
                if (window.localStorage && !ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") != ej.persistStateVersion) {
                    for (var i in window.localStorage) {
                        if (i.indexOf("$ej$") != -1) {
                            window.localStorage.removeItem(i); //removing the previously stored plugin item from local storage
							window.localStorage.setItem("persistKey", ej.persistStateVersion);
						}				
                    }
                }
                else if (document.cookie && !ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") != ej.persistStateVersion) {
                    var splits = document.cookie.split(/; */);
                    for (var k in splits) {
                        if (k.indexOf("$ej$") != -1) {
                            ej.cookie.set(k.split("=")[0], model, new Date()); //removing the previously stored plugin item from local storage
							ej.cookie.set("persistKey", ej.persistStateVersion);
						}		
                    }
                }
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
                this.restoreState(true);
            }

            this._init(options);

            if (typeof this.model.keyConfigs === "object" && !(this.model.keyConfigs instanceof Array)) {
                var requiresEvt = false;
                if (this.model.keyConfigs.focus)
                    this.element.attr("accesskey", this.model.keyConfigs.focus);

                for (var keyProps in this.model.keyConfigs) {
                    if (keyProps !== "focus") {
                        requiresEvt = true;
                        break;
                    }
                }

                if (requiresEvt && this._keyPressed) {
                    var el = element, evt = "keydown";

                    if (this.keySettings) {
                        el = this.keySettings.getElement ? this.keySettings.getElement() || el : el;
                        evt = this.keySettings.event || evt;
                    }

                    this._on(el, evt, function (e) {
                        if (!this.model.keyConfigs) return;

                        var action = keyFn.getActionFromCode(this.model.keyConfigs, e.which, e.ctrlKey, e.shiftKey, e.altKey);
                        var arg = {
                            code: e.which,
                            ctrl: e.ctrlKey,
                            alt: e.altKey,
                            shift: e.shiftKey
                        };
                        if (!action) return;

                        if (this._keyPressed(action, e.target, arg, e) === false)
                            e.preventDefault();
                    });
                }
            }
            this._trigger("create");
        }, proto);

        $.fn[pluginName] = function (options) {
            var opt = options, args;
            for (var i = 0; i < this.length; i++) {

                var $this = $(this[i]),
                    pluginObj = $this.data(pluginName),
                    isAlreadyExists = pluginObj && $this.hasClass(nameSpace),
                    obj = null;

                if (this.length > 0 && $.isPlainObject(opt))
                    options = ej.copyObject({}, opt);

                // ----- plug-in creation/init
                if (!isAlreadyExists) {
                    if (proto.prototype._requiresID === true && !$(this[i]).attr("id")) {
                        $this.attr("id", getUid("ejControl_"));
                    }
                    if (!options || typeof options === "object") {
                        if (proto.prototype.defaults && !ej.isNullOrUndefined(ej.setCulture) && "locale" in proto.prototype.defaults && pluginName != "ejChart") {
                            if (options && !("locale" in options)) options.locale = ej.setCulture().name;
                            else if (ej.isNullOrUndefined(options)) {
                                options = {}; options.locale = ej.setCulture().name;
                            }
                        }
                        new proto($this, options);
                    }
                    else {
                        throwError(pluginName + ": methods/properties can be accessed only after plugin creation");
                    }
                    continue;
                }

                if (!options) continue;

                args = [].slice.call(arguments, 1);

                if (this.length > 0 && args[0] && opt === "option" && $.isPlainObject(args[0])) {
                    args[0] = ej.copyObject({}, args[0]);
                }

                // --- Function/property set/access
                if ($.isPlainObject(options)) {
                    // setModel using JSON object
                    pluginObj.setModel(options);
                }

                    // function/property name starts with "_" is private so ignore it.
                else if (options.indexOf('_') !== 0
                    && !ej.isNullOrUndefined(obj = ej.getObject(options, pluginObj))
                    || options.indexOf("model.") === 0) {

                    if (!obj || !$.isFunction(obj)) {

                        // if property is accessed, then break the jquery chain
                        if (arguments.length == 1)
                            return obj;

                        //setModel using string input
                        pluginObj.option(options, arguments[1]);

                        continue;
                    }

                    var value = obj.apply(pluginObj, args);

                    // If function call returns any value, then break the jquery chain
                    if (value !== undefined)
                        return value;

                } else {
                    throwError(className + ": function/property - " + options + " does not exist");
                }
            }
            if (pluginName.indexOf("ejm") != -1)
                ej.widget.registerInstance($this, pluginName, className, proto.prototype);
            // maintaining jquery chain
            return this;
        };

        ej.widget.register(pluginName, className, proto.prototype);
        ej.loadLocale(pluginName);
    };

    ej.loadLocale = function (pluginName) {
        var i, len, locales = ej.locales;
        for (i = 0, len = locales.length; i < len; i++)
            $.fn["Locale_" + locales[i]](pluginName);
    };


    $.extend(ej.widget, (function () {
        var _widgets = {}, _registeredInstances = [],

        register = function (pluginName, className, prototype) {
            if (!ej.isNullOrUndefined(_widgets[pluginName]))
                throwError("ej.widget : The widget named " + pluginName + " is trying to register twice.");

            _widgets[pluginName] = { name: pluginName, className: className, proto: prototype };

            ej.widget.extensions && ej.widget.extensions.registerWidget(pluginName);
        },
        registerInstance = function (element, pluginName, className, prototype) {
            _registeredInstances.push({ element: element, pluginName: pluginName, className: className, proto: prototype });
        }

        return {
            register: register,
            registerInstance: registerInstance,
            registeredWidgets: _widgets,
            registeredInstances: _registeredInstances
        };

    })());

    ej.widget.destroyAll = function (elements) {
        if (!elements || !elements.length) return;

        for (var i = 0; i < elements.length; i++) {
            var data = elements.eq(i).data(), wds = data["ejWidgets"];
            if (wds && wds.length) {
                for (var j = 0; j < wds.length; j++) {
                    if (data[wds[j]] && data[wds[j]].destroy)
                        data[wds[j]].destroy();
                }
            }
        }
    };

    ej.cookie = {
        get: function (name) {
            var value = RegExp(name + "=([^;]+)").exec(document.cookie);

            if (value && value.length > 1)
                return value[1];

            return undefined;
        },
        set: function (name, value, expiryDate) {
            if (typeof value === "object")
                value = JSON.stringify(value);

            value = escape(value) + ((expiryDate == null) ? "" : "; expires=" + expiryDate.toUTCString());
            document.cookie = name + "=" + value;
        }
    };

    var keyFn = {
        getActionFromCode: function (keyConfigs, keyCode, isCtrl, isShift, isAlt) {
            isCtrl = isCtrl || false;
            isShift = isShift || false;
            isAlt = isAlt || false;

            for (var keys in keyConfigs) {
                if (keys === "focus") continue;

                var key = keyFn.getKeyObject(keyConfigs[keys]);
                for (var i = 0; i < key.length; i++) {
                    if (keyCode === key[i].code && isCtrl == key[i].isCtrl && isShift == key[i].isShift && isAlt == key[i].isAlt)
                        return keys;
                }
            }
            return null;
        },
        getKeyObject: function (key) {
            var res = {
                isCtrl: false,
                isShift: false,
                isAlt: false
            };
            var tempRes = $.extend(true, {}, res);
            var $key = key.split(","), $res = [];
            for (var i = 0; i < $key.length; i++) {
                var rslt = null;
                if ($key[i].indexOf("+") != -1) {
                    var k = $key[i].split("+");
                    for (var j = 0; j < k.length; j++) {
                        rslt = keyFn.getResult($.trim(k[j]), res);
                    }
                }
                else {
                    rslt = keyFn.getResult($.trim($key[i]), $.extend(true, {}, tempRes));
                }
                $res.push(rslt);
            }
            return $res;
        },
        getResult: function (key, res) {
            if (key === "ctrl")
                res.isCtrl = true;
            else if (key === "shift")
                res.isShift = true;
            else if (key === "alt")
                res.isAlt = true;
            else res.code = parseInt(key, 10);
            return res;
        }
    };

    ej.getScrollableParents = function (element) {
        return $(element).parentsUntil("html").filter(function () {
            return $(this).css("overflow") != "visible";
        }).add($(window));
    }
    ej.browserInfo = function () {
        var browser = {}, clientInfo = [],
        browserClients = {
            opera: /(opera|opr)(?:.*version|)[ \/]([\w.]+)/i, edge: /(edge)(?:.*version|)[ \/]([\w.]+)/i, webkit: /(chrome)[ \/]([\w.]+)/i, safari: /(webkit)[ \/]([\w.]+)/i, msie: /(msie|trident) ([\w.]+)/i, mozilla: /(mozilla)(?:.*? rv:([\w.]+)|)/i
        };
        for (var client in browserClients) {
            if (browserClients.hasOwnProperty(client)) {
                clientInfo = navigator.userAgent.match(browserClients[client]);
                if (clientInfo) {
                    browser.name = clientInfo[1].toLowerCase() == "opr" ? "opera" : clientInfo[1].toLowerCase();
                    browser.version = clientInfo[2];
                    browser.culture = {};
                    browser.culture.name = browser.culture.language = navigator.language || navigator.userLanguage;
                    if (typeof (ej.globalize) != 'undefined') {
                        var oldCulture = ej.preferredCulture().name;
                        var culture = (navigator.language || navigator.userLanguage) ? ej.preferredCulture(navigator.language || navigator.userLanguage) : ej.preferredCulture("en-US");
                        for (var i = 0; (navigator.languages) && i < navigator.languages.length; i++) {
                            culture = ej.preferredCulture(navigator.languages[i]);
                            if (culture.language == navigator.languages[i])
                                break;
                        }
                        ej.preferredCulture(oldCulture);
                        $.extend(true, browser.culture, culture);
                    }
                    if (!!navigator.userAgent.match(/Trident\/7\./)) {
                        browser.name = "msie";
                    }
                    break;
                }
            }
        }
        browser.isMSPointerEnabled = (browser.name == 'msie') && browser.version > 9 && window.navigator.msPointerEnabled;
        browser.pointerEnabled = window.navigator.pointerEnabled;
        return browser;
    };
    ej.eventType = {
        mouseDown: "mousedown touchstart",
        mouseMove: "mousemove touchmove",
        mouseUp: "mouseup touchend",
        mouseLeave: "mouseleave touchcancel",
        click: "click touchend"
    };

    ej.event = function (type, data, eventProp) {

        var e = $.extend(eventProp || {},
            {
                "type": type,
                "model": data,
                "cancel": false
            });

        return e;
    };

    ej.proxy = function (fn, context, arg) {
        if (!fn || typeof fn !== "function")
            return null;

        if ('on' in fn && context)
            return arg ? fn.on(context, arg) : fn.on(context);

        return function () {
            var args = arg ? [arg] : []; args.push.apply(args, arguments);
            return fn.apply(context || this, args);
        };
    };

    ej.hasStyle = function (prop) {
        var style = document.documentElement.style;

        if (prop in style) return true;

        var prefixs = ['ms', 'Moz', 'Webkit', 'O', 'Khtml'];

        prop = prop[0].toUpperCase() + prop.slice(1);

        for (var i = 0; i < prefixs.length; i++) {
            if (prefixs[i] + prop in style)
                return true;
        }

        return false;
    };

    Array.prototype.indexOf = Array.prototype.indexOf || function (searchElement) {
        var len = this.length;

        if (len === 0) return -1;

        for (var i = 0; i < len; i++) {
            if (i in this && this[i] === searchElement)
                return i;
        }
        return -1;
    };

    String.prototype.startsWith = String.prototype.startsWith || function (key) {
        return this.slice(0, key.length) === key;
    };
    var copyObject = ej.copyObject = function (isDeepCopy, target) {
        var start = 2, current, source;
        if (typeof isDeepCopy !== "boolean") {
            start = 1;
        }
        var objects = [].slice.call(arguments, start);
        if (start === 1) {
            target = isDeepCopy;
            isDeepCopy = undefined;
        }

        for (var i = 0; i < objects.length; i++) {
            for (var prop in objects[i]) {
                current = target[prop], source = objects[i][prop];

                if (source === undefined || current === source || objects[i] === source || target === source)
                    continue;
                if (source instanceof Array) {
                    if (i === 0 && isDeepCopy) {
                        if (prop === "dataSource" || prop === "data" || prop === "predicates")
                            target[prop] = source.slice();
					  else  {
                        target[prop] = new Array();
                        for (var j = 0; j < source.length; j++) {
                            copyObject(true, target[prop], source);
                        }
					  }
                    }
                    else
                        target[prop] = source.slice();
                }
                else if (ej.isPlainObject(source)) {
                    target[prop] = current || {};
                    if (isDeepCopy)
                        copyObject(isDeepCopy, target[prop], source);
                    else
                        copyObject(target[prop], source);
                } else
                    target[prop] = source;
            }
        }
        return target;
    };
    var pInstance = function () {
        return this;
    }

    var _uid = 0;
    var getUid = function (prefix) {
        return prefix + _uid++;
    }

    ej.template = {};

    ej.template.render = ej.template["text/x-jsrender"] = function (self, selector, data, index, prop) {
        if (selector.slice(0, 1) !== "#")
            selector = ["<div>", selector, "</div>"].join("");
        var property = { prop: prop, index: index };
        return $(selector).render(data, property);
    }

    ej.isPlainObject = function (obj) {
        if (!obj) return false;
        if (ej.DataManager !== undefined && obj instanceof ej.DataManager) return false;
        if (typeof obj !== "object" || obj.nodeType || jQuery.isWindow(obj)) return false;
        try {
            if (obj.constructor &&
                !obj.constructor.prototype.hasOwnProperty("isPrototypeOf")) {
                return false;
            }
        } catch (e) {
            return false;
        }

        var key, ownLast = ej.support.isOwnLast;
        for (key in obj) {
            if (ownLast) break;
        }

        return key === undefined || obj.hasOwnProperty(key);
    };
    var getValueFn = false;
    ej.util.valueFunction = function (prop) {
        return function (value, getObservable) {
            var val = ej.getObject(prop, this.model);

            if (getValueFn === false)
                getValueFn = ej.getObject("observables.getValue", ej.widget);

            if (value === undefined) {
                if (!ej.isNullOrUndefined(getValueFn)) {
                    return getValueFn(val, getObservable);
                }
                return typeof val === "function" ? val.call(this) : val;
            }

            if (typeof val === "function") {
                this["ob.values"][prop] = value;
                val.call(this, value);
            }
            else
                ej.createObject(prop, value, this.model);
        }
    };
    ej.util.getVal = function (val) {
        if (typeof val === "function")
            return val();
        return val;
    };
    ej.support = {
        isOwnLast: function () {
            var fn = function () { this.a = 1; };
            fn.prototype.b = 1;

            for (var p in new fn()) {
                return p === "b";
            }
        }(),
        outerHTML: function () {
            return document.createElement("div").outerHTML !== undefined;
        }()
    };

    var throwError = ej.throwError = function (er) {
        try {
            throw new Error(er);
        } catch (e) {
            throw e.message + "\n" + e.stack;
        }
    };

    ej.getRandomValue = function (min, max) {
        if (min === undefined || max === undefined)
            return ej.throwError("Min and Max values are required for generating a random number");

        var rand;
        if ("crypto" in window && "getRandomValues" in crypto) {
            var arr = new Uint16Array(1);
            window.crypto.getRandomValues(arr);
            rand = arr[0] % (max - min) + min;
        }
        else rand = Math.random() * (max - min) + min;
        return rand | 0;
    }

    ej.extensions = {};
    ej.extensions.modelGUID = "{0B1051BA-1CCB-42C2-A3B5-635389B92A50}";
})(window.jQuery, window.Syncfusion);
(function () {
    $.fn.addEleAttrs = function (json) {
        var $this = $(this);
        $.each(json, function (i, attr) {
            if (attr && attr.specified) {
                $this.attr(attr.name, attr.value);
            }
        });

    };
    $.fn.removeEleAttrs = function (regex) {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && regex.test(attr.name)) {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.fn.attrNotStartsWith = function (regex) {
        var proxy = this;
        var attributes = [], attrs;
        this.each(function () {
            attrs = $(this.attributes).clone();
        });
        for (i = 0; i < attrs.length; i++) {
            if (attrs[i] && attrs[i].specified && regex.test(attrs[i].name)) {
                continue
            }
            else
                attributes.push(attrs[i])
        }
        return attributes;

    }
    $.fn.removeEleEmptyAttrs = function () {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && attr.value === "") {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.extend($.support, {
        has3d: ej.addPrefix('perspective') in ej.styles,
        hasTouch: 'ontouchstart' in window,
        hasPointer: navigator.msPointerEnabled,
        hasTransform: ej.userAgent() !== false,
        pushstate: "pushState" in history &&
        "replaceState" in history,
        hasTransition: ej.addPrefix('transition') in ej.styles
    });
    //Ensuring elements having attribute starts with 'ejm-' 
    $.extend($.expr[':'], {
        attrNotStartsWith: function (element, index, match) {
            var i, attrs = element.attributes;
            for (i = 0; i < attrs.length; i++) {
                if (attrs[i].nodeName.indexOf(match[3]) === 0) {
                    return false;
                }
            }
            return true;
        }
    });
    //addBack() is supported from Jquery >1.8 and andSelf() supports later version< 1.8. support for both the method is provided by extending the JQuery function.
    var oldSelf = $.fn.andSelf || $.fn.addBack;
    $.fn.andSelf = $.fn.addBack = function () {
        return oldSelf.apply(this, arguments);
    };
})();;
;
/**
* @fileOverview Plugin to style the tab control.
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, undefined) { 
    ej.widget("ejTab", "ej.Tab", {
        _rootCSS: "e-tab",

        element: null,

        model: null,
        validTags: ["div", "span"],
        _addToPersist: ["selectedItemIndex"],
        _setFirst: false,
        angular: {
            terminal: false
        },

        defaults: {

            collapsible: false,

            enableAnimation: true,

            ajaxSettings: {

                type: 'GET',

                cache: false,

                data: {},

                dataType: "html",

                contentType: "html",

                async: true
            },

            disabledItemIndex: [],

            enabledItemIndex: [],

            hiddenItemIndex: [],

            events: "click",

            idPrefix: "ej-tab-",

            heightAdjustMode: "content",

            selectedItemIndex: 0,

            cssClass: "",

            showCloseButton: false,

            htmlAttributes: {},

            enableTabScroll: false,

            showReloadIcon: false,

            headerPosition: "top",

            width: null,

            height: null,

            headerSize: null,

            enableRTL: false,

            allowKeyboardNavigation: true,

            showRoundedCorner: false,

            enablePersistence: false,

            enabled: true,

            ajaxLoad: null,

            ajaxBeforeLoad: null,

            ajaxSuccess: null,

            ajaxError: null,

            itemActive: null,

            beforeActive: null,

            itemAdd: null,

            itemRemove: null,

            beforeItemRemove: null,

            create: null,

            destroy: null

        },
        dataTypes: {
            cssClass: "string",
            collapsible: "boolean",
            events: "string",
            heightAdjustMode: "enum",
            enabled: "boolean",
            ajaxSettings: "data",
            disabledItemIndex: "data",
            enabledItemIndex: "data",
            enableAnimation: "boolean",
            htmlAttributes: "data"
        },
        observables: ["selectedItemIndex"],
        selectedItemIndex: ej.util.valueFunction("selectedItemIndex"),


        _destroy: function () {
            this._unWireEvents();
            this._removeBaseClass();
        },

        _setModel: function (options) {
            for (var key in options) {
                switch (key) {
                    case "events": {
                        this._off(this.items, this.model.events);
                        this._on(this.items, options[key], this._tabItemClick);
                        break;
                    }
                    case "disabledItemIndex": {
                        this._disableItems(options[key]);
                        options[key] = this.model.disabledItemIndex;
                        break;
                    }
                    case "enabledItemIndex": this._enableItems(options[key]); break;
                    case "enabled": this._enabledAction(options[key]); break;
                    case "selectedItemIndex": {
                        this._isInteraction = false;
                        this.showItem(ej.util.getVal(options[key]));
                        options[key] = this.model.selectedItemIndex;
                        break;
                    }
                    case "heightAdjustMode": {
                        this.model.heightAdjustMode = options[key];
                        this._setTabsHeightStyle(options[key]);
                        this._resizeEvents(options[key]);
                        break;
                    }
                    case "cssClass": this._changeSkin(options[key]); break;
                    case "showRoundedCorner": this._roundedCorner(options[key]); break;
                    case "height": {
                        this.model.height = options[key];
                        this._setTabsHeightStyle(this.model.heightAdjustMode);
                        break;
                    }
                    case "width": this.element.width(options[key]);
                        $(this.contentPanels).width(Number(options[key]));
                        this.refreshTabScroll();
                        break;
                    case "headerSize": this._setHeaderSize(options[key]); break;
                    case "allowKeyboardNavigation": {
                        if (options[key])
                            this._on(this.element, 'keydown', this._keyPress);
                        else
                            this._off(this.element, "keydown");
                        break;
                    }
                    case "headerPosition":
                        {
                            this.model.headerPosition = options[key];
                            if (this.model.headerPosition == ej.Tab.Position.Top) {
                                this._removeVerticalClass();
                                this._removeScroll();
                                this.itemsContainer.remove();
                                this.itemsContainer.insertBefore(this.element.find(">div").first());
                                this.element.find("div.e-active-content").removeClass("e-activebottom");
                                $(this.contentPanels).css("margin-top", "0")
                            }
                            else if (this.model.headerPosition == ej.Tab.Position.Bottom) {
                                this._removeVerticalClass();
                                this._removeScroll();
                                this.element.find("div.e-active-content").removeClass("e-activetop");
                                this.model.enableTabScroll ? $(this.contentPanels).css("margin-top", "0") : $(this.contentPanels).css("position", "relative")
                            }
                            else if (this.model.headerPosition == ej.Tab.Position.Left || this.model.headerPosition == ej.Tab.Position.Right) {
                                this._removeHeaderClass();
                                $(this.items).css('display', '');
                                this._removeScroll();

                            }
                            this._refresh();
                            if (this.model.headerPosition == ej.Tab.Position.Right)
                                this.element.css("position", "")
                            if (this.model.headerPosition == ej.Tab.Position.Left || this.model.headerPosition == ej.Tab.Position.Right) {
                                this._on(this.element.find("div.e-chevron-circle-right"), "click", this._tabScrollClick);
                                
                            }

                            this.scrollstep = 30
                            break;
                        }
                    case "showCloseButton":
                        {
                            if (options[key]) {
                                this._addDeleteIcon();
                                this._on(this.element.find("div.e-close"), "click", this._tabDeleteClick);
                            } else
                                this.element.find("div.e-close").remove();
                            break;
                        }
                    case "enableTabScroll":
                        {
                            this.model.enableTabScroll = options[key];
                            if (options[key]) {
                                this._removeScroll();
                                this._addScroll();
                                if (this.model.headerPosition == "left") {
                                    this._refresh();
                                    this._on(this.element.find("div.e-chevron-circle-right"), "click", this._tabScrollClick);
                                }
                            } else {
                                this._removeScroll();
                                this.itemsContainer.removeAttr("style");
                                $(this.contentPanels).css("margin-top", "0")
                            }
                            if (this.model.headerPosition == ej.Tab.Position.Left || this.model.headerPosition == ej.Tab.Position.Right) {
                                this._refresh();
                                this._on(this.element.find("div.e-chevron-circle-right"), "click", this._tabScrollClick);
                                if (this.model.headerPosition == ej.Tab.Position.Right && !this.model.enableTabScroll)
                                    this.element.css("margin-left", "")
                            }
                            break;
                        }
                    case "showReloadIcon":
                        {
                            if (options[key]) {
                                this._addReloadIcon();
                            } else
                                this.element.find("div.e-reload").remove();
                            break;
                        }
                    case "enableRTL":
                        {
                            this.model.enableRTL = options[key];
                            this._removeScroll();
                            this.itemsContainer.removeAttr("style");
                            $(this.contentPanels).css("margin-top", "0")
                            this.element.find("ul").removeAttr("style")
                            options[key] ? this.element.addClass("e-rtl") : this.element.removeClass("e-rtl");
                            if (this.model.enableTabScroll)
                                this._addScroll();
                            this._refresh();
                            this._on(this.element.find("div.e-chevron-circle-right"), "click", this._tabScrollClick);
                            if (this.model.headerPosition == ej.Tab.Position.Right && this.model.enableRTL)
                                this.element.css("margin-left", '')

                            break;
                        }
                    case "htmlAttributes": this._addAttr(options[key]); break;
                    case "hiddenItemIndex": {
                        if (this.model.headerPosition == ej.Tab.Position.Top || this.model.headerPosition == ej.Tab.Position.Bottom)
                            $(this.items).css('display', 'inline-block');
                        else $(this.items).css('display', '');
                        this.model.hiddenItemIndex = options[key];
                        this.model.hiddenItemIndex.length > 0 && this._hiddenIndexItem(this.model.hiddenItemIndex);
                        break;
                    }
                }
            }
        },

        _removeScroll: function () {
            this.element.find("div.e-chevron-circle-right").remove();
            this.element.find("div.e-chevron-circle-left").remove();
        },

        _addScroll: function () {
            if ((this.model.headerPosition == "left" || this.model.headerPosition == "right" && this._tabContentsHeight() > (this.element.width() || Number(this.model.height))) || (this.model.headerPosition == "top" || this.model.headerPosition == "bottom"))
                this._checkScroll();
            this._addScrollIcon();
            this.refreshTabScroll();
        },

        _init: function () {
            this._addItemIndex = null;
            this.tabId = 0;
            this._hiddenIndex = this.model.hiddenItemIndex;
            this._initialize();
            this._prevSize = this._getDimension($(this.element).parent(), "height");
        },


        _changeSkin: function (skin) {
            if (this.model.cssClass != skin) {
                this.element.removeClass(this.model.cssClass).addClass(skin);
            }
        },

        _tabContentsWidth: function () {
            var length = this.itemsContainer.find('li').length;
            var tabLength = 0;
            for (var i = 0; i < length; i++) {
                tabLength = tabLength + $(this.itemsContainer.find('li')[i]).width();
            }
            return tabLength
        },

        _tabContentsHeight: function () {
            var length = this.itemsContainer.find('li').length;
            var tabHeight = 0;
            for (var i = 0; i < length; i++) {
                tabHeight = tabHeight + $(this.itemsContainer.find('li')[i]).height();
            }
            return tabHeight
        },

        _initialize: function () {
            this.initialRender = true;
            this.element.attr("tabindex", 0).attr("role", "tablist");
            this._itemsRefreshing();
            $(this.anchors).addClass("e-link");
            this._preTabSelectedIndex = this._preTabIndex = -1;
            if (!ej.isNullOrUndefined(this.model.width))
                this.element.width(this.model.width);
            if (!ej.isNullOrUndefined(this.model.height))
                this.element.height(this.model.height);
            this._setTabPosition(this.model.headerPosition);
            if (this.model.showCloseButton)
                this._addDeleteIcon();
            if (this.model.showReloadIcon)
                this._addReloadIcon();
            if (this.model.showRoundedCorner)
                this._roundedCorner(this.model.showRoundedCorner);
            this._enabledAction(this.model.enabled);
            this.contentPanels = [];
            this._addAttr(this.model.htmlAttributes);
            this._reinitialize();
            this._addBaseClass();
            if (!ej.isNullOrUndefined(this.model.headerSize))
                this._setHeaderSize(this.model.headerSize);
            this._disableTabs();
            this._roundedCorner(this.model.showRoundedCorner);
            if (this.model.enableTabScroll) {
                if (this.model.headerPosition == "top" || this.model.headerPosition == "bottom") {
                    if (this.itemsContainer.width() > (this.element.width()))
                        this._addScrollIcon();
                }
                else {
                    if (this.element.height() < (this.items.height() * this.items.length))
                        this._addScrollIcon();
                }
            }
            this._wireEvents(this.model.events);
            // Added for rendering the Windows tab...
            this.showItem(this.selectedItemIndex());
            this._setTabsHeightStyle(this.model.heightAdjustMode);
            this._enabledAction(this.model.enabled);
            this._resizeEvents(this.model.heightAdjustMode);
			if(this.selectedItemIndex() > -1 && this.contentPanels != 0 && this.model.enableRTL)		
				$(this.element).height(this.itemsContainer.height()+parseInt($(this.contentPanels).css("height")));        
            this.model.hiddenItemIndex.length > 0 && this._hiddenIndexItem(this.model.hiddenItemIndex);
        },

        _reinitialize: function ( addContentBaseClass ) {
            var hid, href, hrefBase;
            for (var i = (this._addItemIndex != null) ? this._addItemIndex : 0; i < this.anchors.length; i++) {
                hid = this.anchors[i];
                if (this.divId == undefined)
                    href = $(hid).attr("href");
                else
                    href = this.divId;
                this.divId = undefined;
                hrefBase = href.split("#")[0];
                if (hrefBase && (hrefBase === location.toString().split("#")[0])) {
                    href = a.hash;
                    hid.href = href;
                }
                if (href && href !== "#") {
                    this._addContentTag(href, i);
                    if(addContentBaseClass) this._addContentBaseClass($(this.contentPanels[i]));
                }
                else if (!this.model.enablePersistence) {
                    this.model.disabledItemIndex.push(i);
                }
                if (this._addItemIndex != null) {
                    this._unWireEvents();
                    this._wireEvents(this.model.events);
				if (this.items.length == 1) {
					this.showItem(this.selectedItemIndex());
				}
                    break;
                }
            }

        },
        _itemsRefreshing: function () {
            this.itemsContainer = this.element.find("ol,ul").eq(0);
            this.items = this.itemsContainer.find(" > li:has(a[href])");
            this.anchors = this.items.find('a[href]');
        },
        _setHeaderSize: function (size) {
            this.element.find(">ul li.e-item").css("height", "auto");
            this.element.find(">ul li.e-item").children("a.e-link").css("margin-top", "0px");
            if (this.model.headerPosition == "left") {
                this.element.find(">ul.e-left").css({ "width": size, "text-align": "center" });
            }
            else if (this.model.headerPosition == "right") {
                this.element.find(">ul.e-right").css({ "width": size, "text-align": "center" });
            }
            else {
                this.element.find(">ul.e-header li.e-item").css("height", size);
                this.element.find(">ul.e-header li.e-item a.e-link").css("margin-top", ((this.element.find(">ul.e-header").outerHeight() / 2) - this.element.find(">.e-header li.e-item a.e-link").outerHeight()).toString() + "px");
				this.element.find(">ul.e-header li.e-item .e-icon.e-tabdelete").css("margin-top", (((this.element.find(">ul.e-header").outerHeight() / 2) - this.element.find(">.e-header li.e-item .e-icon.e-tabdelete").outerHeight())-5).toString() + "px");
				this.element.find(">ul.e-header li.e-item .e-icon.e-reload").css("margin-top", (((this.element.find(">ul.e-header").outerHeight() / 2) - this.element.find(">.e-header li.e-item .e-icon.e-reload").outerHeight())-5).toString() + "px");
            }
        },
        _enabledAction: function (flag) {
            if (flag) {
                this.element.removeClass("e-disable");
            }
            else {
                this.element.addClass("e-disable");
            }
        },
        _hiddenIndexItem: function (value) {
            var elementId;
            for (var i = 0; i < value.length; i++) {
                if (!$.inArray(parseInt(value[i]), this._hiddenIndex) > -1) {
                    elementId = $(this.items[parseInt(value[i])]).children('a').attr('href');
                    this._hidePanel(elementId);
                }
            }
            this._hideContentPanel(this.selectedItemIndex(), this.model.hiddenItemIndex);
            this._hiddenIndex = this.model.hiddenItemIndex;
        },
        _hidePanel: function (value) {
            for (var j = 0; j < this.contentPanels.length; j++) {
                if ("#" + $(this.contentPanels[j]).attr('id') == value) {
                    $(this.contentPanels[j]).css('display', 'none');
                    break;
                }
            }
            for (var i = 0; i < this.items.length; i++) {
                if ($(this.items.children('a')[i]).attr('href') == value) {
                    $(this.items[i]).css('display', 'none');
                    break;
                }
            }
        },
        _hideContentPanel: function (index, value) {
            if ($.inArray(index, value) > -1) {
                index += 1;
                if (index <= this.items.length - 1) {
                    this._hideContentPanel(index, value);
                }
                else if (index > this.items.length - 1 && value.length != this.items.length) {
                    this._hideContentPanel(0, value);
                }
            }
            else this.showItem(index);
        },
        _addAttr: function (htmlAttr) {
            var proxy = this;
            $.map(htmlAttr, function (value, key) {
                if (key == "class") proxy.element.addClass(value);
                else if (key == "disabled" && value == "disabled") { proxy.model.enabled = false; proxy._enabledAction(false); }
                else proxy.element.attr(key, value)
            });
        },


        _setTabPosition: function (position) {
            if (position == ej.Tab.Position.Bottom) {
                this.itemsContainer.appendTo(this.element);
                this.items.removeClass("e-bottom-line");
                this.items.addClass("e-top-line");
            }
            else if (position == ej.Tab.Position.Top) {
                this.items.removeClass("e-top-line");
				this.itemsContainer.prependTo(this.element);
                if (this.model.enableRTL)
                    this.items.addClass("e-rtl-top-line e-top-hover");
                else
                    this.items.addClass("e-bottom-line");
            }
            else if (position == ej.Tab.Position.Left || position == ej.Tab.Position.Right) {
                if (this.items.length >= 0) {
                    if (this.model.height)
                        this.itemsContainer.css("height", this.model.height);
                    else {
                        if (!this.model.heightAdjustMode === "fill") $(this.itemsContainer).css("height", "");
                    }
                    this.element.addClass("e-vertical");
                }
            }
        },


        _addDeleteIcon: function () {
            if (this.element.find("div.e-close.e-tabdelete").length <= 0 && this.items.length > 0) {
                var deleteIcon = ej.buildTag('div.e-icon e-close e-tabdelete', "", {}, { role: "presentation" }).css("visibility", "hidden");
                if (this.model.headerPosition == "left" || this.model.headerPosition == "right") {
                    var delIconPosition = this.items.find("a");
                    deleteIcon.insertBefore(delIconPosition);
                }
                else
                    this.items.append(deleteIcon);
            }
        },
        _tabScrollIconCalc: function(){
            this.padding = {
                left : Number(this.element.css("padding-left").split("px")[0]),
                right : Number(this.element.css("padding-right").split("px")[0]),
                top : Number(this.element.css("padding-top").split("px")[0]),
                bottom : Number(this.element.css("padding-bottom").split("px")[0]),
            }; 
            this.scrollPosition = (this.itemsContainer.width() / 2) - this._rightScrollIcon.width();
            this.rightScroll = ej.getDimension(this.element, "width")- (this.itemsContainer.outerWidth()/2);
        },
        _addScrollIcon: function () { 
            this.element.addClass("e-tabscroll").css({"position":"relative", "overflow":"hidden"});
            if (this.element.find("div.e-chevron-circle-right").length <= 0 && this.items.length > 0) {
                this._rightScrollIcon = ej.buildTag('div.e-icon e-chevron-circle-right', "", {}, { role: "presentation" }).css("visibility", "hidden");
                this.itemsContainer.after(this._rightScrollIcon);
                this.scrollstep = 30;
                this._tabScrollIconCalc();
                this._rightScrollIcon.css("position", "absolute");
                if (!this.model.enableRTL) {
                    if (this.model.headerPosition == "left"){
                        this._rightScrollIcon.css("top", this.padding.top + 20 + "px");
                        this._rightScrollIcon.css("left", (this.scrollPosition + this.padding.left) + "px");
                    }
                    else if (this.model.headerPosition == "right"){
                        this._rightScrollIcon.css({"margin-left": this.itemsContainer.width() / 2 - this.scrollstep + "px", "z-index": "15", "top": this.padding.top + 20 + "px", "left": this.rightScroll + "px" });
                        this.element.css({"position": "relative"});
                    }
                    else {
                        if (this.model.enablePersistence == true && this._beforeWidth != 0 && (this._beforeWidth > this.scrollPanelWidth))
                            this._rightScrollIcon.css("margin-right", this.itemsContainer.width() - this.scrollPanelWidth + 20 - ((this.items[this.selectedItemIndex()].offsetLeft - this.scrollPanelWidth) * 2) + "px");
                        else
                            this._rightScrollIcon.css("left", (this.scrollPanelWidth-(this.scrollstep + 20) + this.padding.left) + "px");
                    }
                }
                if (this.model.headerPosition == "left" || this.model.headerPosition == "right") {
                    this._rightScrollIcon.css("transform", "rotate(270deg)");
                    if (ej.browserInfo().name == "msie" && parseInt(ej.browserInfo().version) < 11) {
                            if (!this.model.enableRTL)
                                this._rightScrollIcon.css("top", this.padding.top + 20 + "px");
                            else
                                this._rightScrollIcon.css("top", this.padding.top + 20 + "px");
                    }
                    else {
                        if (this.model.enablePersistence == true && this._beforeWidth != 0 && (this._beforeWidth > this.scrollPanelHeight))
                            this._rightScrollIcon.css("margin-top", "-" + ((this.items[this.selectedItemIndex()].offsetTop * 3 - this.scrollPanelHeight * 2)) + "px");
                        else
                            if (this.model.enableRTL)
                                if(this.model.headerPosition == "left")
                                this._rightScrollIcon.css({"left": "0px", "margin-left": (this.scrollPosition + this.padding.left) + "px", "z-index":"15"});
                                else
                                this._rightScrollIcon.css({"right": (this.itemsContainer.outerWidth()/2) + this.padding.right + "px","z-index":"15"});
                                    

                    }
                }

                else {
                    if (this.model.enableRTL) { 
                        this._rightScrollIcon.css("margin-left", (this.itemsContainer.width() - 14) + "px");
                    } 
                }
                if (ej.browserInfo().name == "msie" && parseInt(ej.browserInfo().version) < 11) {
                     if (this.model.headerPosition == "bottom") {
                        if (!this.model.enableRTL)
                            this._rightScrollIcon.css("top", ((this.itemsContainer.height() / 2) + 27) + "px");
                        else
                            this._rightScrollIcon.css("top", ((this.itemsContainer.height() / 2) + 20) + "px");
                    }
                }
                
                this.element.attr('unselectable', 'on')
                this.element.css('user-select', 'none')
                this.element.on('selectstart', false);
                this._on(this.element.find("div.e-chevron-circle-right"), "click", this._tabScrollClick);
                this._on(this.element.find("div.e-chevron-circle-right"), "mouseover", this._hoverHandler);
                this._on(this.element.find("div.e-chevron-circle-right"), "mouseout", this._hoverHandler);
            }
        },
        _addScrollBackIcon: function () {
            if (this.element.find("div.e-chevron-circle-left").length <= 0) {
                this._leftScrollIcon = ej.buildTag('div.e-icon e-chevron-circle-left', "", {}, { role: "presentation" }).css("visibility", "hidden");
                this.itemsContainer.before(this._leftScrollIcon);
                this.rightscrollstep = 30;
                this.element.attr('unselectable', 'on')
                this.element.css('user-select', 'none')
                this.element.on('selectstart', false);
                this._leftScrollIcon.css("position", "absolute").css("z-index", "10");
                if (this.model.headerPosition == "top" || this.model.headerPosition == "bottom") {
                    if (this.model.enableRTL){ 
                        this._leftScrollIcon.css("left", (this.padding.left + this.rightscrollstep) + "px");
                    }
                }
                if (this.model.headerPosition == "left" || this.model.headerPosition == "right") {
                    if (!this.model.enableRTL) {
                        if (this.model.headerPosition == "right"){
                            this._leftScrollIcon.css({"margin-left": ((this.itemsContainer.width() / 2) - 30) + "px", "z-index": "15", "left": this.rightScroll + "px"});
                            this._leftScrollIcon.css("top", this.scrollPanelHeight + 30 + "px");
                        }
                        else if (this.model.headerPosition == "left"){
                            this._leftScrollIcon.css("left", (this.scrollPosition + this.padding.left) + "px");
                            this._leftScrollIcon.css("top", (this.scrollPanelHeight- 20) + this.padding.top + "px");
                        }
                    }
                    else {
                        this._leftScrollIcon.css("top", this.scrollPanelHeight + "px");
                        if (this.model.headerPosition == "right")
                            
                            this._leftScrollIcon.css({"right": (this.itemsContainer.outerWidth()/2) + this.padding.right + "px", "margin-left": (this.scrollPosition + this.padding.left) + "px", "z-index": "15"});
                        else
                            this._leftScrollIcon.css({"left":"0px", "margin-left": (this.scrollPosition + this.padding.left) + "px"});
                    }
                    this._leftScrollIcon.css("transform", "rotate(270deg)");
                }
                if (ej.browserInfo().name == "msie" && parseInt(ej.browserInfo().version) < 11)
                    if (this.model.headerPosition == "bottom") {
                    this._leftScrollIcon.css("top", ((this.itemsContainer.height() / 2) + 27) + "px");     
                    }
                this._on(this._leftScrollIcon, "click", this._tabScrollBackClick);
                this._on(this.element.find("div.e-chevron-circle-left"), "mouseout", this._hoverHandler);
                this._on(this.element.find("div.e-chevron-circle-left"), "mouseover", this._hoverHandler);
            }
        },


        _addReloadIcon: function () {
            if (this.element.find("div.e-reload").length <= 0 && this.items.length > 0) {
                var reloadIcon = ej.buildTag('div.e-icon e-reload', "", {}, { role: "presentation" }).css("visibility", "hidden");
                if (this.model.headerPosition == "left" || this.model.headerPosition == "right") {
                    var iconPosition = this.items.find("a");
                    reloadIcon.insertBefore(iconPosition);
                }
                else
                    this.items.append(reloadIcon);
            }
        },


        _addBaseClass: function () {
            this.element.addClass("e-widget " + this.model.cssClass);
            this.itemsContainer.addClass("e-box")
            if (this.model.enableRTL)
                this.element.addClass("e-rtl");
            // To avoid border blinking 
            if (this.model.headerPosition == "top") {
                $(this.contentPanels).addClass("e-hidebottom e-addborderbottom");
                $(this.itemsContainer).addClass("e-addborderbottom");
                $(this.contentPanels).removeClass("e-hidetop e-addbordertop e-hideright e-addborderright e-hideleft e-addborderleft");
                $(this.itemsContainer).removeClass("e-addbordertop e-addborderright e-addborderleft");
                this.items.length > 0 && this.itemsContainer.addClass("e-header");
                if (this.model.enableRTL) {
                    this.items.addClass("e-rtl-top-line");
                    this.items.removeClass("e-rtl-bottom-line");
                }
            }
            if (this.model.headerPosition == "bottom") {
                $(this.contentPanels).removeClass("e-hidebottom e-addborderbottom e-hideright e-addborderright e-hideleft e-addborderleft");
                $(this.itemsContainer).removeClass("e-addborderbottom e-addborderright e-addborderleft");
                $(this.contentPanels).addClass("e-hidetop e-addbordertop");
                $(this.itemsContainer).addClass("e-addbordertop");
                this.items.length > 0 && this.itemsContainer.addClass("e-header");
                if (this.model.enableRTL) {
                    this.items.addClass("e-rtl-bottom-line")
                    this.items.removeClass("e-rtl-top-line e-top-line");
                }
            }
            if (this.model.headerPosition == "left") {
                this.items.length > 0 && this.itemsContainer.addClass("e-left");
                $(this.contentPanels).removeClass("e-hidetop e-addbordertop e-hidebottom e-addborderbottom e-hideright e-addborderright");
                $(this.itemsContainer).removeClass("e-addbordertop e-addborderbottom e-addborderright");
                $(this.contentPanels).addClass("e-hideleft e-addborderleft");
                $(this.itemsContainer).addClass("e-addborderleft");
                $(this.items).removeClass("e-rtl-bottom-line e-rtl-top-line");
            }
            if (this.model.headerPosition == "right") {
                this.items.length > 0 && this.itemsContainer.addClass("e-right");
                $(this.contentPanels).removeClass("e-hidetop e-addbordertop e-hidebottom e-addborderbottom e-hideleft e-addborderleft");
                $(this.itemsContainer).removeClass("e-addbordertop e-addborderbottom e-addborderleft");
                $(this.contentPanels).addClass("e-hideright e-addborderright");
                $(this.itemsContainer).addClass("e-addborderright");
                if (this.model.enableTabScroll && this._tabContentsHeight() > (this.element.height || Number(this.model.height)))
                    $(this.itemsContainer).css("z-index", "12").css("margin-left", "-" + this.itemsContainer.find("li").width() + "px");
                $(this.items).removeClass("e-rtl-bottom-line e-rtl-top-line");
            }
            this.items.addClass("e-select e-item").attr("role", "tab").attr("tabindex", -1).attr("aria-expanded", true).attr("aria-selected", false);
            $(this.contentPanels).addClass("e-content  e-content-item e-box").attr("role", "tabpanel").attr("aria-hidden", true);
            if (((this.model.headerPosition == "left" || this.model.headerPosition == "right") && (this._tabContentsHeight() > (this.element.height() || Number(this.model.height)))) || ((this.model.headerPosition == "top" || this.model.headerPosition == "bottom") && this._tabContentsWidth() > ((ej.getDimension(this.element, "width")) || this.model.width)))
                this._checkScroll();
        },
        _addContentBaseClass: function (panelElement) {
            if (this.model.headerPosition == "top") {
                panelElement.addClass("e-hidebottom e-addborderbottom");
                panelElement.removeClass("e-hidetop e-addbordertop e-hideright e-addborderright e-hideleft e-addborderleft");
            }
            if (this.model.headerPosition == "bottom") {
                panelElement.removeClass("e-hidebottom e-addborderbottom e-hideright e-addborderright e-hideleft e-addborderleft");
                panelElement.addClass("e-hidetop e-addbordertop");
            }
            if (this.model.headerPosition == "left") {
                panelElement.removeClass("e-hidetop e-addbordertop e-hidebottom e-addborderbottom e-hideright e-addborderright");
                panelElement.addClass("e-hideleft e-addborderleft");
            }
            if (this.model.headerPosition == "right") {
                panelElement.removeClass("e-hidetop e-addbordertop e-hidebottom e-addborderbottom e-hideleft e-addborderleft");
                panelElement.addClass("e-hideright e-addborderright");
            }
            panelElement.addClass("e-content  e-content-item e-box").attr("role", "tabpanel").attr("aria-hidden", true);
        },

        _checkScroll: function () {
            this.scrollPanelWidth = ej.getDimension(this.element, "width");
            this.scrollPanelHeight = ej.getDimension(this.element, "height");
            if (this.model.enableTabScroll == true && this._tabContentsHeight() > this.items.height()) {
                this.scrollstep = 0;
                this.model.enableTabScroll = true;
                if (this.model.headerPosition == "top" || this.model.headerPosition == "bottom") {
                    this.itemsContainer.css({ "width": ((ej.getDimension(this.element, "width") + (parseInt(this.items.css("width")) * this.items.length))) + "px", "position": "absolute" });
                }
                this._beforeWidth = 0;
                if (this.model.enablePersistence == true) {
                    if (this.model.headerPosition == "top" || this.model.headerPosition == "bottom") {
                        for (var val = 0; val < this.selectedItemIndex() ; val++) {
                            this._beforeWidth += this.items[val].offsetWidth;
                        }
                    }
                    else {
                        for (var val = 0; val < this.selectedItemIndex() ; val++) {
                            this._beforeWidth += this.items[val].offsetHeight;
                        }
                    }
                }
                var widthValue = parseInt(this.itemsContainer.css("width"));
                if (this.model.headerPosition == "top") {
                    var item = $(this.contentPanels);
                    item.css("padding-top", this.itemsContainer.outerHeight() + (item.hasClass("e-activetop") ? 0 : (this.model.enableRTL ? 4 : 3)) + "px");
                    $(this.contentPanels).css({"border-top": "none", "width": ej.getDimension(this.element, "width") - 1 + "px" });
                    this.itemsContainer.css("border-bottom", "1px solid #bbbcbb");
                }
                if (this.model.headerPosition == "bottom") {
                    $(this.contentPanels).css({ "position": "relative", "width": ej.getDimension(this.element, "width") - 1 + "px", "border-bottom": "none" });
                    this.itemsContainer.css("border-top", "1px solid #bbbcbb");
                    $(this.contentPanels).css({ "border-top": "" });
                }

                var rigtVaule = parseInt(widthValue - (this.scrollPanelWidth + this.scrollstep - 1));
                if (this.model.enableRTL && (this.model.headerPosition == "top" || this.model.headerPosition == "bottom")) {
                    this.itemsContainer.css("clip", "rect(0px," + widthValue + "px,100px," + rigtVaule + "px)");
                }
                else if (this.model.headerPosition == "left") {
                    if (this._tabContentsHeight() > Number(this.model.height.split("px")[0])) {
                        this.itemsContainer.css({ "height": ((parseInt(this.itemsContainer.css("height")) + (parseInt(this.items.css("height")) * this.items.length)) + 30) + "px", "position": "absolute", "border-right": "1px solid #bbbcbb", "background": "white" });
                        $(this.contentPanels).css("padding-left", this.itemsContainer.width() + 5 + "px");
                        if (this.model.enableRTL)
                            this.itemsContainer.css("margin-right", (ej.getDimension(this.element, "width") - this.itemsContainer.width()));
                        if (this._beforeWidth == 0 || this._beforeWidth < this.scrollPanelHeight)
                            this.itemsContainer.css("clip", "rect(0px," + (this.itemsContainer.width() + 4) + "px," + this.scrollPanelHeight + "px," + (this.scrollstep) + "px)");
                        else {
                            if (this._beforeWidth > this.scrollPanelHeight) {
                                this.itemsContainer.css({
                                    "clip": "rect(" + ((this.items[this.selectedItemIndex()].offsetTop - this.scrollPanelHeight) * 2) + "px," + (this.itemsContainer.width() + 2) + "px," + (this.items[this.selectedItemIndex()].offsetTop * 2 - this.scrollPanelHeight) + "px,0px)",
                                    "margin-top": "-" + ((this.items[this.selectedItemIndex()].offsetTop - this.scrollPanelHeight) * 2) + "px"
                                });
                            }
                        }

                        this.element.removeClass("e-scrolltab");
                    }
                }
                else if (this.model.headerPosition == "right") {
                    if (this._tabContentsHeight() > Number(this.model.height.split("px")[0])) {
                        this.itemsContainer.css({ "height": ((parseInt(this.itemsContainer.css("height")) + (parseInt(this.items.css("height")) * this.items.length)) + 30) + "px", "position": "absolute", "margin-left": "-1px", "right": 0 + Number(this.element.css("padding-left").split("px")[0]) + "px" }).css("z-index", "12")
                        $(this.contentPanels).css({ "position": "absolute", "width": ej.getDimension(this.element, "width")-this.itemsContainer.outerWidth() + "px", "height": ej.getDimension(this.element, "height") + "px", "border-right": "none" });
                        this.itemsContainer.css("border-left", "1px solid #bbbcbb");
                        if (this.model.enableRTL)
                            this.itemsContainer.css("margin-right", "-" + (this.itemsContainer.width() + 1) + "px");
                        if (this._beforeWidth == 0 || this._beforeWidth < this.scrollPanelHeight)
                            this.itemsContainer.css("clip", "rect(0px," + this.itemsContainer.width() + 2 + "px," + this.scrollPanelHeight + "px," + (this.scrollstep) + "px)");
                        else {
                            if (this._beforeWidth > this.scrollPanelHeight) {
                                this.itemsContainer.css({
                                    "clip": "rect(" + ((this.items[this.selectedItemIndex()].offsetTop - this.scrollPanelHeight) * 2) + "px," + (this.itemsContainer.width() + 2) + "px," + (this.items[this.selectedItemIndex()].offsetTop * 2 - this.scrollPanelHeight) + "px,0px)",
                                    "margin-top": "-" + ((this.items[this.selectedItemIndex()].offsetTop - this.scrollPanelHeight) * 2) + "px"
                                });
                            }
                        }
                        this.element.removeClass("e-scrolltab");
                    }
                    if(this.model.enableRTL){
                        this.itemsContainer.css({ "height": ((parseInt(this.itemsContainer.css("height")) + (parseInt(this.items.css("height")) * this.items.length)) + 30) + "px", "position": "absolute", "margin-left": "-1px", "right": this.itemsContainer.width() + Number(this.element.css("padding-right").split("px")[0]) + "px" }).css("z-index", "12")
                        $(this.contentPanels).css({ "position": "absolute", "width": ej.getDimension(this.element, "width")-this.itemsContainer.outerWidth() + "px", "left": this.element.css("padding-left"), "height": ej.getDimension(this.element, "height") + "px", "border-right": "none", "left": 0 + Number(this.element.css("padding-right").split("px")[0]) + "px"});
                    }
                }
                else {
                    if (this._beforeWidth == 0 || this._beforeWidth < this.scrollPanelWidth) {
                        this.itemsContainer.css({ "clip": "rect(0px," + (this.scrollPanelWidth + this.scrollstep) + "px,100px," + (this.scrollstep) + "px)", "margin-left": "-" + this.scrollstep + "px" });
                    }
                    else {
                        if (this._beforeWidth > this.scrollPanelWidth) {
                            this.itemsContainer.css({ "clip": "rect(0px," + (this.items[this.selectedItemIndex()].offsetLeft * 2 - this.scrollPanelWidth) + "px,100px," + ((this.items[this.selectedItemIndex()].offsetLeft - this.scrollPanelWidth) * 2) + "px)", "margin-left": "-" + ((this.items[this.selectedItemIndex()].offsetLeft - this.scrollPanelWidth) * 2) + "px" });
                        }
                    }
                }
                this.element.find(".e-icon.e-chevron-circle-left").length && this.element.find(".e-icon.e-chevron-circle-left").css("display", "none");
                this._initialClip = this.itemsContainer.css("clip");
            }
        },
        _executeForwardScrolling: function (args , scrollStep) {
			var tabScrollStep= (scrollStep) ? scrollStep :(args.type=='swiperight'||args.type=='swipeleft')? 50: 30;
            if (this.model.headerPosition == "top" || this.model.headerPosition == "bottom") {
                if (!this.model.enableRTL) {
                    var ClipValue1 = Number(this.itemsContainer.css("clip").split("px")[1].replace(",", ""));
                    var ClipValue2 = Number(this.itemsContainer.css("clip").split("px")[3].replace(",", ""));
                    var scrollValue = Number(this._rightScrollIcon.css("margin-right").split("px")[0]);
                    this.itemsContainer.css({ "clip": "rect(0px," + (ClipValue1 + tabScrollStep) + "px,100px," + (ClipValue2 + tabScrollStep) + "px)", "margin-left": "-" + (ClipValue2 + tabScrollStep) + "px" });
					if(args.type=='swipeleft' && Math.abs(Number((this.itemsContainer.css('margin-left')).split("px")[0])) >= (this._tabContentsWidth() - ej.getDimension(this.element, "width")))
					   this._off(this.items, "swipeleft", this._tabSwipe);
					if ((this._leftScrollIcon && this._leftScrollIcon.css("margin-left")) && (Number(this.itemsContainer.css("margin-left").split("px")[0].replace("-", "")) >= (this._tabContentsWidth() - ej.getDimension(this.element, "width")))) {
                        this._rightScrollIcon.css("display", "none"); 
						this._off(this.items, "swipeleft", this._tabSwipe);
                    }

                }
                else {
                    var ClipValue1 = Number(this.itemsContainer.css("clip").split("px")[1].replace(",", ""));
                    var ClipValue2 = Number(this.itemsContainer.css("clip").split("px")[3].replace(",", ""));
                    var itemsMargin = this.itemsContainer.css("margin-right") ? Number(this.itemsContainer.css("margin-right").split("px")[0].replace(",", "")) : 0;
                    var scrollValue = Number(this._rightScrollIcon.css("margin-left").split("px")[0]);
                    var RightScroll = this._leftScrollIcon && this._leftScrollIcon.css("margin-right") ? Number(this._leftScrollIcon.css("margin-right").split("px")[0]) : "";
                    this.itemsContainer.css({ "clip": "rect(0px," + (ClipValue1 - tabScrollStep) + "px,100px," + (ClipValue2 - tabScrollStep) + "px)", "margin-right": "-" + (-itemsMargin + tabScrollStep) + "px" });
                    this._rightScrollIcon.css("margin-left", (scrollValue - tabScrollStep) + "px");
                    this._leftScrollIcon ? this._leftScrollIcon.css("margin-right", (RightScroll + tabScrollStep) + "px") : "";
					 if(args.type=='swipeleft' && Math.abs(Number((this.itemsContainer.css('margin-right')).split("px")[0])) >= (this._tabContentsWidth() - ej.getDimension(this.element, "width")))
					   this._off(this.items, "swipeleft", this._tabSwipe);
                    if (this._leftScrollIcon && this._leftScrollIcon.css("margin-right") && (Number(this.itemsContainer.css("margin-right").split("px")[0].replace("-", ""))) >= (this._tabContentsWidth() - ej.getDimension(this.element, "width")))
                        this._rightScrollIcon.css("display", "none")

                }

            }
            else if (this.model.headerPosition == "left" || this.model.headerPosition == "right") {
                var ClipValue1 = Number(this.itemsContainer.css("clip").split("px")[0].replace(",", "").split("(")[1]);
                var ClipValue2 = Number(this.itemsContainer.css("clip").split("px")[2].replace(",", ""));
                var scrollValue = Number(this._rightScrollIcon.css("margin-top").split("px")[0].replace(",", ""));
                var RightTop = this._leftScrollIcon && this._leftScrollIcon.css("margin-top") ? Number(this._leftScrollIcon.css("margin-top").split("px")[0]) : 0;
                var MarginTop = this.itemsContainer.css("margin-top") ? Number(this.itemsContainer.css("margin-top").split("px")[0]) : 0;
                this.itemsContainer.css({ "clip": "rect(" + (ClipValue1 + tabScrollStep) + "px, " + (this.itemsContainer.width() + 4) + "px," + (ClipValue2 + tabScrollStep) + "px, 0px)", "margin-top": "-" + (-MarginTop + tabScrollStep) + "px" });
                if (ClipValue2 > (this._tabContentsHeight() - 20)) {
                    this.itemsContainer.css({ "clip": "rect(" + (this._tabContentsHeight() - Number(this.model.height) + 2) + "px, " + (this.itemsContainer.width() + 4) + "px, " + (this._tabContentsHeight() + 2) + "px, 0px", "margin-top": "-" + (this._tabContentsHeight() - Number(this.model.height) + 2) + "px" })
                    this._rightScrollIcon.css("display", "none");
                }
            }
        },
        _executeBackwardScrolling: function ( args , scrollStep ) {
            if (this._rightScrollIcon != "") this._rightScrollIcon.css("display", "block");
			var tabScrollStep= (scrollStep) ? scrollStep :(args.type=='swiperight'||args.type=='swipeleft')? 50: 30;
            if (this.model.headerPosition == "top" || this.model.headerPosition == "bottom") {
                if (!this.model.enableRTL) {
                    var ClipValue1 = Number(this.itemsContainer.css("clip").split("px")[1].replace(",", ""));
                    var ClipValue2 = Number(this.itemsContainer.css("clip").split("px")[3].replace(",", ""));
                    var scrollValue = Number(this._rightScrollIcon.css("margin-right").split("px")[0]);
                    this.itemsContainer.css({ "clip": "rect(0px," + (ClipValue1 - tabScrollStep) + "px,100px," + (ClipValue2 - tabScrollStep) + "px)", "margin-left": "-" + (ClipValue2 - tabScrollStep) + "px" });
                    if (ClipValue2 - tabScrollStep < 0) {
                        this.itemsContainer.css({ "clip": "rect(0px," + ej.getDimension(this.element, "width") + "px,100px, 0px", "margin-left": "0px" });
                        this._rightScrollIcon.css("margin-right", this.itemsContainer.width() - ej.getDimension(this.element, "width") + 20 + "px");
                    }
					if(args.type=='swiperight' && Math.abs(Number((this.itemsContainer.css('margin-left')).split("px")[0])) <= (this._tabContentsWidth() - ej.getDimension(this.element, "width")))
						this._on(this.items, "swipeleft", this._tabSwipe);
                    if (ClipValue2 <= tabScrollStep && this._leftScrollIcon)
                        this._leftScrollIcon.css("display", "none");
                }
                else {
                    var ClipValue1 = Number(this.itemsContainer.css("clip").split("px")[1].replace(",", ""));
                    var ClipValue2 = Number(this.itemsContainer.css("clip").split("px")[3].replace(",", ""));
                    var itemsMargin = Number(this.itemsContainer.css("margin-right").split("px")[0]) ? Number(this.itemsContainer.css("margin-right").split("px")[0]) : 0;
                    var RightScroll = this._leftScrollIcon && this._leftScrollIcon.css("margin-right") ? Number(this._leftScrollIcon.css("margin-right").split("px")[0]) : "";
                    var scrollValue = Number(this._rightScrollIcon.css("margin-left").split("px")[0]);
                    this.itemsContainer.css({ "clip": "rect(0px," + (ClipValue1 + tabScrollStep) + "px,100px," + (ClipValue2 + tabScrollStep) + "px)", "margin-right": "-" + (-itemsMargin - tabScrollStep) + "px" });
                    this._rightScrollIcon.css("margin-left", (scrollValue + tabScrollStep) + "px");
                    this._leftScrollIcon ? this._leftScrollIcon.css("margin-right", (RightScroll - tabScrollStep) + "px") : "";
					if(args.type=='swiperight' && Math.abs(Number((this.itemsContainer.css('margin-right')).split("px")[0])) <= (this._tabContentsWidth() - ej.getDimension(this.element, "width")))
						this._on(this.items, "swipeleft", this._tabSwipe);
                    if (itemsMargin >= -tabScrollStep && this._leftScrollIcon) {
                        this._leftScrollIcon.css("display", "none");
                    }
                }
            }

            else if (this.model.headerPosition == "left" || this.model.headerPosition == "right") {
                var ClipValue1 = Number(this.itemsContainer.css("clip").split("px")[0].replace(",", "").split("(")[1]);
                var ClipValue2 = Number(this.itemsContainer.css("clip").split("px")[2].replace(",", ""));
                var scrollValue = Number(this._rightScrollIcon.css("margin-top").split("px")[0]);
                var RightTop = this._leftScrollIcon.css("margin-top") ? Number(this._leftScrollIcon.css("margin-top").split("px")[0]) : 0;
                var MarginTop = this.itemsContainer.css("margin-top") ? Number(this.itemsContainer.css("margin-top").split("px")[0]) : 0;
                this.itemsContainer.css({ "clip": "rect(" + (ClipValue1 - tabScrollStep) + "px, " + this.itemsContainer.width() + "px," + (ClipValue2 - tabScrollStep) + "px, 0px)", "margin-top": "-" + (-MarginTop - tabScrollStep) + "px" });
                if (Number(this.itemsContainer.css("clip").split("px")[0].split("(")[1]) <= 0) {
                    this.itemsContainer.css({ "clip": "rect( 0px, " + this.itemsContainer.width() + "px," + (Number(this.model.height)) + "px, 0px)", "margin-top": "0px" });
                    this._leftScrollIcon.css("display", "none");
                }
            }
        },

        _removeHeaderClass: function () {
            this.itemsContainer.remove();
            this.itemsContainer.insertBefore(this.element.find(">div").first());
            this.items.removeClass("e-bottom-line e-top-line");
            $(this.contentPanels).removeClass("e-content-bottom e-activetop e-activebottom");
            this.itemsContainer.removeClass("e-header e-left e-right");
        },

        _removeVerticalClass: function () {
            this.element.removeClass("e-vertical");
            this.itemsContainer.removeClass("e-left e-right").removeAttr("style");
        },


        _removeBaseClass: function () {
            this.element.removeClass("e-tab e-widget e-corner e-js e-tabscroll").removeAttr("role tabindex unselectable");
            if ((this.model.headerPosition == "left" || this.model.headerPosition == "right"))
                this._removeVerticalClass();
            this.itemsContainer.removeClass("e-header e-box e-clearall e-select e-addborderbottom e-addbordertop e-addborderleft e-addborderright");
            this.anchors.removeClass("e-link");
            this.items.removeClass("e-select e-item e-active e-bottom-line e-top-line e-margine-top e-margine-bottom e-rtl-top-line e-top-hover e-rtl-bottom-line e-disable").removeAttr("role tabindex aria-selected aria-expanded");
            $(this.contentPanels).removeClass("e-content  e-content-item e-box e-content-bottom e-activetop e-activebottom e-active-content e-hidebottom e-addborderbottom e-hidetop e-addbordertop e-hideleft e-addborderleft e-hideright e-addborderright e-disable").removeAttr("role aria-hidden").css("display", "");
            this.element.find("div.e-close.e-tabdelete,div.e-icon.e-chevron-circle-right,div.e-icon.e-chevron-circle-left,div.e-icon.e-reload").remove();
        },


        _addContentTag: function (href, index) {
            var id = this._getTabId(href);
            var panel = this.element.find("#" + id);
            if (!panel.length) {
                panel = ej.buildTag("div.e-content  e-content-item e-box e-content-bottom #" + id)
                    .insertAfter(this.contentPanels[index - 1] || this.itemsContainer);
            }
            this.contentPanels.splice(index, 0, panel[0]);
        },

        _roundedCorner: function (value) {
            if (value) {
                this.element.addClass('e-corner');
            }
            else if (this.element.hasClass('e-corner')) {
                this.element.removeClass('e-corner');
            }
        },


        _setTabsHeightStyle: function (heightFormat) {
            if (ej.Tab.HeightAdjustMode.Content != heightFormat) $(this.contentPanels).height("");
            if (ej.Tab.HeightAdjustMode.Fill == heightFormat) {
                if (ej.Tab.Position.Left === this.model.headerPosition || ej.Tab.Position.Right === this.model.headerPosition) {
                    $(this.contentPanels).css("height", "100vh");
                }
                this._contentPaneSize();
            }
            else if (ej.Tab.HeightAdjustMode.Auto == heightFormat) {
                var maxHeight = 0;
                $(this.contentPanels).css({ "display": "none" }).addClass('e-active-content');
                for (var i = 0; i < this.contentPanels.length; i++) {
                    maxHeight = Math.max(maxHeight, this._getDimension($(this.contentPanels[i]), "outerHeight"));
                }
                $(this.contentPanels).removeClass('e-active-content');
                $(this.contentPanels).height(maxHeight);
                this.maxAutoHeight = maxHeight;
                this.showItem(this.selectedItemIndex());
            }
            else if (ej.Tab.HeightAdjustMode.None == heightFormat) {
                if (this.model.height != null) {
                    this._contentPaneSize();
                }
            }
            if (ej.Tab.HeightAdjustMode.Fill !== heightFormat) $(this.itemsContainer).height("");
            if (ej.Tab.HeightAdjustMode.Content == heightFormat)
                $(this.contentPanels).height("auto");

            if (this.model.enableTabScroll && (this.model.headerPosition == "left" || this.model.headerPosition == "right")) {
                $(this.contentPanels).css("height", this.model.height + "px");
            }

        },
        _getDimension: function (element, method) {
            var value;
            var $hidden = $(element).parents().addBack().filter(':hidden');
            var prop = { visibility: 'hidden', display: 'block' };
            var hiddenCollection = [];
            $hidden.each(function () {
                var hidden = {}, name;
                for (name in prop) {
                    hidden[name] = this.style[name];
                    this.style[name] = prop[name];
                }
                hiddenCollection.push(hidden);
            });
            value = /(outer)/g.test(method) ?
            $(element)[method](true) :
           $(element)[method]();

            $hidden.each(function (i) {
                var hidden = hiddenCollection[i], name;
                for (name in prop) {
                    this.style[name] = hidden[name];
                }
            });
            return value;
        },
        // Tab to active given index value
        showItem: function (index) {
            if ($.inArray(index, this.model.disabledItemIndex) < 0) {
                var proxy = this;
                if (this._isInteraction != false) this._isInteraction = true;
                this._preTabSelectedIndex = this.selectedItemIndex();
                this.selectedItemIndex(index);
                if (this.selectedItemIndex() >= this.contentPanels.length) {
                    this.selectedItemIndex(0);
                    index = this.selectedItemIndex();
                }
                if (index >= 0 && !this.initialRender && true === this._onBeforeActive(index)){
                    this.selectedItemIndex(this._preTabSelectedIndex);
                    return false;
                } 
                else this._preTabIndex = this._preTabSelectedIndex;
                $(this.items[this.selectedItemIndex()]).attr("aria-expanded", true).attr("aria-selected", true).attr("tabindex", 0);
                if (this.selectedItemIndex() != null && this.selectedItemIndex() < this.contentPanels.length) {
                    this._ajaxLoad();
                    this.hideItem(this._preTabIndex);
                    $(this.contentPanels[this.selectedItemIndex()]).fadeIn(this.model.enableAnimation ? 20 : 0, function () {
                        if (!proxy.initialRender && proxy._onActive())
                            return true;
                        proxy.initialRender = false;
                    });
                    if (!(this.model.headerPosition == "left" || this.model.headerPosition == "right")) {
                        var activeClass = this.model.headerPosition == ej.Tab.Position.Top ? "e-activetop" : "e-activebottom";
                        $(this.contentPanels[this.selectedItemIndex()]).addClass(activeClass)
                    }
                    else
                        $(this.contentPanels[this.selectedItemIndex()]).addClass("e-active-content ");
                    $(this.items[this.selectedItemIndex()]).addClass("e-active").removeClass("e-select");
                    $(this.items[this.selectedItemIndex()]).removeClass("e-margine-top e-margine-bottom");

                    for (var i = 0; i <= $(this.items).length; i++) {
                        if ($(this.items[i]).hasClass("e-select")) {
                            if (this.model.headerPosition == "right") {
                                $(this.items[i]).removeClass("e-margine-top e-margine-bottom");
                            }
                            if (this.model.headerPosition == "left") {
                                $(this.items[i]).removeClass("e-margine-top e-margine-bottom");
                            }
                            if (this.model.headerPosition == "top") {
                                if (!this.element.hasClass("e-tab-collapsed"))
                                    $(this.items[i]).addClass("e-margine-top");
                                else
                                    $(this.items[i]).removeClass("e-margine-top");
                                $(this.items[i]).removeClass("e-margine-bottom");
                            }
                            if (this.model.headerPosition == "bottom") {
                                $(this.items[i]).removeClass("e-margine-top");
                                $(this.items[i]).addClass("e-margine-bottom");
                            }
                        }
                    }
                    $(this.contentPanels[this.selectedItemIndex()]).addClass("e-active-content").removeAttr("aria-hidden", false);
                }
            }
            if (this.model.enableTabScroll && this._tabContentsWidth() > (this.model.width || this.element.width()) && this.itemsContainer.find("li").length && (this.model.headerPosition == "top" || this.model.headerPosition == "bottom")) {
                if (!this.model.enableRTL) {
                    var itemPosition = Number(this.itemsContainer.find("li.e-active").position().left.toFixed(0)) + this.itemsContainer.find("li.e-active").width() - ej.getDimension(this.element, "width");
                    if ((itemPosition > 0) && (Number(this.itemsContainer.find("li.e-active").offset().left.toFixed(0)) + this.itemsContainer.find("li.e-active").width() > ej.getDimension(this.element, "width") || (Number(this.itemsContainer.find("li.e-active").offset().left.toFixed(0)) - this.itemsContainer.find("li.e-active").width() < 0))) {
                        this.itemsContainer.css("clip", "rect(0 ," + (ej.getDimension(this.element, "width") + (itemPosition + 10)) + "px, 100px," + (itemPosition + 10) + "px)").css("margin-left", "-" + (itemPosition + 10) + "px")
                        this._rightScrollIcon ? this._rightScrollIcon.css("margin-right", (this.itemsContainer.width() - ej.getDimension(this.element, "width") + 10 - itemPosition) + "px").css("display", "block") : "";
                        this._addScrollBackIcon();
                        if ((this._leftScrollIcon && this._leftScrollIcon.css("margin-left")) && (Number(this.itemsContainer.css("margin-left").split("px")[0].replace("-", "")) >= (this._tabContentsWidth() - ej.getDimension(this.element, "width"))) && ((Number(this.itemsContainer.find("li.e-active").offset().left.toFixed(0)) - this.itemsContainer.find("li.e-active").width() < 0))) {
                        this._rightScrollIcon.css("display", "none"); 
						this._off(this.items, "swipeleft", this._tabSwipe);
                    }else
                        this._leftScrollIcon ? this._leftScrollIcon.css("display", "block") : "";
                        this._rightScrollIcon ? this._rightScrollIcon.css("display", "none") : "";
                    }
                }
            }
            else if (this.model.enableTabScroll && this.model.height && (this.model.headerPosition == "left" || this.model.headerPosition == "right") && !this.model.enableRTL) {
                var itemPosition = Number(this.itemsContainer.find("li.e-active").position().top.toFixed(0)) + this.itemsContainer.find("li.e-active").height() - Number(this.model.height);
                if ((itemPosition > 0) && (Number(this.itemsContainer.find("li.e-active").offset().top.toFixed(0)) + this.itemsContainer.find("li.e-active").height() > Number(this.model.height) || (Number(this.itemsContainer.find("li.e-active").offset().top.toFixed(0)) - this.itemsContainer.find("li.e-active").height() < 0))) {
                    this.itemsContainer.css("clip", "rect(" + itemPosition + "px," + (this.itemsContainer.outerWidth() + 2) + "px, " + (Number(this.model.height) + itemPosition) + "px, 0px").css("margin-top", "-" + itemPosition + "px");
                    this._addScrollBackIcon();
                }
            }

        },

        hideItem: function (index) {
            $(this.contentPanels[index]).fadeOut(0);
            if (!(this.model.headerPosition == "left" || this.model.headerPosition == "right"))
                var activeClass = this.model.headerPosition == ej.Tab.Position.Top ? "e-activetop" : "e-activebottom";
            $(this.items[index]).removeClass("e-active").addClass("e-select");
            $(this.contentPanels[index]).removeClass("e-active-content " + activeClass).attr("aria-hidden", true);
        },


        _ajaxLoad: function () {
            var content = $(this.contentPanels[this.selectedItemIndex()]);
            var link = this.anchors[this.selectedItemIndex()];
            var href = $(link).attr("href");
            if (content.is(':empty') && href.indexOf("#") !== 0)
                this._sendAjaxOptions(content, link);
        },


        _getTabId: function (href) {
            return !href.indexOf("#") ? href.replace("#", "") : this.model.idPrefix + this._getNextTabId();
        },

        _getNextTabId: function () {
            return ++this.tabId;
        },


        _disableTabs: function () {
            for (var i = 0, li; (li = this.items[i]) ; i++) {
                if ($.inArray(i, this.model.disabledItemIndex) > -1) {
                    $(li).find("a").off(this.model.events);
                    $(li).find("div.e-close").off("click");
                }
                $(li)[$.inArray(i, this.model.disabledItemIndex) != -1 &&
                    !$(li).hasClass("e-tab-selected") ? "addClass" : "removeClass"]("e-disable");
                $(this.contentPanels[i])[$.inArray(i, this.model.disabledItemIndex) != -1 &&
                    !$(this.contentPanels[i]).hasClass("e-tab-selected") ? "addClass" : "removeClass"]("e-disable");
            }
        },


        _tabItemClick: function (args) {

            if (this.model.enabled) {
                args.preventDefault(); // Prevent the ancher tag url action
                var index;
                if (this.selectedItemIndex() == $(this.items).index($(args.currentTarget)) && this.model.collapsible) {
                    index = -1; $(this.element).addClass("e-tab-collapsed");
                }
                else {
                    index = $(this.items).index($(args.currentTarget));
                }
                if (index != this.selectedItemIndex())
                    this.showItem(index);
                $(this.element).removeClass("e-tab-collapsed");               
				if(this.selectedItemIndex() > -1 && this.contentPanels != 0 && this.model.enableRTL)
				    $(this.element).height(this.itemsContainer.height()+parseInt($(this.contentPanels[this.selectedItemIndex()]).css("height")));
            }
        },

        _tabDeleteClick: function (args) {
            if (this.model.enabled) {
                var currentTab = $(args.target);
                var tabWidth = $(args.target).parent().width();
                if (currentTab.hasClass("e-close"))
                    var index = $(this.items).index($(args.target).parent());
                if (index == this.selectedItemIndex() && this.items.length > index)
                    this.selectedItemIndex(this.selectedItemIndex() + 1)
                var itemsMargin = Number(this.itemsContainer.css("margin-right").split("px")[0]) ? Number(this.itemsContainer.css("margin-right").split("px")[0]) : 0;
                if(this.model.enableTabScroll && (this.model.headerPosition == "top" || this.model.headerPosition == "bottom") && ( this._leftScrollIcon || this._rightScrollIcon ) && this._isSizeExceeded()) {
                     if(!this.model.enableRTL || (this.model.enableRTL && itemsMargin < -tabWidth )) this._executeBackwardScrolling(args,tabWidth);
                     else {
                         this.itemsContainer.css({"margin-right":"0px","clip":this._initialClip});
                         this._leftScrollIcon && this._leftScrollIcon.css("display", "none");
                         this._rightScrollIcon && this._rightScrollIcon.css("display", "none");
                     }	 
                }
                this.removeItem(index);
                if(this.model.enableTabScroll && (this.model.headerPosition == "top" || this.model.headerPosition == "bottom") && ( this._leftScrollIcon || this._rightScrollIcon ) && !this.model.enableRTL) {
                    this._on(this.element.find("div.e-chevron-circle-right"), "mouseover", this._hoverHandler);
                    this._on(this.element.find("div.e-chevron-circle-right"), "mouseout", this._hoverHandler);
                }
            }
        },
        _tabScrollClick: function (args) {
            if (this.model.enabled) {
                if ((this._rightScrollIcon[0] == args.target)) {
                    this._executeForwardScrolling(args);

                    this._addScrollBackIcon();
                    this._leftScrollIcon.css("display", "block");
                }
            }
        },
		
		_tabSwipe: function(e){ 
			 if(e.type=='swipeleft')  
			this._executeForwardScrolling(e);
			else 
			this._executeBackwardScrolling(e);
		},
        _tabScrollBackClick: function (args) { 
            if (this.model.enabled) {
                if ((this._leftScrollIcon[0] == args.target)) {
                    this._executeBackwardScrolling(args);
                }
            }
        },

        _tabReloadClick: function (args) {
            if (this.model.enabled) {
                var currentTab = $(args.target);
                if (currentTab.hasClass("e-reload")) {
                    var link = this.anchors[this.selectedItemIndex()];
                    var href = $(link).attr("href");
                    var content = $(this.contentPanels[this.selectedItemIndex()]);
                    if (href.indexOf("#") !== 0)
                        this._sendAjaxOptions(content, link);
                    else
                        this.showItem(this.selectedItemIndex());
                }
            }
        },


        _sendAjaxOptions: function (content, link) {
            //load waiting popup
            if (this._onBeforeLoad(link))
                return true;
            content.addClass("e-load");
            var proxy = this;
            var curTabTitle = $(link).html();
            var hrefLink = link.href.replace("#", "");
            var ajaxOptions = {
                type: this.model.ajaxSettings.type, cache: this.model.ajaxSettings.cache, url: hrefLink, data: this.model.ajaxSettings.data,
                dataType: this.model.ajaxSettings.dataType, contentType: this.model.ajaxSettings.contentType, async: this.model.ajaxSettings.async,
                "success": function (data) {
                    try {
                        proxy._ajaxSuccessHandler(data, content, link, curTabTitle);
                    } catch (e) {

                    }
                }, "error": function () {
                    try {
                        proxy._ajaxErrorHandler(link, proxy.selectedItemIndex(), curTabTitle);
                    } catch (e) {

                    }
                }
            };
            this._sendAjaxRequest(ajaxOptions);
        },

        _sendAjaxRequest: function (ajaxOptions) {
            $.ajax({
                type: ajaxOptions.type,
                cache: ajaxOptions.cache,
                url: ajaxOptions.url,
                dataType: ajaxOptions.dataType,
                data: ajaxOptions.data,
                contentType: ajaxOptions.contentType,
                async: ajaxOptions.async,
                success: ajaxOptions.success,
                error: ajaxOptions.error,
                beforeSend: ajaxOptions.beforeSend,
                complete: ajaxOptions.complete
            });
        },


        _ajaxSuccessHandler: function (data, content, link, curTabTitle) {
            if (curTabTitle != null)
                $(link).html(curTabTitle);
            content.removeClass("e-load");
            content.html(data).addClass("e-tab-loaded"); //to indicate the content is already loaded
            var eventData = { data: data, url: link, content: content };
            this._trigger("ajaxSuccess", eventData);
            if (this._onLoad(link))
                return true;
        },


        _ajaxErrorHandler: function (data, link, index, title) {
            this._trigger("ajaxError", { data: data, url: link });
            this._onLoad(link);
        },

        _createContentPanel: function (id) {
            return $('<div></div>')
				.attr("id", id)
				.addClass("e-content  e-content-item e-content-bottom e-box");
        },


        _refresh: function () {
            this._unWireEvents();
            this.itemsContainer.removeAttr("style class");
            $(this.contentPanels).removeAttr("style class");
            this.element.css("margin-left", "");
            this._removeVerticalClass();
            this._removeHeaderClass();
            this._initialize();
        },

        _keyPress: function (e) {
            if (this.model.enabled) {
                var index, currentEle, targetEle = $(e.target),code;
                if (e.keyCode) code = e.keyCode; // ie and mozilla/gecko
                else if (e.which) code = e.which; // ns4 and opera
                else code = e.charCode;
                if (targetEle.hasClass("e-link") || targetEle.hasClass("e-item")) {
                    switch (code) {
                        case 39:
                        case 40:
                            {
                                e.preventDefault();
								var index = [];
								for(var i=0; i<this.getItemsCount();i++) {
									if($.inArray(i,this.model.hiddenItemIndex) < 0)
									{
										index.push(i);
									}
								}
								var tabIndex = $.inArray(this.selectedItemIndex(),index);
								tabIndex==index.length-1?this.showItem(index[0]): this.showItem(index[tabIndex+1]);
                                break;
                            }
                        case 37:
                        case 38:
                            {
                                e.preventDefault();
								var index = [];
								for(var i=0; i<this.getItemsCount();i++) {
									if($.inArray(i,this.model.hiddenItemIndex) < 0)
									{
										index.push(i);
									}
								}
								var tabIndex = $.inArray(this.selectedItemIndex(),index);
								tabIndex==0 ? this.showItem(index[index.length-1]) : this.showItem(index[tabIndex-1]);
                                break;
                            }
                        case 35:
                            {
                                e.preventDefault();
                                this.showItem(this.getItemsCount() - 1);
                                break;
                            }
                        case 36:
                            {
                                e.preventDefault();
                                this.showItem(0);
                                break;
                            }
                        case 13:
                            {
                                e.preventDefault();
                                this.showItem(this.selectedItemIndex());
                                break;
                            }
                    }
                }
                else if (e.ctrlKey && !targetEle.hasClass("e-tab")) {
                    switch (code) {
                        case 38:
                            e.preventDefault();
                            index = $(this.contentPanels).index(targetEle.parent(".e-content"));
                            currentEle = $(this.items[index]);
                            break;
                        case 33:
                            e.preventDefault();
                            currentEle = $(this.items[0]);
                            this.showItem(0);
                            break;
                        case 34:
                            e.preventDefault();
                            currentEle = $(this._headers[this.getItemsCount() - 1]);
                            this.showItem(this.getItemsCount() - 1);
                            break;
                    }
                }
                if (!ej.isNullOrUndefined(currentEle)) {
                    currentEle.addClass("e-focus");
                    currentEle.focus();
                }
            }
        },

        _hoverHandler: function (args) {
            args.preventDefault();
            if (this.model.enabled) {
                var index = $(this.items).index($(args.target).parent());
                if (index == -1)
                    index = $(this.items).index($(args.target));
				if((this.model.showCloseButton || this.model.showReloadIcon) && !$(this.items[index]).hasClass("e-disable")){
                args.type === "mouseout" ? $(this.element.find("div.e-tabdelete")[index]).css("visibility", "hidden") : $(this.element.find("div.e-tabdelete")[index]).css("visibility", "visible");
				args.type === "mouseout" ? $(this.element.find("div.e-reload")[index]).css("visibility", "hidden") : $(this.element.find("div.e-reload")[index]).css("visibility", "visible");
				}
                args.type === "mouseout" ? $(this.element.find("div.e-chevron-circle-right")).css("visibility", "hidden") : $(this.element.find("div.e-chevron-circle-right")).css("visibility", "visible");
                args.type === "mouseout" ? $(this.element.find("div.e-chevron-circle-left")).css("visibility", "hidden") : $(this.element.find("div.e-chevron-circle-left")).css("visibility", "visible");
            }
        },


        _wireEvents: function (event) {
            this._on(this.items, event, this._tabItemClick);
            this._on(this.itemsContainer, "mouseover", this._hoverHandler);
            this._on(this.itemsContainer, "mouseout", this._hoverHandler);
            this._on(this.element.find(">ul").eq(0).find(">li div.e-close"), "click", this._tabDeleteClick);
            this._on(this.element.find("div.e-chevron-circle-left"), "click", this._tabScrollBackClick);
			if (this.model.enableTabScroll)this._on(this.items, "swipeleft swiperight", this._tabSwipe);
            this._on(this.itemsContainer, "focusin", this._focusIn);
            this._on(this.itemsContainer, "focusout", this._focusOut);
            $(window).on('resize', $.proxy(this._resize, this));
            this._on(this.element.find(">ul").eq(0).find(">li div.e-reload"), "click", this._tabReloadClick);
			this._resizeEvents(this.model.heightAdjustMode);
        },
        _resize: function () {
            if (this.model && this.model.width == null && this.model.enableTabScroll && (this.model.headerPosition == "top" || this.model.headerPosition == "bottom")) {
                this._removeScroll()
                this._addScroll()
            }
        },


        _unWireEvents: function () {
            this._off(this.items, this.model.events);
            this._off(this.element.find(">ul").eq(0).find(">li div.e-close"), "click");
            this._off(this.element.find("div.e-chevron-circle-right"), "click");
            this._off(this.element.find("div.e-chevron-circle-left"), "click");
			if (this.model.enableTabScroll)this._off(this.items, "swipeleft swiperight", this._tabSwipe);
            this._off(this.itemsContainer, "mouseover", this._hoverHandler);
            this._off(this.itemsContainer, "mouseout", this._hoverHandler);
            this._off(this.element.find("div.e-chevron-circle-left"), "mouseover", this._hoverHandler);
            this._off(this.element.find("div.e-chevron-circle-right"), "mouseover", this._hoverHandler);
            this._off(this.element.find("div.e-chevron-circle-left"), "mouseout", this._hoverHandler);
            this._off(this.element.find("div.e-chevron-circle-right"), "mouseout", this._hoverHandler);
            this._off(this.itemsContainer, "focusin", this._focusIn);
            this._off(this.itemsContainer, "focusout", this._focusOut);
            this._off(this.element.find(">ul").eq(0).find(">li div.e-reload"), "click");
            this._resizeEvents();
        },
        _resizeEvents: function (value) {
            if (value === "fill") $(window).on('resize', $.proxy(this._windowResized, this));
            else $(window).off('resize', $.proxy(this._windowResized, this));
        },


        _windowResized: function (e) {
            var maxHeight = this._getDimension($(this.element).parent(), "height");
            if (this._prevSize == maxHeight) return;
            else this._contentPaneSize();
            this._prevSize = maxHeight;
            if (!this.model.width && this.model.enableTabScroll)
                this._addScroll();
        },
        _contentPaneSize: function () {
            if (this.model.height != null && this.model.heightAdjustMode == "none") {
                $(this.element).height(this.model.height);
                var maxHeight = this._getDimension($(this.element), "height");
            }
            else var maxHeight = this._getDimension($(this.element).parent(), "height");
            $(this.contentPanels).height("");
            $(this.element).parent().css({ "overflow": "auto" });
            if (this.model.headerPosition === "top" || this.model.headerPosition === "bottom")
                maxHeight -= this._getDimension($(this.itemsContainer), "outerHeight");
            var maxPadding = 0, padding;
            for (var i = 0; i < this.contentPanels.length; i++) {
                if ($(this.contentPanels[i]).hasClass("e-active-content")) {
                    padding = Math.max(maxPadding, this._getDimension($(this.contentPanels[i]), "outerHeight") - this._getDimension($(this.contentPanels[i]), "height"));
                    if (this.model.height != null && this.model.heightAdjustMode == "none") $(this.contentPanels[i]).outerHeight(maxHeight).css({ "overflow": "auto" })
                    else $(this.contentPanels[i]).height(maxHeight - padding).css({ "overflow": "auto" });
                } else {
                    maxPadding = Math.max(maxPadding, this._getDimension($(this.contentPanels[i]), "outerHeight") - this._getDimension($(this.contentPanels[i]), "height"));
                    if (this.model.height != null && this.model.heightAdjustMode == "none") $(this.contentPanels[i]).outerHeight(maxHeight).css({ "overflow": "auto" })
                    else $(this.contentPanels[i]).height(maxHeight - maxPadding).css({ "overflow": "auto" });
                }
            }
        },
        _disableItems: function (indexes) {
            if (!this.model.enabled) return false;
            if (indexes != null) {
                for (var i = 0; i < indexes.length; i++) {
                    if ($.inArray(indexes[i], this.model.disabledItemIndex) == -1)
                        this.model.disabledItemIndex.push(indexes[i]);
                }
                this.model.disabledItemIndex.sort();
                this._disableTabs();
            }
        },

        _enableItems: function (indexes) {
            if (!this.model.enabled) return false;
            for (var i = 0; i < indexes.length; i++) {
                var index = indexes[i];
                this.model.disabledItemIndex = $.grep(this.model.disabledItemIndex, function (n, i) {
                    return n != index;
                });
            }
            this._disableTabs();
        },


        disable: function () {
            var indexes = [];
            for (var index = 0; index < this.getItemsCount() ; index++) {
                indexes.push(index);
            }
            this._disableItems(indexes);
            this.model.enabledItemIndex = [];
            this._unWireEvents();
        },

        enable: function () {
            var indexes = [];
            this.model.disabledItemIndex = [];
            for (var index = 0; index < this.getItemsCount() ; index++) {
                if ($.inArray(index, this.model.enabledItemIndex) < 0) {
                    this.model.enabledItemIndex.push(index);
                    indexes.push(index);
                }
                this._enableItems(index);
            }
        },

        getItemsCount: function () {
            if (this.items) {
                return this.items.length;
            }
        },

        addItem: function (url, displayLabel, index, cssClass, id) {
            (index >= 0 && index < this.items.length) ? this._addItemIndex = index : this._addItemIndex = this.items.length;
            for (var disable_index = 0; disable_index < this.model.disabledItemIndex.length; disable_index++) {
                if (this.model.disabledItemIndex[disable_index] >= index)
                    this.model.disabledItemIndex[disable_index]++;
            }
            if (this.model.headerPosition == "left") {
                this.items.length >= 0 && this.itemsContainer.addClass("e-left");
            }
            else if (this.model.headerPosition == "right") {
                this.items.length >= 0 && this.itemsContainer.addClass("e-right");
            }
            else
                this.items.length == 0 && this.itemsContainer.addClass("e-header");
            var liTag = ej.buildTag("li.e-select e-item");
            if ((this.model.headerPosition == "top"))
                if (this.model.enableRTL)
                    $(liTag).addClass("e-rtl-top-line e-top-hover");
                else
                    $(liTag).addClass("e-bottom-line");
            if (!ej.isNullOrUndefined(cssClass)) {
                var span = ej.buildTag('span').addClass(cssClass);
                liTag.append(span);
            }
            if (index === undefined && displayLabel === undefined && url != null)
                displayLabel = "Item";
            if (index === undefined && displayLabel === undefined && id === undefined) {
                url = "#Item" + this.items.length;
                displayLabel = "Item"
            }
            if (id != undefined) {
                if (id.indexOf("#") != 0)
                    id = "#" + id;
                this.divId = id;
            }
            else if (url != undefined)
                id = url;
            var aTag = ej.buildTag("a", displayLabel, {}, { href: url });
            aTag.addClass("e-link");
            if (this.model.headerPosition == "top" || this.model.headerPosition == "bottom")
                aTag.appendTo(liTag);
            if (this.model.showCloseButton) {
                var deleteIcon = ej.buildTag('div.e-icon e-close e-tabdelete', "", {}, {}).css("visibility", "hidden");
                liTag.append(deleteIcon);
                this._on(deleteIcon, "click", this._tabDeleteClick);
            }
            if (this.model.headerPosition == "left" || this.model.headerPosition == "right")
                aTag.appendTo(liTag);
            if (index === undefined) {
                index = this.anchors.length;
            }
            var insertIndex = index >= this.items.length;
            if (insertIndex) {
                liTag.appendTo(this.itemsContainer);
            } else {
                liTag.insertBefore(this.items[index]);
            }
            if (!ej.isNullOrUndefined(this.model.headerSize))
                this._setHeaderSize(this.model.headerSize);
            if (this.selectedItemIndex() == index) {
                this.hideItem[index];
                this.selectedItemIndex(this.selectedItemIndex() + 1);
            } else {
                this.hideItem[index];
                if (index < this.selectedItemIndex())
                    this.selectedItemIndex(this.selectedItemIndex() + 1);
            }
            this._itemsRefreshing();
            this._reinitialize(true);
            if (this.model.headerPosition == "top")
                $(this.contentPanels[index]).addClass("e-hidebottom");
            if (this.model.headerPosition == "bottom") {
                $(this.contentPanels[index]).addClass("e-hidetop");
                liTag.addClass("e-top-line e-item e-select e-margine-bottom")
            }
            if (this.model.headerPosition == "left")
                $(this.contentPanels[index]).addClass("e-hideleft");
            if (this.model.headerPosition == "right")
                $(this.contentPanels[index]).addClass("e-hideright");
            var data = {
                tabHeader: this.anchors[index],
                tabContent: this.contentPanels[index]
            };
            this.refreshTabScroll();
            this._addItemIndex = null;
            this._onAdd(data);
            if (this.model.showReloadIcon) {
                var reloadIcon = ej.buildTag('div.e-icon e-reload', "", {}, { role: "presentation" }).css("visibility", "hidden");
                $(this.element.find("li")[index]).append(reloadIcon)
            }
            if (this.model.enableTabScroll && this.model.headerPosition == "right") {
                $(this.contentPanels).css("height", this.model.height + "px");
            }
			this._setTabsHeightStyle(this.model.heightAdjustMode);
        },

        _isSizeExceeded: function () {
            var eleWidth = this.element.width(), itemsWidth = 0;
            var tabcount = this.items.length;
            for (var tabVal = 0; tabVal < tabcount; tabVal++) {
                var tabWidth = $(this.items[tabVal]).width();
                itemsWidth += tabWidth;
            }
            return (itemsWidth > eleWidth ? true : false);
        },

        refreshTabScroll: function () {
            if (this._isSizeExceeded()) {
                this.element.find("div.e-chevron-circle-right").length >= 1 && this.element.find("div.e-chevron-circle-right").remove();
                if (this.model.enableTabScroll) {
                    this._checkScroll();
                    this._addScrollIcon();
                }
            }
            else {
                if (((this.model.headerPosition == "left" || this.model.headerPosition == "right") && this._tabContentsHeight() > (this.element.width() || Number(this.model.height))) || ((this.model.headerPosition == "top" || this.model.headerPosition == "bottom") && (this.itemsContainer.width() > (this.element.outerWidth()))))
                    this._checkScroll();
            }
        },

        removeItem: function (index) {
            if (!this.model.enabled) return false;
            if (index != null && index > -1 && index < this.items.length) {
                if (this._onBrforeRemove({ index: index }) === true)
                    return false;
                var removeTabWidth = $(this.items[index]).width();
                var removedTab = $(this.items[index]).remove();
                if(this.model.enableTabScroll)
                     this.itemsContainer.css("width", (this.itemsContainer.width()-removeTabWidth) + "px");
                this.model.disabledItemIndex = [];
                if (removedTab.hasClass("e-active")) {
                    index == 0 ? this.selectedItemIndex(index + 1) : this.selectedItemIndex(index - 1);
                    this.showItem(this.selectedItemIndex());
                }
                $(this.element.find(">div.e-content")[index]).remove();
                this.contentPanels.splice(index, 1);
                index < this.selectedItemIndex() ? this.selectedItemIndex(this.selectedItemIndex() - 1) : this.selectedItemIndex();

                if (index < 0 || index >= this.anchors.length) {
                    this.selectedItemIndex(0);
                }
                if ((this.model.headerPosition == "left" || this.model.headerPosition == "right") && this.items.length == 1)
                    this._removeVerticalClass();
                else
                    this.items.length == 1 && this.itemsContainer.removeClass("e-header");
                this._unWireEvents();
                this._itemsRefreshing();
                this._wireEvents(this.model.events);
                if (this.model.enableTabScroll)
                    this._on(this.element.find("div.e-chevron-circle-right"), "click", this._tabScrollClick);
                for (var indx = 0; indx < this.items.length; indx++)
                    if ($(this.items[indx]).hasClass('e-disable'))
                        this.model.disabledItemIndex.push(indx);
                this._disableTabs();
                var data = {
                    removedTab: removedTab
                };
                this._onRemove(data);
            }
            if (this.getItemsCount() == 0) {
                this.itemsContainer.removeAttr("style")
                this.itemsContainer.find("div").remove()
            }
            if (this._tabContentsHeight() < Number(this.model.height) && this.itemsContainer.css("clip").split("px").length && this.model.enableTabScroll && (this.model.headerPosition == "left" || this.model.headerPosition == "right")) {
                this._refresh();
                this.itemsContainer.removeAttr("style");
                this._leftScrollIcon ? this._leftScrollIcon.remove() : "";
                this._rightScrollIcon ? this._rightScrollIcon.remove() : "";
            }
            else if (this.model.enableTabScroll && (this.model.headerPosition == "left" || this.model.headerPosition == "right")) {
                if (this._leftScrollIcon && Number(this.itemsContainer.css("clip").split("px")[0].replace(",", "").split("(")[1]) != -(Number(this._leftScrollIcon.css("margin-top").split("px")[0]))) {
                    this._removeScroll();
                    this._addScroll();
                } else
                    this.refreshTabScroll();
                this.showItem(this.selectedItemIndex())
            }

        },

        show: function () {
            if (!this.model.enabled) return false;
            this.element.css("visibility", "visible");
        },

        hide: function () {
            if (!this.model.enabled) return false;
            this.element.css("visibility", "hidden");
        },

        _onBeforeLoad: function (link) {
            var data;
            if (this.selectedItemIndex() == -1 && this.model.collapsible)
                data = { prevActiveHeader: this.items[this._preTabIndex], prevActiveIndex: this._preTabIndex, activeHeader: null, activeIndex: null, url: link, isInteraction: this._isInteraction };
            else
                data = { prevActiveHeader: this.items[this._preTabIndex], prevActiveIndex: this._preTabIndex, activeHeader: this.items[this.selectedItemIndex()], activeIndex: this.selectedItemIndex(), url: link, isInteraction: this._isInteraction };
            return this._trigger("ajaxBeforeLoad", data);
        },

        _focusIn: function () {
            if (!this.model.readOnly && this.model.allowKeyboardNavigation)
                $(this.element).on("keydown", $.proxy(this._keyPress, this));
        },

        _focusOut: function (e) {
            $(this.element).off("keydown", $.proxy(this._keyPress, this));
        },

        _onLoad: function (link) {
            var data;
            if (this.selectedItemIndex() == -1 && this.model.collapsible)
                data = { prevActiveHeader: this.items[this._preTabIndex], prevActiveIndex: this._preTabIndex, activeHeader: null, activeIndex: null, url: link, isInteraction: this._isInteraction };
            else
                data = { prevActiveHeader: this.items[this._preTabIndex], prevActiveIndex: this._preTabIndex, activeHeader: this.items[this.selectedItemIndex()], activeIndex: this.selectedItemIndex(), url: link, isInteraction: this._isInteraction };
            return this._trigger("ajaxLoad", data);
        },

        _onActive: function () {
            var data;
            if (this.selectedItemIndex() == -1 && this.model.collapsible)
                data = { prevActiveHeader: this.items[this._preTabIndex], prevActiveIndex: this._preTabIndex, activeHeader: null, activeIndex: null, isInteraction: this._isInteraction };
            else
                data = { prevActiveHeader: this.items[this._preTabIndex], prevActiveIndex: this._preTabIndex, activeHeader: this.items[this.selectedItemIndex()], activeIndex: this.selectedItemIndex(), isInteraction: this._isInteraction };
            this._isInteraction = true;
            return this._trigger("itemActive", data);

        },

        _onBeforeActive: function (index) {
            if (this.model.beforeActive != null) {
                var data;
                if (this.selectedItemIndex() == -1 && this.model.collapsible)
                    data = { prevActiveHeader: this.items[this._preTabSelectedIndex], prevActiveIndex: this._preTabSelectedIndex, activeHeader: null, activeIndex: null, isInteraction: this._isInteraction };
                else
                    data = { prevActiveHeader: this.items[this._preTabSelectedIndex], prevActiveIndex: this._preTabSelectedIndex, activeHeader: this.items[index], activeIndex: index, isInteraction: this._isInteraction };
                return this._trigger("beforeActive", data);
            }
        },

        _onAdd: function (data) {
            return this._trigger("itemAdd", data);
        },

        _onRemove: function (data) {
            return this._trigger("itemRemove", data);
        },

        _onBrforeRemove: function (data) {
            return this._trigger("beforeItemRemove", data);
        }
    });

    ej.Tab.HeightAdjustMode = {
        /**  Panel height adjusts based on the content */
        Content: "content",
        /**  All panel height will be set the tallest panel height. */
        Auto: "auto",
        /**  Content panel take based on the parent height. */
        Fill: "fill",
        /**  Content panel take based on the height property. */
        None: "none"
    };

    ej.Tab.Position = {
        /**  Tab headers display to top position. */
        Top: "top",
        /**  Tab headers display to bottom position. */
        Bottom: "bottom",
        /**  Tab headers display to left position. */
        Left: "left",
        /** Tab headers display to right position. */
        Right: "right"
    };

})(jQuery, Syncfusion);;