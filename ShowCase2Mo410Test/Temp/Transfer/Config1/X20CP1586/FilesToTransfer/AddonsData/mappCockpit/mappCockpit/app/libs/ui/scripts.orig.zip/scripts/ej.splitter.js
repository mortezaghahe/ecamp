﻿/*!
*  filename: ej.splitter.js
*  version : 16.4.0.52
*  Copyright Syncfusion Inc. 2001 - 2019. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
*/


window.ej = window.Syncfusion = window.Syncfusion || {};


(function ($, ej, undefined) {
    'use strict';

    ej.version = "16.4.0.52";

    ej.consts = {
        NamespaceJoin: '-'
    };
    ej.TextAlign = {
        Center: 'center',
        Justify: 'justify',
        Left: 'left',
        Right: 'right'
    };
    ej.Orientation = { Horizontal: "horizontal", Vertical: "vertical" };

    ej.serverTimezoneOffset = 0;

    ej.parseDateInUTC = false;

    ej.persistStateVersion = null;

    ej.locales = ej.locales || [];

    if (!Object.prototype.hasOwnProperty) {
        Object.prototype.hasOwnProperty = function (obj, prop) {
            return obj[prop] !== undefined;
        };
    }

    //to support toISOString() in IE8
    if (!Date.prototype.toISOString) {
        (function () {
            function pad(number) {
                var r = String(number);
                if (r.length === 1) {
                    r = '0' + r;
                }
                return r;
            }
            Date.prototype.toISOString = function () {
                return this.getUTCFullYear()
                    + '-' + pad(this.getUTCMonth() + 1)
                    + '-' + pad(this.getUTCDate())
                    + 'T' + pad(this.getUTCHours())
                    + ':' + pad(this.getUTCMinutes())
                    + ':' + pad(this.getUTCSeconds())
                    + '.' + String((this.getUTCMilliseconds() / 1000).toFixed(3)).slice(2, 5)
                    + 'Z';
            };
        }());
    }

    String.format = function () {
        var source = arguments[0];
        for (var i = 0; i < arguments.length - 1; i++)
            source = source.replace(new RegExp("\\{" + i + "\\}", "gm"), arguments[i + 1]);

        source = source.replace(/\{[0-9]\}/g, "");
        return source;
    };

    jQuery.uaMatch = function (ua) {
        ua = ua.toLowerCase();

        var match = /(chrome)[ \/]([\w.]+)/.exec(ua) ||
            /(webkit)[ \/]([\w.]+)/.exec(ua) ||
            /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua) ||
            /(msie) ([\w.]+)/.exec(ua) ||
            ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua) ||
            [];

        return {
            browser: match[1] || "",
            version: match[2] || "0"
        };
    };
    // Function to create new class
    ej.defineClass = function (className, constructor, proto, replace) {
        /// <summary>Creates the javascript class with given namespace & class name & constructor etc</summary>
        /// <param name="className" type="String">class name prefixed with namespace</param>
        /// <param name="constructor" type="Function">constructor function</param>
        /// <param name="proto" type="Object">prototype for the class</param>
        /// <param name="replace" type="Boolean">[Optional]Replace existing class if exists</param>
        /// <returns type="Function">returns the class function</returns>
        if (!className || !proto) return undefined;

        var parts = className.split(".");

        // Object creation
        var obj = window, i = 0;
        for (; i < parts.length - 1; i++) {

            if (ej.isNullOrUndefined(obj[parts[i]]))
                obj[parts[i]] = {};

            obj = obj[parts[i]];
        }

        if (replace || ej.isNullOrUndefined(obj[parts[i]])) {

            //constructor
            constructor = typeof constructor === "function" ? constructor : function () {
            };

            obj[parts[i]] = constructor;

            // prototype
            obj[parts[i]].prototype = proto;
        }

        return obj[parts[i]];
    };

    ej.util = {
        getNameSpace: function (className) {
            /// <summary>Internal function, this will create namespace for plugins using class name</summary>
            /// <param name="className" type="String"></param>
            /// <returns type="String"></returns>
            var splits = className.toLowerCase().split(".");
            splits[0] === "ej" && (splits[0] = "e");

            return splits.join(ej.consts.NamespaceJoin);
        },

        getObject: function (nameSpace, from) {
            if (!from || !nameSpace) return undefined;
			(typeof(nameSpace) != "string") && (nameSpace = JSON.stringify(nameSpace));
            var value = from, splits = nameSpace.split('.');

            for (var i = 0; i < splits.length; i++) {

                if (ej.util.isNullOrUndefined(value)) break;

                value = value[splits[i]];
            }

            return value;
        },

        createObject: function (nameSpace, value, initIn) {
            var splits = nameSpace.split('.'), start = initIn || window, from = start, i, t, length = splits.length;

            for (i = 0; i < length; i++) {
                t = splits[i];
                if (i + 1 == length)
                    from[t] = value;
                else if (ej.isNullOrUndefined(from[t]))
                    from[t] = {};

                from = from[t];
            }

            return start;
        },

        isNullOrUndefined: function (value) {
            /// <summary>Util to check null or undefined</summary>
            /// <param name="value" type="Object"></param>
            /// <returns type="Boolean"></returns>
            return value === undefined || value === null;
        },
        exportAll: function (action, controlIds) {
            var inputAttr = [], widget, locale = [], index, controlEle, controlInstance, controlObject, modelClone;
            var attr = { action: action, method: 'post', "data-ajax": "false" };
            var form = ej.buildTag('form', "", null, attr);
            if (controlIds.length != 0) {
                for (var i = 0; i < controlIds.length; i++) {
                    index = i;
                    controlEle = $("#" + controlIds[i]);
                    controlInstance = $("#" + controlIds[i]).data();
                    widget = controlInstance["ejWidgets"];
                    controlObject = $(controlEle).data(widget[0]);
                    locale.push({ id: controlObject._id, locale: controlObject.model.locale });
                    if (!ej.isNullOrUndefined(controlObject)) {
                        modelClone = controlObject._getExportModel(controlObject.model);
                        inputAttr.push({ name: widget[0], type: 'hidden', value: controlObject.stringify(modelClone) });
                        var input = ej.buildTag('input', "", null, inputAttr[index]);
                        form.append(input);
                    }
                }
                $('body').append(form);
                form.submit();
                setTimeout(function () {
                    var ctrlInstance, ctrlObject;
                    if (locale.length) {
                        for (var j = 0; j < locale.length; j++) {
                            if (!ej.isNullOrUndefined(locale[j].locale)) {
                                ctrlInstance = $("#" + locale[j].id).data();
                                widget = ctrlInstance["ejWidgets"];
                                ctrlObject = $("#" + locale[j].id).data(widget[0]);
                                ctrlObject.model.locale = locale[j].locale;
                            }
                        }
                    }
                }, 0);
                form.remove();
            }
            return true;
        },
        print: function (element, printWin) {
            var $div = ej.buildTag('div')
            var elementClone = element.clone();
            $div.append(elementClone);
            if (!printWin)
                var printWin = window.open('', 'print', "height=452,width=1024,tabbar=no");
            printWin.document.write('<!DOCTYPE html>');
            var links = $('head').find('link').add("style");
            if (ej.browserInfo().name === "msie") {
                var a = ""
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.write('<html><head></head><body>' + a + $div[0].innerHTML + '</body></html>');
            }
            else {
                var a = ""
                printWin.document.write('<html><head>')
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.writeln(a + '</head><body>')
                printWin.document.writeln($div[0].innerHTML + '</body></html>')
            }
            printWin.document.close();
            printWin.focus();
            setTimeout(function () {
                if (!ej.isNullOrUndefined(printWin.window)) {
                    printWin.print();
                    setTimeout(function () { printWin.close() }, 1000);
                }
            }, 1000);
        },
        ieClearRemover: function (element) {
            var searchBoxHeight = $(element).height();
            element.style.paddingTop = parseFloat(searchBoxHeight / 2) + "px";
            element.style.paddingBottom = parseFloat(searchBoxHeight / 2) + "px";
            element.style.height = "1px";
            element.style.lineHeight = "1px";
        },
        //To send ajax request
        sendAjaxRequest: function (ajaxOptions) {
            $.ajax({
                type: ajaxOptions.type,
                cache: ajaxOptions.cache,
                url: ajaxOptions.url,
                dataType: ajaxOptions.dataType,
                data: ajaxOptions.data,
                contentType: ajaxOptions.contentType,
                async: ajaxOptions.async,
                success: ajaxOptions.successHandler,
                error: ajaxOptions.errorHandler,
                beforeSend: ajaxOptions.beforeSendHandler,
                complete: ajaxOptions.completeHandler
            });
        },

        buildTag: function (tag, innerHtml, styles, attrs) {
            /// <summary>Helper to build jQuery element</summary>
            /// <param name="tag" type="String">tagName#id.cssClass</param>
            /// <param name="innerHtml" type="String"></param>
            /// <param name="styles" type="Object">A set of key/value pairs that configure styles</param>
            /// <param name="attrs" type="Object">A set of key/value pairs that configure attributes</param>
            /// <returns type="jQuery"></returns>
            var tagName = /^[a-z]*[0-9a-z]+/ig.exec(tag)[0];

           var id = /#([_a-z0-9-&@\/\\,+()$~%:*?<>{}\[\]]+\S)/ig.exec(tag);
            id = id ? id[id.length - 1].replace(/[&@\/\\,+()$~%.:*?<>{}\[\]]/g, ''): undefined;

            var className = /\.([a-z]+[-_0-9a-z ]+)/ig.exec(tag);
            className = className ? className[className.length - 1] : undefined;

            return $(document.createElement(tagName))
                .attr(id ? { "id": id } : {})
                .addClass(className || "")
                .css(styles || {})
                .attr(attrs || {})
                .html(innerHtml || "");
        },
        _preventDefaultException: function (el, exceptions) {
            if (el) {
                for (var i in exceptions) {
                    if (exceptions[i].test(el[i])) {
                        return true;
                    }
                }
            }

            return false;
        },

        //Gets the maximum z-index in the document
        getMaxZindex: function () {
            var maxZ = 1;
            maxZ = Math.max.apply(null, $.map($('body *'), function (e, n) {
                if ($(e).css('position') == 'absolute' || $(e).css('position') == 'fixed')
                    return parseInt($(e).css('z-index')) || 1;
            })
            );
            if (maxZ == undefined || maxZ == null)
                maxZ = 1;
            return maxZ;
        },

        //To prevent default actions for the element
        blockDefaultActions: function (e) {
            e.cancelBubble = true;
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
            if (e.stopPropagation) e.stopPropagation();
        },

        //To get dimensions of the element when its hidden
        getDimension: function (element, method) {
            var value;
            var $hidden = $(element).parents().andSelf().filter(':hidden');
            if ($hidden) {
                var prop = { visibility: 'hidden', display: 'block' };
                var tmp = [];
                $hidden.each(function () {
                    var temp = {}, name;
                    for (name in prop) {
                        temp[name] = this.style[name];
                        this.style[name] = prop[name];
                    }
                    tmp.push(temp);
                });
                value = /(outer)/g.test(method) ?
                $(element)[method](true) :
               $(element)[method]();

                $hidden.each(function (i) {
                    var temp = tmp[i], name;
                    for (name in prop) {
                        this.style[name] = temp[name];
                    }
                });
            }
            return value;
        },
        //Get triggers when transition End
        transitionEndEvent: function () {
            var transitionEnd = {
                '': 'transitionend',
                'webkit': 'webkitTransitionEnd',
                'Moz': 'transitionend',
                'O': 'otransitionend',
                'ms': 'MSTransitionEnd'
            };

            return transitionEnd[ej.userAgent()];
        },
        //Get triggers when transition End
        animationEndEvent: function () {
            var animationEnd = {
                '': 'animationend',
                'webkit': 'webkitAnimationEnd',
                'Moz': 'animationend',
                'O': 'webkitAnimationEnd',
                'ms': 'animationend'
            };

            return animationEnd[ej.userAgent()];
        },
        //To return the start event to bind for element
        startEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchstart" : "mousedown";
        },
        //To return end event to bind for element
        endEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchend" : "mouseup"
        },
        //To return move event to bind for element
        moveEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? ($.support.hasPointer && !ej.isMobile()) ? "ejtouchmove" : "touchmove" : "mousemove";
        },
        //To return cancel event to bind for element
        cancelEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchcancel" : "mousecancel";
        },
        //To return tap event to bind for element
        tapEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "tap" : "click";
        },
        //To return tap hold event to bind for element
        tapHoldEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "taphold" : "click";
        },
        //To check whether its Device
        isDevice: function () {
            if (ej.getBooleanVal($('head'), 'data-ej-forceset', false))
                return ej.getBooleanVal($('head'), 'data-ej-device', this._device());
            else
                return this._device();
        },
        //To check whether its portrait or landscape mode
        isPortrait: function () {
            var elem = document.documentElement;
            return (elem) && ((elem.clientWidth / elem.clientHeight) < 1.1);
        },
        //To check whether its in lower resolution
        isLowerResolution: function () {
            return ((window.innerWidth <= 640 && ej.isPortrait() && ej.isDevice()) || (window.innerWidth <= 800 && !ej.isDevice()) || (window.innerWidth <= 800 && !ej.isPortrait() && ej.isWindows() && ej.isDevice()) || ej.isMobile());
        },
        //To check whether its iOS web view
        isIOSWebView: function () {
            return (/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(navigator.userAgent));
        },
        //To check whether its Android web view
        isAndroidWebView: function () {
            return (!(typeof (Android) === "undefined"));
        },
        //To check whether its windows web view
        isWindowsWebView: function () {
            return location.href.indexOf("x-wmapp") != -1;
        },
        _device: function () {
            return (/Android|BlackBerry|iPhone|iPad|iPod|IEMobile|kindle|windows\sce|palm|smartphone|iemobile|mobile|pad|xoom|sch-i800|playbook/i.test(navigator.userAgent.toLowerCase()));
        },
        //To check whether its Mobile
        isMobile: function () {
            return ((/iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/i.test(navigator.userAgent.toLowerCase()) && /mobile/i.test(navigator.userAgent.toLowerCase()))) || (ej.getBooleanVal($('head'), 'data-ej-mobile', false) === true);
        },
        //To check whether its Tablet
        isTablet: function () {
            return (/ipad|xoom|sch-i800|playbook|tablet|kindle/i.test(navigator.userAgent.toLowerCase())) || (ej.getBooleanVal($('head'), 'data-ej-tablet', false) === true) || (!ej.isMobile() && ej.isDevice());
        },
        //To check whether its Touch Device
        isTouchDevice: function () {
            return (('ontouchstart' in window || (window.navigator.msPointerEnabled && ej.isMobile())) && this.isDevice());
        },
        //To get the outerHTML string for object
        getClearString: function (string) {
            return $.trim(string.replace(/\s+/g, " ").replace(/(\r\n|\n|\r)/gm, "").replace(new RegExp("\>[\n\t ]+\<", "g"), "><"));
        },
        //Get the attribute value with boolean type of element
        getBooleanVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value.toLowerCase() == "true";
            else
                return option;
        },
        //Gets the Skew class based on the element current position
        _getSkewClass: function (item, pageX, pageY) {
            var itemwidth = item.width();
            var itemheight = item.height();
            var leftOffset = item.offset().left;
            var rightOffset = item.offset().left + itemwidth;
            var topOffset = item.offset().top;
            var bottomOffset = item.offset().top + itemheight;
            var widthoffset = itemwidth * 0.3;
            var heightoffset = itemheight * 0.3;
            if (pageX < leftOffset + widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topleft";
            if (pageX > rightOffset - widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topright";
            if (pageX > rightOffset - widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomright";
            if (pageX < leftOffset + widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomleft";
            if (pageX > leftOffset + widthoffset && pageY < topOffset + heightoffset && pageX < rightOffset - widthoffset)
                return "e-m-skew-top";
            if (pageX < leftOffset + widthoffset)
                return "e-m-skew-left";
            if (pageX > rightOffset - widthoffset)
                return "e-m-skew-right";
            if (pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottom";
            return "e-m-skew-center";
        },
        //Removes the added Skew class on the element
        _removeSkewClass: function (element) {
            $(element).removeClass("e-m-skew-top e-m-skew-bottom e-m-skew-left e-m-skew-right e-m-skew-topleft e-m-skew-topright e-m-skew-bottomleft e-m-skew-bottomright e-m-skew-center e-skew-top e-skew-bottom e-skew-left e-skew-right e-skew-topleft e-skew-topright e-skew-bottomleft e-skew-bottomright e-skew-center");
        },
        //Object.keys  method to support all the browser including IE8.
        _getObjectKeys: function (obj) {
            var i, keys = [];
            obj = Object.prototype.toString.call(obj) === Object.prototype.toString() ? obj : {};
            if (!Object.keys) {
                for (i in obj) {
                    if (obj.hasOwnProperty(i))
                        keys.push(i);
                }
                return keys;
            }
            if (Object.keys)
                return Object.keys(obj);
        },
        _touchStartPoints: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt;
                object._distX = 0;
                object._distY = 0;
                object._moved = false;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
            }
        },
        _isTouchMoved: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt,
                deltaX = point.pageX - object._pointX,
                deltaY = point.pageY - object._pointY,
                timestamp = Date.now(),
                newX, newY,
                absDistX, absDistY;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
                object._distX += deltaX;
                object._distY += deltaY;
                absDistX = Math.abs(object._distX);
                absDistY = Math.abs(object._distY);
                return !(absDistX < 5 && absDistY < 5);
            }
        },
        //To bind events for element
        listenEvents: function (selectors, eventTypes, handlers, remove, pluginObj, disableMouse) {
            for (var i = 0; i < selectors.length; i++) {
                ej.listenTouchEvent(selectors[i], eventTypes[i], handlers[i], remove, pluginObj, disableMouse);
            }
        },
        //To bind touch events for element
        listenTouchEvent: function (selector, eventType, handler, remove, pluginObj, disableMouse) {
            var event = remove ? "removeEventListener" : "addEventListener";
            var jqueryEvent = remove ? "off" : "on";
            var elements = $(selector);
            for (var i = 0; i < elements.length; i++) {
                var element = elements[i];
                switch (eventType) {
                    case "touchstart":
                        ej._bindEvent(element, event, eventType, handler, "mousedown", "MSPointerDown", "pointerdown", disableMouse);
                        break;
                    case "touchmove":
                        ej._bindEvent(element, event, eventType, handler, "mousemove", "MSPointerMove", "pointermove", disableMouse);
                        break;
                    case "touchend":
                        ej._bindEvent(element, event, eventType, handler, "mouseup", "MSPointerUp", "pointerup", disableMouse);
                        break;
                    case "touchcancel":
                        ej._bindEvent(element, event, eventType, handler, "mousecancel", "MSPointerCancel", "pointercancel", disableMouse);
                        break;
                    case "tap": case "taphold": case "ejtouchmove": case "click":
                        $(element)[jqueryEvent](eventType, handler);
                        break;
                    default:
                        if (ej.browserInfo().name == "msie" && ej.browserInfo().version < 9)
                            pluginObj["_on"]($(element), eventType, handler);
                        else
                            element[event](eventType, handler, true);
                        break;
                }
            }
        },
        //To bind events for element
        _bindEvent: function (element, event, eventType, handler, mouseEvent, pointerEvent, ie11pointerEvent, disableMouse) {
            if ($.support.hasPointer)
                element[event](window.navigator.pointerEnabled ? ie11pointerEvent : pointerEvent, handler, true);
            else
                element[event](eventType, handler, true);
        },
        _browser: function () {
            return (/webkit/i).test(navigator.appVersion) ? 'webkit' : (/firefox/i).test(navigator.userAgent) ? 'Moz' : (/trident/i).test(navigator.userAgent) ? 'ms' : 'opera' in window ? 'O' : '';
        },
        styles: document.createElement('div').style,
        /**
       * To get the userAgent Name     
       * @example             
       * &lt;script&gt;
       *       ej.userAgent();//return user agent name
       * &lt;/script&gt         
       * @memberof AppView
       * @instance
       */
        userAgent: function () {
            var agents = 'webkitT,t,MozT,msT,OT'.split(','),
            t,
            i = 0,
            l = agents.length;

            for (; i < l; i++) {
                t = agents[i] + 'ransform';
                if (t in ej.styles) {
                    return agents[i].substr(0, agents[i].length - 1);
                }
            }

            return false;
        },
        addPrefix: function (style) {
            if (ej.userAgent() === '') return style;

            style = style.charAt(0).toUpperCase() + style.substr(1);
            return ej.userAgent() + style;
        },
        //To Prevent Default Exception

        //To destroy the mobile widgets
        destroyWidgets: function (element) {
            var dataEl = $(element).find("[data-role *= ejm]");
            dataEl.each(function (index, element) {
                var $element = $(element);
                var plugin = $element.data("ejWidgets");
                if (plugin)
                    $element[plugin]("destroy");
            });
        },
        //Get the attribute value of element
        getAttrVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value;
            else
                return option;
        },

        // Get the offset value of element
        getOffset: function (ele) {
            var pos = {};
            var offsetObj = ele.offset() || { left: 0, top: 0 };
            $.extend(true, pos, offsetObj);
            if ($("body").css("position") != "static") {
                var bodyPos = $("body").offset();
                pos.left -= bodyPos.left;
                pos.top -= bodyPos.top;
            }
            return pos;
        },

        // Z-index calculation for the element
        getZindexPartial: function (element, popupEle) {
            if (!ej.isNullOrUndefined(element) && element.length > 0) {
                var parents = element.parents(), bodyEle;
                bodyEle = $('body').children();
                if (!ej.isNullOrUndefined(element) && element.length > 0)
                    bodyEle.splice(bodyEle.index(popupEle), 1);
                $(bodyEle).each(function (i, ele) { parents.push(ele); });

                var maxZ = Math.max.apply(maxZ, $.map(parents, function (e, n) {
                    if ($(e).css('position') != 'static') return parseInt($(e).css('z-index')) || 1;
                }));
                if (!maxZ || maxZ < 10000) maxZ = 10000;
                else maxZ += 1;
                return maxZ;
            }
        },

        isValidAttr: function (element, attribute) {
            var element = $(element)[0];
            if (typeof element[attribute] != "undefined")
                return true;
            else {
                var _isValid = false;
                $.each(element, function (key) {
                    if (key.toLowerCase() == attribute.toLowerCase()) {
                        _isValid = true;
                        return false;
                    }
                });
            }
            return _isValid;
        }

    };

    $.extend(ej, ej.util);

    // base class for all ej widgets. It will automatically inhertied
    ej.widgetBase = {
        droppables: { 'default': [] },
        resizables: { 'default': [] },

        _renderEjTemplate: function (selector, data, index, prop, ngTemplateType) {
            var type = null;
            if (typeof selector === "object" || selector.startsWith("#") || selector.startsWith("."))
                type = $(selector).attr("type");
            if (type) {
                type = type.toLowerCase();
                if (ej.template[type])
                    return ej.template[type](this, selector, data, index, prop);
            }
            // For ejGrid Angular2 Template Support
            else if (!ej.isNullOrUndefined(ngTemplateType))
                 return ej.template['text/x-'+ ngTemplateType](this, selector, data, index, prop);
            return ej.template.render(this, selector, data, index, prop);
        },

        destroy: function () {

            if (this._trigger("destroy"))
                return;

            if (this.model.enablePersistence) {
                this.persistState();
                $(window).off("unload", this._persistHandler);
            }

            try {
                this._destroy();
            } catch (e) { }

            var arr = this.element.data("ejWidgets") || [];
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] == this.pluginName) {
                    arr.splice(i, 1);
                }
            }
            if (!arr.length)
                this.element.removeData("ejWidgets");

            while (this._events) {
                var item = this._events.pop(), args = [];

                if (!item)
                    break;

                for (var i = 0; i < item[1].length; i++)
                    if (!$.isPlainObject(item[1][i]))
                        args.push(item[1][i]);

                $.fn.off.apply(item[0], args);
            }

            this._events = null;

            this.element
                .removeClass(ej.util.getNameSpace(this.sfType))
                .removeClass("e-js")
                .removeData(this.pluginName);

            this.element = null;
            this.model = null;
        },

        _on: function (element) {
            if (!this._events)
                this._events = [];
            var args = [].splice.call(arguments, 1, arguments.length - 1);

            var handler = {}, i = args.length;
            while (handler && typeof handler !== "function") {
                handler = args[--i];
            }

            args[i] = ej.proxy(args[i], this);

            this._events.push([element, args, handler, args[i]]);

            $.fn.on.apply(element, args);

            return this;
        },

        _off: function (element, eventName, selector, handlerObject) {
            var e = this._events, temp;
            if (!e || !e.length)
                return this;
            if (typeof selector == "function") {
                temp = handlerObject;
                handlerObject = selector;
                selector = temp;
            }
            var t = (eventName.match(/\S+/g) || [""]);
            for (var i = 0; i < e.length; i++) {
                var arg = e[i],
                r = arg[0].length && (!handlerObject || arg[2] === handlerObject) && (arg[1][0] === eventName || t[0]) && (!selector || arg[1][1] === selector) && $.inArray(element[0], arg[0]) > -1;
                if (r) {
                    $.fn.off.apply(element, handlerObject ? [eventName, selector, arg[3]] : [eventName, selector]);
                    e.splice(i, 1);
                    break;
                }
            }

            return this;
        },

        // Client side events wire-up / trigger helper.
        _trigger: function (eventName, eventProp) {
            var fn = null, returnValue, args, clientProp = {};
            $.extend(clientProp, eventProp)

            if (eventName in this.model)
                fn = this.model[eventName];

            if (fn) {
                if (typeof fn === "string") {
                    fn = ej.util.getObject(fn, window);
                }

                if ($.isFunction(fn)) {

                    args = ej.event(eventName, this.model, eventProp);

                    
                    returnValue = fn.call(this, args);

                    // sending changes back - deep copy option should not be enabled for this $.extend 
                    if (eventProp) $.extend(eventProp, args);

                    if (args.cancel || !ej.isNullOrUndefined(returnValue))
                        return returnValue === false || args.cancel;
                }
            }

            var isPropDefined = Boolean(eventProp);
            eventProp = eventProp || {};
            eventProp.originalEventType = eventName;
            eventProp.type = this.pluginName + eventName;

            args = $.Event(eventProp.type, ej.event(eventProp.type, this.model, eventProp));

            this.element && this.element.trigger(args);

            // sending changes back - deep copy option should not be enabled for this $.extend 
            if (isPropDefined) $.extend(eventProp, args);

            if (ej.isOnWebForms && args.cancel == false && this.model.serverEvents && this.model.serverEvents.length)
                ej.raiseWebFormsServerEvents(eventName, eventProp, clientProp);

            return args.cancel;
        },

        setModel: function (options, forceSet) {
            // check for whether to apply values are not. if _setModel function is defined in child,
            //  this will call that function and validate it using return value

            if (this._trigger("modelChange", { "changes": options }))
                return;

            for (var prop in options) {
                if (!forceSet) {
                    if (this.model[prop] === options[prop]) {
                        delete options[prop];
                        continue;
                    }
                    if ($.isPlainObject(options[prop])) {
                        iterateAndRemoveProps(this.model[prop], options[prop]);
                        if ($.isEmptyObject(options[prop])) {
                            delete options[prop];
                            continue;
                        }
                    }
                }

                if (this.dataTypes) {
                    var returnValue = this._isValidModelValue(prop, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + prop + " - " + returnValue;
                }
                if (this.model.notifyOnEachPropertyChanges && this.model[prop] !== options[prop]) {
                    var arg = {
                        oldValue: this.model[prop],
                        newValue: options[prop]
                    };

                    options[prop] = this._trigger(prop + "Change", arg) ? this.model[prop] : arg.newValue;
                }
            }
            if ($.isEmptyObject(options))
                return;

            if (this._setFirst) {
                var ds = options.dataSource;
                if (ds) delete options.dataSource;

                $.extend(true, this.model, options);
                if (ds) {
                    this.model.dataSource = (ds instanceof Array) ? ds.slice() : ds;
                    options["dataSource"] = this.model.dataSource;
                }
                !this._setModel || this._setModel(options);

            } else if (!this._setModel || this._setModel(options) !== false) {
                $.extend(true, this.model, options);
            }
            if ("enablePersistence" in options) {
                this._setState(options.enablePersistence);
            }
        },
        option: function (prop, value, forceSet) {
            if (!prop)
                return this.model;

            if ($.isPlainObject(prop))
                return this.setModel(prop, forceSet);

            if (typeof prop === "string") {
                prop = prop.replace(/^model\./, "");
                var oldValue = ej.getObject(prop, this.model);

                if (value === undefined && !forceSet)
                    return oldValue;

                if (prop === "enablePersistence")
                    return this._setState(value);

                if (forceSet && value === ej.extensions.modelGUID) {
                    return this._setModel(ej.createObject(prop, ej.getObject(prop, this.model), {}));
                }

                if (forceSet || ej.getObject(prop, this.model) !== value)
                    return this.setModel(ej.createObject(prop, value, {}), forceSet);
            }
            return undefined;
        },

        _isValidModelValue: function (prop, types, options) {
            var value = types[prop], option = options[prop], returnValue;

            if (!value)
                return true;

            if (typeof value === "string") {
                if (value == "enum") {
                    options[prop] = option ? option.toString().toLowerCase() : option;
                    value = "string";
                }

                if (value === "array") {
                    if (Object.prototype.toString.call(option) === '[object Array]')
                        return true;
                }
                else if (value === "data") {
                    return true;
                }
                else if (value === "parent") {
                    return true;
                }
                else if (typeof option === value)
                    return true;

                return "Expected type - " + value;
            }

            if (option instanceof Array) {
                for (var i = 0; i < option.length; i++) {
                    returnValue = this._isValidModelValue(prop, types, option[i]);
                    if (returnValue !== true) {
                        return " [" + i + "] - " + returnValue;
                    }
                }
                return true;
            }

            for (var innerProp in option) {
                returnValue = this._isValidModelValue(innerProp, value, option);
                if (returnValue !== true)
                    return innerProp + " : " + returnValue;
            }

            return true;
        },

        _returnFn: function (obj, propName) {
            if (propName.indexOf('.') != -1) {
                this._returnFn(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
            }
            else
                obj[propName] = obj[propName].call(obj.propName);
        },

        _removeCircularRef: function (obj) {
            var seen = [];
            function detect(obj, key, parent) {
                if (typeof obj != 'object') { return; }
                if (!Array.prototype.indexOf) {
                    Array.prototype.indexOf = function (val) {
                        return jQuery.inArray(val, this);
                    };
                }
                if (seen.indexOf(obj) >= 0) {
                    delete parent[key];
                    return;
                }
                seen.push(obj);
                for (var k in obj) { //dive on the object's children
                    if (obj.hasOwnProperty(k)) { detect(obj[k], k, obj); }
                }
                seen.pop();
                return;
            }
            detect(obj, 'obj', null);
            return obj;
        },

        stringify: function (model, removeCircular) {
            var observables = this.observables;
            for (var k = 0; k < observables.length; k++) {
                var val = ej.getObject(observables[k], model);
                if (!ej.isNullOrUndefined(val) && typeof (val) === "function")
                    this._returnFn(model, observables[k]);
            }
            if (removeCircular) model = this._removeCircularRef(model);
            return JSON.stringify(model);
        },

        _setState: function (val) {
            if (val === true) {
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
            } else {
                this.deleteState();
                $(window).off("unload", this._persistHandler);
            }
        },

        _removeProp: function (obj, propName) {
            if (!ej.isNullOrUndefined(obj)) {
                if (propName.indexOf('.') != -1) {
                    this._removeProp(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
                }
                else
                    delete obj[propName];
            }
        },

        persistState: function () {
            var model;

            if (this._ignoreOnPersist) {
                model = copyObject({}, this.model);
                for (var i = 0; i < this._ignoreOnPersist.length; i++) {
                    this._removeProp(model, this._ignoreOnPersist[i]);
                }
                model.ignoreOnPersist = this._ignoreOnPersist;
            } else if (this._addToPersist) {
                model = {};
                for (var i = 0; i < this._addToPersist.length; i++) {
                    ej.createObject(this._addToPersist[i], ej.getObject(this._addToPersist[i], this.model), model);
                }
                model.addToPersist = this._addToPersist;
            } else {
                model = copyObject({}, this.model);
            }

            if (this._persistState) {
                model.customPersists = {};
                this._persistState(model.customPersists);
            }

            if (window.localStorage) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") == null)
                    window.localStorage.setItem("persistKey", ej.persistStateVersion);
                window.localStorage.setItem("$ej$" + this.pluginName + this._id, JSON.stringify(model));
            }
            else if (document.cookie) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") == null)
                    ej.cookie.set("persistKey", ej.persistStateVersion);
                ej.cookie.set("$ej$" + this.pluginName + this._id, model);
            }
        },

        deleteState: function () {
            if (window.localStorage)
                window.localStorage.removeItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                ej.cookie.set("$ej$" + this.pluginName + this._id, model, new Date());
        },

        restoreState: function (silent) {
            var value = null;
            if (window.localStorage)
                value = window.localStorage.getItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                value = ej.cookie.get("$ej$" + this.pluginName + this._id);

            if (value) {
                var model = JSON.parse(value);

                if (this._restoreState) {
                    this._restoreState(model.customPersists);
                    delete model.customPersists;
                }

                if (ej.isNullOrUndefined(model) === false)
                    if (!ej.isNullOrUndefined(model.ignoreOnPersist)) {
                        this._ignoreOnPersist = model.ignoreOnPersist;
                        delete model.ignoreOnPersist;
                    } else if (!ej.isNullOrUndefined(model.addToPersist)) {
                        this._addToPersist = model.addToPersist;
                        delete model.addToPersist;
                    }
            }
            if (!ej.isNullOrUndefined(model) && !ej.isNullOrUndefined(this._ignoreOnPersist)) {
                for(var i = 0, len =  this._ignoreOnPersist.length; i < len; i++) {
					if (this._ignoreOnPersist[i].indexOf('.') !== -1)
                        ej.createObject(this._ignoreOnPersist[i], ej.getObject(this._ignoreOnPersist[i], this.model), model);
                    else
                        model[this._ignoreOnPersist[i]] = this.model[this._ignoreOnPersist[i]];
				}
                this.model = model;
            }
            else
                this.model = $.extend(true, this.model, model);

            if (!silent && value && this._setModel)
                this._setModel(this.model);
        },

        //to prevent persistence
        ignoreOnPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    this._ignoreOnPersist.push(collection[i]);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    var index = this._addToPersist.indexOf(collection[i]);
                    this._addToPersist.splice(index, 1);
                }
            }
        },

        //to maintain persistence
        addToPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    var index = this._ignoreOnPersist.indexOf(collection[i]);
                    this._ignoreOnPersist.splice(index, 1);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    if ($.inArray(collection[i], this._addToPersist) === -1)
                        this._addToPersist.push(collection[i]);
                }
            }
        },

        // Get formatted text 
        formatting: function (formatstring, str, locale) {
            formatstring = formatstring.replace(/%280/g, "\"").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
            locale = ej.preferredCulture(locale) ? locale : "en-US";
            var s = formatstring;
            var frontHtmlidx, FrontHtml, RearHtml, lastidxval;
            frontHtmlidx = formatstring.split("{0:");
            lastidxval = formatstring.split("}");
            FrontHtml = frontHtmlidx[0];
            RearHtml = lastidxval[1];
            if (typeof (str) == "string" && $.isNumeric(str))
                str = Number(str);
            if (formatstring.indexOf("{0:") != -1) {
                var toformat = new RegExp("\\{0(:([^\\}]+))?\\}", "gm");
                var formatVal = toformat.exec(formatstring);
                if (formatVal != null && str != null) {
                    if (FrontHtml != null && RearHtml != null)
                        str = FrontHtml + ej.format(str, formatVal[2], locale) + RearHtml;
                    else
                        str = ej.format(str, formatVal[2], locale);
                } else if (str != null)
                    str = str;
                else
                    str = "";
                return str;
            } else if (s.startsWith("{") && !s.startsWith("{0:")) {
                var fVal = s.split(""), str = (str || "") + "", strSplt = str.split(""), formats = /[0aA\*CN<>\?]/gm;
                for (var f = 0, f, val = 0; f < fVal.length; f++)
                    fVal[f] = formats.test(fVal[f]) ? "{" + val++ + "}" : fVal[f];
                return String.format.apply(String, [fVal.join("")].concat(strSplt)).replace('{', '').replace('}', '');
            } else if (this.data != null && this.data.Value == null) {
                $.each(this.data, function (dataIndex, dataValue) {
                    s = s.replace(new RegExp('\\{' + dataIndex + '\\}', 'gm'), dataValue);
                });
                return s;
            } else {
                return this.data.Value;
            }
        },
    };

    ej.WidgetBase = function () {
    }

    var iterateAndRemoveProps = function (source, target) {
		if(source instanceof Array) {
			for (var i = 0, len = source.length; i < len; i++) {
				prop = source[i];
				if(prop === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(prop))
					iterateAndRemoveProps(prop, target[prop]);
			}
		}
		else {
			for (var prop in source) {
				if (source[prop] === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(source[prop]))
					iterateAndRemoveProps(source[prop], target[prop]);
			}
		}
    }

    ej.widget = function (pluginName, className, proto) {
        /// <summary>Widget helper for developers, this set have predefined function to jQuery plug-ins</summary>
        /// <param name="pluginName" type="String">the plugin name that will be added in jquery.fn</param>
        /// <param name="className" type="String">the class name for your plugin, this will help create default cssClas</param>
        /// <param name="proto" type="Object">prototype for of the plug-in</param>

        if (typeof pluginName === "object") {
            proto = className;
            for (var prop in pluginName) {
                var name = pluginName[prop];

                if (name instanceof Array) {
                    proto._rootCSS = name[1];
                    name = name[0];
                }

                ej.widget(prop, name, proto);

                if (pluginName[prop] instanceof Array)
                    proto._rootCSS = "";
            }

            return;
        }

        var nameSpace = proto._rootCSS || ej.getNameSpace(className);

        proto = ej.defineClass(className, function (element, options) {

            this.sfType = className;
            this.pluginName = pluginName;
            this.instance = pInstance;

            if (ej.isNullOrUndefined(this._setFirst))
                this._setFirst = true;

            this["ob.values"] = {};

            $.extend(this, ej.widgetBase);

            if (this.dataTypes) {
                for (var property in options) {
                    var returnValue = this._isValidModelValue(property, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + property + " - " + returnValue;
                }
            }

            var arr = (element.data("ejWidgets") || []);
            arr.push(pluginName);
            element.data("ejWidgets", arr);

            for (var i = 0; ej.widget.observables && this.observables && i < this.observables.length; i++) {
                var t = ej.getObject(this.observables[i], options);
                if (t) ej.createObject(this.observables[i], ej.widget.observables.register(t, this.observables[i], this, element), options);
            }

            this.element = element.jquery ? element : $(element);
            this.model = copyObject(true, {}, proto.prototype.defaults, options);
            this.model.keyConfigs = copyObject(this.keyConfigs);

            this.element.addClass(nameSpace + " e-js").data(pluginName, this);

            this._id = element[0].id;

            if (this.model.enablePersistence) {
                if (window.localStorage && !ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") != ej.persistStateVersion) {
                    for (var i in window.localStorage) {
                        if (i.indexOf("$ej$") != -1) {
                            window.localStorage.removeItem(i); //removing the previously stored plugin item from local storage
							window.localStorage.setItem("persistKey", ej.persistStateVersion);
						}				
                    }
                }
                else if (document.cookie && !ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") != ej.persistStateVersion) {
                    var splits = document.cookie.split(/; */);
                    for (var k in splits) {
                        if (k.indexOf("$ej$") != -1) {
                            ej.cookie.set(k.split("=")[0], model, new Date()); //removing the previously stored plugin item from local storage
							ej.cookie.set("persistKey", ej.persistStateVersion);
						}		
                    }
                }
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
                this.restoreState(true);
            }

            this._init(options);

            if (typeof this.model.keyConfigs === "object" && !(this.model.keyConfigs instanceof Array)) {
                var requiresEvt = false;
                if (this.model.keyConfigs.focus)
                    this.element.attr("accesskey", this.model.keyConfigs.focus);

                for (var keyProps in this.model.keyConfigs) {
                    if (keyProps !== "focus") {
                        requiresEvt = true;
                        break;
                    }
                }

                if (requiresEvt && this._keyPressed) {
                    var el = element, evt = "keydown";

                    if (this.keySettings) {
                        el = this.keySettings.getElement ? this.keySettings.getElement() || el : el;
                        evt = this.keySettings.event || evt;
                    }

                    this._on(el, evt, function (e) {
                        if (!this.model.keyConfigs) return;

                        var action = keyFn.getActionFromCode(this.model.keyConfigs, e.which, e.ctrlKey, e.shiftKey, e.altKey);
                        var arg = {
                            code: e.which,
                            ctrl: e.ctrlKey,
                            alt: e.altKey,
                            shift: e.shiftKey
                        };
                        if (!action) return;

                        if (this._keyPressed(action, e.target, arg, e) === false)
                            e.preventDefault();
                    });
                }
            }
            this._trigger("create");
        }, proto);

        $.fn[pluginName] = function (options) {
            var opt = options, args;
            for (var i = 0; i < this.length; i++) {

                var $this = $(this[i]),
                    pluginObj = $this.data(pluginName),
                    isAlreadyExists = pluginObj && $this.hasClass(nameSpace),
                    obj = null;

                if (this.length > 0 && $.isPlainObject(opt))
                    options = ej.copyObject({}, opt);

                // ----- plug-in creation/init
                if (!isAlreadyExists) {
                    if (proto.prototype._requiresID === true && !$(this[i]).attr("id")) {
                        $this.attr("id", getUid("ejControl_"));
                    }
                    if (!options || typeof options === "object") {
                        if (proto.prototype.defaults && !ej.isNullOrUndefined(ej.setCulture) && "locale" in proto.prototype.defaults && pluginName != "ejChart") {
                            if (options && !("locale" in options)) options.locale = ej.setCulture().name;
                            else if (ej.isNullOrUndefined(options)) {
                                options = {}; options.locale = ej.setCulture().name;
                            }
                        }
                        new proto($this, options);
                    }
                    else {
                        throwError(pluginName + ": methods/properties can be accessed only after plugin creation");
                    }
                    continue;
                }

                if (!options) continue;

                args = [].slice.call(arguments, 1);

                if (this.length > 0 && args[0] && opt === "option" && $.isPlainObject(args[0])) {
                    args[0] = ej.copyObject({}, args[0]);
                }

                // --- Function/property set/access
                if ($.isPlainObject(options)) {
                    // setModel using JSON object
                    pluginObj.setModel(options);
                }

                    // function/property name starts with "_" is private so ignore it.
                else if (options.indexOf('_') !== 0
                    && !ej.isNullOrUndefined(obj = ej.getObject(options, pluginObj))
                    || options.indexOf("model.") === 0) {

                    if (!obj || !$.isFunction(obj)) {

                        // if property is accessed, then break the jquery chain
                        if (arguments.length == 1)
                            return obj;

                        //setModel using string input
                        pluginObj.option(options, arguments[1]);

                        continue;
                    }

                    var value = obj.apply(pluginObj, args);

                    // If function call returns any value, then break the jquery chain
                    if (value !== undefined)
                        return value;

                } else {
                    throwError(className + ": function/property - " + options + " does not exist");
                }
            }
            if (pluginName.indexOf("ejm") != -1)
                ej.widget.registerInstance($this, pluginName, className, proto.prototype);
            // maintaining jquery chain
            return this;
        };

        ej.widget.register(pluginName, className, proto.prototype);
        ej.loadLocale(pluginName);
    };

    ej.loadLocale = function (pluginName) {
        var i, len, locales = ej.locales;
        for (i = 0, len = locales.length; i < len; i++)
            $.fn["Locale_" + locales[i]](pluginName);
    };


    $.extend(ej.widget, (function () {
        var _widgets = {}, _registeredInstances = [],

        register = function (pluginName, className, prototype) {
            if (!ej.isNullOrUndefined(_widgets[pluginName]))
                throwError("ej.widget : The widget named " + pluginName + " is trying to register twice.");

            _widgets[pluginName] = { name: pluginName, className: className, proto: prototype };

            ej.widget.extensions && ej.widget.extensions.registerWidget(pluginName);
        },
        registerInstance = function (element, pluginName, className, prototype) {
            _registeredInstances.push({ element: element, pluginName: pluginName, className: className, proto: prototype });
        }

        return {
            register: register,
            registerInstance: registerInstance,
            registeredWidgets: _widgets,
            registeredInstances: _registeredInstances
        };

    })());

    ej.widget.destroyAll = function (elements) {
        if (!elements || !elements.length) return;

        for (var i = 0; i < elements.length; i++) {
            var data = elements.eq(i).data(), wds = data["ejWidgets"];
            if (wds && wds.length) {
                for (var j = 0; j < wds.length; j++) {
                    if (data[wds[j]] && data[wds[j]].destroy)
                        data[wds[j]].destroy();
                }
            }
        }
    };

    ej.cookie = {
        get: function (name) {
            var value = RegExp(name + "=([^;]+)").exec(document.cookie);

            if (value && value.length > 1)
                return value[1];

            return undefined;
        },
        set: function (name, value, expiryDate) {
            if (typeof value === "object")
                value = JSON.stringify(value);

            value = escape(value) + ((expiryDate == null) ? "" : "; expires=" + expiryDate.toUTCString());
            document.cookie = name + "=" + value;
        }
    };

    var keyFn = {
        getActionFromCode: function (keyConfigs, keyCode, isCtrl, isShift, isAlt) {
            isCtrl = isCtrl || false;
            isShift = isShift || false;
            isAlt = isAlt || false;

            for (var keys in keyConfigs) {
                if (keys === "focus") continue;

                var key = keyFn.getKeyObject(keyConfigs[keys]);
                for (var i = 0; i < key.length; i++) {
                    if (keyCode === key[i].code && isCtrl == key[i].isCtrl && isShift == key[i].isShift && isAlt == key[i].isAlt)
                        return keys;
                }
            }
            return null;
        },
        getKeyObject: function (key) {
            var res = {
                isCtrl: false,
                isShift: false,
                isAlt: false
            };
            var tempRes = $.extend(true, {}, res);
            var $key = key.split(","), $res = [];
            for (var i = 0; i < $key.length; i++) {
                var rslt = null;
                if ($key[i].indexOf("+") != -1) {
                    var k = $key[i].split("+");
                    for (var j = 0; j < k.length; j++) {
                        rslt = keyFn.getResult($.trim(k[j]), res);
                    }
                }
                else {
                    rslt = keyFn.getResult($.trim($key[i]), $.extend(true, {}, tempRes));
                }
                $res.push(rslt);
            }
            return $res;
        },
        getResult: function (key, res) {
            if (key === "ctrl")
                res.isCtrl = true;
            else if (key === "shift")
                res.isShift = true;
            else if (key === "alt")
                res.isAlt = true;
            else res.code = parseInt(key, 10);
            return res;
        }
    };

    ej.getScrollableParents = function (element) {
        return $(element).parentsUntil("html").filter(function () {
            return $(this).css("overflow") != "visible";
        }).add($(window));
    }
    ej.browserInfo = function () {
        var browser = {}, clientInfo = [],
        browserClients = {
            opera: /(opera|opr)(?:.*version|)[ \/]([\w.]+)/i, edge: /(edge)(?:.*version|)[ \/]([\w.]+)/i, webkit: /(chrome)[ \/]([\w.]+)/i, safari: /(webkit)[ \/]([\w.]+)/i, msie: /(msie|trident) ([\w.]+)/i, mozilla: /(mozilla)(?:.*? rv:([\w.]+)|)/i
        };
        for (var client in browserClients) {
            if (browserClients.hasOwnProperty(client)) {
                clientInfo = navigator.userAgent.match(browserClients[client]);
                if (clientInfo) {
                    browser.name = clientInfo[1].toLowerCase() == "opr" ? "opera" : clientInfo[1].toLowerCase();
                    browser.version = clientInfo[2];
                    browser.culture = {};
                    browser.culture.name = browser.culture.language = navigator.language || navigator.userLanguage;
                    if (typeof (ej.globalize) != 'undefined') {
                        var oldCulture = ej.preferredCulture().name;
                        var culture = (navigator.language || navigator.userLanguage) ? ej.preferredCulture(navigator.language || navigator.userLanguage) : ej.preferredCulture("en-US");
                        for (var i = 0; (navigator.languages) && i < navigator.languages.length; i++) {
                            culture = ej.preferredCulture(navigator.languages[i]);
                            if (culture.language == navigator.languages[i])
                                break;
                        }
                        ej.preferredCulture(oldCulture);
                        $.extend(true, browser.culture, culture);
                    }
                    if (!!navigator.userAgent.match(/Trident\/7\./)) {
                        browser.name = "msie";
                    }
                    break;
                }
            }
        }
        browser.isMSPointerEnabled = (browser.name == 'msie') && browser.version > 9 && window.navigator.msPointerEnabled;
        browser.pointerEnabled = window.navigator.pointerEnabled;
        return browser;
    };
    ej.eventType = {
        mouseDown: "mousedown touchstart",
        mouseMove: "mousemove touchmove",
        mouseUp: "mouseup touchend",
        mouseLeave: "mouseleave touchcancel",
        click: "click touchend"
    };

    ej.event = function (type, data, eventProp) {

        var e = $.extend(eventProp || {},
            {
                "type": type,
                "model": data,
                "cancel": false
            });

        return e;
    };

    ej.proxy = function (fn, context, arg) {
        if (!fn || typeof fn !== "function")
            return null;

        if ('on' in fn && context)
            return arg ? fn.on(context, arg) : fn.on(context);

        return function () {
            var args = arg ? [arg] : []; args.push.apply(args, arguments);
            return fn.apply(context || this, args);
        };
    };

    ej.hasStyle = function (prop) {
        var style = document.documentElement.style;

        if (prop in style) return true;

        var prefixs = ['ms', 'Moz', 'Webkit', 'O', 'Khtml'];

        prop = prop[0].toUpperCase() + prop.slice(1);

        for (var i = 0; i < prefixs.length; i++) {
            if (prefixs[i] + prop in style)
                return true;
        }

        return false;
    };

    Array.prototype.indexOf = Array.prototype.indexOf || function (searchElement) {
        var len = this.length;

        if (len === 0) return -1;

        for (var i = 0; i < len; i++) {
            if (i in this && this[i] === searchElement)
                return i;
        }
        return -1;
    };

    String.prototype.startsWith = String.prototype.startsWith || function (key) {
        return this.slice(0, key.length) === key;
    };
    var copyObject = ej.copyObject = function (isDeepCopy, target) {
        var start = 2, current, source;
        if (typeof isDeepCopy !== "boolean") {
            start = 1;
        }
        var objects = [].slice.call(arguments, start);
        if (start === 1) {
            target = isDeepCopy;
            isDeepCopy = undefined;
        }

        for (var i = 0; i < objects.length; i++) {
            for (var prop in objects[i]) {
                current = target[prop], source = objects[i][prop];

                if (source === undefined || current === source || objects[i] === source || target === source)
                    continue;
                if (source instanceof Array) {
                    if (i === 0 && isDeepCopy) {
                        if (prop === "dataSource" || prop === "data" || prop === "predicates")
                            target[prop] = source.slice();
					  else  {
                        target[prop] = new Array();
                        for (var j = 0; j < source.length; j++) {
                            copyObject(true, target[prop], source);
                        }
					  }
                    }
                    else
                        target[prop] = source.slice();
                }
                else if (ej.isPlainObject(source)) {
                    target[prop] = current || {};
                    if (isDeepCopy)
                        copyObject(isDeepCopy, target[prop], source);
                    else
                        copyObject(target[prop], source);
                } else
                    target[prop] = source;
            }
        }
        return target;
    };
    var pInstance = function () {
        return this;
    }

    var _uid = 0;
    var getUid = function (prefix) {
        return prefix + _uid++;
    }

    ej.template = {};

    ej.template.render = ej.template["text/x-jsrender"] = function (self, selector, data, index, prop) {
        if (selector.slice(0, 1) !== "#")
            selector = ["<div>", selector, "</div>"].join("");
        var property = { prop: prop, index: index };
        return $(selector).render(data, property);
    }

    ej.isPlainObject = function (obj) {
        if (!obj) return false;
        if (ej.DataManager !== undefined && obj instanceof ej.DataManager) return false;
        if (typeof obj !== "object" || obj.nodeType || jQuery.isWindow(obj)) return false;
        try {
            if (obj.constructor &&
                !obj.constructor.prototype.hasOwnProperty("isPrototypeOf")) {
                return false;
            }
        } catch (e) {
            return false;
        }

        var key, ownLast = ej.support.isOwnLast;
        for (key in obj) {
            if (ownLast) break;
        }

        return key === undefined || obj.hasOwnProperty(key);
    };
    var getValueFn = false;
    ej.util.valueFunction = function (prop) {
        return function (value, getObservable) {
            var val = ej.getObject(prop, this.model);

            if (getValueFn === false)
                getValueFn = ej.getObject("observables.getValue", ej.widget);

            if (value === undefined) {
                if (!ej.isNullOrUndefined(getValueFn)) {
                    return getValueFn(val, getObservable);
                }
                return typeof val === "function" ? val.call(this) : val;
            }

            if (typeof val === "function") {
                this["ob.values"][prop] = value;
                val.call(this, value);
            }
            else
                ej.createObject(prop, value, this.model);
        }
    };
    ej.util.getVal = function (val) {
        if (typeof val === "function")
            return val();
        return val;
    };
    ej.support = {
        isOwnLast: function () {
            var fn = function () { this.a = 1; };
            fn.prototype.b = 1;

            for (var p in new fn()) {
                return p === "b";
            }
        }(),
        outerHTML: function () {
            return document.createElement("div").outerHTML !== undefined;
        }()
    };

    var throwError = ej.throwError = function (er) {
        try {
            throw new Error(er);
        } catch (e) {
            throw e.message + "\n" + e.stack;
        }
    };

    ej.getRandomValue = function (min, max) {
        if (min === undefined || max === undefined)
            return ej.throwError("Min and Max values are required for generating a random number");

        var rand;
        if ("crypto" in window && "getRandomValues" in crypto) {
            var arr = new Uint16Array(1);
            window.crypto.getRandomValues(arr);
            rand = arr[0] % (max - min) + min;
        }
        else rand = Math.random() * (max - min) + min;
        return rand | 0;
    }

    ej.extensions = {};
    ej.extensions.modelGUID = "{0B1051BA-1CCB-42C2-A3B5-635389B92A50}";
})(window.jQuery, window.Syncfusion);
(function () {
    $.fn.addEleAttrs = function (json) {
        var $this = $(this);
        $.each(json, function (i, attr) {
            if (attr && attr.specified) {
                $this.attr(attr.name, attr.value);
            }
        });

    };
    $.fn.removeEleAttrs = function (regex) {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && regex.test(attr.name)) {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.fn.attrNotStartsWith = function (regex) {
        var proxy = this;
        var attributes = [], attrs;
        this.each(function () {
            attrs = $(this.attributes).clone();
        });
        for (i = 0; i < attrs.length; i++) {
            if (attrs[i] && attrs[i].specified && regex.test(attrs[i].name)) {
                continue
            }
            else
                attributes.push(attrs[i])
        }
        return attributes;

    }
    $.fn.removeEleEmptyAttrs = function () {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && attr.value === "") {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.extend($.support, {
        has3d: ej.addPrefix('perspective') in ej.styles,
        hasTouch: 'ontouchstart' in window,
        hasPointer: navigator.msPointerEnabled,
        hasTransform: ej.userAgent() !== false,
        pushstate: "pushState" in history &&
        "replaceState" in history,
        hasTransition: ej.addPrefix('transition') in ej.styles
    });
    //Ensuring elements having attribute starts with 'ejm-' 
    $.extend($.expr[':'], {
        attrNotStartsWith: function (element, index, match) {
            var i, attrs = element.attributes;
            for (i = 0; i < attrs.length; i++) {
                if (attrs[i].nodeName.indexOf(match[3]) === 0) {
                    return false;
                }
            }
            return true;
        }
    });
    //addBack() is supported from Jquery >1.8 and andSelf() supports later version< 1.8. support for both the method is provided by extending the JQuery function.
    var oldSelf = $.fn.andSelf || $.fn.addBack;
    $.fn.andSelf = $.fn.addBack = function () {
        return oldSelf.apply(this, arguments);
    };
})();;
;
/**
* @fileOverview Plugin to style the Html Div elements
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, undefined) {

    ej.widget("ejSplitter", "ej.Splitter", {

        element: null,

        model: null,
        validTags: ["div", "span"],
        _rootCSS: "e-splitter",
        _setFirst: false,
        angular: {
            terminal: false
        },

        defaults: {

            cssClass: "",

            orientation: "horizontal",

            enableAnimation: true,

            properties: [],

            height: null,

            width: null,

            // EnableAutoResize is a deprecated API, we can achieve this requirement by isResponsive property
            enableAutoResize: false,

            isResponsive: false,

            enableRTL: false,
			
			allowKeyboardNavigation: true,

            htmlAttributes: {},

            expanderTemplate: null,

            animationSpeed: 300,

            beforeExpandCollapse: null,
			
			clickOnExpander: null,

            expandCollapse: null,

            resize: null,

            create: null,

            destroy: null
        },

        dataTypes: {
            cssClass: "string",
            orientation: "enum",
            properties: "data",
            enableAutoResize: "boolean",
            expanderTemplate: "string",
            isResponsive: "boolean",
            enableRTL: "boolean",
			allowKeyboardNavigation: "boolean",
            animationSpeed: "number",
            enableAnimation: "boolean",
            htmlAttributes: "data",
        },


        _init: function () {
            this._initialize();
            this._render();
            if (this.model.isResponsive || this.model.enableAutoResize)
                this._wireEvents(true);
            else
                this._wireEvents(false);
        },

        _setModel: function (options) {
            var option;
            for (option in options) {
                switch (option) {
                    case "cssClass": this._changeSkin(options[option]); break;
                    case "enableAutoResize": this._windowResizing(options[option]); break;
                    case "isResponsive": this._windowResizing(options[option]); break;
                    case "enableRTL": this._rtl(options[option]); break;
                    case "htmlAttributes": this._addAttr(options[option]); break;
                    case "orientation": this._refreshSplitter("orientation", options[option]); break;
                    case "properties": this._refreshSplitter("properties", options[option]); break;
                    case "width": this.model.width = options[option]; this._setHeightWidth(); break;
                    case "height": this.model.height = options[option]; this._setHeightWidth(); break;
                }
            }
        },

        refresh: function () {
            this._setPanesSize();
            this._getPanesPercent();
        },

        collapse: function (paneIndex) {
            this._clickArrow(paneIndex, true, true);
        },

        expand: function (paneIndex) {
            this._clickArrow(paneIndex, false, true);
        },

        _clickArrow: function (index, bool, canClick) {
            if (this._inMovement || index < 0 || index > this.panes.length || this.panes.length <= 1) return false;
            var arrow, cls = bool ? "e-collapse" : "e-expand", splitbars = this.element.children(".e-splitbar:not(.e-shadowbar)");
            if(ej.isNullOrUndefined(this.model.expanderTemplate)){
			if (index == splitbars.length) arrow = this._clickArrow(index - 1, !bool, false);
            else arrow = $(splitbars[index]).children("." + cls);
			}
			else{
			arrow = $(splitbars[index]).children(".e-splitter-"+this.model.orientation.substr(0, 1)+"-template");
			if(bool)
			this._collapseArrowClick(this.templateargs);
			else
			this._expandArrowClick(this.templateargs);
			}
			if(!ej.isNullOrUndefined(this.model.expanderTemplate)) this._templateIconPositioning(true);
            if (canClick) (arrow.css("display") != "none" || !ej.isNullOrUndefined(this.model.expanderTemplate)) && arrow.mouseup();
            else return arrow;
        },


        addItem: function (content, property, index) {
            var paneCount = this.panes.length;
            index = this._getNumber(index);
			 var totalSize = this.element[this.containerCss]();
            if (ej.isNullOrUndefined(index)) index = paneCount;
            if (index < 0 || index > paneCount) return "";
            var property = this._getPaneProperty(property), paneDiv, paneDivSize, requiredSize;
            property = this._checkMinMaxSize(property);
            paneDiv = ej.buildTag("div.e-pane e-" + this.model.orientation.substr(0, 1) + "-pane");
            this.element.append(paneDiv[this.containerCss](property.paneSize));
            paneDivSize = property.paneSize = paneDiv[this.containerCss]();
			 if(paneCount==0) this.panes.push(paneDiv);	
            paneDiv.remove();
            var start = index, end = (paneCount>0)?paneCount:this.panes.length, i, j, insert, before, direction = 2, getters = {}, taken = 0, canInsert = false;
            requiredSize = paneDivSize + this._bar;

            for (j = 0; j < direction; j++) {
                for (i = start; i < end; i++) {
                    var _paneSize = $(this.panes[i])[this.containerCss]();
					 var minSize=(!ej.isNullOrUndefined(this.model.properties[i]))?(this.model.properties[i].minSize): property.minSize;
                    var availableSpace = _paneSize - minSize;
                    if (availableSpace >= requiredSize - taken) {
                        getters[i] = _paneSize - (requiredSize - taken);
                        canInsert = true;
                        break;
                    }
					else if((paneCount==0)&&(availableSpace>=0)){
						  getters[i] = minSize;
                        taken += availableSpace;
						canInsert=true;
					}
                    else if (availableSpace > 0) {
                        getters[i] = minSize;
                        taken += availableSpace;
                    }
                }
                if (canInsert) break;
                else end = start, start = 0;
            }
            if (!canInsert) return "";
            for (var pos in getters)
                $(this.panes[pos])[this.containerCss](getters[pos]);
			if(paneCount<=0) paneDiv.append($(this.panes[index]));
			else{
            if (index == paneCount) {
                insert = "insertBefore", before = 1;
                paneDiv.insertAfter($(this.panes[index - 1]));
            }
            else {
                insert = "insertAfter", before = 0;
                paneDiv.insertBefore($(this.panes[index]));
            }
			 }
            this.model.properties.splice(index, 0, property);
			 if(paneCount==0)this.element.append(paneDiv[this.containerCss](totalSize));			
			 if(paneCount>0){
            this.panes.splice(index, 0, paneDiv);
            var splitBar = this._createSplitBar(index - before);
            splitBar[insert](paneDiv);
			 }
            paneDiv.append(content);
            this._updateModel();
            return paneDiv;
        },


        removeItem: function (index) {
            var paneCount = this.panes.length - 1;
            index = this._getNumber(index);
            if (ej.isNullOrUndefined(index)) index = paneCount;
            if (index < 0 || index > paneCount || paneCount < 0) return null;
            var targetPane, nextPane, splitbars, removedSize;
            targetPane = $(this.panes[index]);
            removedSize = targetPane[this.containerCss]() + this._bar;
            targetPane.remove();
            splitbars = this.element.children(".e-splitbar:not(.e-shadowbar)");
            if (index == paneCount) {
                nextPane = $(this.panes[index - 1]);
                $(splitbars[index - 1]).remove();
            }
            else {
                nextPane = $(this.panes[index + 1]);
                $(splitbars[index]).remove();
            }
            nextPane[this.containerCss](nextPane[this.containerCss]() + removedSize);
            this._removeArrays(index);
            this._updateModel();
        },
        _checkMinMaxSize: function (property) {
            if ((!ej.isNullOrUndefined(property.minSize))&&(property.paneSize < property.minSize))
                property.paneSize = property.minSize;
            if ((!ej.isNullOrUndefined(property.maxSize))&&(property.paneSize > property.maxSize))
                property.paneSize = property.maxSize;
            return property;
        },

        _removeArrays: function (index) {
            this.model.properties.splice(index, 1);
            this.panes.splice(index, 1);
            this.oldPaneSize.splice(index, 1);
            this.oldPanePercent.splice(index, 1);
            this._sizePercent.splice(index, 1);
        },

        _getNumber: function (value) {
            value = parseFloat(value);
            return isNaN(value) ? null : value;
        },

        _updateModel: function () {
            for (var i = 0; i < this.panes.length; i++)
                this.model.properties[i].paneSize = $(this.panes[i])[this.containerCss]();
            this._getPanesPercent();
        },

        _getPaneProperty: function (property) {
            var _default = { paneSize: 10, minSize: 10, maxSize: null, collapsible: true, resizable: true, expandable: true };
            return $.extend(_default, property);
        },

        _changeSkin: function (skin) {
            this.element.removeClass(this.model.cssClass).addClass(skin);
        },

        _windowResizing: function (boolean) {
            if (boolean) this._wireEvents(boolean);
            else this._unWireEvents();
        },

        _refreshSplitter:function(key,value){
            this._unWireEvents();
            this._refreshDestroy();
            this.model[key] = value;
            this._init();
        },

		_destroy: function() {
			this.element.removeClass("e-splitter");
			this._refreshDestroy();
			this._unWireEvents();
		},

        _refreshDestroy: function () {
            this.element.removeClass("e-widget e-box e-rtl" + this.model.cssClass + " e-" + this.model.orientation);
            this.element.children(".e-splitbar").remove();
            this.element.children(".e-pane").removeClass("e-pane e-" + this.model.orientation.substr(0, 1) + "-pane").height("").width("");
        },

        _initialize: function () {
            this.panes = [];
            this.oldPaneSize = [];
            this.oldPanePercent = [];
            this._initialPropertiesValue = [];
            this._updateHeightWidth = false;
            this.shadowBar = null;
            this._inMovement = false;
            this.containerCss = this.model.orientation == "horizontal" ? "width" : "height";
            this.displayCss = this.model.orientation == "horizontal" ? "left" : "top";
            this.borderCss = this.model.orientation == "horizontal" ? "right" : "bottom";
            this._bar = 9;      // For the center splitbar size
        },

        _render: function () {
            this.element.addClass("e-widget e-box " + this.model.cssClass + " e-" + this.model.orientation).attr("data-role", "splitter");
            var i, j, target = this.element[0];
            for (i = 0, j = 0; i < target.children.length; i++) {
                $(target.children[i]).addClass("e-pane");
                this.panes.push(target.children[i]);
            }
            this._setPanesProperty();
            this._insertSplitBar();
            this._setDimentions();
			if (!ej.isNullOrUndefined(this.model.expanderTemplate))
			    this.element.find(".e-splitter-" + this.model.orientation.substr(0, 1) +"-template").css("z-index",ej.getMaxZindex()+1);
            this._setPanesSize();
            this._getPanesPercent();
            this._addAttr(this.model.htmlAttributes);
            this._checkProperties();
            this.element.find(".e-pane").addClass("e-" + this.model.orientation.substr(0, 1) + "-pane");
			if(this.model.isResponsive){
				if (isNaN(this.model.height) && (this.model.height.indexOf("%") > 0))
					this.element.css("height",this.model.height);
				if (isNaN(this.model.width) && (this.model.width.indexOf("%") > 0))
					this.element.css("width",this.model.width );
			}
        },
		_templateClick:function(event){
			var args = this.templateargs={
					cancel: false,
					targetElement: $(event.target),
					event: event.type,
					model: this.model,
					currentTarget: $(event.currentTarget)
				}
			this._trigger("clickOnExpander", args);
		},
		_templateIconPositioning:function(bool){
			var proxy = this;
			if(ej.browserInfo().name=="webkit" && bool){
		        proxy.element.find(".e-splitter-" + proxy.model.orientation.substr(0, 1) + "-template").css("display", "none")
		        setTimeout(function (e) {
		            proxy.element.find(".e-splitter-" + proxy.model.orientation.substr(0, 1) + "-template").css("display", "block");
		        }, proxy._isMouseMove ? 10 : proxy.model.animationSpeed);
		        proxy._isMouseMove = false;
		    }
		    if (!bool)
		        setTimeout(function (e) {
				proxy.element.find(".e-splitter-" + proxy.model.orientation.substr(0, 1) +"-template").css("display", "inline-block");
			}, 100);
		},
        _setPanesProperty: function () {
            for (var p = 0; p < this.panes.length; p++) {
                if (this.model.properties[p] != undefined) {
                    this.model.properties[p].paneSize = this.model.properties[p].paneSize == undefined ? "0px" : this.model.properties[p].paneSize;
                    this.model.properties[p].minSize = isNaN(parseFloat(this.model.properties[p].minSize)) ? 10 : parseFloat(this.model.properties[p].minSize);
                    this.model.properties[p].maxSize = isNaN(parseFloat(this.model.properties[p].maxSize)) ? null : parseFloat(this.model.properties[p].maxSize);
                    this.model.properties[p].collapsible = this.model.properties[p].collapsible != false ? true : false;
                    this.model.properties[p].resizable = this.model.properties[p].resizable != false ? true : false;
                    this.model.properties[p].expandable = this.model.properties[p].expandable != false ? true : false;
                }
                else this.model.properties.push({ paneSize: "0px", minSize: 10, maxSize: null, collapsible: true, resizable: true, expandable: true });
                this._initialPropertiesValue[p] = this.model.properties[p].paneSize;
            }
        },
        _addAttr: function (htmlAttr) {
            var proxy = this;
            $.map(htmlAttr, function (value, key) {
                if (key == "class") proxy.element.addClass(value);
                else proxy.element.attr(key, value)
            });
        },


        _insertSplitBar: function () {
            if (this.panes.length > 1) {
                var i, splitBar;
                for (i = 0; i < this.panes.length - 1; i++) {
                    splitBar = this._createSplitBar(i);
                    splitBar.insertAfter(this.panes[i]);
                }
            }
        },

        _createSplitBar: function (i) {
            var orient = this.model.orientation.substr(0, 1), arrow1, arrow2, arrow3, splitBar, accessible = false;
            splitBar = ej.buildTag("span.e-box e-splitbar e-split-divider e-" + orient + "-bar").attr("aria-expanded", true);
            ej.browserInfo().name == "msie" && splitBar.addClass("e-pinch");
			 if (!ej.isNullOrUndefined(this.model.expanderTemplate)) {
                var splitter = document.getElementsByClassName("e-split-divider")[0], splitterSpan = document.createElement("span");
                $(splitterSpan).append(this.model.expanderTemplate);
                $(splitterSpan).attr("class", "e-splitter-" + this.model.orientation.substr(0, 1) + "-template e-resize");
				$(splitterSpan).on( (ej.isTouchDevice())? 'tap' : 'click' , $.proxy(this._templateClick, this));
				splitBar.append(splitterSpan);
				this._templateIconPositioning(false);
            }
			else{
            arrow1 = ej.buildTag("span.e-icon e-collapse e-" + orient + "-arrow " + ((orient == "h") ? "e-arrow-sans-left" :"e-arrow-sans-up"));
            splitBar.append(arrow1);
            arrow3 = ej.buildTag("span.e-activebar e-" + orient + "-arrow ");
            splitBar.append(arrow3);
            arrow2 = ej.buildTag("span.e-icon e-expand e-" + orient + "-arrow " + ((orient == "h") ? "e-arrow-sans-right" :"e-arrow-sans-down"));
            splitBar.append(arrow2);
            accessible = true;
            this._on(arrow1, (ej.isDevice()) ? "tap" : "mouseup", this._collapseArrowClick);
			this._on(arrow2, (ej.isDevice()) ? "tap" : "mouseup", this._expandArrowClick);
            if (!this.model.properties[i].collapsible)
                arrow1.css("display", "none");
		   if(!this.model.properties[i].expandable)
			   arrow2.css("display", "none");
            if (this.model.properties[i + 1].collapsible)
                arrow2.css("display", "block");
		   }
            if (this.model.properties[i].resizable && this.model.properties[i + 1].resizable) {
                splitBar.addClass("e-resize").removeClass("e-icon-hide");
                accessible = true;
                this._on(splitBar, ej.eventType.mouseDown, this._mouseDownOnDivider);
                if (ej.isNullOrUndefined(this.model.expanderTemplate)) this._on(arrow3, ej.eventType.mouseDown, this._mouseDownOnDivider);
            }
            if (accessible) {
                splitBar.attr({ "role": "separator", "tabindex": "0" });
                this._on(splitBar, "focus focusout", this._focusOnDivider);
            }
            else splitBar.attr({ "role": "presentation" });
            return splitBar;
        },
        _getTemplatedString: function (list) {
            var str = this.model.expanderTemplate, start = str.indexOf("${"), end = str.indexOf("}");
            while (start != -1 && end != -1) {
                var content = str.substring(start, end + 1);
            }
            return content;
        },
        _getPanesPercent: function () {
            this._sizePercent = [];
            var size = this.element[this.containerCss](), outerSize = size - ((this.panes.length - 1) * this._bar), i;
            for (i = 0; i < this.panes.length; i++) {
                if (!$(this.panes[i]).hasClass("collapsed"))
                    this.oldPaneSize[i] = $(this.panes[i])[this.containerCss]();
                this.oldPanePercent[i] = this._convertToPercent(outerSize, this.oldPaneSize[i]);
                this._sizePercent.push(this._convertToPercent(outerSize, $(this.panes[i])[this.containerCss]()));
            }
        },

        _setDimentions: function () {
			var parentObj = this._getParentObj(),_width = parseInt(this.model.width), _height = parseInt(this.model.height);
			if (isNaN(this.model.width) && (this.model.width.indexOf("%") > 0))
                _width = (this.model.isResponsive) ? this._convertToPixel(parentObj.innerWidth(), _width):this.model.width;
            if (isNaN(this.model.height) && (this.model.height.indexOf("%") > 0))
                _height = (this.model.isResponsive) ? this._convertToPixel(parentObj.innerHeight(), _height):this.model.height;
            if (this.model.height)
                this.element.css("height",_height);
            if (this.model.width)
                this.element.css("width",_width );
        },

        _setHeightWidth: function () {
            this._updateHeightWidth = true;
   		    this._setDimentions();
            this._setPanesSize();
            this._getPanesPercent();
        },

         _getParentObj: function () {
            return this.element.parent();
        },
        _checkProperties: function () {
            if (this.model.enableRTL) this._rtl(this.model.enableRTL);
            this._prevSize = this.element[this.containerCss]();
        },
        _getExactInnerWidth: function () {
            var browser = ej.browserInfo(), exactInnerWidth;
            if (browser.name == "msie") {
                if (browser.version == 8 || browser.version == 9)
                    exactInnerWidth = $(this.element)[this.containerCss]();
                else
                    exactInnerWidth = parseFloat(window.getComputedStyle(this.element[0])[this.containerCss]);
            }
            else
                exactInnerWidth = parseFloat(window.getComputedStyle(this.element[0])[this.containerCss])
                                 - (parseFloat(this.element.css("border-" + this.displayCss + "-width")) +
                                     parseFloat(this.element.css("border-" + this.borderCss + "-width")) +
                                     parseFloat(this.element.css("padding-" + this.displayCss)) +
                                     parseFloat(this.element.css("padding-" + this.borderCss)));
            return exactInnerWidth;
        },

        _rtl: function (boolean) {
            if (boolean) this.element.addClass("e-rtl");
            else this.element.removeClass("e-rtl");
        },

        _setPanesSize: function () {
            var attr = this.containerCss,
            zeroPanes = 0,
            totalPaneSize = 0,
            totalSize = this.element[attr](),
            remainZero = false,
            bar = this._bar=($(this.element).find(">.e-splitbar").length>0)?parseFloat($(this.element).find(">.e-splitbar").css(attr)):this._bar,
            zerothPanes = [],
            panLength, j, paneCount = this.panes.length;

            if (paneCount > 1) {
                for (j = 0; j < paneCount ; j++) {
                    $(this.panes[j]).css(attr, (this._updateHeightWidth == true) ? this._initialPropertiesValue[j] : this.model.properties[j].paneSize);
                    this._updateHeightWidth = false;
                    bar = (j == paneCount - 1) ? 0 : bar;
                    panLength = parseFloat($(this.panes[j])[attr]());
                    if(!ej.isNullOrUndefined(this.model.properties[j].maxSize)) panLength = panLength > this.model.properties[j].maxSize ? this.model.properties[j].maxSize : panLength;
                    $(this.panes[j]).css(attr, panLength);
                    if (panLength <= 0) {
                        zeroPanes++;
                        zerothPanes.push(j);
                        totalPaneSize += bar;
                    }
                    else {
                        if (remainZero) {
                            $(this.panes[j]).css(attr, 0);
                            totalPaneSize += panLength + bar;
                            this.model.properties[j].paneSize = 0;
                        }
                        else {
                            totalPaneSize += panLength + bar;
                            if (totalPaneSize > totalSize) {
                                var currPane = totalPaneSize - totalSize + bar,
                                remainDivider = paneCount - j - 1;
                                currPane += remainDivider * bar;
                                $(this.panes[j]).css(attr, currPane);
                                remainZero = true;
                                totalPaneSize += currPane + bar;
                            }
                            this.model.properties[j].paneSize = panLength;
                        }
                    }
                }
            }
            else if (paneCount == 1) {
                $(this.panes[0]).css(attr, "100%");
                totalPaneSize = totalSize;
            }

            if (paneCount > 1 && totalPaneSize != totalSize) {
			     var remainingSize, lastPane = $(this.panes[paneCount - 1]);
                if (totalPaneSize > totalSize) {
                    remainingSize = totalPaneSize - totalSize;
                    lastPane.css(attr, remainingSize);
                }
                else if (totalPaneSize < totalSize) {
                    remainingSize = totalSize - totalPaneSize;
                    if (zeroPanes > 0) {
                        var z, avgWid = parseFloat(remainingSize / zeroPanes);
                        for (z = 0; z < zeroPanes ; z++) {
                            $(this.panes[zerothPanes[z]]).css(attr, avgWid);
                            this.model.properties[zerothPanes[z]].paneSize = avgWid;
                        }
                    }
                    else {
                        for(var i = paneCount; i > 0; i--){
                            if(ej.isNullOrUndefined(this.model.properties[i - 1].maxSize)){ lastPane = $(this.panes[i - 1]); break;	}
                        }
                        lastPane.css(attr, parseFloat(lastPane[attr]() + remainingSize));
                        this.model.properties[paneCount - 1].paneSize = lastPane[attr]();
                    }
                }
            }
            if (paneCount > 1) this._checkPaneSize();
        },

        _getUnit: function (str) {
            if (str == "px") return "px";
            else if (str == "pt") return "pt";
            else if (str.substr(1) == "%") return "%";
            else return "px";
        },

        _getNormalValue: function (position) {
            var currentLOB, currentLOBPercent, totalValue, currentValue;
            if (this.model.orientation == "vertical") {
                currentLOB = position.y - this.element.offset().top;
                currentLOBPercent = currentLOB / this.element.outerHeight();
                totalValue = this.element.height();
            }
            else {
                currentLOB = position.x - this.element.offset().left;
                currentLOBPercent = currentLOB / this.element.outerWidth();
                totalValue = this.element.width();
            }
            if (currentLOBPercent > 1) {
                currentLOBPercent = 1;
            }
            if (currentLOBPercent < 0) {
                currentLOBPercent = 0;
            }
            currentValue = currentLOBPercent * totalValue;
            return this._trimValue(currentValue);
        },

        _trimValue: function (value) {
            var step, stepModValue, correctedValue;
            step = 1;
            stepModValue = (value) % step;
            correctedValue = value - stepModValue;
            if (Math.abs(stepModValue) * 2 >= step)
                correctedValue += (stepModValue > 0) ? step : (-step);
            return parseFloat(correctedValue.toFixed(5));
        },

        _getSplitbarIndex: function () {
            return this.element.children(".e-splitbar:not(.e-shadowbar)").index(this.currentSplitBar);
        },

        _paneResize: function () {
            if (this.shadowBar == null) return false;
            this.currentSplitBar = this.shadowBar.next();
            var newPosition, prevPane, nextPane, prevPaneIndex, nextPaneIndex, index = this._getSplitbarIndex();
            prevPane = this.shadowBar.prev(), nextPane = this.currentSplitBar.next();
            prevPaneIndex = index, nextPaneIndex = index + 1;
            newPosition = this.shadowBar.offset()[this.displayCss];
            newPosition = newPosition - this.currentSplitBar.offset()[this.displayCss];
            $(prevPane).css(this.containerCss, newPosition + $(prevPane)[this.containerCss]() + "px");
            $(nextPane).css(this.containerCss, $(nextPane)[this.containerCss]() - newPosition + "px");
            this.oldPaneSize[prevPaneIndex] = $(prevPane)[this.containerCss]();
            this.oldPaneSize[nextPaneIndex] = $(nextPane)[this.containerCss]();
            this.shadowBar.remove();
            this._checkPaneSize();
            var prevObj = { item: prevPane, index: prevPaneIndex, size: this.oldPaneSize[prevPaneIndex] };
            var nextObj = { item: nextPane, index: nextPaneIndex, size: this.oldPaneSize[nextPaneIndex] };
            this._updateModelValue(prevObj, nextObj);
            this._trigger("resize", {
                prevPane: prevObj,
                nextPane: nextObj,
                splitbarIndex: index
            });
        },

        _checkPaneSize: function () {
            var total = 0, len, i, splitterLen, paneCount = this.panes.length;
            for (i = 0; i < paneCount; i++) {
                len = this.containerCss=='width' ? $(this.panes[i])['outerWidth']() :$(this.panes[i])['outerHeight']();
                total += len + this._bar;
            }
            total -= this._bar;
            splitterLen = this._getExactInnerWidth();
            if (total != splitterLen) {
                var remain = splitterLen - total;
                var last = $(this.panes[paneCount - 1])[this.containerCss]();
                if (last == 0) {
                    for (i = paneCount - 1; i >= 0; i--) {
                        if ($(this.panes[i]).hasClass("expanded") && !$(this.panes[i]).hasClass("collapsed")) {
                            last = $(this.panes[i])[this.containerCss]();
                            $(this.panes[i]).css(this.containerCss, parseFloat(last + remain));
                            break;
                        }
                    }
                }
                else
                    $(this.panes[paneCount - 1]).css(this.containerCss, parseFloat(last + remain));
            }
        },

        _maxminDraggableRange: function (shadowbarPos) {
            var prevPane, nextPane, prevPaneSize, nextPaneSize, splitbarPosition, prevPaneRange, nextPaneRange,
                prevPaneIndex, nextPaneIndex, PaneMax1, PaneMax2, PaneMin1, PaneMin2, index;
            prevPane = this.shadowBar.prev();
            this.currentSplitBar = this.shadowBar.next();
            nextPane = this.currentSplitBar.next();
            prevPaneSize = prevPane[this.containerCss]();
            nextPaneSize = nextPane[this.containerCss]();
            splitbarPosition = this.displayCss == "left" ? this.currentSplitBar[0].offsetLeft : this.currentSplitBar[0].offsetTop;
            prevPaneRange = splitbarPosition - prevPaneSize;
            nextPaneRange = nextPaneSize + splitbarPosition;
            index = this._getSplitbarIndex();
            prevPaneIndex = index;
            nextPaneIndex = index + 1;
            PaneMax1 = this.model.properties[prevPaneIndex].maxSize;
            PaneMax2 = this.model.properties[nextPaneIndex].maxSize;
            PaneMax1 = PaneMax1 != null ? parseInt(PaneMax1, 10) : null;
            PaneMax2 = PaneMax2 != null ? parseInt(PaneMax2, 10) : null;
            this.model.properties[prevPaneIndex].minSize = parseInt(this.model.properties[prevPaneIndex].minSize, 10);
            this.model.properties[nextPaneIndex].minSize = parseInt(this.model.properties[nextPaneIndex].minSize, 10);
            PaneMin1 = this.model.properties[prevPaneIndex].minSize;
            PaneMin2 = this.model.properties[nextPaneIndex].minSize;
            this.shadowBar.removeClass("e-end-indicaton");
            if (shadowbarPos > nextPaneRange - PaneMin2) {
                this.resizedPosition = nextPaneRange - PaneMin2;
                this.shadowBar.addClass("e-end-indicaton");
            }
            else if (shadowbarPos < prevPaneRange + PaneMin1) {
                this.resizedPosition = prevPaneRange + PaneMin1;
                this.shadowBar.addClass("e-end-indicaton");
            }
            if (PaneMax1 != null) {
                if (shadowbarPos > prevPaneRange + PaneMax1) {
                    this.resizedPosition = prevPaneRange + PaneMax1;
                    this.shadowBar.addClass("e-end-indicaton");
                }
            }
            else if (PaneMax2 != null) {
                if (shadowbarPos < nextPaneRange - PaneMax2) {
                    this.resizedPosition = nextPaneRange - PaneMax2;
                    this.shadowBar.addClass("e-end-indicaton");
                }
            }
        },

        _collapseArrowClick: function (event) {
            if (this.shadowBar != null) return;
            var $target = (!ej.isNullOrUndefined(event.target)) ? $(event.target): $(event.currentTarget);
            this._inMovement = true;
            this.currentSplitBar = $target.parent();
            var currBarNo, prevPane, nextPane, prevPaneIndex, nextPaneIndex, prevPaneSize, nextPaneSize, properties = {};
            var paneCount = this.panes.length;
            currBarNo = this._getSplitbarIndex();
            prevPane = this.currentSplitBar.prev();
            nextPane = this.currentSplitBar.next();
            prevPaneIndex = currBarNo;
            nextPaneIndex = currBarNo + 1;
            prevPaneSize = prevPane[this.containerCss]();
            nextPaneSize = nextPane[this.containerCss]();
            var proxy = this, collapsed, expanded;
            collapsed = { item: prevPane, index: prevPaneIndex, size: prevPaneSize };
            expanded = { item: nextPane, index: nextPaneIndex, size: nextPaneSize };
            if (this._raiseEvent("beforeExpandCollapse", collapsed, expanded, currBarNo, 'beforeCollapse'))
                return false;
            if (!nextPane.hasClass("collapsed")) {
                this.oldPaneSize[prevPaneIndex] = prevPaneSize;
                prevPane.addClass("collapsed");
                nextPane.addClass("expanded");
                this.currentSplitBar.attr("aria-expanded", false);
                $target.parent().removeClass("e-resize").addClass("e-icon-hide");
                if(ej.isNullOrUndefined(this.model.expanderTemplate)) $target.css("display", "none");
                if (!this.model.properties[nextPaneIndex].collapsible)
                     $($target.siblings()).not('.e-activebar').css("display", "block");
                if (prevPaneIndex != 0) {
                    var preBar = prevPane.prev();
                    preBar.find(".e-expand").css("display", "none");
                    if (!this.model.properties[prevPaneIndex - 1].collapsible && $(prevPane.prev().prev()[0]).hasClass("expanded"))
                        preBar.find(".e-collapse").css("display", "block");
                    preBar.removeClass("e-resize").addClass("e-icon-hide");
                }
                properties[this.containerCss] = 0;
                prevPane.animate(properties, this.model.enableAnimation ? this.model.animationSpeed : 0);
                properties[this.containerCss] = prevPaneSize + nextPaneSize;
                nextPane.animate(properties, this.model.enableAnimation ? this.model.animationSpeed : 0, function () {
                    proxy._raiseEvent("expandCollapse", collapsed, expanded, currBarNo, 'collapsed');
                });
            }
            else {
                if (prevPaneSize < this.oldPaneSize[nextPaneIndex]) {
                    $target.addClass("e-end-indicaton");
                    this._inMovement = false;
                    $(document).on("mouseup", $.proxy(this._mouseUpOnArrow, this));
                    return false;
                }
                else {
                    prevPane.removeClass("expanded");
                    nextPane.removeClass("collapsed");
                    $target.parent().addClass("e-resize").removeClass("e-icon-hide");
                    $($target.siblings()).not('.e-activebar').css("display", "block");
                    if (!this.model.properties[prevPaneIndex].collapsible)
                        $target.css("display", "none");
                    if (nextPaneIndex != paneCount - 1) {
                        var nextBar = nextPane.next();
                        if (!this.model.properties[nextPaneIndex + 1].collapsible)
                            nextBar.find(".e-expand").css("display", "none");
                        nextBar.find(".e-collapse").css("display", "block");
                        if (!nextBar.next().hasClass("collapsed")) {
                            nextBar.addClass("e-resize").removeClass("e-icon-hide");
                            nextBar.attr("aria-expanded", true);
                        }
                    }

                    properties[this.containerCss] = this.oldPaneSize[nextPaneIndex];
                    nextPane.animate(properties, this.model.enableAnimation ? this.model.animationSpeed : 0);
                    properties[this.containerCss] = prevPaneSize - this.oldPaneSize[nextPaneIndex];
                    prevPane.animate(properties, this.model.enableAnimation ? this.model.animationSpeed : 0, function () {
                        proxy._raiseEvent("expandCollapse", collapsed, expanded, currBarNo, 'collapsed');
                    });
                }
            }
        },

        _expandArrowClick: function (event) {
            if (this.shadowBar != null) return;
           var $target = (!ej.isNullOrUndefined(event.target)) ? $(event.target): $(event.currentTarget);
            this._inMovement = true;
            this.currentSplitBar = $target.parent();
            var currBarNo, prevPane, nextPane, prevPaneIndex, nextPaneIndex, prevPaneSize, nextPaneSize, properties = {};
            var paneCount = this.panes.length;
            currBarNo = this._getSplitbarIndex();
            prevPane = this.currentSplitBar.prev();
            nextPane = this.currentSplitBar.next();
            prevPaneIndex = currBarNo;
            nextPaneIndex = currBarNo + 1;
            prevPaneSize = prevPane[this.containerCss]();
            nextPaneSize = nextPane[this.containerCss]();
            var proxy = this, collapsed, expanded;
            collapsed = { item: nextPane, index: nextPaneIndex, size: nextPaneSize };
            expanded = { item: prevPane, index: prevPaneIndex, size: prevPaneSize };

            if (this._raiseEvent("beforeExpandCollapse", collapsed, expanded, currBarNo, 'beforeExpand'))
                return false;
            if (!prevPane.hasClass("collapsed")) {
                this.oldPaneSize[nextPaneIndex] = nextPaneSize;
                prevPane.addClass("expanded");
                nextPane.addClass("collapsed");
                $target.parent().removeClass("e-resize").addClass("e-icon-hide");
                if(ej.isNullOrUndefined(this.model.expanderTemplate)) $target.css("display", "none");
                if (!this.model.properties[prevPaneIndex].collapsible)
                      $($target.siblings()).not('.e-activebar').css("display", "block");
                if (nextPaneIndex != paneCount - 1) {
                    var nextBar = nextPane.next();
                    nextBar.find(".e-collapse").css("display", "none");
                    if (!this.model.properties[nextPaneIndex + 1].collapsible && $(nextPane.next().next()[0]).hasClass("collapsed"))
                        nextBar.find(".e-expand").css("display", "block");
                    nextBar.removeClass("e-resize").addClass("e-icon-hide");
                    nextBar.attr("aria-expanded", false);
                }
                properties[this.containerCss] = prevPaneSize + nextPaneSize;
                prevPane.animate(properties, this.model.enableAnimation ? this.model.animationSpeed : 0);
                properties[this.containerCss] = 0;
                nextPane.animate(properties, this.model.enableAnimation ? this.model.animationSpeed : 0, function () {
                    proxy._raiseEvent("expandCollapse", collapsed, expanded, currBarNo, 'expanded');
                });
            }
            else {
                if (nextPaneSize < this.oldPaneSize[prevPaneIndex]) {
                    $target.addClass("e-end-indicaton");
                    this._inMovement = false;
                    $(document).on("mouseup", $.proxy(this._mouseUpOnArrow, this));
                    return false;
                }
                else {
                    prevPane.removeClass("collapsed");
                    nextPane.removeClass("expanded");
                    this.currentSplitBar.attr("aria-expanded", true);
                    $target.parent().addClass("e-resize").removeClass("e-icon-hide");
                      $($target.siblings()).not('.e-activebar').css("display", "block");
                    if (!this.model.properties[nextPaneIndex].collapsible)
                        $target.css("display", "none");
                    if (prevPaneIndex != 0) {
                        var preBar = prevPane.prev();
                        if (!this.model.properties[currBarNo - 1].collapsible)
                            preBar.find(".e-collapse").css("display", "none");
                        preBar.find(".e-expand").css("display", "block");
                        if (!preBar.prev().hasClass("collapsed")) preBar.addClass("e-resize").removeClass("e-icon-hide");
                    }

                    properties[this.containerCss] = this.oldPaneSize[prevPaneIndex];
                    prevPane.animate(properties, this.model.enableAnimation ? this.model.animationSpeed : 0);
                    properties[this.containerCss] = nextPaneSize - this.oldPaneSize[prevPaneIndex];
                    nextPane.animate(properties, this.model.enableAnimation ? this.model.animationSpeed : 0, function () {
                        proxy._raiseEvent("expandCollapse", collapsed, expanded, currBarNo, 'expanded');
                    });
                }
            }
        },

        _raiseEvent: function (evtName, collapsed, expanded, index, type) {
            if (evtName == "expandCollapse") {
                this._inMovement = false;
                this._updateModelValue(collapsed, expanded);
            }
            return this._trigger(evtName, {
                collapsed: collapsed,
                expanded: expanded,
                splitbarIndex: index,
				action: type
            });

        },

        _updateModelValue: function (collapsed, expanded) {
            this.model.properties[collapsed.index].paneSize = collapsed.item[this.containerCss]();
            this.model.properties[expanded.index].paneSize = expanded.item[this.containerCss]();
            this._getPanesPercent();
        },

        _mouseUpOnArrow: function (event) {
            this.element.find(".e-end-indicaton").removeClass("e-end-indicaton");
            $(document).off("mouseup", $.proxy(this._mouseUpOnArrow, this));
        },

        _keydownOnDivider: function (e) {
            var key = e.keyCode;
            if (key == 37 || key == 38 || key == 39 || key == 40) {
                e.preventDefault();
                var oriTarget = $(e.data.target);
                if (e.ctrlKey) {
                    if (this.shadowBar == null) {
                        this.currentSplitBar = oriTarget;
                        var index = this._getSplitbarIndex();
                        if (this.model.orientation == "vertical") {
                            if (e.keyCode == 38) this.collapse(index);
                            else if (e.keyCode == 40) this.expand(index);
                        }
                        else {
                            if (e.keyCode == 37) this.collapse(index);
                            else if (e.keyCode == 39) this.expand(index);
                        }
                    }
                }
                else if (oriTarget.hasClass("e-resize")) {
                    var target = (this.shadowBar != null) ? this.shadowBar : oriTarget;
                    var offset = target.offset(), location = { pageX: offset.left, pageY: offset.top };
                    $.extend(true, e, location);
                    if ((this.model.orientation == "vertical" && (e.keyCode == 38 || e.keyCode == 40)) ||
                        (this.model.orientation == "horizontal" && (e.keyCode == 37 || e.keyCode == 39))) {
                        if (e.keyCode == 38) e.pageY -= 5;
                        else if (e.keyCode == 40) e.pageY += 5;
                        else if (e.keyCode == 37) e.pageX -= 5;
                        else if (e.keyCode == 39) e.pageX += 5;
                        this._mouseMoveOnDivider(e);
                    }
                }
            }
            else if (key == 13) {
                e.preventDefault();
                this._mouseUpOnDivider();
            }
            else if (key == 27) {
                e.preventDefault();
                if (this.shadowBar != null) this.shadowBar.remove();
                this.shadowBar = null;
                this._mouseUpOnDivider();
                this.element.children(".e-splitbar.e-hover").focusout();
            }
        },

        _focusOnDivider: function (e) {
            if (e.type == "focus") {
                if (!$(e.target).hasClass("e-hover")) {
                    $(e.target).addClass("e-hover");
                    if (this.model.allowKeyboardNavigation)
                        $(document).on("keydown", { target: e.target }, $.proxy(this._keydownOnDivider, this));
                }
            }
            else {
                this.element.children(".e-splitbar.e-hover").removeClass("e-hover");
                this._mouseUpOnDivider();
                $(document).off("keydown", $.proxy(this._keydownOnDivider, this));
            }
        },

        _mouseDownOnDivider: function (event) {
            event.preventDefault();
            var $target;
            ($(event.target).hasClass("e-activebar")) ? $target=$(event.target.parentElement) : (!ej.isNullOrUndefined(this.model.expanderTemplate) && $(event.target).parents(".e-splitbar").length>0) ? $target = $(event.target).parents(".e-splitbar") : $target=$(event.target);
            if ($target.hasClass("e-splitbar") && $target.hasClass("e-resize")) {
                this._overlayElement = ej.buildTag('div.e-pane-overlay');
                if (!$target.hasClass("e-hover")) $target.focus();
                this.element.find(".e-pane").not(".e-splitter").append(this._overlayElement);
                $(document).on(ej.eventType.mouseMove, { target: ($(event.target).hasClass("e-activebar")) ? event.target.parentElement : event.target }, $.proxy(this._mouseMoveOnDivider, this));
                $(document).on(ej.eventType.mouseUp, $.proxy(this._mouseUpOnDivider, this));
                $(document).on("mouseleave", $.proxy(this._mouseUpOnDivider, this));
            }
            else if ($target.hasClass("e-expand") || $target.hasClass("e-collapse")) {
                $target.parent().focus();
            }
        },

        _mouseMoveOnDivider: function (event) {
            var _data = event.data;
            event = event.type == "touchmove" ? event.originalEvent.changedTouches[0] : event;
            this._isMouseMove = true;
            var position = { x: event.pageX, y: event.pageY };
            this.resizedPosition = this._getNormalValue(position);
            if (this.shadowBar == null) {
                var target;
                ($(_data.target).hasClass('e-activebar')) ? target=$(_data.target.parentElement) : (!ej.isNullOrUndefined(this.model.expanderTemplate) && $(event.target).parents(".e-splitbar").length>0) ? target = $(_data.target).parents(".e-splitbar") : target=$(_data.target);
                this.shadowBar = target.clone().addClass("e-shadowbar").removeClass("e-hover").removeClass("e-split-divider").insertBefore(target);
                this.shadowBar.children().remove();
            }
            this._maxminDraggableRange(this.resizedPosition);
            this.shadowBar.css(this.displayCss, this.resizedPosition);
        },

        _mouseUpOnDivider: function (event) {
            this._paneResize();
			if(!ej.isNullOrUndefined(this.model.expanderTemplate)) this._templateIconPositioning(true);
            this.element.find(".e-pane").not(".e-splitter").find(".e-pane-overlay").remove();
            $(document).off(ej.eventType.mouseMove, $.proxy(this._mouseMoveOnDivider, this));
            $(document).off(ej.eventType.mouseUp, $.proxy(this._mouseUpOnDivider, this));
            $(document).off("mouseleave", $.proxy(this._mouseUpOnDivider, this));
            // sets shadowBar null after removing shadowBar element
            this.shadowBar = null;
        },

        _windowResized: function (event) {
            var size = this._getExactInnerWidth();
            if (this._prevSize == size) return false;
            var paneCount = this.panes.length, outerSize = size - ((paneCount - 1) * this._bar), i, val;
            this._prevSize = size;
            for (i = 0; i < paneCount; i++) {
                val = this._convertToPixel(outerSize, this._sizePercent[i]);
                $(this.panes[i]).css(this.containerCss, val + "px");
            }
            for (i = 0; i < this.oldPaneSize.length; i++)
                this.oldPaneSize[i] = this._convertToPixel(outerSize, this.oldPanePercent[i]);
            var last = $(this.panes[this.panes.length - 1])[this.containerCss]();
            if (last == 0) {
                this._checkPaneSize();
            }
        },

        _convertToPercent: function (outer, pane) {
            return (pane * 100) / outer;
        },
        _convertToPixel: function (tot, percent) {
            return parseFloat((tot * percent) / 100);
        },

        _wireEvents: function (boolean) {
            if (boolean) $(window).on('resize', $.proxy(this._windowResized, this));
        },

        _unWireEvents: function () {
            $(window).off('resize', $.proxy(this._windowResized, this));
        }
    });

})(jQuery, Syncfusion);;